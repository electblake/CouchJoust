;       NAM     F000 TEST ROM FOR 'JOUST' INCLUDING AUDITING AND ADJUSTMENTS
;
;       INCLUDE RAMDEF.SRC
;       INCLUDE EQU.SRC
;       INCLUDE MESSEQU.SRC
;       INCLUDE MESSEQU2.SRC

;       SETDP   $A0

        ORG     TSTORG
PWRUPV  JMP     PWRUP
        JMP     ADVSWS                                                          ;;Fixme was: ADVSW$
        JMP     AUTCYC
        JMP     JNAP
        JMP     RAND
        JMP     TEST
        JMP     CYCLE

;*COLOR RAM TABLE
;*
CRTAB   FCB     0       ;0 SPACED OUT
        FCB     $F9     ;1 LASER (SPECIAL)
        FCB     $07     ;2 RED
        FCB     $28     ;3 GREEN
        FCB     $2F     ;4 YELLOW
        FCB     $00     ;5 MESSAGES
        FCB     $A4     ;6 GRAY
        FCB     $15     ;7 TERRAIN
        FCB     $C7     ;8 PURPLE
        FCB     $FF     ;9 WHITE
        FCB     $38     ;A BOMB CYCLER
        FCB     $17     ;B ORANGE
        FCB     $CC     ;C CYCLER
        FCB     $81     ;D TIE1
        FCB     $81     ;E TIE2
        FCB     $2F     ;F TIE3,MONO


;*
;***    POWER UP ROUTINE
;*
PWRUP   ORCC    #$FF    ;NO INTERRUPTS ETC.
        LDS     #HSTK   ;IF AND WHEN WE DECIDE TO USE THE STACK
        CLR     PIA0+1
        CLR     PIA0
        LDA     #$3C    ;SET LED 3 TO 1 (WE'RE MAKING AN F TO BLANK)
        STA     PIA0+1
        CLR     PIA1+1
        LDA     #$C0    ;BITS 6,7 TO OUTPUTS (LEDS)
        STA     PIA1
        LDA     #$3C    ;SET BIT 2 TO 1
        STA     PIA1+1  ;CLEAR CB2 (LED)
        LDA     #$C0    ;CLEAR LEDS
        STA     PIA1    ;SET BITS 0,1
        LDA     #1
        STA     RWCNTL  ;MAKE SURE WE COPY FROM ROM!
        LDX     #CRTAB
        LDY     #CRAM
PWRUP0  LDD     ,X++
        STD     ,Y++
        CMPX    #CRTAB+16
        BLO     PWRUP0
        LDA     #2
        LDY     #PWRUP1
        LDX     #0
        BRA     RAMTST  ;DO A RAM TEST.
PWRUP1  LDY     #PWRUP4
        JMP     ROMTST
PWRUP4  LDA     #$34    ;PUT A ZERO IN THE LED.
        STA     PIA0+1
        STA     PIA1+1
        CLR     PIA1
        LDA     #RAM>>8                                                         ;;Fixme was: LDA  #RAM!>8
        TFR     A,DP
        LDS     #HSTK
        JSR     SCCLR
        LDA     #MSIND  ;INITIAL TESTS INDICATE
        LDX     #$3070
        LDB     #$99
        JSR     OUTPHR
        LDA     #MSALL  ;ALL SYSTEMS GO
        LDX     #$3A90
        LDB     #$99
        JSR     OUTPHR  ;INDICATE OK
        LDY     #CKCMSV ;DELAY TO JUMP INTO GAME.
        LDA     #7
        JMP     DELA1

;*
;*      RAM TEST....Y = PLACE TO RETURN IF NO ERROR
;*      X = SEED TO START WITH
;*      A = ITERATIONS TO MAKE

RAMTST  ORCC    #$3F    ;NO INTERRUPTS DURING TEST
        CLR     RWCNTL  ;SET TO RAM READ
        TFR     A,DP    ;COUNT AT DP.
        TFR     X,D     ;START WITH A PASSED SEED.
RAM2    TFR     D,U     ;SAVE THE SEED
RAM0    LDX     #0      ;MEMORY POINTER
RAM3    COMB            ;DONT ASK
        BITB    #9
        BNE     RAM4
        COMB
        RORA
        RORB
        BRA     RAM6
RAM4    COMB
        BITB    #9
        BNE     RAM5
        RORA
        RORB
        BRA     RAM6
RAM5    LSRA
        RORB
RAM6    STD     ,X++
        EXG     X,D     ;SINCE IRQ RUNS OUT OF RAM, STROKE ROVER
        TSTB
        BNE     RAM6B   ;EVERY 256!
        LDB     #WDATA
        STB     WDOG    ;HAVE A BONE..EVER BEEN BONED.....
        TFR     DP,B    ;CHECK IS NORMAL DIAGS
        CMPB    #$FF    ;FF MEANS FRONT DOOR
        BNE     RAM6C
        LDB     PIA0    ;CHECK FOR ADV.
        BITB    #2
        BEQ     RAM6C   ;NOT PRESSED.
        JMP     ,Y      ;TIME TO RETURN
RAM6C   CLRB            ;RETURN B TO ZERO
RAM6B   EXG     X,D     ;TRADE BACK
        CMPX    #$C000  ;DONE??
        BNE     RAM3    ;NOPE..CONTINUE
;*
        TFR     U,D     ;RESTORE SEED.
        LDX     #0
RAM7    COMB
        BITB    #9
        BNE     RAM8
        COMB
        RORA
        RORB
        BRA     RAM10
RAM8    COMB
        BITB    #9
        BNE     RAM9
        RORA
        RORB
        BRA     RAM10
RAM9    LSRA
        RORB
RAM10   CMPD    ,X++
        BNE     RERROR  ;RAM ERROR!
RAM25   EXG     X,D     ;CHECK FOR END OF PAGE
        TSTB
        BNE     RAM17
        LDB     #WDATA
        STB     WDOG
        TFR     DP,B    ;SEE IF NORMAL RUN
        CMPB    #$FF    ;FRONT DOOR??
        BNE     RAM17C  ;NOPE
        LDB     PIA0    ;CHECK ADV.
        BITB    #2
        BEQ     RAM17C
        JMP     ,Y      ;JUST RETURN (NO ERRORS)
RAM17C  CLRB
RAM17   EXG     X,D     ;TRADE BACK
        CMPX    #$C000  ;DONE??
        BNE     RAM7
        TFR     D,U     ;SHOVE NEW SEED OVER
        TFR     DP,A
        CMPA    #$FF    ;FF INDICATES FRONT DOOR
        BNE     RAM99
        TFR     U,D
        JMP     RAM0    ;DO ANOTHER ITERATION IN THIS TEST.
RAM99   DECA            ;TAKE ONE AWAY
        TFR     A,DP    ;RETURN
        CMPA    #$80    ;ZERO OUT IN AUTO CYCLE???
        BEQ     RAM99S  ;YEP....
        TSTA            ;SET FOR BELOW BRANCH
        TFR     U,D     ;MAKE SEED AND SAVED SEED LOOK ALIKE
        LBNE    RAM0    ;DO ANOTHER ITERATION
RAM99S  LDB     #1      ;SET BACK TO ROM                                        ;;Fixme was: RAM99$
        STB     RWCNTL
        JMP     ,Y      ;RETURN
RERROR  LEAX    -2,X    ;BACK TO ERROR POINT
        EORA    ,X      ;FIND DIFFERENCE.
        EORB    1,X
        TSTA            ;NO DIFFERENCE?
        BNE     RERR2   ;DIFF.
        TSTB
        BNE     RERR2
        LEAX    2,X     ;UNDO THIS BULLSHIT...MAYBE ALPHA BABY.
        BRA     RAM25   ;AND CONTINUE
RERR2   LDU     #$30    ;FIND BANK NUMBER
        EXG     X,D
        CLRB
        EXG     X,D
RERR0   CMPX    #0
        BEQ     RERR1   ;DONE.
        LEAX    -$100,X
        LEAU    $10,U
        CMPU    #$30
        BLS     RERR0
        LDU     #$10
        BRA     RERR0
RERR1   LEAU    1,U
        ASRA
        BCS     RERR5   ;THIS IS THE BIT
        ASRB
        BCS     RERR5
        BRA     RERR1
RERR5   TFR     U,D     ;BRING THE BANK,BIT INTO B
        LDA     #1      ;INDICATE RAM ERROR
        STA     RWCNTL  ;BACK TO THAT JAZZ
        LDS     #RERR6  ;RETURN HERE
        BRA     PULSE   ;PULSE THE LEDS
RERR6   LDA     #RAM>>8                                                         ;;Fixme was: LDA  #RAM!>8
        TFR     A,DP
        TFR     CC,A
        COMA
        LDS     #HSTK   ;SET UP THE STACK
        JSR     SCCLR
        BITA    #$C0    ;INITIAL TEST???
        BNE     RER099  ;NOP
RER098  LDA     #MSIND  ;'INITIAL TESTS INDICATE'
        LDX     #$3070
        LDB     #$22
        JSR     OUTPHR
RER099  LDA     #MSRRM  ;'RAM ERROR '
        LDX     #$4090
        LDB     #$22
        JSR     OUTPHR  ;PRINT THE MESSAGE.
        TFR     U,D
        TFR     B,A
        LDB     #$22
        JSR     OUTBCD
        TFR     CC,A    ;SEE WHICH TEST
        BITA    #$40    ;FIRQ SAYS FRONT DOOR
        BNE     REROR7  ;NOPE
        JMP     FDRET   ;DO THE FRONT DOOR RETURN
REROR7  LDY     #CKCMSV ;OTHERWISE START...TRY AND RUN THE GAME.
        BRA     DELAY

DELAY   LDA     #32
DELA1   LDX     #$5800
DELA2   LEAX    -1,X
        LDB     #WDATA
        STB     WDOG
        CMPX    #0
        BNE     DELA2
        DECA
        BNE     DELA1
        JMP     ,Y      ;RETURN

;*
;*      PULSE......PUT SOME CRAP IN LED'S
;*      LOW HALF OF A IS ERROR CODE...
;*      BOTH HALVES OF B ARE THE RELEVANT DATA.
;*

PULSE   TFR     D,U     ;SAVE A,B
        LDA     #2
        TFR     A,DP
PULSE0  TFR     U,D
        LDY     #PULSE1
        JMP     PSSUB
PULSE1  LDA     #2
        LDY     #PULSE2
        BRA     DELA1
PULSE2  LDY     #PULSE3
        BRA     BLKLED
PULSE3  LDA     #1
        LDY     #PULSE4
        BRA     DELA1
PULSE4  TFR     U,D     ;GET DATA BACK
        TFR     B,A     ;SHIFT B DOWN
        LSRA
        LSRA
        LSRA
        LSRA            ;PROPER HALF
        LDY     #PULSE5
        BRA     PSSUB   ;PULSE IT.
PULSE5  LDA     #2
        LDY     #PULSE6
        BRA     DELA1
PULSE6  LDY     #PULSE7
        BRA     BLKLED
PULSE7  LDA     #1
        LDY     #PULSE8
        BRA     DELA1
PULSE8  TFR     U,D
        TFR     B,A
        LDY     #PULSE9
        BRA     PSSUB
PULSE9  LDA     #2
        LDY     #PULS10
        BRA     DELA1
PULS10  LDY     #PULS11
        BRA     BLKLED
PULS11  LDA     #5
        LDY     #PULS12
        BRA     DELA1
PULS12  TFR     DP,A    ;SEE IF FIRST PASS??
        DECA
        TFR     A,DP
        BNE     PULSE0
        LDY     #PULS95
        BRA     BLKLED  ;BLANK EM.
PULS95  TFR     U,D     ;RESTORE D
        JMP     ,S      ;AND RETURN

BLKLED  LDA     #$3C
        STA     PIA0+1
        INCA
        STA     PIA1+1
        LDA     #$C0
        STA     PIA1
        JMP     ,Y      ;AND RETURN

;*      PSSUB - PUT LOW HALF OF A TO LEDS

PSSUB   TFR     A,B     ;SAVE A COPY.
        RORA            ;BIT 0 - CARRY
        RORA            ;BIT 0 - BIT 7
        RORA            ;BIT 0 - BIT 6
        ANDA    #$C0
        STA     PIA1    ;THOSE BITS OUT.
        LDA     #$34    ;ASSUME ZERO
        BITB    #$4     ;SEE IF 1
        BEQ     PSSUB1  ;NOPE
        LDA     #$3C
PSSUB1  STA     PIA1+1  ;THATS ALL FOR THAT BIT
        LDA     #$34
        BITB    #$8
        BEQ     PSSUB2
        LDA     #$3C
PSSUB2  STA     PIA0+1
        JMP     ,Y      ;AND RETURN

ROMTST  ORCC    #$3F    ;NO INTERRUPTS WHILE THIS RUNS
        LDX     #ROMTAB ;INDEX INTO TABLE
ROM0    CMPX    #ROMEND ;DONE??
        BNE     ROM2    ;BRA= NOPE

ROMDUN  JMP     ,Y      ;ALL ROMS OK...RETURN.

ROM2    LDA     1,X     ;LOOK TO SEE IF PART STUFFED??
        BEQ     ROMBOT  ;NOPE...MOVE TO NEXT
        LDA     ,X      ;GET BASE
        CLRB
        TFR     D,U     ;USE U TO POINT THROUGH
        LDA     #WDATA  ;FOR ROVER
ROM1    ADDB    ,U+     ;ADD A BYTE
        STA     WDOG
        EXG     D,U     ;SEE IF DUN
        CMPA    2,X     ;ARE WE TO NEXT PART
        EXG     D,U     ;CHANGE BACK
        BNE     ROM1    ;NOPE
        CMPB    1,X     ;EXPECTED SUM???
        BNE     ROMERR  ;NOPE....LETS SEND OUT PROBLEM WARNING.
ROMBOT  LEAX    2,X     ;MOVE TO NEXT PART
        BRA     ROM0
ROMERR  LDA     ,X      ;GET THE ADDRESS OF THE BAD PART
        LSRA
        LSRA
        LSRA
        LSRA
        CMPA    #$D     ;ONE OF TOP 3 PARTS??
        BLO     ROMER1  ;NOPE
        SUBA    #4      ;GROUP THEM WITH THE LOWER PARTS
ROMER1  ADDA    #1      ;MAKE ERRORS FROM 1-12
        DAA             ;AND MAKE BCD
        TFR     A,B
        LDA     #2      ;ROM ERROR
        LDS     #RERR3  ;RETURN
        JMP     PULSE   ;AND SEND OUT THE CODE
RERR3   LDA     #RAM>>8                                                         ;;Fixme was: LDA  #RAM!>8
        TFR     A,DP
        LDA     #WDATA
        STA     WDOG
        LDS     #HSTK
        JSR     SCCLR
        TFR     CC,A
        COMA

        STB     XTEMP
        BITA    #$C0    ;INITIAL TEST??
        BNE     RERR95  ;NOP
RERR94  LDA     #MSIND  ;'INITIAL TESTS INDICATE'
        LDX     #$3070
        LDB     #$22
        JSR     OUTPHR
RERR95  LDA     #MSROM  ;'ROM ERROR '
        LDX     #$4090
        LDB     #$22
        JSR     OUTPHR  ;PRINT THE MESSAGE.
        LDA     XTEMP
        BITA    #$F0
        BNE     .1S
        ORA     #$F0
.1S     LDB     #$22
        JSR     OUTBCD

        TFR     CC,B    ;SEE WHERE WE CAME FROM
        BITB    #$40    ;FIRQ SAYS FRONT DOOR
        BNE     ROMER3
        JMP     FDROM
ROMER3  LDY     #CKCMSV ;NOW TRY AND RUN THE GAME
        JMP     DELAY   ;BUT NOT UNTIL A SHORT DELAY.


;*      ROMTAB  - THIS TABLE INDICATES THE BASE OF THE PART, AND THE
;*      RESULTING SUM.  IF SUM=0 THEN PART IS NOT STUFFED.

       IF DEBUG = 0             ;FOR ROM VERSION                                ;;Fixme was: IFE DEBUG
ROMTAB  FCB     $00,$A2 ;0000
        FCB     $10,$A9 ;1000
        FCB     $20,$50 ;2000
        FCB     $30,$FA ;3000
        FCB     $40,$A7 ;4000
        FCB     $50,$BF ;5000
        FCB     $60,$85 ;6000
        FCB     $70,$47 ;7000
        FCB     $80,$51 ;8000
        FCB     $90,$0  ;9000
        FCB     $A0,$0  ;A000
        FCB     $B0,$0  ;B000
        FCB     $C0,$0  ;C000
        FCB     $D0,$3D ;D000
        FCB     $E0,$D5 ;E000
        FCB     $F0,$77 ;F000
ROMEND  FCB     0
        FCB     $11     ;CHECK BYTE (FUDGER) FOR THIS PART ($F000)
;*
      ELSE                      ;FOR DECON DEBUGGING
;*
ROMTAB  FCB     $00,$0  ;0000
        FCB     $10,$0  ;1000
        FCB     $20,$0  ;2000
        FCB     $30,$0  ;3000
        FCB     $40,$0  ;4000
        FCB     $50,$0  ;5000
        FCB     $60,$0  ;6000
        FCB     $70,$0  ;7000
        FCB     $80,$0  ;8000
        FCB     $90,$0  ;9000
        FCB     $A0,$0  ;A000
        FCB     $B0,$0  ;B000
        FCB     $C0,$0  ;C000
        FCB     $D0,$0  ;D000
        FCB     $E0,$0  ;E000
        FCB     $F0,$0  ;F000
ROMEND  FCB     0
        FCB     $0      ;CHECK BYTE (FUDGER) FOR THIS PART ($F000)
       ENDIF

;*
;*      ADVANCE SWITCH
;*

ADVSWS  LDA     #$04    ;MAKE SURE THAT NO ONE INTERRUPTS US                    ;;Fixme was: ADVSW$ (invalid symbol name)
        STA     $C805
        STA     $C807
        STA     $C80D
        STA     $C80F
        LDA     #$FF
        STA     INDIAG
        JSR     INITCM  ;INITIALIZE COLOR MATRIX
        LDA     PIA0    ;CHECK WHICH TYPE OF TEST
        RORA            ;AUTO UP??
        LBCS    BOOK    ;YEP...GO TO BOOKKEEPING
        JSR     SCCLR
        ORCC    #$BF    ;FIRQ ENABLED INDICATES NORMAL DIAGNOSTICS RUNNING.
        LDY     #DAG999
        JMP     BLKLED  ;BLANK THE LEDS
DAG999  LDA     #WDATA
        STA     WDOG
        LDA     PIA0    ;WAIT FOR ADVANCE SWITCH LET GO
        BITA    #2
        BNE     DAG999
        LDY     #DIAG0
        JMP     ROMTST  ;DO THE ROM TEST
DIAG0   LDA     #RAM>>8                                                         ;;Fixme was: LDA  #RAM!>8
        TFR     A,DP
        JSR     SCCLR   ;CLEAR FOR ROMS MESSAGE.
        LDA     #TXROMK
        JSR     TEXT    ;PRINT THE MESSAGE
        LDB     #3
DIG111  LDX     #$7000
DIAG1   LDA     #WDATA
        STA     WDOG
        LDA     PIA0
        BITA    #2
        BNE     DIAG2   ;CONTINUE IF ADVANCE PRESSED.
        LEAX    -1,X
        CMPX    #0
        BNE     DIAG1
        DECB
        BNE     DIG111
DIG11S  LDY     #DIAG2                                                          ;;Fixme was: DIG11$
        LDX     #0
        LDA     #$FF    ;INDICATE FRONT DOOR
        JMP     RAMTST  ;DO THE RAM TEST.
DIAG2   LDA     #1
        STA     RWCNTL
        LDA     #RAM>>8                                                         ;;Fixme was: LDA  #RAM!>8
        TFR     A,DP
        JSR     SCCLR
        LDA     #TXRAMK
        JSR     TEXT    ;PRINT RAM OK MESSAGE
DIAG22  LDA     #WDATA
        STA     WDOG
        LDA     PIA0
        BITA    #2
        BNE     DIAG22  ;HOLD CONTROL UNTIL LET GO.
RAMERJ  LDX     #$9C00  ;RAM ERROR MESSAGE COMES HERE.
DIAG3   CLR     ,X+     ;CLR USABLE MEMORY
        LDB     #WDATA
        STB     WDOG
        CMPX    #HSTK+1
        BNE     DIAG3
        LDD     #$A55A
        STD     HSEED
        STA     INDIAG  ;INDICATE THAT WE'RE DIAGNOSTICS
        BSR     ZLED    ;ZERO IN LED
DIAG4   JSR     AVWAIT  ;WAIT FOR ADVANCE SWITCH.
        JSR     CMTEST  ;TEST CMOS.
        LDA     #TXCMOK
        BCC     DIAG66
        LDB     #$2F    ;INDICATE THAT ITS IN R/W HALF
        CMPX    #CMOS+$100
        BHI     DIAG5   ;IT WAS IN WRITABLE HALF
        LDB     #$1F
DIAG5   LDS     #DIAG55
        LDA     #$3
        JMP     PULSE
DIAG55  LDS     #HSTK
        BSR     ZLED
        LDA     #RAM>>8                                                         ;;Fixme was: LDA  #RAM!>8
        TFR     A,DP
        LDA     #TXCMER
        CMPB    #$1F
        BHI     DIAG66
        LDA     #TXCMDR
DIAG66  JSR     SCCLR
        JSR     TEXT    ;PRINT ONE OF THE TWO MESSAGES.
        JSR     AVWAIT
        CLR     FDTEST  ;INDICATE FRONT DOOR TEST CALLING
        JSR     SNDSRT  ;START THE SOUND TEST
DIAG6   JSR     SNDCYC  ;CYCLE ONE SOUND
        JSR     AVCHK   ;CHECK ADVANCE SWITCH.
        BCC     DIAG6   ;NOT PRESSED, DO ANOTHER SOUND
        LDA     #$3F
        STA     SOUND
        CLRA
        JSR     JNAP
DIAG77  CLRA            ;SILENCE
        STA     SOUND
        JSR     AVWAIT  ;NOW WAIT FOR RELEASE.
        JSR     SWTEST  ;DO A SWITCH TEST.
        JSR     AVWAIT  ;WAIT FOR RELESE
        JSR     CRTEST  ;DO THE COLOR MATRIX TEST
        JSR     AVCHK   ;HOLDING BUTTON??
        BCC     DIAG78  ;NOPE...CONTINUE
        JSR     AVWAIT  ;WAIT FOR LET GO TIME.
DIAG78  BRA     TSTPAT  ;DO SOME TEST PATTERNS  THEN GO TO BOOK.

ZLED    CLR     PIA1    ;ZERO IN LED INDICATES ON LAST TEST OR DUN
        LDA     #$34
        STA     PIA0+1
        INCA
        STA     PIA1+1
        RTS
;*
INITCM  LDX     #CRTAB
        LDY     #PCRAM
ADVS90  LDD     ,X++
        STD     ,Y++
        CMPX    #CRTAB+16
        BLO     ADVS90
        RTS
;*
;***    AUTO CYCLE
;*
AUTCYC  LDA     #$3C    ;MAKE SURE THAT NO ONE INTERRUPTS US
        STA     $C805
        STA     $C807
        STA     $C80D
        STA     $C80F
        LDA     #$3F    ;MAKE LOOK LIKE FRONT DOOR TEST THANX TO MOTOROLA
        TFR     A,CC    ;SET TO AUTOCYCLE NO INTS PLEASE ETC.
        LDA     #$8F    ;FIFTEEN RAM PASSES, IN AUTOCYCLE
        LDX     RAMALS+$600 ;TAKE A BYTE FROM THE RAM TEST
        LEAX    $1234,X ;ADD A STUPID NUMBER TO VARY TEST
        LDY     #AUTO1
        JMP     RAMTST  ;TEST THE RAM
AUTO1   LDY     #AUTO2
        JMP     ROMTST
AUTO2   LDA     #RAM>>8                                                         ;;Fixme was: LDA  #RAM!>8
        TFR     A,DP
        LDS     #HSTK   ;JUST IN CASE
        JSR     CMTEST
        BCC     AUTO4
        LDA     #TXCMDR
        CMPX    #CMOS+$100 ;WRITE PROTECT??
        BLS     AUTO8
        LDA     #TXCMER
AUTO8   JSR     SCCLR
        JSR     TEXT    ;PRINT THE ERROR
AUTO5   LDA     #WDATA
        STA     WDOG
        BRA     AUTO5
AUTO4   BSR     BARS
        LDY     #AUTCYC
        LDA     #4
        JMP     DELA1
;*
;***    TEST PATTERNS
;*
TSTPAT  BSR     CROSS   ;DO FANCY HASSLER PAT.
        JSR     AVWAIT  ;WAIT FOR ADVANCE
        JSR     SCCLR
        LDA     #$7     ;RED
        STA     PCRAM
        JSR     AVWAIT
        LDA     #$38    ;GREEN
        STA     PCRAM
        JSR     AVWAIT
        LDA     #$C0
        STA     PCRAM   ;BLUE
        JSR     AVWAIT
        BSR     BARS
        JSR     AVWAIT
        JMP     BOOK

BARS    LDX     #CRAM
        LDY     #CBARCL
BARS0   LDD     ,Y++    ;GET A COLOR
        STD     ,X++
        LDA     #WDATA
        STA     WDOG
        CMPX    #PCRAM+16
        BLO     BARS0
        LDD     #0
        LDX     #0
COLR1   STX     XTEMP                                                           ;;Fixme was: COLOR1 (duplicate symbol)
        LEAX    $F00,X
COLOR2  STD     ,--X
        PSHS    A
        LDA     #WDATA
        STA     WDOG
        PULS    A
        CMPX    XTEMP
        BNE     COLOR2
        LEAX    $900,X
        TSTA
        BNE     COLOR3
        LDX     #$D00
COLOR3  ADDD    #$1111
        BCC     COLR1
        RTS
;*
CBARCL  FCB     $5,$5,$28,$28,$80,$80,$0,$0
        FCB     $AD,$AD,$2D,$2D,$A8,$A8,$85,$85
;*
;* DON HASSLER CROSSHATCH
;*
;*      RAM0 = BLACK - 00
;*      RAM1 = WHITE - FF
;*      RAM2 = BLUE - C0
;*      RAM3 = GREEN - 38
;*      RAM4 = RED - 07
;*
CROSS   JSR     SCCLR   ;CLEAR SCREEN
        CLRA
        JSR     SETPCR  ;ZERO COLOR MATRIX
        CLR     RWCNTL
        LDA     #$FF
        STA     CRAM+1
        LDA     #$C0
        STA     CRAM+2
        LDA     #$38
        STA     CRAM+3
        LDA     #$7
        STA     CRAM+4
        LDY     #WVERT  ;MOVE WHITE VERTICALS
        LDD     #$0101
CROSS4  LDX     0,Y     ;GET START PTR
        LDB     #WDATA
        STB     WDOG
        LDB     #$01
CROSS5  STD     ,X++    ;MOVE IN WHITE
        CMPX    2,Y     ;CK IF LINE DONE
        BNE     CROSS5  ;NO, KEEP GOING
        LEAY    4,Y     ;INCR Y BY 4
        CMPY    #WVERTX ;CK IF ALL DONE
        BNE     CROSS4  ;NO, DO NEXT LINE
        LDA     #$11    ;MOVE WHITE HORIZ
        LDY     #WHORZ
CROSS2  LDX     0,Y     ;GET START PTR
        STX     XTEMP
CROSS3  STA     0,X     ;MOVE IN WHITE
        INC     XTEMP   ;UPDATE PTR
        LDB     #WDATA
        STB     WDOG
        LDX     XTEMP
        CMPX    2,Y     ;CK IF DONE
        BNE     CROSS3  ;NO, KEEP GOING
        LEAY    4,Y     ;INCR Y BY 4
        CMPY    #WHORZX ;CK IF ALL DONE
        BNE     CROSS2  ;NO, DO NEXT LINE
        LDY     #HORIZ  ;MOVE IN COLOR HORIZ.
CROSS6  LDX     0,Y     ;GET START PTR
        STX     XTEMP
        LDA     4,Y     ;GET COLOR
CROSS7  STA     0,X     ;MOVE IN COLOR
        INC     XTEMP
        LDB     #WDATA
        STB     WDOG
        LDX     XTEMP
        CMPX    2,Y     ;CK IF LINE DONE
        BNE     CROSS7  ;NO, KEEP GOING
        LEAY    5,Y     ;INCR Y BY 5
        CMPY    #HORIZX ;CK IF ALL DONE
        BNE     CROSS6  ;NO, DO NEXT LINE
        LDY     #VERT   ;MOVE IN COLOR VERTICAL
CROSS8  LDX     0,Y     ;GET START PTR
        LDA     4,Y     ;GET COLOR
CROSS9  STA     ,X+     ;MOVE IN COLOR
        LDB     #WDATA
        STB     WDOG
        CMPX    2,Y     ;CK IF LINE DONE
        BNE     CROSS9  ;NO, KEEP GOING
        LEAY    5,Y     ;INCR Y BY 5
        CMPY    #VERTX  ;CK IF ALL DONE
        BNE     CROSS8  ;NO, DO NEXT LINE
        LDA     #$21    ;BLUE TOUCH UP
        STA     $437E
        LDA     #$20
        STA     $937E
        LDX     #$4B0A
CROSSA  LDA     0,X
        ANDA    #$F0
        ORA     #$02
        LDB     #WDATA
        STB     WDOG
        STA     ,X+
        CMPX    #$4B6D
        BNE     CROSSA
        LDX     #$4B90
CROSSB  LDA     0,X
        ANDA    #$F0
        ORA     #$02
        LDB     #WDATA
        STB     WDOG
        STA     ,X+
        CMPX    #$4BF3
        BNE     CROSSB
        LDX     #$0B18
        STX     XTEMP   ;MOVE IN DOTS
CROSSC  LDX     XTEMP
        LDA     0,X     ;OR IN DOT
        ANDA    #$F0
        ORA     #$01
        STA     0,X     ;STORE DOT
        LDB     XTEMP+1 ;UPDATE VERTICAL PTR
        ADDB    #$22
        BCS     CROSSD
        STB     XTEMP+1
        BRA     CROSSC
CROSSD  LDB     #$18
        STB     XTEMP+1 ;RE-INIT VERT. PTR
        LDB     XTEMP
        ADDB    #$10    ;UPDATE HORIZ PTR
        STB     XTEMP
        CMPB    #$9B    ;CK IF DONE
        BNE     CROSSC  ;NO, KEEP GOING
        LDB     #1
        STB     RWCNTL
        LDB     #WDATA
        STB     WDOG
        RTS
;*
;* CROSS HATCH DATA
;*
WHORZ   FDB     $0407
        FDB     $9407
        FDB     $0429
        FDB     $9429
        FDB     $044B
        FDB     $944B
        FDB     $046D
        FDB     $946D
        FDB     $048F
        FDB     $948F
        FDB     $04B1
        FDB     $94B1
        FDB     $04D3
        FDB     $94D3
        FDB     $04F5
        FDB     $94F5
WHORZX  EQU     *
WVERT   FDB     $0307
        FDB     $03F5
        FDB     $1307
        FDB     $13F5
        FDB     $2307
        FDB     $23F5
        FDB     $3307
        FDB     $33F5
        FDB     $4307
        FDB     $43F5
        FDB     $5307
        FDB     $53F5
        FDB     $6307
        FDB     $63F5
        FDB     $7307
        FDB     $73F5
        FDB     $8307
        FDB     $83F5
        FDB     $9307
        FDB     $93F5
WVERTX  EQU     *
HORIZ   FDB     $4505
        FDB     $5205
        FCB     $44
        FDB     $4506
        FDB     $5206
        FCB     $44
        FDB     $4507
        FDB     $5207
        FCB     $00
        FDB     $4508
        FDB     $5208
        FCB     $33
        FDB     $4509
        FDB     $5209
        FCB     $33
        FDB     $45F3
        FDB     $52F3
        FCB     $33
        FDB     $45F4
        FDB     $52F4
        FCB     $33
        FDB     $45F5
        FDB     $52F5
        FCB     $00
        FDB     $45F6
        FDB     $52F6
        FCB     $44
        FDB     $45F7
        FDB     $52F7
        FCB     $44
        FDB     $047E
        FDB     $437E
        FCB     $22
        FDB     $547E
        FDB     $937E
        FCB     $22
HORIZX  EQU     *
VERT    FDB     $026F
        FDB     $028E
        FCB     $04
        FDB     $036F
        FDB     $038E
        FCB     $30
        FDB     $936F
        FDB     $938E
        FCB     $00
        FDB     $946F
        FDB     $948E
        FCB     $34
VERTX   EQU     *
;*
;***    COLOR   MATRIX  TEST
;*
CRTEST  JSR     SCCLR   ;CLEAR OUT BABY
        LDA     #TXCMT  ;PRINT THE MESSAGE
        JSR     TEXT
        LDA     #$80
        STA     SW0ST
CRTST1  CLRA
        JSR     JNAP
CRTST2  JSR     AVCHK   ;PRESS??
        BCS     CMTBYE  ;NOPE
        DEC     SW0ST   ;DONE WITH DELAY??
        BNE     CRTST1
        LDA     COLRMT  ;GET FIRST COLOR.
        BSR     SETPCR  ;STORE IT DOWN
        BSR     RAMBAR  ;SET UP MEMORY.
CRTTSS  LDX     #COLRMT ;TABLE TO STORE                                         ;;Fixme was: CRTT$$ (invalid symbol name)
CRTST3  LDA     ,X+     ;GET A COLOR
        STX     XTEMP
        BSR     SETPCR  ;STORE IT THROUGH
        LDA     #$80
        STA     SW0ST
CRTST4  CLRA
        JSR     JNAP
CRTST5  JSR     AVCHK   ;ADVANCE??
        BCS     CMTBYE  ;YEP
        DEC     SW0ST
        BNE     CRTST4
        LDX     XTEMP   ;RESTORE POINTER
        CMPX    #COLRMT+8
        BLO     CRTST3
        BRA     CRTTSS  ;CONTINUE THROUGH
CMTBYE  RTS

RAMBAR  LDX     #$0
        LDY     #COLRMD ;NUMBERS TO PUT IN BARS
RAMBA1  STX     XTEMP   ;SAVE OUR X
        LEAX    $F00,X
        LDA     ,Y+
RAMBA2  TFR     A,B
        STD     ,--X
        LDB     #WDATA
        STB     WDOG
        CMPX    XTEMP
        BNE     RAMBA2
        LEAX    $900,X
        TSTA
        BNE     RAMBA3
        LDX     #$D00
RAMBA3  CMPY    #COLRMD+16
        BNE     RAMBA1
        RTS

COLRMT  FCB     $02,$03,$04,$10,$18,$20,$40,$80
COLRMD  FCB     $00,$FF,$11,$EE,$22,$DD,$33,$CC
        FCB     $44,$BB,$55,$AA,$66,$99,$77,$88

SETPCR  LDX     #CRAM
SETPC1  STA     ,X+
        CMPX    #CRAM+16
        BLO     SETPC1
        RTS
;*
;***    SWITCH TEST
;*

SWMH    EQU     44      ;HEIGHT OF FIRST MESSAGE

SWTEST  LDA     #10
        STA     XTEMP   ;DELAY COUNTER FOR EXIT
        JSR     SCCLR   ;CLEAR IT PLEASE
        LDA     #TXSWTS ;SWITCH TEST MESSAGE.
        JSR     TEXT
        LDB     #WDATA
        STB     WDOG
        LDU     #SW0ST
SWTES0  CLR     ,U+
        CMPU    #SW3SCI
        BLS     SWTES0
SWTES2  LDU     #STABP
        BSR     SWSCN0
SWTES1  LDA     #$34
        STA     PIA3+1
        LDB     #WDATA
        STB     WDOG
        BSR     SWSCN0  ;SCAN THE COCKTAIL SIDE
        LDA     #$3C
        STA     PIA3+1
        BSR     SWDISP
        JSR     AVCHK   ;ADVANCE PRESSED?
        BCC     SWT999  ;NOPE.
        LDB     #WDATA
        STB     WDOG
        DEC     XTEMP
        BEQ     SWTBYE
SWT999  CLRA
        JSR     JNAP
        BRA     SWTES2

SWTBYE  RTS

SWSCN0  LDX     ,U++    ;GET ADDRESS OF PORT
        BEQ     SWSCN5  ;DONE
        LDY     ,U++    ;GET ADDRESS TO STORE STATE
        LDA     ,X      ;GET NEW STATE
        EORA    ,Y      ;SEE WHERE DIFFERENT
        STA     1,Y     ;AND SAVE AS DIFFERENCE BYTE.
        BRA     SWSCN0
SWSCN5  RTS

SWDISP  LDU     #SPHTAB ;WE'LL WALK THROUGH SWITCH PHRASE TABLE
        LDY     #SW0ST  ;WALK THROUGH THE SCANNED STUFF.
SWDIS4  LDB     #1      ;WALK FROM LSB
SWDIS0  BITB    1,Y     ;SEE IF THIS BIT CHANGED.
        BEQ     SWDIS2
        BSR     SWACT   ;TAKE SOME ACTION
SWDIS2  LEAU    3,U     ;MOVE TO NEXT ENTRY
        ASLB            ;SHIFT ONE DOWN
        BCC     SWDIS0
        LDB     #WDATA
        STB     WDOG
        LEAY    2,Y     ;TO NEXT BYTE
        CMPY    #SW3SCI ;PAST TABLE
        BHI     SWDIS9  ;YEP..DONE
;*      LDA     PIA3    ;COCKTABLE
;*      BMI     SWDIS4  ;YEP...FULL SCAN
        BRA     SWDIS4  ;YEP...FULL SCAN
        CMPY    #SW3SCN ;NOPE..DONE WITH NORMAL SWITCHES??
        BLS     SWDIS4  ;NOT DONE
SWDIS9  RTS             ;RETURN BABY.

SWACT   PSHS    B,X     ;SAVE THE MASK
        LDA     #$3F
        STA     SOUND   ;BRING SOUND LINES HIGH IN ANTICIPATION
        EORB    ,Y      ;INVERT THE BIT
        STB     ,Y      ;AND MAKE THAT THE NEW STATE
        LDB     ,S      ;RESTORE MASK
        BITB    ,Y      ;WHICH WAY DID IT GO
        BNE     SWPRNT  ;ON....PRINT A MESSAGE.
        LDB     2,U     ;HEIGHT
        BEQ     SWNOAC
        LDA     #$40    ;X
        TFR     D,X     ;MAKE IT CURSOR
        LDB     #WDATA
        STB     WDOG
        LDD     #$3006!DMAFIX                                           ;;Fixme was: LDD  #$3006!XDMAFIX

        STD     $CA06   ;DMA X and Y SIZE
        STX     $CA04   ;DMA DESTINATION
;*      ORIGIN WE DON'T CARE ABOUT BECAUSE OF CONSTANT SUBSTITUTION
        LDB     #$00    ;CLEAR IT
        STB     $CA01   ;DMA CONSTANT
        LDB     #$12    ;CONSTANT SUBSTITUTION, WRITE BLOCK
        STB     $CA00   ;AND LET THE DMA GO!!!!

        LDB     #WDATA
        STB     WDOG
        PULS    B,X,PC
SWPRNT  LDB     2,U     ;GET HEIGHT
        BEQ     SWNOAC
        LDA     #$40    ;CURSOR
        TFR     D,X
        LDB     #WDATA
        STB     WDOG
        LDB     #$BB
        LDA     ,U      ;GET MESSAGE NUMBER
        JSR     OUTP35  ;AND PRINT IT.
        LDA     1,U     ;GET THE PLAYER NUMBER
        LDB     #WDATA
        STB     WDOG
        LDB     #$BB
        JSR     OUTB35
        LDA     #$3C
        STA     SOUND   ;MAKE A SOUND
SWNOAC  PULS    B,X,PC  ;AND RETURN.

STABP   FDB     PIA0,SW0ST
        FDB     PIA2,SW2ST
        FDB     PIA3,SW3ST
        FDB     0
        FDB     PIA2,SW2STI
        FDB     PIA3,SW3STI
        FDB     0

SPHTAB  FCB     MSSWCH,$FF,SWMH         ;AUTO UP
        FCB     MSSWCH+1,$FF,SWMH+7     ;ADVANCE
        FCB     MSSWCH+2,$FF,SWMH+14    ;RIGHT COIN
        FCB     MSSWCH+3,$FF,SWMH+21    ;HIGH SCORE RESET
        FCB     MSSWCH+4,$FF,SWMH+28    ;LEFT COIN
        FCB     MSSWCH+5,$FF,SWMH+35    ;CENTER COIN
        FCB     MSSWCH+6,$FF,SWMH+42    ;SLAM SWITCH
        FCB     0,0,0   ;UNUSED         ;(SOUND HANDSHAKE)
;*
        FCB     MSSWCH+9,$F1,SWMH+49    ;MOVE LEFT PLAYER 1
        FCB     MSSWCH+10,$F1,SWMH+56   ;MOVE RIGHT PLAYER 1
        FCB     MSSWCH+11,$F1,SWMH+63   ;FLAP PLAYER 1
        FCB     0,0,0   ;UNUSED
        FCB     MSSWCH+8,$FF,SWMH+70    ;START ONE
        FCB     MSSWCH+7,$FF,SWMH+77    ;START TWO
        FCB     0,0,0   ;UNUSED
        FCB     0,0,0   ;UNUSED
;*
        FCB     0,0,0   ;UNUSED
        FCB     0,0,0   ;UNUSED
        FCB     0,0,0   ;UNUSED
        FCB     0,0,0   ;UNUSED
        FCB     0,0,0   ;UNUSED
        FCB     0,0,0   ;UNUSED
        FCB     0,0,0   ;UNUSED
        FCB     0,0,0   ;UNUSED
;*
        FCB     MSSWCH+9,$F2,SWMH+84    ;MOVE LEFT PLAYER 2
        FCB     MSSWCH+10,$F2,SWMH+91   ;MOVE RIGHT PLAYER 2
        FCB     MSSWCH+11,$F2,SWMH+98   ;FLAP PLAYER 2
        FCB     0,0,0   ;UNUSED
        FCB     0,0,0   ;UNUSED
        FCB     0,0,0   ;UNUSED
        FCB     0,0,0   ;UNUSED
        FCB     0,0,0   ;UNUSED
;*
        FCB     0,0,0   ;UNUSED
        FCB     0,0,0   ;UNUSED
        FCB     0,0,0   ;UNUSED
        FCB     0,0,0   ;UNUSED
        FCB     0,0,0   ;UNUSED
        FCB     0,0,0   ;UNUSED
        FCB     0,0,0   ;UNUSED
        FCB     0,0,0   ;UNUSED

FDRET   LDU     #RAMERJ ;RAM ERROR RETURN
        BRA     FDROM0

FDROM   LDU     #DIG11S
FDROM0  LDS     #HSTK
FDROM5  LDY     #FDROM6
        LDA     #1
        JMP     DELA1
FDROM6  LDA     PIA0
        BITA    #$2
        BNE     FDROM5
FDROM1  LDY     #FDROM7
        LDA     #1
        JMP     DELA1
FDROM7  LDA     PIA0
        BITA    #$2
        BEQ     FDROM1
FDROM2  LDY     #FDROM8
        LDA     #1
        JMP     DELA1
FDROM8  LDA     PIA0
        BITA    #2
        BNE     FDROM2
        JMP     ,U

AVWAIT  LDA     PIA0    ;SEE IF ADVANCE PRESSED
        BITA    #$2     ;WELL??
        BNE     AVWAT2
        LDA     #$01
        BSR     JNAP
        BRA     AVWAIT  ;WELL, WAIT FOR IT.
AVWAT2  CLR     CRAM
        JSR     SCCLR
        BRA     AVWAT5
AVWAT4  LDA     PIA0
        BITA    #$2     ;WAIT FOR IT TO BE RELEASED
        BEQ     AVWAT3
AVWAT5  LDA     #$01
        BSR     JNAP
        BRA     AVWAT4
AVWAT3  RTS

AVCHK   LDA     PIA0
        BITA    #$2
        BEQ     AVCHK1
        ORCC    #$01    ;SEC
        RTS
AVCHK1  ANDCC   #$FE    ;CLC
        RTS

JNAP    LDB     #WDATA
        LDX     #$0300
.1S     STB     WDOG
        LEAX    -1,X
        BNE     .1S
        DECA
        BPL     JNAP
        RTS

;*
;*      DISPLAY BOOKKEEPPING
;*

BOOK    LDA     #RAM>>8                                                         ;;Fixme was: LDA  #RAM!>8
        TFR     A,DP
        JSR     INITCM  ;COLOR MATRIX PROPER.
        BSR     AVCHK
        BCC     BOOK3
        BSR     AVWAIT  ;WAIT FOR HIM TO LET GO.
BOOK3   LDA     #TXBOOK
        JSR     TEXT    ;PRINT THE BOOKKEEPING MESSAGE
        LDU     #SLOT1
        LDX     #$1A30
        LDA     #MSAUD  ;FIRST OF THE AUDIT MESSAGES
BOOK0   PSHS    A,X     ;SAVE MESSAGE NUMBER
        LDB     #$88
        JSR     OUTPHR  ;PRINT IT.
        EXG     U,X
        JSR     RCMSB   ;GET THE TOP BYTE

        BITB    #$F0    ;IS THE FIRST NIBBLE 0
        BNE     .1S
        ORB     #$F0    ;YES. SO BLANK IT
        BITB    #$0F    ;IS THIS NIBBLE 0
        BNE     .1S
        ORB     #$0F    ;YES. SO BLANK IT.
.1S     TFR     B,A     ;COPY B INTO A
        COMA
        PSHS    D
        JSR     RCMSD
        TST     ,S+     ;GET THE COMPLEMENTED BYTE BACK (FULLY BLANKED = 00)
        BNE     .2S     ;BRA= FIRST BYTE WAS NOT FULLY BLANKED
        BITA    #$F0    ;IS THE FIRST NIBBLE 0
        BNE     .2S
        ORA     #$F0    ;YES. SO BLANK IT
        BITA    #$0F    ;IS THIS NIBBLE 0
        BNE     .2S
        ORA     #$0F    ;YES. SO BLANK IT.
        BITB    #$F0    ;IS THE FIRST NIBBLE 0
        BNE     .2S
        ORB     #$F0    ;YES. SO BLANK IT

.2S     TFR     D,Y
        EXG     U,X
        TFR     X,D
        LDA     #$6A
        TFR     D,X
        PULS    A
        LDB     #$88
        JSR     OUTBCD
        LDB     #WDATA
        STB     WDOG
        TFR     Y,D
        PSHS    B
        LDB     #$88
        JSR     OUTBCD
        PULS    A
        JSR     OUTBCD
        LDA     #WDATA
        STA     WDOG

BOOK2   PULS    A,X     ;RESTORE A
        LEAX    $10,X
        INCA
        CMPU    #ENDBOK
        BLS     BOOK0   ;THANK YOU SIR, MAY I HAVE ANOTHER??

        LDA     #MSTIM
        LDB     #$88
        JSR     OUTPHR
        TFR     X,D
        LDA     #$6E
        TFR     D,X
        EXG     U,X
        LDX     #$CD20
        JSR     RCMSB
        STB     BCDN
        JSR     RCMSD
        STD     BCDN+1
        LDX     #$CD38
        JSR     RCMSB
        STB     BCDD
        JSR     RCMSD
        STD     BCDD+1
        EXG     U,X
        BSR     DIVPTC
        LDB     #$88
        BITA    #$F0    ;IS THE FIRST NIBBLE 0
        BNE     .3S
        ORA     #$F0    ;YES. SO BLANK IT
.3S     JSR     OUTBCD
        LDA     #CCOLN
        JSR     OUTCHR
        LDA     BCDN+2
        JSR     OUTBCD
        LDA     #WDATA
        STA     WDOG

        JSR     AVWAIT
        JMP     ADJUST  ;NOW GO DO ADJUSTMENT MODE

;*
;*
;*      DIVIDE PLAY TIME BY CREDITS
;*       INPUT: BCDN RMB 3 - BCD PLAYTIME (M.S.DIGIT BCDN+3)
;*              BCDD RMB 3 - BCD CREDITS (M.S.DIGIT BCDD+3)
;*      OUTPUT: REG.A = BCD MINUTES
;*              BCDN+0 = BCD SECONDS
;*      DESTROIES REG.B
;*
DIVPTC  PSHS    X,Y
        BSR     BCDDIV
        LDD     BCDN+0  ;OVERFLOWING ANSWER?
        BEQ     .3S     ; BR=NO
        LDA     #$99    ;YES, INDICATE OVERFLOW
        PSHS    A
        STA     BCDN+2
        CLR     BCDN+1
        CLR     BCDN+0
        BRA     PTCRTS
;*
.3S     LDA     BCDN+2  ;SAVE MINUTES
        PSHS    A
        LDD     BCDR+0
        STD     BCDN+0
        LDA     BCDR+2
        STA     BCDN+2
        LDD     #0
        STD     BCDR+0
        STA     BCDR+2
        LDA     #4      ;CALCULATE SECONDS FROM REMAINDER
.1S     ASL     BCDN+2  ;MULTIPLY BY 10
        ROL     BCDN+1
        ROL     BCDN+0
        ROL     BCDR+2  ;ALSO, USE CARRY
        DECA
        BNE     .1S
        LDX     #BCDN+3 ;PREPARE TO MULTIPLY BY 6 (FINAL MULTIPLY BY 60)
        LDY     #BCDN+3
        LDU     #BCDN+3
        BSR     BCDAD2          ;TIMES 2
        LDD     BCDR+2
        STD     BCDCNT+0
        LDD     BCDN+1
        STD     BCDTMP+1
        LDX     #BCDCNT+4
        BSR     BCDAD2          ;TIMES 4
        BSR     BCDAD2          ;TIMES 6
        BSR     BCDDI2          ;DIVIDE TO GET SECONDS
PTCRTS  PULS    A,X,Y,PC
;*
;*      BCD ADDITION IN 8 BCD DIGITS
;*      DESTROIES REG.D
;*      PERFORMS THUS ([REG.U] = [REG.X] + [REG.Y])
;*      REG.U, REG.Y & REG.X POINTS TO L.S.BYTE+1
;*
BCDAD2  PSHS    X,Y,U
        LDB     #4      ;8 BCD DIGITS TO ADD
        BRA     BCDADC
;*
;*      BCD ADDITION IN 6 BCD DIGITS
;*      DESTROIES REG.D
;*      PERFORMS THUS ([REG.U] = [REG.X] + [REG.Y])
;*      REG.U, REG.Y & REG.X POINTS TO L.S.BYTE+1
;*
BCDADD  PSHS    X,Y,U
        LDB     #3      ;6 BCD DIGITS TO ADD
BCDADC  ANDCC   #$FE    ;CLEAR CARRY
.1S     LDA     ,-X
        ADCA    ,-Y
        DAA
        STA     ,-U
        DECB
        BNE     .1S
        PULS    X,Y,U,PC
;*
;*      BCD DIVIDE ROUTINE (BCDDIV & BCDDI2)
;*       INPUT: BCDN RMB 3 = 6 BCD DIGIT NUMERATOR (UNSIGNED)
;*              BCDD RMB 3 = 6 BCD DIGIT DENOMINATOR (UNSIGNED)
;*       OUTPUT: BCDN   RMB 3 = THE ANSWER IN BCD
;*               BCDN+3 RMB 3 = THE REMAINDER IN BCD
;*      DESTROIES: REG.D, REG.X, REG.Y
;*
BCDDIV  LDD     #0
        STD     BCDR+0  ;CLEAR REMAINDER OF DIVIDE
        STA     BCDR+2
BCDDI2  LDD     BCDD    ;DIVIDE BY ZERO?
        BNE     BDVDIV  ; BR=NO
        LDA     BCDD+2
        BNE     BDVDIV
        LDD     #0      ;YES, GIVE A RESULT OF ZERO
        STD     BCDN+0
        STA     BCDN+2
        RTS
;*
BDVDIV  LDA     #6+1    ;THE WORLD WAS CREATED IN 6 DIGITS!
        STA     BCDCNT
        LDX     #BCDR+3 ;PRE-LOAD REGISTERS FOR SUBTRACTION ROUTINE
        LDY     #BCDD+3
        LDU     #BCDTMP+3
        BSR     BCDNEG  ;MAKE DENOMINATOR NEGATIVE VIA 10'S COMPLIMENT
BDVLP   DEC     BCDCNT  ;ANY MORE DIGITS LEFT?
        BNE     .2S     ; BR=YES
        BRA     BCDNEG  ;RESTORE DENOMINATOR
;*
.2S     LDA     #4      ;BCD NIBBLE SHIFT
.1S     ASL     BCDN+2
        ROL     BCDN+1
        ROL     BCDN+0
        ROL     BCDR+2
        ROL     BCDR+1
        ROL     BCDR+0
        DECA
        BNE     .1S
BDVCMP  BSR     BCDADD  ;SUBTRACT OFF THE LARGE DENOMINATOR
        BCS     BDVOK   ; BR=SUBTRACT WAS GOOD ENOUGH
        BRA     BDVLP
;*
BDVOK   LDD     BCDTMP+0        ;NEW REMAINDER
        STD     BCDR+0
        LDA     BCDTMP+2
        STA     BCDR+2
        INC     BCDN+2  ;NBR OF SUCCESSFULL SUBTRACTIONS GOES TO THE ANSWER
        BRA     BDVCMP  ;CHACK AGAIN FOR SUBTRACTION (MAXIMUM LOOPS = 9)
;*
;*      TO BCD SUBTRACT, NEGATE THEN ADD IN 6 BCD DIGITS
;*      DESTROIES REG.D
;*      PERFORMS THUS ([REG.Y] = NOT([REG.Y]) + 1)
;*      REG.Y POINTS TO L.S.BYTE+1
;*
BCDNEG  PSHS    Y
        LDB     #3      ;COMPLIMENT THE BCD NUMBER
.2S     LDA     #$99    ;DIGIT BY DIGIT (THERE MUST BE A FASTER WAY!)
        SUBA    ,-Y
        STA     ,Y
        DECB
        BNE     .2S
        LDY     ,S      ;RESTORE REG.Y
        LDB     #3      ;6 BCD DIGITS TO SUBTRACT
        ORCC    #$01    ;SET CARRY TO ADD 1
.1S     LDA     -1,Y
        ADCA    #0
        DAA
        STA     ,-Y
        DECB
        BNE     .1S
        PULS    Y,PC
;*


ADJUST  LDX     #SPECFN ;ZERO OUT THE SPECIAL FUNCTION BYTES
ADJS11  CLR     ,X+
        CMPX    #ENDADJ
        BLO     ADJS11
        JSR     SCCLR   ;CLEAR THE SCREEN
        JSR     AVCHK
        BCC     .3S
        JSR     AVWAIT  ;WAIT FOR HIM TO LET GO.
.3S     LDA     #TXADJT
        JSR     TEXT    ;PRINT THE ADJUSTMENT MESSAGE
        LDU     #CMOS
        LDX     #$1A20
        LDA     #MSADJS ;FIRST OF THE AUDIT MESSAGES
.4S     PSHS    A,X     ;SAVE MESSAGE NUMBER
        LDB     #$22
        JSR     OUTP35  ;PRINT IT.
        STB     COLR
        STB     BCDR
        TFR     X,Y
        JSR     OUTCMOS
        LEAU    2,U
        LDB     #WDATA
        STB     WDOG
        PULS    A,X     ;RESTORE A
        LEAX    $A,X
        INCA
        CMPU    #ENDADJ
        BLT     .4S
        LDA     #TXBADJ ;PUT OUT THE MESSAGES AT THE BOTTOM OF THE SCREEN
        JSR     TEXT35  ;IN 3X5 CHARACTER FORMAT
        CLR     BCDR

        LDA     COINSL+1
        ANDA    #$0F
        CMPA    #9
        BNE     CURSOR
        LDA     #MSFRPLY
        LDB     COLR
        LDX     #$703E
        JSR     OUTP35

CURSOR  LDY     #$1620  ;FIRST CURSOR POSITION
        LDU     #CMOS   ;GET THE FIRST CMOS ADJUSTABLE LOCATION
        TFR     Y,X     ;GET THE CURSOR POSITION
        LDA     #CCURSR ;GET THE CURSOR CHARACTER
        LDB     #$33    ;GET THE COLOR
        STD     SW0ST   ;SAVE THE CURSOR COLOR AND CHARACTER OFFSET IN MEMORY
        JSR     OUTC35  ;WRITE THE 3X5 CURSOR OUT
.1S     LDA     #WDATA  ;LET'S GO AND PET THE FUCKING DOG..........
        STA     WDOG
        LDA     PIA2    ;CHECK THE SWITCHES
        ANDA    #$03    ;WE ONLY WANT BITS 0&1 (THIS IS FOR JOUST)
        BEQ     .3S     ;BRA= NO
        BSR     CSWIT   ;SEE WHO IT IS
.3S     LDB     #$34    ;FLIP TO THE COCKTAIL SIDE
        STB     PIA3+1
        LDA     PIA2    ;GET THE REST OF THEM
        ANDA    #$03    ;WE ONLY WANT BITS 0&1 (THIS IS FOR JOUST)
        BEQ     .2S     ;BRA=NO
        JSR     CSWIT1  ;SEE WHO THEY ARE
.2S     LDB     #$3C    ;SET BACK TO THE NORMAL SIDE
        STB     PIA3+1
        JSR     AVCHK   ;CHECK TO SEE IF THE ADVANCE SWITCH HAS BEEN PRESSED
        BCC     .1S     ;NOT EVEN AN ADVANCE SO LETS CHECK THEM AGAIN
        JSR     AVWAIT
        JMP     ADVSCV  ;GO START EXEC UP AND THE GAME


CSWIT   STA     SW3ST   ;SAVE THE SWITCH
        CMPA    SW2ST   ;GET THE LAST SWITCH HE HIT
        BEQ     .1S     ;BRA= YES
        CLR     SW2SCN  ;CLEAR THE B PORT
        LDA     SW3ST   ;GET THE SWITCH
        STA     SW2ST   ;SAVE THE SWITCH
        LDA     #$2     ;       NAP ONLY 16 MS
        JSR     JNAP    ;AND TAKE A CAT NAP
        LDA     PIA2    ;READ THE PORT TO MAKE SURE THAT IT IS VALID
        BNE     .3S
.1S     LDB     #$05    ;TIME TO WAIT
        STB     SW3SCN  ;SAVE IT
.5S     LDA     PIA2    ;READ THE PORT
        BNE     .2S     ;BRA= STILL PRESSED
        CLR     SW2ST   ;SAY THAT NO SWITCH HAS BEEN PRESSED
        RTS             ;TOO BAD YOU LET GO
.2S     LDA     #$2     ;       NAP ONLY 16 MS
        JSR     JNAP    ;AND TAKE A CAT NAP
        DEC     SW3SCN  ;ONE LESS TIME
        BNE     .5S     ;NOT DONE SO CHECK AGAIN
        LDA     PIA2    ;READ ONCE AGAIN

.3S     BITA    #$02    ;DID HE PRESS MOVE LEFT
        BNE     .4S     ;BRA= YES HE DID SO MOVE THE CURSOR UP
        BITA    #$01
        BEQ     NOMOVE
        CMPY    #AEND   ;IS HE AT THE BOTTOM
        BEQ     NOMOVE  ;BRA= YES SO DON'T DO A THING
        BSR     NOCURS  ;ERASE THE CURSOR
        LEAY    -$A,Y   ;NOT UP SO IT MUST BE DOWN
        LEAU    -2,U    ;MOVE TO THE NEXT CMOS LOCATION
        CMPU    #MINUNT ;IS HE IN THE MIDDLE OF PRICE SELECTION
        BNE     .10S
        TST     SEED    ;HE'S NOT IN CUSTOM ADJUST
        BEQ     .10S
        LEAY    -$3C,Y  ;BIG JUMP
        LEAU    -$C,U   ;IN CMOS TOO..
.10S    BRA     CURS    ;WRITE THE CURSOR OUT IN IT'S NEW POSITION
.4S     CMPY    #ATOP   ;IS HE AT THE TOP OF THE ADJUSTMENTS
        BEQ     NOMOVE  ;BRA= YES SO DON'T DO A THING
        BSR     NOCURS  ;ERASE THE CURSOR
        LEAY    $A,Y    ;MOVE THE CURSOR UP
        LEAU    2,U     ;MOVE BACK A CMOS LOCATION
        CMPU    #SLOT1M ;IS HE IN THE MIDDLE OF PRICE SELECTION
        BNE     CURS
        TST     SEED    ;HE'S NOT IN CUSTOM ADJUST
        BEQ     CURS
        LEAY    $3C,Y   ;BIG JUMP
        LEAU    $C,U    ;IN CMOS TOO..

CURS    TFR     Y,X     ;GET THE CURSOR
        LDD     SW0ST   ;GET THE DATA BACK
        JSR     OUTC35  ;WRITE THE 3X5 CURSOR OUT
NOMOVE  CLRA
        JSR     JNAP
        RTS

NOCURS  TFR     Y,X     ;GET THE CURSOR
        LDA     SW0ST   ;GET THE DATA BACK
        CLRB
        JSR     OUTC35  ;WRITE THE 3X5 CURSOR OUT
        RTS


CSWIT1  STA     SW3ST   ;SAVE THE SWITCH
        CMPA    SW2STI  ;GET THE LAST SWITCH HE HIT
        BEQ     .1S     ;BRA= YES
        CLR     SW2SCI  ;CLEAR THE B PORT
        LDA     SW3ST   ;GET THE SWITCH
        STA     SW2STI  ;SAVE THE SWITCH
        LDA     #$2     ;       NAP ONLY 16 MS
        JSR     JNAP    ;AND TAKE A CAT NAP
        LDA     PIA2    ;READ THE PORT TO MAKE SURE THAT IT IS VALID
        BNE     .3S
.1S     LDB     #$08    ;TIME TO WAIT
        STB     SW3SCI  ;SAVE IT
.5S     LDA     PIA2    ;READ THE PORT
        BNE     .2S     ;BRA= STILL PRESSED
        CLR     SW2SCI  ;SAY THAT NO SWITCH HAS BEEN PRESSED
        RTS             ;TOO BAD YOU LET GO
.2S     CLRA            ;NAP ONLY 16 MS
        JSR     JNAP    ;AND TAKE A CAT NAP
        DEC     SW3SCI  ;ONE LESS TIME
        BNE     .5S     ;NOT DONE SO CHECK AGAIN
        LDA     PIA2    ;READ ONCE AGAIN

.3S     PSHS    A
        TFR     U,X     ;GET THE CMOS LOCATION
        JSR     RCMSA
        PSHS    A
        CLRB
        STB     COLR
        BSR     OUTCMOS
        LDB     #WDATA
        STB     WDOG
        LDX     #MINMAX ;GET THE TABLE OF MAXIMUMS AND MINIMUMS
        TFR     U,D
        LEAX    B,X
        PULS    D
        ANDB    #$03    ;ONLY NEED BITS 0&1 (FOR JOUST)
        BITB    #$02    ;IS IT UP
        BNE     .10S    ;BRA= NO
        BITB    #$01
        BEQ     CWRET
        CMPA    0,X     ;IS IT AT IT'S MAX.
        BEQ     CWRET   ;BRA= YES..
        ADDA    #$99    ;BCD -1
        BRA     CMWRIT
.10S    CMPA    1,X     ;IS IT AT IT'S MIN.
        BEQ     CWRET   ;BRA= YES..
        ADDA    #$01    ;BCD +1

CMWRIT  DAA             ;MAKE IT DECIMAL AGAIN
        TFR     U,X
        JSR     WCMSA   ;WRITE THE NEW VALUE
CWRET   LDB     #$22
        STB     COLR
        JSR     OUTCMOS
        CLRA
        JMP     JNAP

MINMAX  FCB     $00,$99
        FCB     $01,$99
        FCB     $00,$01
        FCB     $00,$09
        FCB     $00,$99
        FCB     $00,$99
        FCB     $00,$99
        FCB     $01,$99
        FCB     $00,$99
        FCB     $00,$99
        FCB     $00,$09
        FCB     $03,$20
        FCB     $00,$01
        FCB     $00,$01
        FCB     $00,$01
        FCB     $00,$01
        FCB     $00,$01
        FCB     $00,$01

OUTCMOS TFR     U,D
        LSRB
        LDX     #SPECAL
        LEAX    B,X
        TST     0,X
        BMI     OUTSPC
OUT2    TFR     U,X
        JSR     RCMSA
        CMPU    #COINSL
        BNE     .2S
        STA     SEED
        TST     BCDR
        BNE     .2S
        BSR     PRICOUT
.2S     BITA    #$F0
        BNE     .1S
        ORA     #$F0
.1S     PSHS    A
        TFR     Y,D
        LDA     #$6A
        TFR     D,X
        PULS    A
        LDB     COLR
        JSR     OUTB35
        RTS

OUTSPC  LDA     0,X
        BITA    #$01
        BNE     .1S
        TFR     U,X
        JSR     RCMSB
        LDA     #MSNO
        TSTB
        BEQ     .2S
        LDA     #MSYES
.2S     PSHS    A
        TFR     Y,D
        LDA     #$6A
        TFR     D,X
        PULS    A
        LDB     COLR
        JMP     OUTP35
.1S     BSR     OUT2
        LDA     #CTHOU
        JMP     OUTC35

SPEC    EQU     $80
NOREPLC EQU     $01
NORM    EQU     $00

SPECAL  FCB     SPEC+NOREPLC
        FCB     NORM
        FCB     SPEC
        FCB     NORM
        FCB     NORM
        FCB     NORM
        FCB     NORM
        FCB     NORM
        FCB     NORM
        FCB     NORM
        FCB     NORM
        FCB     NORM
        FCB     SPEC
        FCB     SPEC
        FCB     SPEC
        FCB     SPEC
        FCB     SPEC
        FCB     SPEC

PRICOUT PSHS    D,U,X,Y
        LDX     #$0438!DMAFIX                                                           ;;Fixme was: LDX  #$0438!XDMAFIX
        STX     $CA06
        LDX     #$6A48
        STX     $CA04
        CLRB
        STB     $CA01
        LDB     #$12
        STB     $CA00
        LDX     #CSELCT
        CMPA    #9
        BNE     .8S
        PSHS    A,X
        LDA     #MSFRPLY
        LDB     COLR
        LDX     #$703E
        JSR     OUTP35
        PULS    A,X
.8S     TFR     A,B
        ASLB
        PSHS    B
        ASLB
        ADDB    ,S+
        ABX
        LEAU    2,U
.2S     EXG     U,X
        CMPX    #GA1    ;AT THE END OF COIN ADJUSTMENTS
        BEQ     .1S
        LDA     ,U+
        JSR     WCMSA
        LDB     #WDATA
        STB     WDOG
        EXG     U,X
        LEAY    $A,Y
        PSHS    X
        LEAX    -2,U
        JSR     RCMSA
        BITA    #$F0
        BNE     .10S
        ORA     #$F0
.10S    PSHS    A
        TFR     Y,D
        LDA     #$6A
        TFR     D,X
        PULS    A
        LDB     COLR
        JSR     OUTB35
        PULS    X
        BRA     .2S
.1S     PULS    D,U,X,Y,PC

;*
;* COINAGE SELECT TABLE
;*
CSELCT  FCB     $01,$04,$01,$01,$00,$00 ;FACTORY USE FOR CUSTOM START
        FCB     $01,$04,$01,$02,$04,$00 ;50C..3/$1.00
        FCB     $06,$00,$01,$01,$00,$00 ;NEWNEW GERMAN
        FCB     $01,$04,$01,$01,$00,$00 ;25C
        FCB     $01,$16,$06,$02,$00,$00 ;NEW FRENCH
        FCB     $01,$04,$01,$02,$00,$00 ;50C
        FCB     $01,$00,$04,$01,$00,$00
        FCB     $01,$00,$02,$01,$00,$00
        FCB     $01,$00,$02,$02,$00,$00
        FCB     $00,$00,$00,$00,$00,$00 ;FREE PLAY
;*
;*
;*      SOUND TEST
;*

SNDSRT  JSR     SCCLR   ;CLEAR THE SCREEN
SNDSR1  LDD     #$FE01  ;SET UP FOR SOUND LINE 1
        STD     SW0SCN
        RTS

SNDCYC  LDA     #$3F
        STA     SOUND
        LDA     #3
        JSR     JNAP
SNDC55  CLRA
        STA     SOUND
        LDA     #3
        JSR     JNAP
SNDCY6  LDA     #$3F
        STA     SOUND
        LDA     #3
        JSR     JNAP
SNDCY1  LDD     SW0SCN
        ANDA    #$3F
        STA     SOUND
        LDB     #$99
        LDX     #$3A80
        LDA     #MSSND
        JSR     OUTPHR
        LDA     SW0SCN+1
        ORA     #$F0
        LDB     #$99
        JSR     OUTBCD
        LDA     #$40
        STA     SW0ST
SNDCY4  LDA     #$1
        JSR     JNAP
SNDCY5  JSR     AVCHK   ;ADVANCE???
        BCS     SNDCY3  ;THEN GO
        DEC     SW0ST
        BNE     SNDCY4
SNDCY3  LDA     FDTEST  ;SEE WHO SET THIS UP??
        BNE     SNDC90  ;AUTOCY DID....ALWAYS ADVANCE
        LDA     PIA0    ;CHECK MANUAL/AUTO
        RORA
        BCC     SNDC91  ;MANUAL...DON'T MOVE ON.
SNDC90  LDX     #$5780
        LDA     SW0SCN+1
        ORA     #$F0
        LDB     #$00
        JSR     OUTBCD
        LDD     SW0SCN
        ORCC    #$01    ;SEC
        ROLA            ;MOVE TO NEXT LINE
        INCB
        CMPB    #7      ;UP TO LINE 6??
        BLO     SNDCY2
        BSR     SNDSR1
SNDCY2  STD     SW0SCN
SNDC91  RTS


;*
;*      CMOS RAM TEST
;*

CMTEST  LDX     #CMOS
        LDY     #LOWRAM ;USE SAMRAM
CMTST1  LDA     ,X+     ;DON'T DO DOUBLES BECAUSE OF HARDWARE BRAIN DAM.
        STA     ,Y+
        CMPX    #CMOS+$400 ;DONE??
        BNE     CMTST1
        LDB     #6      ;ENOUGH ITERATIONS TO ASSURE
CMTST2  LDU     HSEED
        LDY     SEED
        LDX     #CMOS
CMTST3  JSR     RAND
        STA     ,X+
        LDA     #WDATA
        STA     WDOG
        CMPX    #CMOS+$400 ;DONE??
        BNE     CMTST3
        STY     SEED     ;RESTORE SEED
        STU     HSEED
        LDX     #CMOS
CMTST4  JSR     RAND
        EORA    ,X+
        ANDA    #$F
        BNE     CMEROR
        LDA     #WDATA
        STA     WDOG
        CMPX    #CMOS+$400
        BNE     CMTST4
        DECB            ;ANOTHER PASS...DONE??
        BNE     CMTST2
        BSR     RAMBAK
        ANDCC   #$FE    ;CLC CLEAR IT FOR REAL
        RTS             ;AND RETURN

RAMBAK  LDU     #LOWRAM
        LDY     #CMOS
RAMBK0  LDA     ,U+
        STA     ,Y+
        CMPY    #CMOS+$400
        BNE     RAMBK0
        RTS

CMEROR  BSR     RAMBAK
        ORCC    #$01    ;SEC
        RTS


;*
;*RANDOM NUMBER GENERATOR
;*
RAND    PSHS    B
        LDB     SEED
        LDA     #3
        MUL
        ADDB    #17
        LDA     LSEED
        LSRA
        LSRA
        LSRA
        EORA    LSEED
        LSRA
        ROR     HSEED
        ROR     LSEED
        ADDB    LSEED
        ADCB    HSEED
        STB     SEED
        LDA     SEED
        PULS    B,PC

;*
;*      AND THE EVER POPULAR COPYRIGHT MESSAGE

        FCC     ' JOUST - COPYRIGHT  (C) 1982 WILLIAMS ELECTRONICS INC. '
        FCC     ' ALL RIGHTS RESERVED '

IRQVEC  JMP     [$EFF8]


CYCLE   LDA     #PRAM
        LDX     #CLRTAB
        LDB     0,X
        STB     PIMAGE,U
.1S     LDB     ,X+
        STB     A,U
        INCA
        CMPA    #PRAM+8
        BNE     .1S
        CLRA
        STA     PTIMX,U
        LEAY    PRAM+7,U
        STY     PDIST,U
.2S     PCNAP   4
        LDB     #PRAM
        ADDB    PTIMX,U
        LDA     PIMAGE,U
        STA     B,U
        LDA     PTIMX,U
        INCA
        CMPA    #$08
        BNE     .4S
        CLRA
.4S     CMPA    #$04
        BNE     .7S
        LEAX    PRAM,U
        LDB     ,X+
        PSHS    B
.6S     LDB     ,X+
        STB     -2,X
        CMPX    PDIST,U
        BLE     .6S
        PULS    B
        STB     -1,X
.7S     STA     PTIMX,U
        ADDA    #PRAM
        LDB     A,U
        STB     PIMAGE,U
        LDB     #$E8
        STB     A,U
        LDX     #RAMCOL+8
        LEAY    PRAM,U
.3S     LDA     ,Y+
        STA     ,X+
        CMPX    #RAMCOL+15
        BLE     .3S
        BRA     .2S


TEST    LDA     #$77
        STA     XTEMP
        LDX     #$912
.1S     BSR     SUB1
        LEAX    $600,X
        CMPX    #$8D00
        BLO     .1S
.2S     BSR     SUB2
        LEAX    $0C,X
        CMPX    #$8DE8
        BLO     .2S
        LEAX    -$608,X
.3S     BSR     SUB1
        CMPX    #$9E3
        LEAX    -$600,X
        BHI     .3S
        LEAX    +$1FC,X
.4S     BSR     SUB2
        LEAX    -$0C,X
        CMPX    #$50E
        BHI     .4S
        RTS


SUB2    LDD     #$040C!DMAFIX                                                           ;;Fixme was: LDD  #$040C!XDMAFIX
        BRA     SUB3
SUB1    LDD     #$0608!DMAFIX                                                           ;;Fixme was: LDD  #$0608!XDMAFIX
SUB3    STD     $CA06
        STX     $CA04
        LDA     XTEMP
        ADDA    #$11
        BCC     .1S
        LDA     #$88
.1S     STA     XTEMP
        STA     $CA01
        LDA     #$12
        STA     $CA00
        RTS

CLRTAB  FCB     $AF
        FCB     $77
        FCB     $37
        FCB     $1F
        FCB     $17
        FCB     $0F
        FCB     $04
        FCB     $0A
;*
TSTEND  EQU     *                                                                       ;;Fixme was: ENDADR (duplicate symbol)
TSTLEN  EQU     TSTEND-TSTORG                                                           ;;Fixme was: LENGTH     EQU     ENDADR-TSTORG (multiple duplicate symbols)
;*
        ORG     TSTORG+$FF0
        FDB     PWRUPV,PWRUPV,PWRUPV,PWRUPV
        FDB     IRQVEC,PWRUPV,PWRUPV,PWRUPV
;*
;       END     ;SYSV