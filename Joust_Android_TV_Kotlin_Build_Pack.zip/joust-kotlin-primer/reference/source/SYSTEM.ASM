;       NAM SYSTEM OVERHEAD
;       SUBTTL  WILLIAMS 1982,
;*
;******************************************************************
;*      WILLIAMS ELECTRONICS 1982
;*      ORGINAL GAME NAME; JOUST
;*      GAME DESIGNER; JOHN NEWCOMER
;*      PROGRAMMER; BILL PFUTZENREUTER
;*      STARTED PROGRAMMING; FEB 10, 1982
;*      FILE: OVERHEAD SYSTEM PROGRAMS
;*
;       INCLUDE RAMDEF.SRC      ;DONT FORGET STANDARD DEFINITIONS               ;;We don't need these
;       INCLUDE EQU.SRC         ;KOLKER EQUATES
DEBUG2  EQU     0               ;DEBUG
;*
;*  FILE I/O EQUATES
;*
ERASE   EQU     $00             ;OFFSET TO ERASE AREA IN DMABEG & DMAEND
WRITE   EQU     $02             ;OFFSET TO WRITE AREA IN DMABEG & DMAEND
QUADA   EQU     $00             ;OFFSET TO QUADRANT A FROM DMABEG & DMAEND
QUADB   EQU     $40             ;OFFSET TO QUADRANT B FROM DMABEG & DMAEND
QUADC   EQU     $80             ;OFFSET TO QUADRANT C FROM DMABEG & DMAEND
QUADD   EQU     $C0             ;OFFSET TO QUADRANT D FROM DMABEG & DMAEND
;*
;*      THE PROGRAM'S VECTORS
;*
        ORG     SYSV
        ORCC    #$F0            ;DISABLE INTERUPTS
        LDS     #STACK          ;TRUE STACK
        JMP     INIT2           ;STANDARD OVERHEAD VECTORS
        JMP     CRPROC          ;CREATE A PROCESS
        JMP     KLPROC          ;KILL A PROCESS
        JMP     SUCIDE          ;KILL SELF PROCESS
        JMP     NAPTIM          ;NAP ENTERANCE
        JMP     DCOLOR          ;LOAD COLOR RAM ADDR OF COLORS
        JMP     RANDSYS         ;RANDOM NUMBER GENERATOR                        ;;Fixme was: RAND (duplicate symbol in T12REV3.ASM)
        JMP     CL1ALL          ;ALLOCATE DMA AREA FOR ERASE OPERATION
        JMP     WR1ALL          ;ALLOCATE DMA AREA FOR WRITE OPERATION
        JMP     CL1CLS          ;ALLOCATE & FLAVOR AREA FOR 1 ERASE OPERATION
        JMP     WR1CLS          ;ALLOCATE & FLAVOR AREA FOR 1 WRITE OPERATION
        JMP     CL2CLS          ;ALLOCATE & FLAVOR AREA FOR 2 ERASE OPERATION
        JMP     WR2CLS          ;ALLOCATE & FLAVOR AREA FOR 2 WRITE OPERATION
        JMP     SND             ;SOUND ROUTINE
        JMP     CUPROC          ;CREATE A PROCESS AFTER REG.U PROCESS
        FDB     COLOR1          ;COLOR TABLET ADDRESS
        FDB     LAVA            ;BUBBLING LAVA CONTROL ROUTINE
        JMP     NAPTPC          ;NAP VIA A JSR
        JMP     NEWCL5          ;THE NEW CLIF5 UN-COMPACTOR ROUTINE
;*
        ASSUME DPR:$A0                                                          ;;Fixme was: SETDP  !HBASE
INIT2   LDA     #$A0            ;SET-UP BASE PAGE                               ;;Fixme was: LDA  #!HBASE
        TFR     A,DP
;*
;*      CLEAR ALL OF ASCREEN
;*
        LDX     #$0000
        CLRB
.1S                                                                             ;;Fixme was: 1$
;*
;*      PET THE WATCHDOG STUFF
;*
        LDA     #WDATA
        STA     WDOG
        CLRA
        STD     ,X++
        STD     ,X++
        CMPX    #$BF80
        BLO     .1S
;*                              REG.A & REG.B = 0
        INCB                    ;#$01 (READ ROM)
        STB     DRRUC           ;THIS 1ST BECAUSE OF INTERUPTS USING THIS BIT
        STB     RRUC
;*
;*
;*  PIA INITIALIZATION
;*  DATA DIRECTION
        STA     WCPIAA
        STA     WCPIAB
        STA     WPIAA           ;INPUTS
        STA     WPIAB           ;INPUTS
        LDB     #%00110100      ;$34
        STB     WCPIAA          ;SETUP, WIDGET FOR SWITCH INPUTS
        STB     WCPIAB
;*
;*      IRQ, 7-SEG, SOUND PIA INITIALIZATION
;*      INTERRUPTS
;*
        STA     CPIAA
        STA     CPIAB
        STA     PIAA            ;INPUTS
        COMA
        STA     PIAB            ;OUTPUTS
        LDB     #%00110100      ;IGNORE CNT240 INTERUPT
        STB     CPIAA
        LDB     #%00110101      ;BUT ENABLE PIA'S 4MS INTERUPT LOW-HIGH EDGE
        STB     CPIAB
        LDB     #$3F            ;INHIBIT 1ST SOUND
        STB     PIAB            ; (AND MAKE 7-SEGMENT DISPLAY A ZERO)
;*
;*      CLOSE COINS SWITCHES VIA SOFTWARE (WHO KNOWS WHAT
;*
        LDA     #$3C
        STA     SWDEB           ;DEBOUNCED STATE IS CLOSED
        STA     SWT0+0          ;DEBOUNCE 9 TIMES UNTIL OPEN
;*
;*      INITILIZE PROCESS LINKS
;*
        LDU     #PBLKST
        STU     PFREE           ;START LINK OF FREE PROCESS RAM
        LDA     #PBLKM/2        ;ALLWAYS HAVE AN EVEN NBR OF PROCESSES
PLINIT  LEAX    PBLKL,U
        STX     PLINK,U
        LEAU    PBLKL,X
        STU     PLINK,X
        DECA
        BNE     PLINIT
;*
;*      INITILIZE INTERUPTS VARIABLES
;*
        LDX     #DTBL1  ;START READING DATA FROM DMA BLOCK TABLE #1
        STX     ITBL
;********CLR    DMAINT  ; & INDICATE WHICH TABLE TO GO TO NEXT
        LDX     #DTBL2  ;START SECONDARY PROCESS WAITING FOR PREVIOUS
        STX     PDTBL   ; DMA BLOCK TABLE #2
;*
;*      INITIAL COLORS
;*
        LDX     #COLOR1 ;LOAD DEFAULT COLOR CHART
        JSR     DCOLOR
;*
;*      INITIAL GAME TIME NBRS
;*
        LDD     #60*60
        STD     MINUTE
;*
        LDX     #CREDST         ;GET THE CREDITS IN CMOS
        JSR     RCMSB
        TFR     B,A
        CMPA    #$20            ;TOO HI?
        BHI     .1S             ; BR=YES
        ANDA    #$0F            ;BCD NUMBER?
        CMPA    #$09
        BLS     .2S             ; BR=YES
.1S     CLRB
        LDX     #CREDST         ;RESET THE CREDITS IN CMOS
        JSR     WCMSB
.2S     STB     CREDIT
;*
;*      START SINGLE PROCESS
;*
        LDU     #PDUMMY         ;THIS 1ST PROCESS STARTS FROM THE DUMMY PROCESS
        LDX     #VPWRUP         ;CREATE POWER-UP MODE PRIMARY PROCESS I.D.=0
        CLRA
        CLRB
        JSR     CUPROC
        ANDCC   #$EF            ;EI, LET INTERUPTS FLY!!!
;*
;*      EXECUTE THE PROCESSES IN ORDER OF CREATION
;*              NOTE; THIS IS NOT A SUBROUTINE
;*                    NO STACK OR REGISTERS ARE SAVED
;*
EXECST  LDX     #DTBL1          ;PUT NEW IMAGES IN DMA AREA #1?
        LDA     DMAFOR
        BPL     EXTBL1          ; BR=YES
        LDX     #DTBL2          ;PUT DMA IMAGES IN TABLE 2
EXTBL1  STX     DTBL            ;REMEMBER FOREGROUND START OF NEXT TABLE
        COM     DMAFOR          ;NEXT TIME USE THE OTHER DMA BUFFER
EXEINT  TST     ,X              ;IS THIS TABLE READY TO BE WRITTEN INTO?
        BNE     EXEINT          ; BR=NO
        LEAX    DMA1-DTBL1,X    ;1ST FREE RAM AREA FOR DMA INFO.
        STX     DMAFRE
;*
        LDA     STMR            ;ANY SOUND LEFT?
        BEQ     EXESND          ; BR=NO
        DEC     STMR            ;NEXT TIME
        BNE     EXESND          ; BR=TIME NOT UP YET
        LDX     SNDPTR          ;GET SOUND GROUP
        BEQ     EXESND          ; BR=NO SOUND LEFT
        LDD     ,X++            ;GET REG.A=SND CODE, REG.B=SND TIME
        BMI     .1S             ;CONTINUATION BIT SET
        LDX     #0
.1S     STX     SNDPTR
        STB     STMR
        LDB     #$FF            ;SEND THE SOUND TO THE SOUND BOARD
        STB     PIAB
        ANDA    #$3F            ;DO NOT DISTURBE 7-SEGMENT DISPLAY
        STA     PIAB
EXESND  EQU     *
;*
        CLRA                    ;NOW RESET FORGROUNDS CLEAR & WRITE POINTERS
        CLRB
        LDX     #DMABEG
        STX     DMAEND-DMABEG,X ;1ST LINK OF DMAEND POINTERS
        STD     ,X++            ;ZERO LINK INDICATES NOT IN USE
        STX     DMAEND-DMABEG,X
        STD     ,X
        LEAX    QUADB-QUADA-2,X
        STX     DMAEND-DMABEG,X
        STD     ,X++
        STX     DMAEND-DMABEG,X
        STD     ,X
        LEAX    QUADC-QUADB-2,X
        STX     DMAEND-DMABEG,X
        STD     ,X++
        STX     DMAEND-DMABEG,X
        STD     ,X
        LEAX    QUADD-QUADC-2,X
        STX     DMAEND-DMABEG,X
        STD     ,X++
        STX     DMAEND-DMABEG,X
        STD     ,X
;*
;*      MAIN EXEC LOOP
;*
EXEC    LDU     #PDUMMY         ;START AT FIRST PROCESS IN LIST
        LDS     #STACK          ;STACK IS RESET
        CLR     PRISEC          ;PRIMARY PROCESSES ARE FIRST
        BRA     EXEPRI
;*
EXELOP  STU     PEXEC           ;CURRENTLY EXECUTING PROCESS
        JMP     [PPC,U]         ;DEFAULT PC SLEEP ADDRESS, GO START/RE-START
NAPTPC  LDX     ,S++            ;GET NEXT PC COUNTER
NAPTIM  LDU     PEXEC           ;NAP ENTERANCE (PC=REG.X TIME=REG.A)
        STX     PPC,U           ;NEW PC COUNTER (REG.X)
        STA     PNAP,U          ;NEW NAP TIME (REG.A)
EXEPS   LDA     PRISEC          ;ON PRIMARY OR SECONDARY PROCESSES??
        BNE     EXESEC          ; BR=SECONDARY
EXEPRI  STU     PPREV           ;REMEMBER LAST PROCESS EXECUTED
        LDU     PLINK,U         ;NEXT PROCESS
        BEQ     EXEPEN          ; BR=NO MORE PRIMARY PROCESSES
        LDA     PPRI,U          ;IS THIS A PRIMARY PROCESS??
        BNE     EXEPRI          ; BR=NO, SKIP THIS PROCESS
        DEC     PNAP,U          ;1 LESS NAP TIME UNIT
        BEQ     EXELOP
        BRA     EXEPRI
;*
EXEPEN  LDS     #STACK          ;STACK IS RESET
        COM     PRISEC          ;START SECONDARY PROCESSES
        LDU     PSEC            ;START SECONDARY LIST
        BNE     EXESEC
        LDU     #PDUMMY
;*
EXESEC  STU     PPREV           ;REMEMBER LAST PROCESS EXECUTED
        LDA     [PDTBL]         ;SECONDARY PROCESS TIME UP?
        BEQ     EXESE2          ; BR=YES
        LDU     PLINK,U         ;NEXT PROCESS
        BEQ     EXESEN          ; BR=NO MORE SECONDARY PROCESSES
        LDA     PPRI,U          ;IS THIS A SECONDARY PROCESS??
        BEQ     EXESEC          ; BR=NO, SKIP THIS PROCESS
        DEC     PNAP,U          ;1 LESS NAP TIME UNIT
        BEQ     EXELOP
        BRA     EXESEC
;*
EXESE2  NOP
EXESEN  STU     PSEC            ;(REMEMBER LAST SECONDARY PROCESS)
;*
EXEDON  EQU     *               ;NOW COMPLETE THE ERASE & WRITE LINKS
;*
      IF DEBUG2 <> 0                                                            ;;Fixme was: IFN DEBUG2
        LDD     DMAFRE          ;OVER WRITE DMA TABLE?
        SUBD    DTBL
        CMPD    #DTBL2-DTBL1
        BLS     DTBOVR          ; BR=NO
        SWI                     ;OVER WROTE DMA TABLE!!
      ENDIF
DTBOVR  LDU     DTBL            ;POINT TO CURRENT DMA TABLE
        STU     PDTBL           ; (WILL BE PREVIOUS DATA TABLE)
        LEAU    DTBL1A-DTBL1,U  ;POINT TO DMA TABLES INTERUPT LINK AREA
        LDX     #0              ;A ZERO FOR END OF LINK(S)
        LDD     DMABEG+ERASE+QUADA      ;FOR INTERUPT B, LINK CLEAR A
        STD     ,U
        STX     [DMAEND+ERASE+QUADA]    ;(END OF LINKS)
;*
DTBC1   LDD     DMABEG+ERASE+QUADB      ;FOR INTERUPT C - CLR B, WR A
        BNE     DTBC2
        LDD     DMABEG+WRITE+QUADA
        STD     2,U
        BRA     DTBC2A
DTBC2   STD     2,U                     ;CLR B EXISTS, SO LINK IN WR A
        LDD     DMABEG+WRITE+QUADA
        STD     [DMAEND+ERASE+QUADB]
DTBC2A  STX     [DMAEND+WRITE+QUADA]
;*
DTBD1   LDD     DMABEG+ERASE+QUADC      ;FOR INTERUPT D - CLR C, WR B
        BNE     DTBD2
        LDD     DMABEG+WRITE+QUADB
        STD     4,U
        BRA     DTBD2A
DTBD2   STD     4,U                     ;CLR C EXISTS, SO LINK IN WR B
        LDD     DMABEG+WRITE+QUADB
        STD     [DMAEND+ERASE+QUADC]
DTBD2A  STX     [DMAEND+WRITE+QUADB]
;*
DTBA1   LDD     DMABEG+ERASE+QUADD      ;FOR INTERUPT A - CLR D, WR C, WR D
        BNE     DTBA3
        LDD     DMABEG+WRITE+QUADC
        BNE     DTBA2
        LDD     DMABEG+WRITE+QUADD
        STD     6,U
        BRA     DTBA4A
DTBA2   STD     6,U                     ;WR C EXISTS ONLY, SO LINK IN WR D
        LDD     DMABEG+WRITE+QUADD
        STD     [DMAEND+WRITE+QUADC]
        BRA     DTBA4A
DTBA3   STD     6,U                     ;CLR D EXISTS, LINK WR C OR WR D?
        LDD     DMABEG+WRITE+QUADC
        BNE     DTBA4
        LDD     DMABEG+WRITE+QUADD
        STD     [DMAEND+ERASE+QUADD]
        BRA     DTBA4A
DTBA4   STD     [DMAEND+ERASE+QUADD]    ;CLR D, WR C EXISTS, SO LINK IN WR D
        LDD     DMABEG+WRITE+QUADD
        STD     [DMAEND+WRITE+QUADC]
DTBA4A  STX     [DMAEND+WRITE+QUADD]
;*
DTBEN   INC     DTBL1-DTBL1A,U          ;INDICATE BUFFER READY FOR INTERUPTS
        JMP     EXECST          ;LOOP FOREVER
;*
;*      SUCIDE, KILL YOURSELF (EITHER JSR OR JMP)
;*
SUCIDE  LDS     #STACK          ;STACK IS IN THE CLEAR
        LDU     PEXEC           ;GET EXECUTING PROCESSES BLOCKS
        LDD     PLINK,U         ;LINK NEXT TASK TO...
        STD     [PPREV]         ; PREVIOUSES TASK LINK
        LDD     PFREE           ;LINK 1ST FREE RAM LINK TO..
        STD     PLINK,U         ; THIS CURRENTLY DELETING TASK
        STU     PFREE           ;LINK DELETEING TASK TO FREE RAM LINK
        LDU     PPREV           ;MAINTAIN PREVIOUS LINK
        JMP     EXEPS           ;CONTINUE IN EXEC LOOP
      IF DEBUG2 = 0                                                             ;;Fixme was: IFE DEBUG2
;*
;*      AND THE EVER POPULAR COPYRIGHT MESSAGE
;*
        FCC     'JOUST (C)1982 WILLIAMS ELECTRONICS INC.'
      ENDIF
;*
;*      KILL ANY PROCESSES (NOT INCLUDING ITSELF)
;*              INPUTS REG.A = PROCESS I.D.
;*                     REG.B = MASK FOR MORE THAN 1 I.D.
;*
KLPROC  PSHS    D,U
        LDX     #PDUMMY         ;INIT DUMMY PREVIOUS PROCESS ADDRESS
        LDU     PDUMMY          ;INIT CURRENT PROCESS AS BEGINNING OF LIST
        BEQ     KLPRTS          ; BR=NO PROCESSES TO KILL
KLPLOP  LDB     1,S             ;GET PROCESS MASK
        ANDB    PID,U           ;DISCARD UNWANTED BITS
        CMPB    ,S              ;COMPARE WITH PROCESS I.D. TO MATCH
        BNE     KLPNOM          ; BR=NO MATCH
        CMPU    PEXEC           ;IS THIS THE KILLER?
        BNE     KLPKIL          ; BR=NO, GO KILL IT
        STX     PPREV           ;UPDATE PREVIOUSLY EXECUTED PROC(IN CASE OF KIL)
KLPNOM  TFR     U,X             ;CURRENT PROCESS IS NOW PREVIOUS PROCESS
KLPNXT  LDU     PLINK,U         ;GETTING NEW CURRENT PROCESS
        BNE     KLPLOP
KLPRTS  PULS    D,U,PC
;*
KLPKIL  CMPU    PSEC            ;IS THE SECONDARY EXECUTION TASK LIST HERE?
        BNE     KLPSEC          ; BR=NO
        STX     PSEC            ;YES, REMEMBER PREVIOUS ACTIVE TASK ADDRESS
KLPSEC  LDD     PLINK,U         ;LINK NEXT TASK TO...
        STD     PLINK,X         ; PREVIOUSES TASK LINK
        LDD     PFREE           ;LINK 1ST FREE RAM LINK TO..
        STD     PLINK,U         ; THIS CURRENTLY DELETING TASK
        STU     PFREE           ;LINK DELETEING TASK TO FREE RAM LINK
        TFR     X,U             ;GET BACK INTO ACTIVE TASK LIST
        BRA     KLPNXT          ;THE OLD PROCESS IS STILL THE OLD PROCESS
;*
;*
;*      CREATE A PROCESS AFTER CURRENT PROCESS
;*              INPUT REG.X = START ADDRESS
;*                    REG.A = PROCESS I.D.
;*                    REG.B = PRIMARY (0) OR SECONDARY (<>0) SELECTION
;*                    PEXEC = CURRENT PROCESS BEING EXECUTED
;*              OUTPUT REG.Y = NEW PROCESSES BLOCK ADDRESS
;*                     REG.U = CURRENT PROCESS BEING EXECUTED
;*
CRPROC  LDU     PEXEC
;
;
;       CREATE A PROCESS AFTER REG.U PROCESS
;               INPUT REG.X = START ADDRESS
;                     REG.A = PROCESS I.D.
;                     REG.B = PRIMARY (0) OR SECONDARY (<>0) SELECTION
;                     REG.U = CURRENT PROCESS BLOCK, NEW PROCESS WILL BE NEXT
;               OUTPUT REG.Y = NEW PROCESSES BLOCK ADDRESS
;
CUPROC  PSHS    D
        LDY     PFREE
      IF DEBUG2 <> 0                                                            ;;Fixme was: IFN DEBUG2
         BNE    CRPRAM          ;BR=RAM AVAILABLE
         SWI                    ;HERE IF OUT OF PROCESS BLOCKS
      ENDIF
CRPRAM  LDD     PLINK,Y         ;REMOVE NEW LINK FROM..
        STD     PFREE           ; FREE PROCESS RAM
        LDD     PLINK,U         ;MAKE NEXT ACTIVE PROC LINK AFTER...
        STD     PLINK,Y         ; NEWLY CREATED PROCESS
        STY     PLINK,U         ;ACTIVATE LINK TO NEWLY CREATE PROCESS
        LDA     #1              ;NEW - WAKE-UP IMMEDIATELY
        STA     PNAP,Y
        STX     PPC,Y           ;NEW - PC LOCATION
        PULS    D
        STA     PID,Y           ;NEW - PROCESS I.D.
        STB     PPRI,Y          ;NEW - PRIMARY/SECONDARY PROCESS SELECTION
        RTS
;*
;*      ALLOCATE DMA AREA FOR ERASE OPERATION
;*       INPUT REG.B = LOWEST REG.Y LOCATION
;*       OUTPUT REG.X = DMA BLOCK AREA
;*
CL1ALL  ANDB    #$C0            ;CALC QUADRANT'S POINTER ADDRESS
        LDX     #DMAEND+ERASE
        ABX
        LDD     DMAFRE          ;GET SOME FREE RAM FOR THIS DMA OPERATION
        STD     [,X]
        ADDD    #8
        STD     ,X
        ADDD    #2
        LDX     DMAFRE
        STD     DMAFRE          ;1 LESS SPACE IN FREE DMA RAM
        RTS
;*
;*      ALLOCATE DMA AREA FOR WRITE OPERATION
;*       INPUT REG.B = LOWEST REG.Y LOCATION
;*       OUTPUT REG.X = DMA BLOCK AREA
;*              CLSX,CLSY = SCREEN OFFSETS
;*
WR1ALL  ANDB    #$C0            ;CALC QUADRANT'S POINTER ADDRESS
        LDX     #DMAEND+WRITE
        ABX
        LDD     DMAFRE          ;GET SOME FREE RAM FOR THIS DMA OPERATION
        STD     [,X]
        ADDD    #8
        STD     ,X
        ADDD    #2
        LDX     DMAFRE
        STD     DMAFRE          ;1 LESS SPACE IN FREE DMA RAM
        RTS
;*
;*      ALLOCATE & FLAVOR AREA FOR 1 ERASE OPERATION
;*       INPUT REG.U = PROCESS AREA OF OBJECT
;*       OUTPUT REG.X = DMA BLOCK AREA
;*              CLSX,CLSY = SCREEN OFFSETS
;*
CL1CLS  LDB     PPOSY+1,U
        STB     CLSY            ;NEW CLASIFIED Y CO-ORDINATE
        ANDB    #$C0            ;CALC QUADRANT'S POINTER ADDRESS
        LDX     #DMAEND+ERASE
        ABX
        LDD     DMAFRE          ;GET SOME FREE RAM FOR THIS DMA OPERATION
        STD     [,X]
        ADDD    #8
        STD     ,X
        ADDD    #2
        LDX     DMAFRE
        STD     DMAFRE          ;1 LESS SPACE IN FREE DMA RAM
        LDD     PPOSX,U
      IF DEBUG2 <> 0                                                            ;;Fixme was: IFN DEBUG2
         CMPD   #310            ;DO NOT WRITE INTO SCRATCH PAD OR I/O AREA
         BLO    .1S
         CMPD   #-16
         BHI    .1S
         SWI
.1S                                                                             ;;Fixme was: 1$
      ENDIF
        RORA
        RORB
        STB     CLSX            ;NEW SCREEN X LOCATION
        LDA     #$1A            ;ASSUME SER/BLOCK, CONSTANT, & ZERO TRANSFER
        BCC     CL1NOF
        ORA     #$20            ;FLAVOR THE IMAGE
CL1NOF  CLRB                    ;ZERO CONSTANT BYTE
        STD     ,X              ;DEFAULT DMA COMMAND
        RTS
;*
;*      ALLOCATE & FLAVOR AREA FOR 1 WRITE OPERATION
;*       INPUT REG.U = PROCESS BLOCK WITH VALID PPOSX,PPOSY
;*       OUTPUT REG.X = DMA BLOCK AREA
;*              CLSX,CLSY = SCREEN OFFSETS
;*
WR1CLS  LDB     PPOSY+1,U
        STB     CLSY            ;NEW CLASIFIED Y CO-ORDINATE
        ANDB    #$C0            ;CALC QUADRANT'S POINTER ADDRESS
        LDX     #DMAEND+WRITE
        ABX
        LDD     DMAFRE          ;GET SOME FREE RAM FOR THIS DMA OPERATION
        STD     [,X]
        ADDD    #8
        STD     ,X
        ADDD    #2
        LDX     DMAFRE
        STD     DMAFRE          ;1 LESS SPACE IN FREE DMA RAM
        LDD     PPOSX,U
      IF DEBUG2 <> 0                                                            ;;Fixme was: IFN DEBUG2
         CMPD   #310            ;DO NOT WRITE INTO SCRATCH PAD OR I/O AREA
         BLO    .1S
         CMPD   #-16
         BHI    .1S
         SWI
.1S                                                                             ;;Fixme was: 1$
      ENDIF
        RORA
        RORB
        STB     CLSX            ;NEW SCREEN X LOCATION
        LDA     #$0A            ;ASSUME SERIAL TO BLOCK, ZERO SURPRESS TRANSFER
        BCC     WR1NOF
        ORA     #$20            ;FLAVOR THE IMAGE
WR1NOF  STA     ,X              ;DEFAULT DMA COMMAND
        RTS
;*
;*      ALLOCATE & FLAVOR AREA FOR 2 ERASE OPERATION
;*       INPUT REG.U = PROCESS BLOCK WITH VALID PPOSX,PPOSY
;*       OUTPUT REG.X = DMA BLOCK AREA
;*              CLSX,CLSY = SCREEN OFFSETS
;*
CL2CLS  LDB     PPOSY+1,U
        STB     CLSY            ;NEW CLASIFIED Y CO-ORDINATE
        ANDB    #$C0            ;CALC QUADRANT'S POINTER ADDRESS
        LDX     #DMAEND+ERASE
        ABX
        LDD     DMAFRE          ;GET SOME FREE RAM FOR THIS DMA OPERATION
        STD     [,X]
        ADDD    #8
        STD     ,X
        ADDD    #2
        STD     [,X]
        ADDD    #8
        STD     ,X
        ADDD    #2
        LDX     DMAFRE
        STD     DMAFRE          ;1 LESS SPACE IN FREE DMA RAM
        LDD     PPOSX,U
        RORA
        RORB
        STB     CLSX            ;NEW SCREEN X LOCATION
        LDA     #$1A            ;ASSUME SER/BLOCK, CONSTANT, & ZERO TRANSFER
        BCC     CL2NOF
        ORA     #$20            ;FLAVOR THE IMAGE
CL2NOF  CLRB                    ;ZERO CONSTANT BYTE
        STD     ,X              ;DEFAULT DMA COMMAND
        STD     10,X            ; IN BOTH AREA'S
        RTS
;*
;*      ALLOCATE & FLAVOR AREA FOR 2 WRITE OPERATION
;*       INPUT REG.U = PROCESS BLOCK WITH VALID PPOSX,PPOSY
;*       OUTPUT REG.X = DMA BLOCK AREA
;*              CLSX,CLSY = SCREEN OFFSETS
;*
WR2CLS  LDB     PPOSY+1,U
        STB     CLSY            ;NEW CLASIFIED Y CO-ORDINATE
        ANDB    #$C0            ;CALC QUADRANT'S POINTER ADDRESS
        LDX     #DMAEND+WRITE
        ABX
        LDD     DMAFRE          ;GET SOME FREE RAM FOR THIS DMA OPERATION
        STD     [,X]
        ADDD    #8
        STD     ,X
        ADDD    #2
        STD     [,X]
        ADDD    #8
        STD     ,X
        ADDD    #2
        LDX     DMAFRE
        STD     DMAFRE          ;1 LESS SPACE IN FREE DMA RAM
        LDD     PPOSX,U
        RORA
        RORB
        STB     CLSX            ;NEW SCREEN X LOCATION
        LDA     #$0A            ;ASSUME SERIAL TO BLOCK, ZERO SURPRESS TRANSFER
        BCC     WR2NOF
        ORA     #$20            ;FLAVOR THE IMAGE
WR2NOF  STA     ,X              ;DEFAULT DMA COMMAND
        STA     10,X            ; IN BOTH AREAS
        RTS
;*
;*
;*      INTERUPT HANDLER
;*
IRQ     STS     IRQSTK          ;REMEMBER STACK POINTER (NO DCON FROM NOW ON!)
        LDA     #WDATA
        STA     WDOG            ;TICKLE WATCH DOG
        INC     RANDOM
        DEC     RANDOM+1
        LDA     DRRUC           ;DMA READS ROM!
        ORA     #1
        STA     RRUC
        LDB     PIAB            ;CLEAR 4MS
        LDB     VSCAN
        ANDB    #$C0            ;SHOW ONLY VALID INTERUPT BITS
        LBNE    IRQ2            ;UPDATE COLOR RAM ON VERTICAL LINE 0
;*
;*      UPDATE COLOR RAM DURING VERTICAL RE-TRACE (REALLY TOP OF SCREEN)
;*
        LDU     #RAMCOL         ;COLOR RAM REFRESH (DURING VERTICAL RETRACE)
        PULU    D,X,Y,S
        LDU     #CRAM+8
        PSHU    D,X,Y,S
        LDU     #RAMCOL+8
        PULU    D,X,Y,S
        LDU     #CRAM+16
        PSHU    D,X,Y,S
        LDS     IRQSTK          ;RESTORE STACK POINTER
;*
;*      GAME TIME CALCULATIONS
;*
        LDA     GOVER           ;GAME OVER?
        BPL     .1S             ; BR=YES
        LDD     MINUTE          ;CALC NBR OF MINUTES IN AN ACTIVE GAME
        SUBD    #1
        BGT     .11S
        LDB     #6              ;INC BOOKS GAME TIME
        JSR     AUDIT1
        LDD     #60*60          ;NBR OF INTERUPTS UNTIL 1 MINUTE
.11S    STD     MINUTE                                                          ;;Fixme was: 11$
.1S                                                                             ;;Fixme was: 1$
;*
;*      SWITCH DEBOUNCER, USED FOR A COMMON GAME.
;*      THIS ROUTINE IS SERVICED EVERY 1/60 SEC AND 2 CONSECTIVE
;*      CLOSURES MEANS THE SWITCH IS CLOSED, THEN 9 CONSECTIVE OPENS
;*      MEANS THE SWITCH IS OPEN
;*
        LDA     SWSLAM          ;DECREMENT SLAM SWITCH TIMER DEBOUNCE
        BEQ     IRQSLM          ; BR=SLAM NEVER CLOSED
        DEC     SWSLAM          ; 1 LESS TIME UNIT TO GO.
IRQSLM
        LDD     SWT0+6          ;DEBOUNCE SWITCHES, MOVE SWITCH TIME TABLE
        STD     SWT0+7
        LDD     SWT0+4
        STD     SWT0+5
        LDD     SWT0+2
        STD     SWT0+3
        LDD     SWT0
        STD     SWT0+1
        LDA     PIAA            ;READ SWITCHES (3 COINS,H.S. RESET,ADVANCE)
        STA     SWT0+0
        BITA    #$40            ;SLAM SWITCH CLOSED?
        BEQ     IRQNSL          ; BR=NO
        LDB     #2*60           ;2 SECOND DELAY BEFORE COIN ACCEPTANCE
        STB     SWSLAM
IRQNSL
        LDB     SWT0+0          ;DEBOUNCE SO THAT 3 STABLE SAMPLES IS THE
        ORB     SWT0+1          ; DEBOUNCED STATE
        ORB     SWT0+2
        ORB     SWT0+3
        ORB     SWT0+4
        ORB     SWT0+5
        ORB     SWT0+6
        ORB     SWT0+7
        ORB     SWT0+8          ;THE MINIMIZED STATE TABLE IS
        ANDB    SWDEB           ; DEBounced switch
        STB     SWTEMP          ;  = T0*T1 + DEB*(T0+T1+T2+T3+T4+T5+T6+T7+T8)
        ANDA    SWT0+1
        ORA     SWTEMP
        LDB     SWDEB           ;REMEMBER OLD DEBOUNCED STATE FOR 0 TO 1 CHANGE
        STA     SWDEB
        COMB                    ;NOW, SHOW SWITCHES THAT JUST TURNED ON
        ANDB    SWDEB
        ANDB    #$3E            ;REVIEL DEBOUNCED SWITCHES TO ACT UPON
        BEQ     IRQNSW          ; BR=NO SWITCH PRESSED
        LSRB
        PSHS    B
        LSR     ,S              ;IS THIS SWITCH ACTIVE?
        BCC     IRNADV          ; BR=NO
        JSR     ADVANC          ;ADVANCE BUTTON PRESSED
IRNADV  LDA     SWSLAM          ;SLAM SWITCH CLOSED RECIENTLY?
        BNE     IRNRCO          ; BR=YES, SKIP COIN SWITCHES
        LSR     ,S              ;IS THIS SWITCH ACTIVE?
        BCC     IRNRCO          ; BR=NO
        JSR     COINRV          ;RIGHT COIN SLOT
IRNRCO  LSR     ,S              ;IS THIS SWITCH ACTIVE?
        BCC     IRNHSR          ; BR=NO
        JSR     RESHSB          ;H.S. RESET BUTTON PRESSED
IRNHSR  LDA     SWSLAM          ;SLAM SWITCH CLOSED RECIENTLY?
        BNE     IRNCCO          ; BR=YES, SKIP COIN SWITCHES
        LSR     ,S              ;IS THIS SWITCH ACTIVE?
        BCC     IRNLCO          ; BR=NO
        JSR     COINLV          ;LEFT COIN SLOT
IRNLCO  LSR     ,S              ;IS THIS SWITCH ACTIVE?
        BCC     IRNCCO          ; BR=NO
        JSR     COINCV          ;CENTER COIN SLOT
IRNCCO  PULS    B
IRQNSW  EQU     *               ;END OF SWITCH DEBOUNCER
;*
;*      BEAM INTERFERENCE FOR BUFFERED DMA I/O OPERATIONS
;*
IRQ2    LDX     ITBL            ;POINT TO SELECTED DMA TBLE BLOCK
        LDA     ISQCNT          ;REMEMBER LAST QUADRANT WRITTEN OUT
        TST     ,X              ;WHAT MODE IS CURRENT INTERUPT DMA TABLE IN?
        BEQ     IRQRTS          ;BR=FOREGROUND NOT READY WITH DATA
        BMI     IRQNXT          ; BR=ALREADY STARTED DMA'ING THIS TABLE
        COM     ,X+             ;NEW STARTING IMAGE, & POINT TO FIRST LINK
        STX     ISQPTR          ;REMEMBER THIS INTERUPT QUADRANT TO UPDATE
        CLRA                    ;1ST QUADRANT TO BE UPDATED
;*
;*      WARNING; SENSITIVE INTERUPT DRIVEN DMA OPERATIONS
;*              DMA OPERATION COULD HAVE DESTROYED REG.DP
;*
IRQNXT  STA     >ISQCNT
        EORA    >VSCAN          ;ABLE TO WRITE DATA IN THIS QUADRANT WITHOUT
        ANDA    #$C0            ; BEAM INTERFERANCE?
        BEQ     IRQRTS          ;BR=BEAM INTREFERANCE, DO NOT WRITE DATA!
        LDX     >ISQPTR         ;NEXT QUADRANT TO UPDATE ON SCREEN
        LDU     ,X++
        STX     >ISQPTR
        LEAX    0,U             ;ANY DATA TO MOVE?
        BEQ     IRQSKD          ; BR=NO, SO SKIP THE DMA OPERATION
        DEC     >CPIAB          ;DISABLE PIA INTERUPTS (PLAYING WITH CC)
        LDA     PIAB            ;CLEAR 4MS INTERUPT, JUST IN CASE...
IRQDMA  LDS     #DMA+8          ;START/RESTART DMA LOOPING
        PULU    CC,D,DP,X,Y
        PSHS    CC,D,DP,X,Y     ;DMA OPERATION STARTED & COMPLETED
        LDU     ,U              ;NEXT DMA OPERATION
        BNE     IRQDMA          ; BR=VALID LINK
        ORCC    #$FF            ;DMA COMPLETE, MAKE SURE INTERUPTS ARE OFF!
        INC     >CPIAB          ;ENABLE PIA INTERUPTS TO MICRO-PROCESSOR
IRQSKD  LDA     >ISQCNT         ;BUMP QUADRANT COUNTER (SAME AS VERT COUNTER)
        ADDA    #$40
        BNE     IRQNXT          ;BR=MORE QUADRANTS TO DO, TRY TO DO IT ANY WAYS
        LDX     >ITBL           ;FREE UP THE DMA BUFFER
        CLR     ,X
        LDX     #DTBL1          ;NEXT DMA BUFFER UPDATES SCREEN
        COM     >DMAINT
        BPL     IRQBUF          ; BR=DMA TABLE 1
        LDX     #DTBL2          ;HERE IF DMA TABLE 2
IRQBUF  STX     >ITBL           ;REMEMBER THIS TABLE
IRQRTS  LDS     >IRQSTK
        LDA     >DRRUC          ;RESTORE READ REGISTER!
        STA     >RRUC
        RTI
;*
;*      LOAD 16 COLOR BYTES FROM [REG.X] INTO RAM COPY
;*       (ONLY REFRESH COLOR I/O PORT RAM DURING VERTICAL RETRACE)
;*
DCOLOR  LDY     #RAMCOL         ;LOAD COPY OF COLOR RAM
DCOLR2  LDB     #16             ;16 COLORS
DCLRLP  LDA     ,X+
        STA     ,Y+
        DECB
        BNE     DCLRLP
        RTS
;*
;*      SIMPLE RANDOM NUMBER GENERATOR
;*       OUTPUT; REG.A - A RANDOM NUMBER 0 TO 127
;*               CARRY BIT - RANDOM BIT 0 OR 1
;*       DESTROIES; NONE (EXCEPT REG.A)
;*
RANDSYS LDA     RANDOM+1        ;RANDOM BIT (IN CARRY)                          ;;Fixme was: RAND
        LSRA
        LSRA
        LSRA
        EORA    RANDOM+1
        LSRA
        ROR     RANDOM
        ROR     RANDOM+1
        RTS
;*
;*      SIMPLE SOUND PROCESSOR
;*       INPUT; REG.X = ADDRESS OF SOUND TABLE
;*       OUTPUT; TOP MOST SOUND QUE'D & SENT AT BEGINNING OF NEXT FRAME
;*       DESTROIES; REG.D
;*
SND     LDA     ,X+             ;GET SOUND PIRORITY
        BMI     .1S             ;SOUND PIRORITYS OF 128 TO 255 ARE ALWAYS SENT
        LDB     GOVER           ;NO SOUNDS 0 TO 127 DURING END OF GAME
        BPL     NOSND
.1S     LDB     STMR            ;SOUND STILL SOUNDING                           ;;Fixme was: 1$
        BEQ     SN1NS           ; BR=NO SOUND
        CMPA    SPRI            ;OK TO INTERUPT THIS PIRORITY SOUND?
        BLO     NOSND           ; BR=NO
SN1NS   STA     SPRI            ;NEW PIRORITY
        LDA     #1              ;ALLOW FOR NEXT SOUND
        STA     STMR
        STX     SNDPTR          ;SAVE SOUND TABLE ADDRESS
NOSND   RTS
;*************************************************************************
;*      LAVA EFFECTS BY KEN LANTZ                                        *
;*                                                                       *
;*      TO BE STARTED AT BEGINNING OF GAME & CONTINUES TILL E.O.G.       *
;*      to be in high memory for screen access                           *
;*      ASSUMES SAFRAM TO BE $EA THEN $E5 THEN $E0                       *
;*************************************************************************
CLR3    EQU     $4      ;RED LAVA COLOR EQUATE
LNYBB   EQU     16      ;nybble moving constants left nybble = nybble *16       ;;Fixme was: LN (duplicate symbol)
RN      EQU     1       ;right nybble = nybble *1
BN      EQU     17      ;both nybbles = nybble *17   (hex equevelent of 11)
;*****************************************************************************
LAVA    LDX     #$00FF          ;start at the bottom left edge
;********       LDA     #$20            ;init-a-nap (used later)
;********       STA     PFRAME-1,U
        STX     SAFRM2          ;which we will refer to and update
        LDD     #LXPOST         ;INIT LAVA X POSITION SELECTOR
        STD     LXPOS2
NEXTLN  PCNAP   20              ;Sleep long enough for the cliffs to be in place
        LDX     SAFRM2          ;get the line and location
        LDB     #CLR3*BN        ;lava color
        LDA     DRRUC           ;LOOK AT THE SCREEN
        ANDA    #~$01                                                           ;;Fixme was: ANDA  #!N$01
        STA     DRRUC           ;THIS 1ST BECAUSE OF INTERUPTS USING THIS BIT
        STA     RRUC
.1S     STB     ,X                                                              ;;Fixme was: 1$
        LEAX    $100,X
        CMPX    #$9600          ;MAXIMUM SCREEN ADDRESS?
        BHI     SPECIAL         ; BR=YES
        LDA     ,X              ;is place in where ever
        ANDA    #$EE
        BEQ     .1S             ;BR = we don't have cliff
;*
SP1     BITA    #$F0            ;here we may have a pixel left over
        BNE     .2S             ; but then we must do the right side lava level
        ORA     #CLR3*LNYBB                                                     ;;Fixme was: ORA  #CLR3*LN
        STA     ,X
.2S     LDD     SAFRM2                                                          ;;Fixme was: 2$
        LDA     #$96            ;same loop but moving in from the right edge
        TFR     D,X
        LDB     #CLR3*BN
.1S     STB     ,X                                                              ;;Fixme was: 1$
        LEAX    -$100,X
        LDA     ,X
        BEQ     .1S
;*
SP2     BITA    #$0F            ;do we have a left over nybble?
        BNE     SPECIAL
        ORA     #CLR3*RN
        STA     ,X
SPECIAL LDA     DRRUC           ;!we are done with the screen so turn
        ORA     #$01            ; every thing back on
        STA     DRRUC           ;THIS 1ST BECAUSE OF INTERUPTS USING THIS BIT
        STA     RRUC
        DEC     SAFRM2+1        ;up one line
CHECK   LDB     SAFRM2+1
        CMPB    SAFRAM
        BGE     NEXTLN
;*
;* If lava is up to level process falls on thru to do the bubbles
;*
        PCNAP   1
        JSR     VRAND
        STA     PFRAME-1,U      ;pseudo random bubble location
        ANDA    #$0F
        LDX     LXPOS2
        LDA     A,X
        BCC     BURSTR
;*
;*      DO A "BUBBLE" OR A BUBBLE THAT IS IN MIDDLE OF THE LAVA
;*
        LDB     PFRAME-2,U
        ANDB    #$0F            ;limits bubbles to range E2 to EF
        ORB     #$02            ;so that they stay in the lava
        ADDB    SAFRM2+1        ;USE INTERNAL LIMITS, NOT SAFRAM
        INCB
        TFR     D,X
        STX     PFRAME+4,U
        LDA     #CLR3*LNYBB                                                     ;;Fixme was: LDA  #CLR3*LN
        STA     ,X
        LDX     #SNBUB          ;THE SOUND A BUBBLE MAKES
        JSR     SND
        PCNAP   8
        LDX     PFRAME+4,U
        LDA     #CLR3*RN        ;$03
        STA     0,X
        STA     $100,X
        LDA     #CLR3*LNYBB     ;$30                                            ;;Fixme was: LDA  #CLR3*LN
        STA     -1,X
        STA     1,X
        PCNAP   8
        LDX     PFRAME+4,U
        LDA     #CLR3*BN        ;$33
        STA     -1,X
        STA     0,X
        STA     1,X
        STA     $100,X
        LDA     #5
        ADDA    PFRAME-2,U      ;This rolls the height of the bubbles
        STA     PFRAME-2,U
        BRA     CHECK
;*
;*      DO A "BURSTER" OR A BUBBLE THAT IS ON THE SURFACE OF THE LAVA
;*
BURSTR  LDB     SAFRM2+1
        INCB
        STD     PFRAME+4,U
        TFR     D,X
        CLR     1,X
        PCNAP   8
        LDX     PFRAME+4,U
        LDB     #CLR3*BN
        STB     1,X
        CLR     0,X
        STB     -1,X
        PCNAP   8
        LDX     PFRAME+4,U
        LDB     #CLR3*BN
        STB     0,X
        STB     -$101,X
        STB     $FF,X
        CLR     -1,X
        PCNAP   8
        LDX     PFRAME+4,U
        CLR     -$101,X
        CLR     $FF,X
        JMP     CHECK
;*
LXPOST  FCB     $1C,$17,$10,$0D,$06,$04,$74,$78
        FCB     $7F,$85,$89,$8C,$15,$90,$83,$05
        FCB     $AC
;*
;*      SCREEN COLORS
;*
COLOR1  FCB     @000    ;@000   ;COLOR 0 - BACKGROUND COLOR
        FCB     @377    ;@377
        FCB     @160    ;@071   ;COLOR 2 -
        FCB     @130    ;@007
        FCB     @017    ;@017   ;COLOR 4 - MAN'S BODY
        FCB     @077    ;@077
        FCB     @121    ;@111   ;COLOR 6 -
        FCB     @350    ;@350
        FCB     @024    ;@024   ;COLOR 8 -
        FCB     @220    ;@220
        FCB     @135    ;@062   ;COLOR 10-
        FCB     @021    ;@145
        FCB     @037    ;@121   ;COLOR 12-
        FCB     @244    ;@244
        FCB     @012    ;@012   ;COLOR 14-
        FCB     @147    ;@147
;*
;*      ROUTINE TO DRIVE THE 1 COMPACTED IMAGE
;*
NEWCL5  LDX     #$1B*2          ;START X PIXEL POSITION ON SCREEN
        LDY     #$D3            ;START Y PIXEL POSITION ON SCREEN
        LDU     VCOMCL5         ;START OF COMPACTED DATA
;*                              ;FALL INTO UN-COMPACTING ROUTINE
;*
;*      UN-COMPACTING ROUTINE
;*       INPUT; REG.X = X PIXEL POSITION
;*              REG.Y = Y PIXEL POSITION
;*              REG.U = COMPACTED IMAGE START ADDRESS
;*
UNCOM   PSHS    D,X,Y           ;SAVE SOME REGGIES
        CLR     ,S              ;RESET COMPACT BIT MONITER
UNCLP   LDB     ,S              ;GET LAST COMPACTED BITS OF
        CLRA                    ;RESET LENGTH CODE
.10S    INCA                    ;1 MORE ENCODED LENGTH                          ;;Fixme was: 10$
        ASLB                    ;GET NEXT BIT
        BNE     .15S            ;BR=BYTE NOT EMPTY YET
        LDB     ,U+             ;NEXT COMPRESSED BYTE
        ASLB                    ;NEXT COMPRESSED BIT
        INCB                    ;SET BYTE EMPTY FLAG
.15S    BCC     .10S            ; BR=NOT AT END OF LENGTH                       ;;Fixme was: 15$
        BSR     REST            ;GET THE RESET OF THE CODEWORD IN REG.A
        SUBA    #2              ;CODEWORD & RUN LENGTH ARE TWO OFF
        STA     1,S             ;SAVE RUN LENGTH
        LDA     #3              ;GET 3 BIT COLOR ??NIBBLE??
        BSR     REST
        STB     ,S              ;SAVE THESE COMPACTED BITS
        LDB     1,S             ;GET SAVED RUN LENGTH
        BNE     .30S            ; BR=1 OR MORE RUN LENGTH (A VALID RUN LENGTH)
        ANDA    #$07            ;"END OF LINE" OR "END OF IMAGE"?
        BEQ     .25S            ; BR=EOI
        LDX     2,S             ;RELOAD BEGINNING OF PIXEL LINE
        LEAY    1,Y             ;NEXT PIXEL LINE
        BRA     UNCLP           ;DECODE NEXT LINE
;*
.25S    PULS    D,X,Y,PC        ;RETURN TO CALLER                               ;;Fixme was: 25$
;*
.30S    ANDA    #$07            ;UNCOMAPCT 3 BIT COLOR NIBBLE                   ;;Fixme was: 30$
        BEQ     .33S
        ADDA    #8-1
.33S    EQU     *                                                               ;;Fixme was: 33$
;*
;*      WRITE PIXEL ROUTINE (NEEDS TO READ SCREEN)
;*      INPUT;  REG.A = LOWER NIBBLE OF COLOR
;*              REG.X = X PIXEL POSITION
;*              REG.Y = Y PIXEL POSITION
;*      OUPUT;  REG.X = REG.X+1
;*              PIXEL ON THE SCREEN
;*
WRPIX   PSHS    D,Y             ;SAVE REGGIES AGAIN
        LDA     DRRUC           ;LOOK AT THE SCREEN
        ANDA    #~$01                                                           ;;Fixme was: ANDA  #!N$01
        STA     DRRUC           ;THIS 1ST BECAUSE OF INTERUPTS USING THIS BIT
        STA     RRUC
.33S    TFR     X,D             ;CALC X BYTE LOCATION                           ;;Fixme was: 33$
        RORA
        RORB
        TFR     B,A
        LDB     3,S             ;GET Y BYTE LOCATION
        TFR     D,Y             ;CRT ADDRESS FOR THE PIXEL
        LDA     ,S              ;GET COLOR NIBBLE
        BCS     .10S            ; BR=LOWER NIBBLE (ODD X PIXEL ADDRESS)
        ASLA
        ASLA
        ASLA
        ASLA
.10S    ORA     ,Y              ;ASSUMES A BLANK SCREEN                         ;;Fixme was: 10$
        STA     ,Y
        LEAX    1,X             ;NEXT PIXEL LOCATION
        DEC     1,S             ;       ANY MORE RUNS LEFT FOR THIS LENGTH?
        BNE     .33S            ; BR=YES
        LDA     DRRUC           ;LOOK AT THE ROM
        ORA     #$01
        STA     DRRUC           ;THIS 1ST BECAUSE OF INTERUPTS USING THIS BIT
        STA     RRUC
        PULS    D,Y
        BRA     UNCLP           ;DECODE NEXT RUN LENGTH
;*
;*      DECODE THE REST OF THE INFORMATION
;*       INPUT; REG.A = NUMBER OF BITS TO FETCH
;*              REG.B = NORMAL COMPACTED BITS LEFT
;*              REG.U = CURRENT ADDRESS OF NEXT BIT
;*      OUPUT;  REG.A = UNCOMPRESSED DATA
;*              REG.B & REG.U = CONTINUATING COMPRESSED STATUS
;*
REST    PSHS    A               ;SAVE NBR OF BITS TO GET
        LDA     #1              ;RUN LENGTH START BIT
.10S    ASLB                    ;GET NEXT BIT                                   ;;Fixme was: 10$
        BNE     .15S            ;BR=BYTE NOT EMPTY YET
        LDB     ,U+             ;NEXT COMPRESSED BYTE
        ASLB                    ;NEXT COMPRESSED BIT
        INCB                    ;SET BYTE EMPTY FLAG
.15S    ROLA                    ;PUT BIT INTO ANSWER                            ;;Fixme was: 15$
        DEC     ,S              ;ANY MORE BITS LEFT?
        BNE     .10S            ; BR=YES
        LEAS    1,S             ;UNSAVE THE BIT LENGTH DATA
        RTS
;*
;*      SOUND TABLE FOR THE MODULE
;*
SNBUB   FCB     001,$72,1               ;THE SOUND OF A BUBBLE
;*
SYSEND  EQU     *       ;SHOULDN'T BE GREATER THAN $E697                        ;;Fixme was: ENDADR (duplicate symbol)
SYSLEN  EQU     *-SYSV                                                          ;;Fixme was: LENGTH (duplicate symbol)
        IF *-$E697 > 0                                                          ;;Fixme was: IFGT *-$E697
         FCB    $1111   ;ADDRESS GREATER THAN $E697 ERROR
        ENDIF
;*
        ORG     $EFF0
        FDB     SYSV,SYSV,SYSV,SYSV,IRQ,SYSV,SYSV,SYSV
;       END     ;SYSV                                                           ;;We don't need this