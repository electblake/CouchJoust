;       NOGEN
;       NCLIST
;       BLIST
;*
;*      COLISION OFFSET FOR DETECTING END OF POINTERS & NO COLISION POINTERS
;*
COFF    EQU     $0200
DMAFIX  EQU     $0404
;*
;*      POSITIVE Y-DIRECTION OFFSET MACRO
;*
POSOFF  MACRO   COLISN,XOFF,YOFF,SRC
         FDB    COLISN,XOFF*256+256-YOFF,SRC
        ENDM
;*
;*      IMAGES FOR JOUST
;*
        ORG     $0000
PLAYER  EQU     0       ;FOR DEBUGGING PURPOSES
        FDB     _CLIF1L                                                         ;;Fixme was: FDB        CLIF1L
        FDB     _CLIF1R                                                         ;;Fixme was: FDB        CLIF1R
        FDB     _CLIF2                                                          ;;Fixme was: FDB        CLIF2
        FDB     _CLIF3U                                                         ;;Fixme was: FDB        CLIF3U
        FDB     _CLIF3L                                                         ;;Fixme was: FDB        CLIF3L
        FDB     _CLIF3R                                                         ;;Fixme was: FDB        CLIF3R
        FDB     _CLIF4                                                          ;;Fixme was: FDB        CLIF4
        FDB     _CLIF5  ;BOTTOM CLIFF                                           ;;Fixme was: FDB        CLIF5
        FDB     _TRANS1 ;TRANSPORTER #1                                         ;;Fixme was: FDB        TRANS1
        FDB     _TRANS2 ;TRANSPORTER #2                                         ;;Fixme was: FDB        TRANS2
        FDB     _TRANS3 ;TRANSPORTER #3                                         ;;Fixme was: FDB        TRANS3
        FDB     _TRANS4 ;TRANSPORTER #4                                         ;;Fixme was: FDB        TRANS4
        FDB     _OSTRICH                                                        ;;Fixme was: FDB        OSTRICH
        FDB     _BUZARD                                                         ;;Fixme was: FDB        BUZARD
        FDB     _STORK  ;TOP AREA BIRD                                          ;;Fixme was: FDB        STORK
        FDB     _PLYR1  ;THE LEFT & RIGH PLAYER #1 IMAGE                        ;;Fixme was: FDB        PLYR1
        FDB     _PLYR2  ;THE LEFT & RIGH PLAYER #2 IMAGE                        ;;Fixme was: FDB        PLYR2
        FDB     _PLYR3  ;THE LEFT & RIGH PLAYER #3 IMAGE                        ;;Fixme was: FDB        PLYR3
        FDB     _PLYR4  ;THE LEFT & RIGH PLAYER #4 IMAGE                        ;;Fixme was: FDB        PLYR4
        FDB     _PLYR5  ;THE LEFT & RIGH PLAYER #5 IMAGE                        ;;Fixme was: FDB        PLYR5
        FDB     _EGGI   ;EGG STILLS & HATCHING                                  ;;Fixme was: FDB        EGGI
        FDB     _ILAVAT ;LAVA TROLL HANDS                                       ;;Fixme was: FDB        ILAVAT
        FDB     _IFLAME ;LAVA FLAMES                                            ;;Fixme was: FDB        IFLAME
        FDB     _POOF1  ;PLAYER POOF DEATH                                      ;;Fixme was: FDB        POOF1
        FDB     _POOF2  ;PLAYER POOF DEATH                                      ;;Fixme was: FDB        POOF2
        FDB     _POOF3  ;PLAYER POOF DEATH                                      ;;Fixme was: FDB        POOF3
        FDB     _IPTERO ;PTERODACTYL LEFT/RIGHT 3 FRAME ANAIMATION              ;;Fixme was: FDB        IPTERO
        FDB     _COMCL5 ;THE COMPACTED CLIFF5                                   ;;Fixme was: FDB        COMCL5
        FDB     _ASH1R  ;A DISOULVING PTERODACTYL                               ;;Fixme was: FDB        ASH1R
        FDB     _ASH1L  ;A DISOULVING PTERODACTYL                               ;;Fixme was: FDB        ASH1L
;*
;*      CLIFF1L
;* 0145 START ADDRESS
;* 17 BY 7 BYTES
_CLIF1L FDB     CCLF1L,CSRC1L,$0145,$1107!DMAFIX                                ;;Fixme was: !XDMAFIX
        FDB            CSRC1L,$0145,$1106!DMAFIX                                ;;Fixme was: !XDMAFIX
CSRC1L
        FCB $AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA,$A0
        FCB $88,$8C,$CC,$CA,$AE,$EC,$CC,$CC,$88,$8C,$CC,$AA,$CC,$CC,$CC,$CC,$C0
        FCB $88,$CC,$C8,$88,$88,$EE,$CC,$88,$88,$CC,$88,$8C,$EE,$E8,$88,$00,$00
        FCB $EE,$EE,$EE,$C8,$88,$CE,$EC,$C8,$88,$8C,$EE,$E8,$8C,$EE,$00,$00,$00
        FCB $EE,$EE,$EE,$EE,$EE,$8E,$EE,$C8,$8C,$CE,$EE,$EE,$E8,$00,$00,$00,$00
        FCB $EE,$EE,$EE,$EE,$EE,$EC,$EE,$EE,$88,$EE,$EE,$EE,$E0,$00,$00,$00,$00
        FCB $00,$00,$00,$00,$00,$00,$00,$00,$8E,$EE,$EE,$E0,$00,$00,$00,$00,$00
;*
CCLF1L  FDB     10+COFF,35+32+COFF      ;CLIF1L STARTS -9 TO 33 PIXEL (INCLUDING
;ZERO)
        FDB     10+COFF,35+32+COFF
        FDB     10+COFF,32+32+COFF
        FDB     10+COFF,30+32+COFF
        FDB     10+COFF,28+32+COFF
        FDB     10+COFF,27+32+COFF
        FDB     19+32+COFF,25+32+COFF
        FDB     $8100,$8100             ;TERMINATING POINTER
;*
;*      CLIFF1R
;* $7E45
;* 18 BY 7 BYTES
_CLIF1R FDB     CCLF1R,CSRC1R,$7E45,$1807!DMAFIX                ;OLD X FC       ;;Fixme was: !XDMAFIX
        FDB            CSRC1R,$7E45,$1806!DMAFIX                                ;;Fixme was: !XDMAFIX
CSRC1R
 FDB $AAAA,$AAAA,$AAAA,$AAAA,$AAAA,$AAAA,$AAAA,$AAAA,$AAAA,$AAAA,$AAAA,$AAA0
 FDB $CCCC,$C888,$88CC,$888A,$CC88,$88CC,$8CCC,$CAAC,$CCAA,$AA88,$CC88,$8AA0
 FDB $000E,$EEEE,$EEE8,$8888,$CCCC,$888C,$EEE8,$8888,$88AA,$88CE,$E888,$8880
 FDB $0000,$00EE,$EEEE,$EE88,$8888,$88CE,$EEEE,$E8C8,$888C,$CEEE,$EEE8,$8880
 FDB $0000,$0000,$CCC8,$888E,$EEEE,$EEEE,$EEEE,$E8EE,$EEE8,$8EEE,$EC8E,$EEE0
 FDB $0000,$0000,$888E,$EEEE,$EEEE,$EEEE,$EEEE,$EEEE,$EEE8,$CEEE,$E8EE,$EEE0
 FDB $0000,$0000,$0000,$0000,$0000,$0000,$0000,$0EEE,$EE88,$0000,$08EE,$EEE0
;*
CCLF1R  FDB     1+COFF,36+32+COFF               ;CLIF1R GOES 10 MORE PIXELS OFF S
CREEN
        FDB     1+COFF,36+32+COFF
        FDB     4+COFF,36+32+COFF
        FDB     7+COFF,36+32+COFF
        FDB     9+COFF,36+32+COFF
        FDB     9+COFF,36+32+COFF
        FDB     30+COFF,36+32+COFF
        FDB     $8100,$8100             ;TERMINATING POINTER
;*
;*      AND THE EVER POPULAR COPYRIGHT MESSAGE
;*
        FCC     'JOUST (C) 1982 WILLIAMS ELECTRONICS INC.'
;*
;*      CLIFF2
;* $2B51
;* 44 BY 9 BYTES
_CLIF2  FDB     CCLF2,CSRC2,$2B51,$2C09!DMAFIX  ;OLD X $56                      ;;Fixme was: !XDMAFIX
        FDB           CSRC2,$2B51,$2C08!DMAFIX                                  ;;Fixme was: !XDMAFIX
CSRC2
        FCB      $AA,$AA,$AA,$AA,$AA,$AA,$AC,$CC,$C8,$EE,$DD
        FCB     $DD,$DD,$DD,$DD,$DD,$DD,$DD,$DD,$DD,$DD,$DD
        FCB     $DD,$DD,$EC,$CC,$AC,$CA,$CA,$AA,$AA,$AA,$AA
        FCB     $AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA
        FCB      $AA,$AA,$AA,$AC,$CC,$CC,$CC,$CC,$C8,$8E,$ED
        FCB     $DD,$DD,$DD,$DD,$DD,$DD,$DD,$DD,$DD,$DD,$DD
        FCB     $DD,$DE,$88,$88,$88,$88,$CC,$CC,$CC,$CC,$CA
        FCB     $AA,$AC,$CC,$CC,$CA,$AA,$CC,$CC,$CC,$CC,$CC
        FCB      $00,$0C,$CC,$C8,$88,$88,$CC,$CC,$88,$88,$EE
        FCB     $ED,$DD,$DD,$DD,$DD,$DD,$DD,$DD,$DD,$DD,$DD
        FCB     $DE,$E8,$88,$88,$88,$88,$88,$8C,$CC,$CC,$CC
        FCB     $8C,$C8,$8C,$CC,$CC,$88,$8E,$EE,$EE,$E0,$00
        FCB      $00,$00,$00,$EE,$EE,$EE,$EE,$E8,$8E,$E8,$88
        FCB     $EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE
        FCB     $EE,$8E,$EE,$88,$88,$8E,$88,$88,$88,$88,$88
        FCB     $88,$88,$88,$88,$EE,$EE,$EE,$EC,$CC,$00,$00
        FCB      $00,$00,$00,$00,$CC,$CC,$88,$88,$88,$EE,$E8
        FCB     $88,$8E,$EE,$E8,$88,$8E,$88,$8E,$EE,$88,$EE
        FCB     $EE,$EE,$EE,$EE,$EE,$EE,$EE,$88,$CC,$8C,$C8
        FCB     $88,$88,$EE,$EE,$88,$88,$8E,$C8,$88,$00,$00
        FCB      $00,$00,$00,$CC,$88,$88,$88,$EE,$EE,$88,$EE
        FCB     $E8,$EE,$88,$8E,$EE,$E8,$88,$EE,$E8,$88,$CC
        FCB     $EE,$EE,$EE,$EE,$EE,$88,$88,$EE,$EE,$E8,$CC
        FCB     $88,$EE,$EE,$88,$8E,$EE,$E8,$EE,$EE,$00,$00
        FCB      $00,$00,$00,$88,$8E,$EE,$EE,$EE,$EE,$E8,$8E
        FCB     $EE,$E8,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$E8,$88
        FCB     $CE,$EE,$EE,$EE,$88,$EE,$EE,$EE,$EE,$EE,$E8
        FCB     $CE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$00,$00,$00
        FCB      $00,$00,$00,$00,$00,$00,$EE,$EE,$EE,$EE,$EE
        FCB     $EE,$88,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$E8
        FCB     $88,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE
        FCB     $80,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
        FCB      $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
        FCB     $00,$8E,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE
        FCB     $88,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
        FCB     $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
;*
CCLF2   FDB     1+COFF,88+COFF
        FDB     1+COFF,88+COFF
        FDB     4+COFF,85+COFF
        FDB     7+COFF,84+COFF
        FDB     9+COFF,84+COFF
        FDB     7+COFF,84+COFF
        FDB     7+COFF,82+COFF
        FDB     13+COFF,67+COFF
        FDB     25+COFF,46+COFF
        FDB     $8100,$8100             ;TERMINATING POINTER
;*
;*      CLIFF3L
;* 018A
;* 32 BY 8 BYTES
_CLIF3L FDB     CCLF3L,CSRC3L,$018A,$2008!DMAFIX                                ;;Fixme was: !XDMAFIX
        FDB            CSRC3L,$018A,$2007!DMAFIX                                ;;Fixme was: !XDMAFIX
CSRC3L
        FCB     $0A,$AA,$AA,$AA,$AA,$AA,$EE,$DD,$DD,$DD,$DD,$DD,$DD,$DD,$DD,$DD
        FCB $DD,$DD,$DD,$DD,$DD,$EA,$AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA
        FCB     $06,$AA,$AA,$AA,$CC,$C8,$8E,$ED,$DD,$DD,$DD,$DD,$DD,$DD,$DD,$DD
        FCB $DD,$DD,$DD,$DD,$DE,$88,$88,$CE,$AA,$CC,$A8,$88,$88,$88,$CC,$CC
        FCB     $08,$88,$88,$88,$8E,$E8,$88,$EE,$ED,$DD,$DD,$DD,$DD,$DD,$DD,$DD
        FCB $DD,$DD,$DD,$DE,$E8,$88,$C8,$EE,$88,$88,$CC,$CE,$EE,$EE,$E0,$00
        FCB     $08,$88,$88,$88,$88,$EE,$E8,$88,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE
        FCB $EE,$EE,$EE,$EE,$88,$C8,$EE,$E8,$88,$88,$8E,$EE,$EE,$EE,$00,$00
        FCB     $08,$88,$88,$88,$88,$EE,$EE,$E8,$88,$88,$88,$88,$88,$88,$88,$88
        FCB $88,$88,$88,$88,$EE,$EE,$EE,$88,$88,$CC,$CC,$C8,$88,$EE,$00,$00
        FCB     $00,$00,$00,$00,$00,$00,$0E,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE
        FCB $EE,$EE,$EE,$EE,$EE,$EE,$CC,$EE,$EE,$EE,$EE,$EC,$80,$00,$00,$00
        FCB     $00,$00,$00,$00,$00,$00,$00,$00,$0E,$EE,$EE,$EE,$EE,$EE,$EE,$EE
        FCB $EE,$EE,$EE,$EE,$EE,$C8,$8E,$EE,$EE,$EE,$EE,$EE,$EE,$00,$00,$00
        FCB     $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
        FCB $00,$00,$00,$00,$08,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$00,$00,$00
;*
CCLF3L  FDB     1+COFF,66+32+COFF
        FDB     1+COFF,66+32+COFF
        FDB     1+COFF,63+32+COFF
        FDB     1+COFF,62+32+COFF
        FDB     1+COFF,62+32+COFF
        FDB     15+32+COFF,59+32+COFF
        FDB     19+32+COFF,60+32+COFF
        FDB     44+32+COFF,60+32+COFF
        FDB     $8100,$8100             ;TERMINATING POINTER
;*
;*      CLIFF3U
;* $6581
;* 43 BY 16 BYTES
_CLIF3U FDB     CCLF3R,CSRC3U,$6581,$1D0B!DMAFIX                ;OLD X CA       ;;Fixme was: !XDMAFIX
        FDB            CSRC3U,$6581,$1D0B!DMAFIX                                ;;Fixme was: !XDMAFIX
CSRC3U
        FCB     $AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA,$EE,$DD,$DD,$DD,$DD
        FCB     $DD,$DD,$DD,$DD,$DD,$DD,$DD,$DD,$DD,$DD,$EA,$AA,$AA,$AA
        FCB     $CC,$C8,$88,$88,$AA,$AA,$AC,$CC,$C8,$88,$8E,$ED,$DD,$DD,$DD
        FCB     $DD,$DD,$DD,$DD,$DD,$DD,$DD,$DD,$DD,$DE,$8C,$AA,$8C,$C0
        FCB     $08,$88,$8E,$EE,$EE,$CC,$CC,$CC,$CE,$88,$88,$EE,$ED,$DD,$DD
        FCB     $DD,$DD,$DD,$DD,$DD,$DD,$DD,$DD,$DE,$E8,$88,$8E,$EE,$00
        FCB     $0E,$EE,$EE,$EE,$EE,$88,$8E,$EE,$E8,$EE,$88,$88,$EE,$EE,$EE
        FCB     $EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$88,$8E,$EE,$E0,$00
        FCB     $00,$0C,$CC,$CC,$88,$88,$8C,$CC,$C8,$8E,$EE,$88,$88,$88,$88
        FCB     $88,$88,$88,$88,$88,$88,$88,$88,$88,$88,$88,$8C,$C0,$00
        FCB     $00,$00,$EE,$EE,$EE,$EE,$EE,$EE,$EC,$8E,$EE,$EE,$EE,$EE,$E8
        FCB     $88,$EE,$88,$88,$EE,$88,$88,$88,$EE,$EE,$8E,$E8,$00,$00
        FCB     $00,$00,$00,$0E,$EE,$EE,$EE,$EE,$EE,$88,$8E,$EE,$EE,$E8,$8E
        FCB     $EE,$EE,$EE,$EE,$E8,$88,$EE,$EE,$EE,$E8,$88,$E0,$00,$00
        FCB     $00,$00,$00,$00,$00,$00,$00,$00,$00,$0E,$EE,$EE,$EE,$C8,$EE
        FCB     $EE,$EE,$EE,$EE,$EE,$EE,$EE,$88,$8E,$88,$80,$00,$00,$00
        FCB     $00,$00,$00,$00,$00,$00,$00,$00,$00,$0E,$EE,$EE,$EE,$CE,$EE
        FCB     $EE,$EE,$EE,$EE,$EE,$88,$88,$8E,$EE,$00,$00,$00,$00,$00
        FCB     $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$EE,$EE
        FCB     $EE,$EE,$EE,$EE,$EC,$88,$EE,$EE,$E0,$00,$00,$00,$00,$00
        FCB     $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
        FCB     $00,$00,$00,$00,$08,$EE,$EE,$EE,$00,$00,$00,$00,$00,$00
;*
;*      CLIFF3R
;* $6581 (CONTINUED)
;* 43 BY 16 BYTES
_CLIF3R FDB     CCLF3R,CSRC3R,$7F8A,$1807!DMAFIX                ;OLD X CA       ;;Fixme was: !XDMAFIX
        FDB            CSRC3R,$7F8A,$1806!DMAFIX                                ;;Fixme was: !XDMAFIX
CSRC3R
 FDB $00AA,$AAAA,$AAAA,$AAAA,$AAAA,$AAAA,$AAAA,$AAAA,$AAAA,$AAAA,$AAAA,$AAAA
 FDB $00CC,$C88C,$CC88,$8CAC,$CA8C,$8888,$AAAA,$AEEC,$C888,$A888,$8888,$8888
 FDB $0000,$E88E,$E888,$8EEE,$EE88,$8888,$8888,$88EE,$EEC8,$8888,$8888,$8888
 FDB $0000,$EE88,$888C,$C888,$8E88,$EEEC,$8888,$888E,$EEEE,$EEEE,$EEEE,$EEEE
 FDB $0000,$00EE,$88C8,$8EEE,$EEE8,$EEEE,$CEEE,$EE88,$8EEE,$EEEE,$EEEE,$EEEE
 FDB $0000,$000C,$CCEE,$EEEE,$EEEE,$8CEE,$E800,$0000,$00EE,$EE00,$0000,$0000
 FDB $0000,$000C,$8EEE,$EEEE,$EEEE,$E800,$0000,$0000,$0000,$0000,$0000,$0000
;*
CCLF3R  FDB     1+COFF,58+COFF
        FDB     1+COFF,57+COFF
        FDB     2+COFF,56+COFF
        FDB     2+COFF,55+COFF
        FDB     4+COFF,55+COFF
        FDB     5+COFF,54+COFF
        FDB     8+COFF,53+COFF
        FDB     21+COFF,51+COFF
        FDB     21+COFF,51+COFF
        FDB     28+COFF,86+32+COFF
        FDB     41+COFF,86+32+COFF
        FDB     55+COFF,86+32+COFF
        FDB     57+COFF,86+32+COFF
        FDB     58+COFF,86+32+COFF
        FDB     61+COFF,78+COFF
        FDB     61+COFF,74+COFF
        FDB     $8100,$8100             ;TERMINATING POINTER
;*
;*      CLIFF4
;* $35A3
;* 32 BY 8 BYTES
_CLIF4  FDB     CCLF4,CSRC4,$35A3,$2008!DMAFIX          ;OLD X 6A               ;;Fixme was: !XDMAFIX
        FDB           CSRC4,$35A3,$2007!DMAFIX                                  ;;Fixme was: !XDMAFIX
CSRC4
        FCB     $AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA
        FCB $AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA
        FCB     $88,$CA,$AA,$AA,$AA,$CC,$CC,$CA,$AC,$CC,$CC,$AA,$AA,$CC,$CC,$AA
        FCB $AA,$AA,$AA,$CC,$CA,$CC,$CA,$CC,$AA,$CA,$CC,$CC,$CC,$CC,$AC,$CC
        FCB     $00,$08,$CC,$CC,$CA,$AC,$CC,$C8,$8A,$AA,$CC,$CC,$CC,$CC,$AA,$A8
        FCB $CC,$AC,$CC,$8E,$EE,$88,$88,$CC,$C8,$88,$8C,$C8,$88,$88,$EE,$EE
        FCB     $00,$00,$88,$CC,$C8,$88,$88,$88,$88,$88,$88,$88,$88,$8C,$CC,$CC
        FCB $CC,$CC,$CA,$AE,$EE,$EE,$E8,$88,$88,$88,$EE,$8E,$EE,$EE,$00,$00
        FCB     $00,$00,$08,$88,$EE,$EE,$EE,$88,$EE,$EE,$EE,$88,$EE,$CC,$88,$EE
        FCB $88,$88,$8C,$CC,$AE,$EE,$EE,$E8,$8E,$88,$8E,$00,$00,$00,$00,$00
        FCB     $00,$00,$00,$00,$EE,$EE,$EE,$EE,$EE,$E8,$88,$8E,$E8,$E8,$EE,$8E
        FCB $EE,$EE,$88,$88,$CA,$EE,$EE,$EE,$EE,$EE,$88,$8E,$00,$00,$00,$00
        FCB     $00,$00,$00,$00,$00,$00,$00,$0E,$EE,$EE,$EE,$EE,$E8,$EE,$EE,$EE
        FCB $EE,$EE,$EE,$88,$88,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
        FCB     $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$0E,$EE,$EE,$EE
        FCB $EE,$EE,$EE,$88,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
;*
CCLF4   FDB     1+COFF,64+COFF
        FDB     1+COFF,64+COFF
        FDB     4+COFF,64+COFF
        FDB     5+COFF,60+COFF
        FDB     6+COFF,54+COFF
        FDB     9+COFF,56+COFF
        FDB     16+COFF,42+COFF
        FDB     26+COFF,40+COFF
        FDB     $8100,$8100             ;TERMINATING POINTER
;*
;*      CLIFF5
;* $1BD3
;* 93 BY 33
_CLIF5  FDB     CCLF5,CSRC5,$1BD3,$5D02!DMAFIX          ;OLD X 36               ;;Fixme was: !XDMAFIX
        FDB           CSRC5,$1BD3,$5D02!DMAFIX          ;TOP                    ;;Fixme was: !XDMAFIX
        FDB           CSRC5L,$1BD3,$080D!DMAFIX         ;LEFT SIDE              ;;Fixme was: !XDMAFIX
        FDB           CSRC5R,$70D3,$080D!DMAFIX         ;RIGHT SIDE             ;;Fixme was: !XDMAFIX
CSRC5R
        FCB     $AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA
        FCB     $AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA
        FCB     $CC,$88,$88,$8C,$CC,$CC,$CC,$C0
        FCB     $88,$88,$CC,$CC,$C8,$88,$8C,$A0
        FCB     $CC,$8C,$CC,$CC,$CE,$E8,$C8,$00
        FCB     $EC,$8C,$CC,$EE,$E8,$EE,$00,$00
        FCB     $8E,$E8,$EE,$88,$8E,$E0,$00,$00
        FCB     $88,$EE,$E8,$88,$E0,$00,$00,$00
        FCB     $88,$88,$8E,$00,$00,$00,$00,$00
        FCB     $8E,$E8,$E0,$00,$00,$00,$00,$00
        FCB     $88,$EE,$00,$00,$00,$00,$00,$00
        FCB     $8E,$E0,$00,$00,$00,$00,$00,$00
        FCB     $80,$00,$00,$00,$00,$00,$00,$00
;*
CSRC5L
        FCB     $AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA
        FCB     $AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA
        FCB     $CC,$CC,$CC,$88,$88,$8C,$CC,$CC
        FCB     $0E,$EE,$EE,$88,$88,$CC,$CC,$CC
        FCB     $0E,$EE,$EE,$EE,$88,$88,$8C,$88
        FCB     $00,$00,$AC,$C8,$8C,$CC,$CC,$88
        FCB     $00,$00,$EC,$CE,$EE,$E8,$EE,$88
        FCB     $00,$00,$0E,$88,$EE,$EE,$E8,$88
        FCB     $00,$00,$00,$E8,$88,$88,$88,$C8
        FCB     $00,$00,$00,$0E,$EE,$EE,$E8,$88
        FCB     $00,$00,$00,$00,$00,$00,$0E,$8E
        FCB     $00,$00,$00,$00,$00,$00,$00,$EE
        FCB     $00,$00,$00,$00,$00,$00,$00,$0E
        FCB     $00,$00,$00,$00,$00,$00,$00,$0E
;*
CSRC5
        FCB     $AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA
        FCB     $AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA
        FCB     $CA,$CC,$CC,$C8,$EE,$DD,$DD,$DD,$DD,$DD,$DD,$DD,$DD
        FCB     $DD,$DD,$DD,$DD,$DD,$DD,$E8,$CC,$CC,$CA,$AA,$AA,$AA
        FCB     $AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA
        FCB     $AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA
        FCB     $AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA
        FCB     $AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA
        FCB     $AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA,$AC,$CC,$CC
        FCB     $CC,$88,$88,$CC,$8E,$ED,$DD,$DD,$DD,$DD,$DD,$DD,$DD
        FCB     $DD,$DD,$DD,$DD,$DD,$DE,$88,$88,$CC,$CC,$CA,$AA,$AA
        FCB     $AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA
        FCB     $AA,$AA,$AA,$AC,$CA,$AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA
        FCB     $AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA,$AA
;*??????        FCB     $CC,$CC,$CC,$88,$88,$8C,$CC,$CC,$CC,$AC,$CC,$C8,$88,$8A,$AA
;*??????        FCB     $A8,$88,$CC,$CC,$C8,$8A,$AA,$AA,$8C,$CC,$88,$88,$88
;*??????        FCB     $88,$8C,$CC,$88,$88,$EE,$ED,$DD,$DD,$DD,$DD,$DD,$DD
;*??????        FCB     $DD,$DD,$DD,$DD,$DE,$E8,$88,$88,$88,$88,$CC,$AC,$AA
;*??????        FCB     $AA,$CC,$CC,$CC,$CC,$CC,$CC,$CC,$CC,$88,$88,$88,$8C
;*??????        FCB     $C8,$88,$CC,$CA,$AA,$AC,$CC,$CC,$C8,$88,$CC,$88,$8C
;*??????        FCB     $CC,$CC,$CC,$AA,$AA,$CC,$88,$88,$8C,$CC,$CC,$CC,$C0
;*??????        FCB     $0E,$EE,$EE,$88,$88,$CC,$CC,$CC,$C8,$8C,$88,$8C,$CC,$CC,$88
;*??????        FCB     $CC,$C8,$88,$88,$88,$CC,$C8,$8C,$CC,$88,$88,$CC,$CC
;*??????        FCB     $CC,$CC,$88,$CC,$C8,$8E,$EE,$EE,$EE,$EE,$EE,$EE,$EE
;*??????        FCB     $EE,$EE,$EE,$EE,$EE,$88,$8C,$CC,$CC,$88,$88,$8C,$C8
;*??????        FCB     $8C,$CC,$88,$8C,$CC,$88,$88,$CC,$CC,$8C,$CC,$88,$88
;*??????        FCB     $88,$88,$88,$88,$88,$88,$8C,$C8,$88,$88,$88,$CC,$CC
;*??????        FCB     $88,$88,$CC,$CC,$88,$88,$88,$CC,$CC,$C8,$88,$8C,$A0
;*??????        FCB     $0E,$EE,$EE,$EE,$88,$88,$8C,$88,$88,$88,$88,$88,$88,$88,$88
;*??????        FCB     $88,$88,$88,$88,$88,$88,$88,$88,$88,$88,$88,$88,$88
;*??????        FCB     $88,$88,$88,$88,$88,$88,$88,$88,$88,$88,$88,$88,$88
;*??????        FCB     $88,$88,$88,$88,$88,$88,$88,$88,$88,$88,$88,$88,$88
;*??????        FCB     $88,$88,$88,$88,$88,$88,$88,$88,$88,$88,$88,$88,$88
;*??????        FCB     $88,$88,$88,$88,$88,$88,$88,$88,$88,$88,$88,$88,$88
;*??????        FCB     $88,$88,$88,$88,$88,$CC,$8C,$CC,$CC,$CE,$E8,$C8,$00
;*??????        FCB     $00,$00,$AC,$C8,$8C,$CC,$CC,$88,$8A,$00,$00,$00,$00,$00,$00
;*??????        FCB     $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
;*??????        FCB     $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
;*??????        FCB     $00,$00,$00,$00,$A8,$88,$8A,$00,$00,$00,$00,$00,$00
;*??????        FCB     $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
;*??????        FCB     $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
;*??????        FCB     $00,$00,$00,$00,$A8,$EC,$8C,$CC,$EE,$E8,$EE,$00,$00
;*??????        FCB     $00,$00,$EC,$CE,$EE,$E8,$EE,$88,$80,$0E,$EE,$EE,$EE,$EE,$EE
;*??????        FCB     $EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE
;*??????        FCB     $EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE
;*??????        FCB     $EE,$EE,$EE,$EE,$08,$88,$80,$0E,$EE,$EE,$EE,$EE,$EE
;*??????        FCB     $EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE
;*??????        FCB     $EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE
;*??????        FCB     $EE,$EE,$EE,$EE,$08,$8E,$E8,$EE,$88,$8E,$E0,$00,$00
;*??????        FCB     $00,$00,$0E,$88,$EE,$EE,$E8,$88,$C0,$EE,$EE,$EE,$EE,$EE,$EE
;*??????        FCB     $EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE
;*??????        FCB     $EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE
;*??????        FCB     $EE,$EE,$EE,$EE,$EC,$88,$C0,$EE,$EE,$EE,$EE,$EE,$EE
;*??????        FCB     $EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE
;*??????        FCB     $EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE
;*??????        FCB     $EE,$EE,$EE,$EE,$EC,$88,$EE,$E8,$88,$E0,$00,$00,$00
;*??????        FCB     $00,$00,$00,$E8,$88,$88,$88,$C8,$00,$EE,$EE,$EE,$EE,$EE,$EE
;*??????        FCB     $EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE
;*??????        FCB     $EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE
;*??????        FCB     $EE,$EE,$EE,$EE,$E0,$88,$00,$EE,$EE,$EE,$EE,$EE,$EE
;*??????        FCB     $EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE
;*??????        FCB     $EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE
;*??????        FCB     $EE,$EE,$EE,$EE,$E0,$88,$88,$8E,$00,$00,$00,$00,$00
;*??????        FCB     $00,$00,$00,$0E,$EE,$EE,$E8,$88,$0E,$EE,$EE,$EE,$EE,$EE,$EE
;*??????        FCB     $EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE
;*??????        FCB     $EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE
;*??????        FCB     $EE,$EE,$EE,$EE,$EE,$88,$0E,$EE,$EE,$EE,$EE,$EE,$EE
;*??????        FCB     $EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE
;*??????        FCB     $EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE
;*??????        FCB     $EE,$EE,$EE,$EE,$EE,$8E,$E8,$E0,$00,$00,$00,$00,$00
;*??????        FCB     $00,$00,$00,$00,$00,$00,$0E,$8E,$0E,$EE,$EE,$EE,$EE,$EE,$EE
;*??????        FCB     $EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE
;*??????        FCB     $EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE
;*??????        FCB     $EE,$EE,$EE,$EE,$EE,$88,$0E,$EE,$EE,$EE,$EE,$EE,$EE
;*??????        FCB     $EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE
;*??????        FCB     $EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE
;*??????        FCB     $EE,$EE,$EE,$EE,$EE,$88,$EE,$00,$00,$00,$00,$00,$00
;*??????        FCB     $00,$00,$00,$00,$00,$00,$00,$EE,$8E,$EE,$EE,$EE,$EE,$EE,$EE
;*??????        FCB     $EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE
;*??????        FCB     $EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE
;*??????        FCB     $EE,$EE,$EE,$EE,$E8,$88,$8E,$EE,$EE,$EE,$EE,$EE,$EE
;*??????        FCB     $EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE
;*??????        FCB     $EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE
;*??????        FCB     $EE,$EE,$EE,$EE,$E8,$8E,$E0,$00,$00,$00,$00,$00,$00
;*??????        FCB     $00,$00,$00,$00,$00,$00,$00,$0E,$80,$EE,$EE,$EE,$EE,$EE,$EE
;*??????        FCB     $EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE
;*??????        FCB     $EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE
;*??????        FCB     $EE,$EE,$EE,$EE,$E8,$88,$80,$EE,$EE,$EE,$EE,$EE,$EE
;*??????        FCB     $EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE
;*??????        FCB     $EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE
;*??????        FCB     $EE,$EE,$EE,$EE,$E8,$80,$00,$00,$00,$00,$00,$00,$00
;*??????        FCB     $00,$00,$00,$00,$00,$00,$00,$0E,$88,$0E,$EE,$EE,$EE,$EE,$EE
;*??????        FCB     $EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE
;*??????        FCB     $EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE
;*??????        FCB     $EE,$EE,$EE,$EE,$88,$88,$88,$0E,$EE,$EE,$EE,$EE,$EE
;*??????        FCB     $EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE
;*??????        FCB     $EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE
;*??????        FCB     $EE,$EE,$EE,$EE,$80,$00,$00,$00,$00,$00,$00,$00,$00
;*??????        FCB     $00,$00,$00,$00,$00,$00,$00,$00,$88,$88,$88,$88,$88,$88,$88
;*??????        FCB     $88,$88,$88,$88,$88,$88,$88,$88,$88,$88,$88,$88,$88
;*??????        FCB     $88,$88,$88,$88,$88,$88,$88,$88,$88,$88,$88,$88,$88
;*??????        FCB     $88,$88,$88,$88,$88,$88,$88,$88,$88,$88,$88,$88,$88
;*??????        FCB     $88,$88,$88,$88,$88,$88,$88,$88,$88,$88,$88,$88,$88
;*??????        FCB     $88,$88,$88,$88,$88,$88,$88,$88,$88,$88,$88,$88,$88
;*??????        FCB     $88,$88,$88,$88,$80,$00,$00,$00,$00,$00,$00,$00,$00
;*??????        FCB     $00,$00,$00,$00,$00,$00,$00,$00,$88,$88,$8C,$CC,$88,$8C,$C8
;*??????        FCB     $88,$88,$88,$88,$88,$88,$88,$88,$88,$88,$88,$88,$88
;*??????        FCB     $88,$CC,$CC,$88,$88,$88,$88,$88,$88,$88,$88,$88,$88
;*??????        FCB     $88,$88,$88,$88,$88,$88,$88,$88,$88,$88,$88,$88,$88
;*??????        FCB     $88,$88,$88,$88,$88,$88,$88,$88,$88,$88,$88,$88,$88
;*??????        FCB     $88,$CC,$CC,$88,$88,$88,$88,$88,$88,$88,$88,$88,$88
;*??????        FCB     $CC,$C8,$88,$88,$00,$00,$00,$00,$00,$00,$00,$00,$00
;*??????        FCB     $00,$00,$00,$00,$00,$00,$00,$00,$88,$88,$EE,$88,$8E,$88,$88
;*??????        FCB     $8C,$CC,$8C,$CC,$88,$88,$CC,$CC,$88,$88,$88,$88,$CC
;*??????        FCB     $8C,$CC,$88,$88,$88,$88,$88,$88,$88,$88,$EE,$88,$88
;*??????        FCB     $88,$88,$88,$88,$88,$88,$88,$88,$88,$88,$88,$88,$88
;*??????        FCB     $88,$88,$88,$8E,$88,$88,$88,$88,$88,$8E,$EE,$CC,$CC
;*??????        FCB     $C8,$88,$CC,$C8,$88,$CC,$C8,$88,$8C,$CC,$88,$8C,$CC
;*??????        FCB     $CC,$CC,$C8,$C8,$00,$00,$00,$00,$00,$00,$00,$00,$00
;*??????        FCB     $00,$00,$00,$00,$00,$00,$00,$08,$A8,$CC,$8E,$EE,$EC,$C8,$CC
;*??????        FCB     $CC,$EE,$EC,$CC,$CC,$8E,$EE,$EE,$EE,$E8,$CC,$CC,$88
;*??????        FCB     $88,$88,$88,$88,$88,$88,$88,$88,$88,$EE,$E8,$88,$88
;*??????        FCB     $88,$88,$88,$88,$88,$88,$88,$88,$88,$88,$88,$88,$88
;*??????        FCB     $88,$88,$88,$8E,$CC,$88,$88,$88,$8C,$EE,$88,$88,$8E
;*??????        FCB     $EE,$8E,$EE,$8C,$CC,$CC,$88,$8C,$CC,$EE,$EE,$EE,$EE
;*??????        FCB     $EC,$8C,$CC,$AA,$00,$00,$00,$00,$00,$00,$00,$00,$00
;*??????        FCB     $00,$00,$00,$00,$00,$00,$00,$08,$C8,$8C,$88,$88,$88,$88,$88
;*??????        FCB     $88,$88,$8E,$CC,$EE,$E8,$8E,$EE,$88,$88,$88,$88,$88
;*??????        FCB     $88,$88,$8E,$EC,$C8,$88,$88,$88,$EE,$E8,$88,$88,$88
;*??????        FCB     $88,$88,$88,$88,$88,$88,$88,$88,$88,$88,$88,$88,$88
;*??????        FCB     $88,$88,$88,$88,$EC,$CC,$C8,$88,$8C,$EE,$8E,$8E,$EE
;*??????        FCB     $EE,$E8,$88,$E8,$C8,$8C,$CC,$C8,$8C,$EE,$EE,$E8,$8E
;*??????        FCB     $E8,$E8,$CC,$AA,$80,$00,$00,$00,$00,$00,$00,$00,$00
;*??????        FCB     $00,$00,$00,$00,$00,$00,$00,$08,$8C,$C8,$8E,$EE,$E8,$8E,$EE
;*??????        FCB     $EE,$0C,$C8,$EE,$E8,$88,$EE,$88,$CC,$CC,$88,$8E,$EE
;*??????        FCB     $8E,$EE,$88,$EE,$CC,$88,$C8,$8E,$88,$88,$88,$88,$88
;*??????        FCB     $88,$88,$88,$88,$88,$88,$88,$88,$88,$88,$88,$88,$88
;*??????        FCB     $88,$88,$88,$88,$EC,$C8,$88,$8C,$C0,$EE,$EE,$EE,$8E
;*??????        FCB     $E8,$EE,$EE,$EE,$E8,$EE,$CC,$CE,$88,$CE,$EE,$EE,$E8
;*??????        FCB     $EE,$EE,$CC,$E8,$C0,$00,$00,$00,$00,$00,$00,$00,$00
;*??????        FCB     $00,$00,$00,$00,$00,$00,$00,$8C,$C8,$8E,$EE,$E8,$8E,$EE,$EE
;*??????        FCB     $E0,$AC,$C8,$88,$88,$8E,$88,$8C,$C8,$EE,$EE,$EE,$88
;*??????        FCB     $EE,$EE,$08,$E8,$CC,$CC,$EE,$88,$88,$88,$88,$88,$88
;*??????        FCB     $88,$88,$88,$88,$88,$88,$88,$88,$88,$88,$88,$88,$88
;*??????        FCB     $88,$88,$88,$88,$8E,$EE,$C8,$E0,$0E,$EE,$EE,$EE,$EE
;*??????        FCB     $EE,$EE,$88,$8E,$E8,$8E,$EE,$EE,$88,$80,$EE,$EE,$88
;*??????        FCB     $E8,$EE,$EE,$88,$A0,$00,$00,$00,$00,$00,$00,$00,$00
;*??????        FCB     $00,$00,$00,$00,$00,$00,$AA,$CC,$CE,$8E,$EE,$8E,$EE,$E8,$EE
;*??????        FCB     $E0,$88,$EC,$C8,$88,$E8,$8C,$CC,$EE,$E8,$8E,$88,$EE
;*??????        FCB     $EE,$E0,$E8,$88,$8E,$EE,$E8,$88,$88,$88,$88,$88,$88
;*??????        FCB     $88,$88,$88,$88,$88,$88,$88,$88,$88,$88,$88,$88,$88
;*??????        FCB     $88,$88,$88,$88,$88,$8E,$EE,$E8,$88,$00,$0E,$EE,$EE
;*??????        FCB     $EE,$EE,$EE,$E8,$EE,$E8,$EE,$CC,$C8,$8A,$0E,$EE,$EE
;*??????        FCB     $E8,$88,$8C,$CC,$A0,$00,$00,$00,$00,$00,$00,$00,$00
;*??????        FCB     $00,$00,$00,$00,$00,$00,$8A,$88,$EE,$E8,$8E,$EE,$88,$EE,$EE
;*??????        FCB     $00,$EE,$88,$88,$8E,$88,$88,$88,$EE,$EE,$EE,$EE,$EE
;*??????        FCB     $00,$0E,$C8,$88,$E8,$88,$88,$88,$88,$88,$88,$88,$88
;*??????        FCB     $88,$88,$88,$88,$88,$88,$88,$88,$88,$88,$88,$88,$88
;*??????        FCB     $88,$88,$88,$88,$88,$88,$88,$E8,$88,$88,$88,$88,$8E
;*??????        FCB     $EE,$EE,$EE,$EE,$EE,$88,$EE,$8C,$CC,$CA,$00,$EE,$E8
;*??????        FCB     $8E,$E8,$88,$EC,$C8,$E0,$00,$00,$00,$00,$00,$00,$00
;*??????        FCB     $00,$00,$00,$00,$00,$00,$88,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$E0
;*??????        FCB     $0E,$EE,$8C,$8C,$EE,$88,$8E,$EE,$EE,$EE,$EE,$EE,$E0
;*??????        FCB     $88,$88,$88,$88,$88,$88,$88,$88,$88,$88,$88,$88,$88
;*??????        FCB     $88,$88,$88,$88,$88,$88,$88,$88,$88,$88,$88,$88,$88
;*??????        FCB     $88,$88,$88,$88,$88,$88,$88,$EE,$8C,$88,$88,$88,$8C
;*??????        FCB     $00,$EE,$EE,$EE,$E8,$E8,$E8,$EE,$EE,$EE,$E0,$EE,$EE
;*??????        FCB     $EE,$8E,$88,$8E,$EE,$80,$00,$00,$00,$00,$00,$00,$00
;*??????        FCB     $00,$00,$00,$00,$00,$CC,$8C,$88,$88,$EE,$EE,$EE,$EE,$EE,$00
;*??????        FCB     $88,$88,$EE,$EE,$EE,$88,$EE,$EE,$EE,$EE,$00,$EE,$08
;*??????        FCB     $88,$C8,$88,$88,$88,$88,$88,$88,$88,$88,$88,$88,$88
;*??????        FCB     $88,$88,$88,$88,$88,$88,$88,$88,$88,$88,$88,$88,$88
;*??????        FCB     $88,$88,$88,$88,$88,$88,$88,$8E,$E8,$88,$88,$88,$88
;*??????        FCB     $C0,$EE,$E0,$0E,$EE,$EE,$8E,$EE,$EE,$EE,$E0,$0E,$EE
;*??????        FCB     $EE,$EE,$EE,$88,$8C,$C0,$00,$00,$00,$00,$00,$00,$00
;*??????        FCB     $00,$00,$00,$00,$00,$88,$CC,$88,$EE,$EE,$EE,$EE,$EE,$E0,$08
;*??????        FCB     $88,$88,$8E,$EE,$88,$8E,$EE,$E0,$00,$00,$C8,$0E,$08
;*??????        FCB     $A8,$88,$88,$8E,$E8,$88,$88,$88,$88,$88,$88,$88,$88
;*??????        FCB     $88,$88,$88,$88,$88,$88,$88,$88,$88,$88,$88,$88,$88
;*??????        FCB     $88,$88,$88,$88,$88,$88,$88,$88,$EE,$E8,$88,$88,$88
;*??????        FCB     $AA,$00,$08,$80,$EE,$E8,$EE,$EE,$88,$8C,$AC,$00,$00
;*??????        FCB     $0E,$EE,$EE,$EE,$8C,$CA,$E0,$00,$00,$00,$00,$00,$00
;*??????        FCB     $00,$00,$00,$00,$00,$8C,$EE,$EE,$EE,$EE,$EE,$E0,$00,$E0,$88
;*??????        FCB     $88,$88,$88,$EE,$E8,$8E,$EE,$00,$00,$08,$C8,$8E,$08
;*??????        FCB     $A8,$88,$88,$CE,$E8,$88,$88,$88,$88,$88,$88,$88,$88
;*??????        FCB     $88,$88,$88,$88,$88,$88,$88,$88,$88,$88,$88,$E8,$E8
;*??????        FCB     $88,$88,$88,$88,$88,$88,$88,$88,$EE,$EE,$88,$88,$8C
;*??????        FCB     $CA,$E0,$08,$8C,$0E,$EE,$EE,$EE,$EE,$CC,$A8,$00,$00
;*??????        FCB     $00,$0E,$EE,$EE,$EE,$CA,$A0,$00,$00,$00,$00,$00,$00
;*??????        FCB     $00,$00,$EE,$8A,$AC,$88,$88,$EE,$EE,$EE,$E0,$00,$00,$08,$A8
;*??????        FCB     $88,$8C,$8E,$EE,$88,$8E,$EE,$E0,$00,$0C,$88,$80,$0C
;*??????        FCB     $A8,$88,$8C,$EE,$E8,$88,$88,$88,$88,$88,$E8,$EE,$88
;*??????        FCB     $88,$88,$88,$88,$88,$88,$88,$88,$88,$88,$8E,$8E,$EE
;*??????        FCB     $88,$88,$88,$88,$88,$88,$88,$8E,$88,$EE,$EC,$8C,$CC
;*??????        FCB     $8E,$E0,$08,$88,$C0,$00,$EE,$EE,$8E,$88,$CE,$00,$00
;*??????        FCB     $00,$00,$EE,$EE,$E8,$8C,$C0,$00,$00,$00,$00,$00,$00
;*??????        FCB     $00,$00,$E8,$88,$E8,$88,$EE,$EE,$EE,$EE,$00,$00,$00,$0A,$88
;*??????        FCB     $88,$C8,$EE,$E8,$88,$EE,$EE,$E0,$00,$8E,$88,$80,$0A
;*??????        FCB     $CC,$88,$C8,$EE,$88,$88,$88,$88,$E8,$E8,$8E,$E8,$88
;*??????        FCB     $88,$88,$88,$88,$88,$88,$88,$88,$88,$8E,$88,$80,$0E
;*??????        FCB     $E8,$88,$88,$88,$88,$EE,$88,$88,$88,$8E,$EE,$EE,$EE
;*??????        FCB     $EE,$E0,$00,$88,$CC,$00,$0E,$EE,$E8,$EE,$E8,$C0,$00
;*??????        FCB     $00,$00,$0E,$EE,$EE,$E8,$88,$00,$00,$00,$00,$00,$00
;*??????        FCB     $00,$00,$8E,$EE,$8E,$EE,$EE,$EE,$00,$00,$00,$00,$00,$00,$CC
;*??????        FCB     $CC,$8E,$EE,$88,$8E,$EE,$EE,$00,$00,$88,$EE,$E0,$08
;*??????        FCB     $CC,$CC,$8E,$E8,$88,$88,$88,$88,$88,$8E,$EE,$08,$88
;*??????        FCB     $88,$88,$88,$88,$88,$88,$88,$88,$8E,$88,$88,$E0,$0E
;*??????        FCB     $EE,$88,$88,$8E,$8E,$88,$EE,$EE,$88,$88,$88,$EE,$EE
;*??????        FCB     $EE,$00,$00,$08,$8E,$00,$00,$EE,$EE,$E8,$88,$80,$08
;*??????        FCB     $88,$00,$0E,$EE,$EE,$EE,$E8,$88,$EE,$00,$00,$00,$00
;*??????        FCB     $00,$88,$CC,$88,$EE,$EE,$EE,$E0,$00,$00,$00,$C8,$E0,$00,$00
;*??????        FCB     $EE,$EE,$E8,$88,$EE,$EE,$E0,$00,$00,$0E,$EE,$E0,$00
;*??????        FCB     $88,$8E,$EE,$E8,$E8,$EE,$88,$8E,$EE,$EE,$00,$0E,$E8
;*??????        FCB     $88,$88,$88,$88,$88,$88,$8E,$EE,$E8,$88,$EE,$E8,$00
;*??????        FCB     $EE,$E8,$8E,$E8,$88,$88,$88,$88,$88,$88,$8E,$EE,$EE
;*??????        FCB     $00,$00,$00,$00,$EE,$E0,$00,$0E,$E8,$8E,$88,$E0,$0E
;*??????        FCB     $88,$80,$0E,$EE,$88,$8E,$E8,$88,$8E,$00,$00,$00,$00
;*??????        FCB     $00,$88,$88,$EE,$EE,$EE,$EE,$E0,$00,$00,$0C,$C8,$8E,$00,$00
;*??????        FCB     $EE,$E8,$88,$8E,$EE,$EE,$E0,$00,$00,$00,$EE,$00,$00
;*??????        FCB     $EE,$EE,$EE,$88,$8E,$EE,$EE,$EE,$EE,$EE,$00,$00,$EE
;*??????        FCB     $EE,$EE,$88,$88,$88,$88,$88,$88,$88,$8E,$EE,$EE,$00
;*??????        FCB     $EE,$EE,$E8,$8E,$EE,$EE,$E8,$8E,$EE,$EE,$88,$8E,$EE
;*??????        FCB     $EE,$E0,$00,$00,$00,$00,$00,$0E,$EE,$EE,$EE,$EE,$EE
;*??????        FCB     $E8,$E0,$00,$EE,$E8,$88,$8E,$EE,$8E,$00,$00,$00,$00
;*??????        FCB     $00,$88,$8E,$EE,$EE,$EE,$EE,$E0,$00,$00,$00,$88,$E0,$00,$00
;*??????        FCB     $0E,$EE,$EE,$EE,$EE,$EE,$E0,$00,$00,$00,$00,$00,$00
;*??????        FCB     $0E,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$00,$00,$00,$0E
;*??????        FCB     $EE,$EE,$EE,$8E,$E8,$88,$8E,$EE,$EE,$EE,$EE,$EE,$00
;*??????        FCB     $00,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE,$EE
;*??????        FCB     $EE,$EE,$00,$00,$00,$00,$00,$0E,$EE,$EE,$EE,$EE,$EE
;*??????        FCB     $EE,$80,$00,$EE,$EE,$88,$88,$8E,$EE,$00,$00,$00,$00
;*
;*
CCLF5   FDB     1+COFF,186+COFF
        FDB     1+COFF,186+COFF
        FDB     1+COFF,185+COFF
        FDB     2+COFF,185+COFF
        FDB     2+COFF,184+COFF
        FDB     5+COFF,182+COFF
        FDB     5+COFF,181+COFF
        FDB     6+COFF,179+COFF
        FDB     7+COFF,176+COFF
        FDB     8+COFF,175+COFF
        FDB     14+COFF,174+COFF
        FDB     15+COFF,173+COFF
        FDB     16+COFF,171+COFF
;*
        FDB     16+COFF,171+COFF        ;NO ONE SHOULD BE HERE OR BELOW
        FDB     16+COFF,171+COFF
        FDB     16+COFF,171+COFF
        FDB     16+COFF,171+COFF
        FDB     16+COFF,171+COFF
        FDB     16+COFF,171+COFF
;********       FDB     16+COFF,171+COFF
;********       FDB     16+COFF,171+COFF
;********       FDB     16+COFF,171+COFF
;********       FDB     16+COFF,171+COFF
;********       FDB     16+COFF,171+COFF
;********       FDB     16+COFF,171+COFF
;********       FDB     16+COFF,171+COFF
;********       FDB     16+COFF,171+COFF
;********       FDB     16+COFF,171+COFF
;********       FDB     16+COFF,171+COFF
;********       FDB     16+COFF,171+COFF
;********       FDB     16+COFF,171+COFF
;********       FDB     16+COFF,171+COFF
;********       FDB     16+COFF,171+COFF
        FDB     $8100,$8100             ;TERMINATING POINTER
;*
;*      COMPACTED CLIF5
;*
_COMCL5 FCB     %00001110,%10011111,%01110110,%11110111,%00101001,%11000111
        FCB     %10110111,%11110010,%11110100,%00010101,%11011100,%01000011
        FCB     %01010110,%01001101,%01100010,%10010111,%00101001,%11000111
        FCB     %00110111,%11011000,%10111101,%00001010,%00011010,%01010000
        FCB     %10110101,%11000100,%10001010,%11100100,%10011011,%10110110
        FCB     %10101100,%01011001,%10101001,%01111010,%10000101,%11011110
        FCB     %01010110,%10010110,%01010110,%10110001,%01011110,%00110001
        FCB     %10010011,%10010110,%01010010,%11101111,%10101100,%11000100
        FCB     %10101001,%00100101,%00101010,%10010101,%10101100,%11001000
        FCB     %10101010,%01010010,%10101001,%00100110,%10110011,%01001010
        FCB     %11100100,%10101011,%00011100,%00111111,%01100010,%01001101
        FCB     %01000011,%11010101,%00101111,%01010000,%10101101,%00100100
        FCB     %10101101,%01000010,%10110101,%10001001,%01010101,%00001010
        FCB     %11010100,%00100011,%01111101,%01001011,%11010111,%00101001
        FCB     %01010000,%10101101,%01010010,%10110101,%10001011,%01011100
        FCB     %10101101,%00010011,%00101001,%01001001,%00101101,%01011000
        FCB     %10110101,%00100000,%10111101,%01100011,%11011101,%11000111
        FCB     %00000100,%11110111,%00111101,%00000010,%01111000,%10100101
        FCB     %11001001,%00010101,%00111110,%01111011,%10011000,%10110000
        FCB     %11011010,%01010100,%00101111,%01010100,%11101100,%00010010
        FCB     %10000110,%11011000,%11101100,%00010010,%10000110,%11110011
        FCB     %11111110,%11100101,%01101010,%11111100,%10100111,%10001011
        FCB     %00001111,%10100101,%01101111,%10010100,%11101010,%01010000
        FCB     %00000010,%01001111,%11000011,%00010100,%00000000,%10010011
        FCB     %11110000,%10000101,%00111110,%01010011,%10101001,%01001111
        FCB     %00010111,%00011111,%01000010,%11111101,%01001111,%01110000
        FCB     %00001001,%01111111,%10101000,%01111011,%10000000,%01001011
        FCB     %11111101,%01000010,%10111101,%01001111,%11100010,%01000000
        FCB     %11111001,%00100111,%10111001,%01000000,%00001001,%01111111
        FCB     %00001000,%01010000,%00000010,%01011111,%11000011,%10011111
        FCB     %11000100,%10010000,%01000111,%01010011,%10000000,%01001101
        FCB     %11101000,%01110000,%00001001,%10111111,%00101001,%11110011
        FCB     %11111000,%10011110,%00111111,%10011111,%11100000,%00010011
        FCB     %01111010,%00011100,%00000010,%01101111,%01000010,%10011110
        FCB     %00100010,%00000001,%00111110,%01000001,%00110011,%10110001
        FCB     %00000100,%11001110,%10000101,%00111100,%01000100,%01000111
        FCB     %11110011,%10000000,%01001011,%11101100,%01110000,%00001001
        FCB     %01111101,%00001100,%01000100,%01000111,%11010000,%11100000
        FCB     %00010010,%01111001,%00000111,%00000000,%10010011,%11110011
        FCB     %00010001,%00100000,%00000100,%11011001,%10001000,%10010000
        FCB     %01110010,%10110101,%01001010,%01010001,%11110010,%11010100
        FCB     %00010011,%00001011,%01010001,%01100010,%10110101,%11001100
        FCB     %01000100,%10000011,%00010100,%11101010,%01111110,%11100101
        FCB     %01101110,%01010110,%10110001,%01101010,%01010001,%01001011
        FCB     %10010101,%10100010,%01000101,%00111000,%01001110,%01111110
        FCB     %01101001,%01011110,%11110101,%01001010,%11010101,%00101011
        FCB     %01011000,%10101101,%01010010,%01010101,%11001111,%01110011
        FCB     %00010001,%00010001,%10011101,%11100101,%00101110,%01011011
        FCB     %10100101,%11001011,%01010101,%11101111,%01110010,%01010111
        FCB     %11001011,%01010001,%01100010,%10111100,%00101000,%00111111
        FCB     %01001010,%01001001,%11101010,%01110111,%00101011,%11110010
        FCB     %10111111,%00101111,%01010100,%10101101,%00101111,%11110111
        FCB     %00101011,%01010001,%11000100,%01000100,%01100111,%10101000
        FCB     %01111010,%00100010,%01111110,%10010101,%01111010,%00010101
        FCB     %11100010,%00100101,%00111010,%01010010,%01001010,%11110000
        FCB     %10101100,%11111101,%10101011,%00011110,%10100111,%11001111
        FCB     %11110010,%01000111,%01010011,%11111100,%11110101,%00001011
        FCB     %01010100,%00111101,%01111110,%10000101,%00111110,%01111111
        FCB     %10010100,%10101000,%11110011,%00010001,%00010000,%10000101
        FCB     %00101010,%00010110,%11101000,%01011111,%11100001,%00101110
        FCB     %01010111,%10101001,%01001110,%10000101,%10101010,%10010101
        FCB     %11111001,%01011110,%10000101,%00111010,%01010100,%00111101
        FCB     %01000011,%11110000,%10111000,%11111101,%00101011,%00010100
        FCB     %10111000,%00100011,%11100101,%00111110,%01001001,%11111001
        FCB     %01001110,%10110111,%11101000,%01111010,%01000111,%11001011
        FCB     %01110100,%10111111,%11001111,%01100010,%00100000,%00110010
        FCB     %10010101,%00001011,%01110100,%00100100,%01111100,%01101101
        FCB     %00101001,%00000111,%11101010,%01010010,%11100100,%10001110
        FCB     %10000101,%10111110,%00110011,%11111100,%10110101,%01001110
        FCB     %00011000,%10010101,%11111101,%11001111,%11010000,%00011111
        FCB     %11010100,%10100111,%01000010,%11111101,%01001110,%00011011
        FCB     %10100001,%11111110,%01011011,%10100001,%11011100,%01001110
        FCB     %00001000,%11010110,%11111111,%00101011,%11110010,%11011111
        FCB     %00101011,%11110000,%10000111,%11101001,%01010100,%11111101
        FCB     %00001010,%11010101,%11101000,%01111110,%10000101,%11111110
        FCB     %00111110,%11000101,%10111000,%01101000,%01011011,%10101001
        FCB     %01010000,%01110111,%11001010,%11111100,%10100111,%01011010
        FCB     %10000111,%01111000,%00100011,%10110001,%01011011,%10111000
        FCB     %10011100,%00110011,%10110100,%00101011,%11010000,%10101111
        FCB     %01000010,%11011101,%00000010,%01110111,%00111111,%00100000
        FCB     %10011001,%11010100,%01111111,%10101010,%01111110,%00011101
        FCB     %10011111,%10011000,%01001101,%11101000,%01010011,%11100101
        FCB     %10101110,%11010000,%00101111,%01000010,%10011101,%01001111
        FCB     %11010010,%11100111,%11110001,%00111000,%00100001,%00010001
        FCB     %11101000,%00010111,%11100111,%10111001,%11101010,%01110101
        FCB     %00100111,%01111100,%00000010,%00100001,%01001111,%10011110
        FCB     %10010010,%01111010,%10000000,%10011111,%10011111,%11100111
        FCB     %11111001,%00100111,%11100000,%10001111,%10011111,%10101001
        FCB     %01011111,%10011000,%10011000,%00010010,%11100111,%10101100
        FCB     %01001100,%11101000,%00011000,%10010001,%11010000,%10010101
        FCB     %11010000,%00100111,%11000010,%10011110,%10000010,%00010001
        FCB     %01001110,%01011001,%11101110,%00010111,%10100000,%01111111
        FCB     %10010010,%10111010,%00000010,%11111010,%10010100,%10110001
        FCB     %00110000,%00100001,%01001010,%10000100,%11011110,%10000000
        FCB     %10000010,%10111101,%01001011,%01110111,%00011101,%11001110
        FCB     %00111111,%10001100,%11101100,%10000010,%10011100,%00111101
        FCB     %00101011,%11001001,%00101000,%11010100,%00100001,%11000010
        FCB     %11111100,%10110111,%01010011,%11011101,%11110101,%11000001
        FCB     %00111111,%00101001,%01110111,%11111000,%10011000,%00110011
        FCB     %11010011,%01111010,%10001111,%11100000,%10100010,%10111101
        FCB     %00001010,%11110111,%00011001,%11101010,%00011111,%11100011
        FCB     %00111011,%01110011,%11010100,%11100001,%01001001,%11111110
        FCB     %01111110,%00100110,%01011011,%10111001,%01001011,%10111111
        FCB     %10100000,%01000011,%11011100,%00010111,%11010010,%11101111
        FCB     %00100100,%10000010,%01111111,%01010001,%11000101,%10000010
        FCB     %01111100,%10100011,%11101011,%00010010,%01111001,%00000011
        FCB     %00111011,%01100011,%11011100,%10101111,%01010010,%11011101
        FCB     %10000111,%01010100,%10100000,%11101110,%11011000,%11110101
        FCB     %01111001,%10100111,%11111001,%01001110,%00110010,%01111111
        FCB     %10010101,%11100010,%00100111,%11101000,%01010111,%11110111
        FCB     %00101011,%01110010,%10011101,%00000010,%10011110,%10101000
        FCB     %01101111,%10011111,%10100001,%11101111,%11001010,%00001111
        FCB     %11010000,%10100101,%10001011,%00001111,%10101001,%11111010
        FCB     %10010010,%10111001,%00100011,%01101100,%01111011,%10010101
        FCB     %11101010,%01011111,%10101000,%11001111,%11010100,%10100000
        FCB     %11011010,%01010100,%00111101,%11001010,%01110010,%10001111
        FCB     %11110011,%11110100,%00101001,%11000110,%00001111,%11010100
        FCB     %10100000,%01001110,%01011001,%01001110,%01001001,%00110011
        FCB     %10101000,%01000010,%10010101,%01000011,%01111100,%10101111
        FCB     %11001111,%01001010,%00000100,%01110101,%00110001,%01100001
        FCB     %10010101,%11111001,%00100111,%10011100,%00011010,%11100101
        FCB     %01111010,%10010111,%11101100,%00010000,%10101111,%01000001
        FCB     %10010110,%10111001,%01001110,%01110001,%01011111,%10000001
        FCB     %01100011,%11110110,%00111111,%01000000,%10111101,%11001111
        FCB     %11110011,%11110100,%00101101,%11001000,%00100100,%01110111
        FCB     %00001000,%01111110,%11000001,%11111011,%00010100,%00001010
        FCB     %01010100,%00010101,%11010100,%10100111,%10001010,%00000100
        FCB     %00101001,%01010000,%10010011,%11001001,%00011101,%11001111
        FCB     %11011100,%00111111,%01010010,%11111100,%10000000,%11011101
        FCB     %01000010,%10010110,%11111001,%11111110,%01010011,%10101001
        FCB     %01111110,%10100001,%00111000,%10000001,%01101110,%10100101
        FCB     %01111110,%01010000,%00101111,%01000010,%10011100,%01000000
        FCB     %10111111,%00101000,%00101111,%01100000,%10011101,%00001111
        FCB     %11010000,%11111101,%00000111,%11010100,%10100000,%01011110
        FCB     %10100101,%00111011,%00011111,%11000101,%00000011,%00010010
        FCB     %11111001,%00000001,%00101010,%00011111,%10110000,%01011110
        FCB     %11000100,%10001110,%01001000,%01001110,%11000000,%10001110
        FCB     %10100100,%11011110,%11000000,%10001110,%00100010,%01011111
        FCB     %10100000,%01111110,%10000100,%10001110,%10000101,%11111010
        FCB     %10010010,%00111001,%11000000,%11101111,%10011111,%10101000
        FCB     %01011110,%11000101,%01111110,%01111111,%00010100,%00001010
        FCB     %01001100,%11100100,%10000100,%00111111,%00100000,%00011101
        FCB     %11000100,%00000000,%10011111,%00100100,%00010011,%11110010
        FCB     %10011101,%10001001,%10111101,%10000000,%11110111,%00110100
        FCB     %00011111,%11110010,%10100001,%10111011,%10010101,%11110001
        FCB     %10000000
CL5LEN  EQU     *-_COMCL5                                                       ;;Fixme was: CL5LEN     EQU     *-COMCL5
;*
;*
;*      TRANSPORTERS
TRASRC
        FDB     $DDDD,$DDDD,$DDDD,$DDDD,$DDDD,$DDDD,$DDDD
        FDB     $0DDD,$DDDD,$DDDD,$DDDD,$DDDD,$DDDD,$DDD0
        FDB     $000D,$DDDD,$DDDD,$DDDD,$DDDD,$DDDD,$D000
;*
_TRANS1 FDB     $0A00,TRASRC,$3551,$0E03!DMAFIX                 ;OLD X $6A      ;;Fixme was: !XDMAFIX
_TRANS2 FDB     $0A00,TRASRC,$7081,$0E03!DMAFIX                 ;OLD X $E0      ;;Fixme was: !XDMAFIX
_TRANS3 FDB     $0A00,TRASRC,$088A,$0E03!DMAFIX                 ;OLD X $10      ;;Fixme was: !XDMAFIX
_TRANS4 FDB     $0A00,TRASRC,$3CD3,$0E03!DMAFIX                 ;OLD X $78      ;;Fixme was: !XDMAFIX
;*
;*
;*
;*      OSTRICH FLYING, RUNNING, SKIDDING, & STANDING FRAMES
;*
;*
_OSTRICH EQU    *
ORSKID  FDB     CSKIDR,$00EF,ORUNSR
        FDB     CSKIDL,$01EF,ORUNSL
ORSTND  FDB     CSTN4R,$00ED,ORUN4R     ;CSTN0R,$00ED,ORUN0R
        FDB     CSTN4L,$01ED,ORUN4L     ;CSTN0L,$00ED,ORUN0L
ORRUN1  FDB     CSTN1R,$00ED,ORUN1R
        FDB     CSTN1L,$01ED,ORUN1L
ORRUN2  FDB     CSTN2R,$00ED,ORUN2R
        FDB     CSTN2L,$02ED,ORUN2L
ORRUN3  FDB     CSTN3R,$00ED,ORUN3R
        FDB     CSTN3L,$02ED,ORUN3L
ORRUN4  FDB     CSTN4R,$00ED,ORUN4R
        FDB     CSTN4L,$01ED,ORUN4L
ORFLAP  FDB     CWNG1R,$00ED,OFLY1R
        FDB     CWNG1L,$00ED,OFLY1L
ORFLOP  FDB     CWNG2R,$00ED,OFLY1R     ;,OFLY2R
        FDB     CWNG2L,$00ED,OFLY1L     ;,OFLY2L
ORFLIP  FDB     CWNG3R,$00ED,OFLY3R
        FDB     CWNG3L,$00ED,OFLY3L
;*
;*      STORK
;*
_STORK  EQU     *
        FDB     CSKIDR,$00EE,SRUNSR
        FDB     CSKIDL,$02EE,SRUNSL
        FDB     CSTN4R,$00ED,SRUN4R     ;CSTN0R,$00ED,SRUN0R
        FDB     CSTN4L,$01ED,SRUN4L     ;CSTN0L,$00ED,SRUN0L
        FDB     CSTN1R,$00ED,SRUN1R
        FDB     CSTN1L,$00ED,SRUN1L
        FDB     CSTN2R,$00ED,SRUN2R
        FDB     CSTN2L,$01ED,SRUN2L
        FDB     CSTN3R,$00ED,SRUN3R
        FDB     CSTN3L,$01ED,SRUN3L
        FDB     CSTN4R,$00ED,SRUN4R
        FDB     CSTN4L,$01ED,SRUN4L
        FDB     CWNG1R,$00ED,SFLY1R
        FDB     CWNG1L,$01ED,SFLY1L
        FDB     CWNG2R,$00ED,SFLY1R     ;,SFLY2R
        FDB     CWNG2L,$01ED,SFLY1L     ;,SFLY2L
        FDB     CWNG3R,$00ED,SFLY3R
        FDB     CWNG3L,$00ED,SFLY3L
;*
CWNG1R
CWNG2R
CWNG3R  FDB     7+COFF,9+COFF
        FDB     7+COFF,9+COFF
        FDB     7+COFF,8+COFF
        FDB     6+COFF,10+COFF
        FDB     6+COFF,17+COFF
        FDB     2+COFF,10+COFF
        FDB     2+COFF,14+COFF
        FDB     2+COFF,14+COFF
        FDB     4+COFF,13+COFF
        FDB     5+COFF,12+COFF
        FDB     5+COFF,12+COFF
        FDB     5+COFF,12+COFF
        FDB     11+COFF,12+COFF
        FDB     $8100,$8100
        FDB     $8100,$8100     ;1 EXTRA END OF POINTER ENTRY
;*
CWNG1L
CWNG2L
CWNG3L  FDB     10+COFF,12+COFF
        FDB     10+COFF,12+COFF
        FDB     11+COFF,12+COFF
        FDB     9+COFF,13+COFF
        FDB     2+COFF,13+COFF
        FDB     9+COFF,17+COFF
        FDB     5+COFF,17+COFF
        FDB     5+COFF,17+COFF
        FDB     6+COFF,15+COFF
        FDB     7+COFF,14+COFF
        FDB     7+COFF,14+COFF
        FDB     7+COFF,14+COFF
        FDB     7+COFF,8+COFF
        FDB     $8100,$8100
        FDB     $8100,$8100     ;1 EXTRA END OF POINTER ENTRY
;*
CSKIDR  FDB     $8000,$8000     ;NO COLISION ON THIS LINE
        FDB     $8000,$8000     ;NO COLISION ON THIS LINE
        FDB     7+COFF,9+COFF
        FDB     7+COFF,9+COFF
        FDB     7+COFF,8+COFF
        FDB     6+COFF,10+COFF
        FDB     6+COFF,10+COFF
        FDB     2+COFF,10+COFF
        FDB     2+COFF,11+COFF
        FDB     3+COFF,11+COFF
        FDB     4+COFF,11+COFF
        FDB     5+COFF,11+COFF
        FDB     5+COFF,11+COFF
        FDB     6+COFF,10+COFF
        FDB     7+COFF,11+COFF
        FDB     7+COFF,11+COFF
        FDB     7+COFF,12+COFF
        FDB     7+COFF,13+COFF
        FDB     7+COFF,14+COFF
        FDB     8+COFF,15+COFF
        FDB     $8100,$8100     ;1 EXTRA END OF POINTER ENTRY
;*
CSTN1R  FDB     7+COFF,9+COFF
        FDB     7+COFF,9+COFF
        FDB     7+COFF,8+COFF
        FDB     6+COFF,10+COFF
        FDB     6+COFF,17+COFF
        FDB     2+COFF,10+COFF
        FDB     2+COFF,14+COFF
        FDB     3+COFF,14+COFF
        FDB     4+COFF,13+COFF
        FDB     5+COFF,12+COFF
        FDB     5+COFF,12+COFF
        FDB     6+COFF,10+COFF
        FDB     4+COFF,10+COFF
        FDB     4+COFF,9+COFF
        FDB     6+COFF,9+COFF
        FDB     7+COFF,10+COFF
        FDB     7+COFF,9+COFF
        FDB     7+COFF,9+COFF
        FDB     7+COFF,9+COFF
        FDB     7+COFF,10+COFF
        FDB     $8100,$8100     ;1 EXTRA END OF POINTER ENTRY
;*
;*      AND THE EVER POPULAR COPYRIGHT MESSAGE
;*
        FCC     'JOUST (C) 1982 WILLIAMS ELECTRONICS INC.'
;*
CSTN2R  FDB     7+COFF,9+COFF
        FDB     7+COFF,9+COFF
        FDB     7+COFF,8+COFF
        FDB     6+COFF,10+COFF
        FDB     6+COFF,17+COFF
        FDB     2+COFF,10+COFF
        FDB     2+COFF,14+COFF
        FDB     3+COFF,14+COFF
        FDB     4+COFF,13+COFF
        FDB     5+COFF,12+COFF
        FDB     5+COFF,12+COFF
        FDB     6+COFF,10+COFF
        FDB     8+COFF,10+COFF
        FDB     7+COFF,10+COFF
        FDB     6+COFF,10+COFF
        FDB     6+COFF,12+COFF
        FDB     6+COFF,12+COFF
        FDB     6+COFF,13+COFF
        FDB     6+COFF,13+COFF
        FDB     6+COFF,8+COFF
        FDB     $8100,$8100     ;1 EXTRA END OF POINTER ENTRY
;*
CSTN3R  FDB     7+COFF,9+COFF
        FDB     7+COFF,9+COFF
        FDB     7+COFF,8+COFF
        FDB     6+COFF,10+COFF
        FDB     6+COFF,17+COFF
        FDB     2+COFF,10+COFF
        FDB     2+COFF,14+COFF
        FDB     3+COFF,14+COFF
        FDB     4+COFF,13+COFF
        FDB     5+COFF,12+COFF
        FDB     5+COFF,12+COFF
        FDB     6+COFF,11+COFF
        FDB     7+COFF,11+COFF
        FDB     6+COFF,10+COFF
        FDB     6+COFF,11+COFF
        FDB     5+COFF,12+COFF
        FDB     5+COFF,13+COFF
        FDB     5+COFF,14+COFF
        FDB     5+COFF,14+COFF
        FDB     5+COFF,14+COFF
        FDB     $8100,$8100     ;1 EXTRA END OF POINTER ENTRY
;*
CSTN4R  FDB     7+COFF,9+COFF
        FDB     7+COFF,9+COFF
        FDB     7+COFF,8+COFF
        FDB     6+COFF,10+COFF
        FDB     6+COFF,17+COFF
        FDB     2+COFF,10+COFF
        FDB     2+COFF,14+COFF
        FDB     3+COFF,14+COFF
        FDB     4+COFF,13+COFF
        FDB     5+COFF,12+COFF
        FDB     5+COFF,12+COFF
        FDB     6+COFF,10+COFF
        FDB     4+COFF,10+COFF
        FDB     4+COFF,9+COFF
        FDB     4+COFF,9+COFF
        FDB     5+COFF,9+COFF
        FDB     5+COFF,10+COFF
        FDB     4+COFF,10+COFF
        FDB     4+COFF,10+COFF
        FDB     4+COFF,11+COFF
        FDB     $8100,$8100     ;1 EXTRA END OF POINTER ENTRY
;*
CSKIDL  FDB     $8000,$8000     ;NO COLISION ON THIS LINE
        FDB     $8000,$8000     ;NO COLISION ON THIS LINE
        FDB     10+COFF,12+COFF
        FDB     10+COFF,12+COFF
        FDB     11+COFF,12+COFF
        FDB     9+COFF,13+COFF
        FDB     9+COFF,13+COFF
        FDB     9+COFF,17+COFF
        FDB     8+COFF,17+COFF
        FDB     8+COFF,16+COFF
        FDB     8+COFF,15+COFF
        FDB     8+COFF,14+COFF
        FDB     8+COFF,14+COFF
        FDB     8+COFF,13+COFF
        FDB     8+COFF,12+COFF
        FDB     8+COFF,12+COFF
        FDB     7+COFF,12+COFF
        FDB     6+COFF,12+COFF
        FDB     5+COFF,12+COFF
        FDB     4+COFF,13+COFF
        FDB     $8100,$8100     ;1 EXTRA END OF POINTER ENTRY
;*
CSTN1L  FDB     10+COFF,12+COFF
        FDB     10+COFF,12+COFF
        FDB     11+COFF,12+COFF
        FDB     9+COFF,13+COFF
        FDB     2+COFF,13+COFF
        FDB     9+COFF,17+COFF
        FDB     5+COFF,17+COFF
        FDB     5+COFF,16+COFF
        FDB     6+COFF,15+COFF
        FDB     7+COFF,14+COFF
        FDB     7+COFF,14+COFF
        FDB     9+COFF,13+COFF
        FDB     9+COFF,15+COFF
        FDB     10+COFF,15+COFF
        FDB     10+COFF,13+COFF
        FDB     9+COFF,12+COFF
        FDB     10+COFF,12+COFF
        FDB     10+COFF,12+COFF
        FDB     10+COFF,12+COFF
        FDB     9+COFF,12+COFF
        FDB     $8100,$8100     ;1 EXTRA END OF POINTER ENTRY
;*
CSTN2L  FDB     10+COFF,12+COFF
        FDB     10+COFF,12+COFF
        FDB     11+COFF,12+COFF
        FDB     9+COFF,13+COFF
        FDB     2+COFF,13+COFF
        FDB     9+COFF,17+COFF
        FDB     5+COFF,17+COFF
        FDB     5+COFF,16+COFF
        FDB     6+COFF,15+COFF
        FDB     7+COFF,14+COFF
        FDB     7+COFF,14+COFF
        FDB     9+COFF,13+COFF
        FDB     9+COFF,11+COFF
        FDB     9+COFF,12+COFF
        FDB     9+COFF,13+COFF
        FDB     5+COFF,13+COFF
        FDB     5+COFF,13+COFF
        FDB     4+COFF,13+COFF
        FDB     4+COFF,13+COFF
        FDB     11+COFF,13+COFF
        FDB     $8100,$8100     ;1 EXTRA END OF POINTER ENTRY
;*
CSTN3L  FDB     10+COFF,12+COFF
        FDB     10+COFF,12+COFF
        FDB     11+COFF,12+COFF
        FDB     9+COFF,13+COFF
        FDB     2+COFF,13+COFF
        FDB     9+COFF,17+COFF
        FDB     5+COFF,17+COFF
        FDB     5+COFF,16+COFF
        FDB     6+COFF,15+COFF
        FDB     7+COFF,14+COFF
        FDB     7+COFF,14+COFF
        FDB     9+COFF,13+COFF
        FDB     8+COFF,12+COFF
        FDB     9+COFF,13+COFF
        FDB     8+COFF,13+COFF
        FDB     7+COFF,14+COFF
        FDB     6+COFF,14+COFF
        FDB     5+COFF,14+COFF
        FDB     5+COFF,14+COFF
        FDB     5+COFF,14+COFF
        FDB     $8100,$8100     ;1 EXTRA END OF POINTER ENTRY
;*
CSTN4L  FDB     10+COFF,12+COFF
        FDB     10+COFF,12+COFF
        FDB     11+COFF,12+COFF
        FDB     9+COFF,13+COFF
        FDB     2+COFF,13+COFF
        FDB     9+COFF,17+COFF
        FDB     5+COFF,17+COFF
        FDB     5+COFF,16+COFF
        FDB     6+COFF,15+COFF
        FDB     7+COFF,14+COFF
        FDB     7+COFF,14+COFF
        FDB     9+COFF,13+COFF
        FDB     9+COFF,15+COFF
        FDB     10+COFF,15+COFF
        FDB     10+COFF,15+COFF
        FDB     10+COFF,14+COFF
        FDB     9+COFF,14+COFF
        FDB     9+COFF,15+COFF
        FDB     9+COFF,15+COFF
        FDB     8+COFF,15+COFF
        FDB     $8100,$8100     ;1 EXTRA END OF POINTER ENTRY
;*
;*
;*      STORK IMAGES
;*              (RIGHT)
;*
;*AAFF0A1478B0FFF4FFF4FFF4FFF4FFF4
;*00FF70580F3F51E81490CD111FA40A67
SRUN1R  FDB     $0914!DMAFIX                                                    ;;Fixme was: !XDMAFIX
        FCB     $00,$00,$00,$00,$00,$06,$D3,$00,$00
        FCB     $00,$00,$00,$00,$00,$01,$94,$C4,$E0
        FCB     $00,$00,$00,$00,$00,$09,$18,$00,$00
        FCB     $00,$00,$00,$00,$00,$06,$D6,$00,$00
        FCB     $00,$00,$00,$00,$00,$0D,$10,$00,$00
        FCB     $00,$00,$00,$00,$00,$0D,$10,$00,$00
        FCB     $00,$00,$00,$00,$06,$D1,$10,$00,$00
        FCB     $00,$00,$06,$DD,$55,$11,$D0,$00,$00
        FCB     $00,$00,$CD,$5D,$D5,$15,$60,$00,$00
        FCB     $00,$05,$85,$51,$54,$1D,$60,$00,$00
        FCB     $04,$84,$C4,$55,$8D,$56,$00,$00,$00
        FCB     $04,$4C,$CC,$88,$D5,$80,$00,$00,$00
        FCB     $00,$0D,$DD,$D1,$D8,$00,$00,$00,$00
        FCB     $00,$DD,$88,$E8,$80,$00,$00,$00,$00
        FCB     $00,$0E,$88,$08,$C0,$00,$00,$00,$00
        FCB     $00,$08,$CC,$CC,$80,$00,$00,$00,$00
        FCB     $00,$00,$00,$EE,$CC,$E0,$00,$00,$00
        FCB     $00,$00,$00,$0C,$EE,$80,$00,$00,$00
        FCB     $00,$00,$00,$0C,$80,$00,$00,$00,$00
        FCB     $00,$00,$00,$08,$C6,$00,$00,$00,$00
;*AAFF091478B0FFF4FFF4FFF4FFF4FFF4
;*00FF70580F3F51E81490CD111FA40A67
SRUN2R  FDB     $0814!DMAFIX                                                    ;;Fixme was: !XDMAFIX
        FCB     $00,$00,$00,$00,$00,$6D,$30,$00
        FCB     $00,$00,$00,$00,$00,$19,$4C,$40
        FCB     $00,$00,$00,$00,$00,$91,$80,$00
        FCB     $00,$00,$00,$00,$00,$0D,$D0,$00
        FCB     $00,$00,$00,$00,$00,$0D,$D0,$00
        FCB     $00,$00,$00,$00,$00,$0D,$10,$00
        FCB     $00,$00,$00,$00,$06,$D1,$10,$00
        FCB     $00,$00,$06,$DD,$55,$11,$50,$00
        FCB     $00,$00,$CD,$5D,$D5,$15,$D0,$00
        FCB     $00,$05,$85,$51,$5C,$15,$60,$00
        FCB     $00,$84,$CC,$55,$8D,$56,$00,$00
        FCB     $04,$44,$CC,$88,$DD,$80,$00,$00
        FCB     $00,$0D,$DD,$D1,$D8,$00,$00,$00
        FCB     $00,$DD,$86,$88,$80,$00,$00,$00
        FCB     $00,$00,$0E,$8C,$CC,$E0,$00,$00
        FCB     $00,$00,$0E,$C8,$EC,$C8,$00,$00
        FCB     $00,$00,$08,$C0,$00,$EC,$00,$00
        FCB     $00,$00,$08,$F0,$00,$08,$80,$00
        FCB     $00,$00,$08,$CE,$00,$00,$80,$00
        FCB     $00,$00,$0E,$CC,$00,$00,$00,$00
;*AAFF091478B0FFF4FFF4FFF4FFF4FFF4
;*00FF70580F3F51E81490CD111FA40A67
SRUN3R  FDB     $0914!DMAFIX                                                    ;;Fixme was: !XDMAFIX
        FCB     $00,$00,$00,$00,$00,$6D,$30,$00,$00
        FCB     $00,$00,$00,$00,$00,$19,$4C,$4E,$00
        FCB     $00,$00,$00,$00,$00,$91,$80,$00,$00
        FCB     $00,$00,$00,$00,$00,$0D,$D0,$00,$00
        FCB     $00,$00,$00,$00,$00,$0D,$D0,$00,$00
        FCB     $00,$00,$00,$00,$00,$0D,$10,$00,$00
        FCB     $00,$00,$00,$00,$06,$D1,$10,$00,$00
        FCB     $00,$00,$06,$DD,$55,$11,$50,$00,$00
        FCB     $00,$00,$CD,$5D,$D5,$15,$D0,$00,$00
        FCB     $00,$05,$85,$51,$5C,$15,$60,$00,$00
        FCB     $00,$84,$CC,$55,$8D,$56,$00,$00,$00
        FCB     $04,$44,$CC,$88,$DD,$80,$00,$00,$00
        FCB     $00,$0D,$DD,$D1,$D8,$00,$00,$00,$00
        FCB     $00,$DD,$60,$08,$88,$00,$00,$00,$00
        FCB     $00,$00,$08,$C8,$EC,$80,$00,$00,$00
        FCB     $00,$00,$EC,$80,$0C,$8E,$00,$00,$00
        FCB     $00,$00,$8C,$80,$00,$CC,$E0,$00,$00
        FCB     $00,$00,$8C,$E0,$00,$08,$CE,$00,$00
        FCB     $00,$00,$C8,$00,$00,$0E,$88,$00,$00
        FCB     $00,$00,$CC,$00,$00,$0E,$EC,$00,$00
;*AAFF091478B0FFF4FFF4FFF4FFF4FFF4
;*00FF70580F3F51E81490CD111FA40A67
SRUN4R  FDB     $0914!DMAFIX                                                    ;;Fixme was: !XDMAFIX
        FCB     $00,$00,$00,$00,$00,$06,$D3,$00,$00
        FCB     $00,$00,$00,$00,$00,$01,$94,$C4,$00
        FCB     $00,$00,$00,$00,$00,$09,$18,$00,$00
        FCB     $00,$00,$00,$00,$00,$06,$D0,$00,$00
        FCB     $00,$00,$00,$00,$00,$06,$10,$00,$00
        FCB     $00,$00,$00,$00,$00,$0D,$10,$00,$00
        FCB     $00,$00,$00,$00,$00,$D1,$10,$00,$00
        FCB     $00,$00,$06,$DD,$55,$11,$D0,$00,$00
        FCB     $00,$00,$CD,$5D,$D5,$15,$60,$00,$00
        FCB     $00,$05,$85,$51,$5C,$1D,$60,$00,$00
        FCB     $00,$84,$CC,$55,$8D,$56,$00,$00,$00
        FCB     $04,$44,$CC,$88,$DD,$80,$00,$00,$00
        FCB     $00,$0D,$DD,$D1,$D8,$00,$00,$00,$00
        FCB     $00,$DD,$68,$8E,$88,$00,$00,$00,$00
        FCB     $00,$0E,$CC,$08,$CE,$00,$00,$00,$00
        FCB     $00,$08,$CE,$08,$C0,$00,$00,$00,$00
        FCB     $00,$00,$C0,$00,$CE,$00,$00,$00,$00
        FCB     $00,$00,$C0,$00,$88,$00,$00,$00,$00
        FCB     $00,$08,$C0,$00,$EC,$00,$00,$00,$00
        FCB     $00,$0C,$C0,$00,$0C,$C0,$00,$00,$00
;*AAFF081378B0FFF4FFF4FFF4FFF4FFF4
;*00FF70580F3F51E81490CD111FA40A67
SRUNSR  FDB     $0813!DMAFIX                                                    ;;Fixme was: !XDMAFIX
        FCB     $00,$00,$00,$00,$03,$D3,$00,$00
        FCB     $00,$00,$00,$00,$0D,$94,$CE,$00
        FCB     $00,$00,$00,$00,$09,$18,$84,$00
        FCB     $00,$00,$00,$00,$00,$61,$60,$00
        FCB     $00,$00,$00,$00,$00,$01,$D0,$00
        FCB     $00,$00,$00,$00,$00,$0D,$D0,$00
        FCB     $00,$00,$00,$00,$00,$0D,$10,$00
        FCB     $00,$00,$06,$DD,$55,$11,$50,$00
        FCB     $00,$00,$CD,$5D,$D5,$15,$D0,$00
        FCB     $00,$05,$85,$51,$5C,$15,$60,$00
        FCB     $00,$84,$CC,$55,$8D,$56,$00,$00
        FCB     $04,$44,$CC,$88,$DD,$80,$00,$00
        FCB     $00,$0D,$DD,$D1,$D8,$00,$00,$00
        FCB     $00,$DD,$68,$88,$C8,$00,$00,$00
        FCB     $00,$00,$00,$8C,$EC,$80,$00,$00
        FCB     $00,$00,$00,$08,$CE,$CE,$00,$00
        FCB     $00,$00,$00,$00,$EC,$EC,$E0,$00
        FCB     $00,$00,$00,$00,$0E,$CE,$CE,$00
        FCB     $00,$00,$00,$00,$00,$CC,$EC,$00
;*AAFF090E78B0FFF4FFF4FFF4FFF4FFF4
;*00FF70580F3F51E81490CD111FA40A67
SFLY1R  FDB     $090E!DMAFIX                                                    ;;Fixme was: !XDMAFIX
        FCB     $00,$00,$00,$00,$00,$6D,$30,$00,$00
        FCB     $00,$00,$00,$00,$00,$19,$4C,$4E,$00
        FCB     $00,$00,$00,$00,$00,$91,$80,$00,$00
        FCB     $00,$00,$00,$00,$00,$01,$D0,$00,$00
        FCB     $00,$00,$00,$00,$00,$01,$D0,$00,$00
        FCB     $00,$00,$09,$77,$99,$0D,$10,$00,$00
        FCB     $00,$00,$6D,$15,$DC,$6D,$10,$00,$00
        FCB     $00,$06,$15,$51,$5C,$D1,$50,$00,$00
        FCB     $00,$6D,$55,$15,$D6,$DD,$60,$00,$00
        FCB     $00,$DD,$55,$5C,$58,$68,$00,$00,$00
        FCB     $04,$86,$DC,$CC,$CC,$E0,$00,$00,$00
        FCB     $08,$48,$68,$C4,$C4,$88,$00,$00,$00
        FCB     $00,$80,$EE,$88,$4E,$CE,$C0,$00,$00
        FCB     $00,$00,$00,$0E,$8E,$8E,$00,$00,$00
;*AAFF0A0D78B0FFF4FFF4FFF4FFF4FFF4
;*00FF70580F3F51E81490CD111FA40A67
SFLY3R  FDB     $090D!DMAFIX                                                    ;;Fixme was: !XDMAFIX
        FCB     $00,$C8,$00,$00,$00,$00,$00,$00,$00
        FCB     $0C,$04,$D0,$00,$00,$06,$D3,$00,$00
        FCB     $00,$44,$DD,$00,$00,$0D,$94,$C4,$E0
        FCB     $04,$48,$84,$90,$00,$09,$18,$00,$00
        FCB     $00,$CC,$88,$C9,$00,$00,$1D,$00,$00
        FCB     $0C,$CC,$CC,$85,$90,$00,$1D,$00,$00
        FCB     $00,$0C,$5C,$8D,$58,$9D,$16,$00,$00
        FCB     $00,$CC,$5D,$DC,$5D,$D1,$D6,$00,$00
        FCB     $00,$08,$4D,$D1,$51,$11,$60,$00,$00
        FCB     $00,$4C,$55,$11,$11,$D6,$00,$00,$00
        FCB     $04,$C4,$58,$8C,$1D,$C0,$00,$00,$00
        FCB     $04,$54,$0E,$E8,$88,$00,$00,$00,$00
        FCB     $00,$00,$88,$E0,$08,$00,$00,$00,$00
;*
;*      (LEFT)
;*      STORK LEFT FACED IMAGES
;*
;*AAFF0A1478B0FFF4FFF4FFF4FFF4FFF4
;*00FF70580F3F51E81490CD111FA40A67
SRUN1L  FDB     $0914!DMAFIX                                                    ;;Fixme was: !XDMAFIX
        FCB     $00,$00,$3D,$60,$00,$00,$00,$00,$00
        FCB     $0E,$4C,$49,$10,$00,$00,$00,$00,$00
        FCB     $00,$00,$81,$90,$00,$00,$00,$00,$00
        FCB     $00,$00,$6D,$60,$00,$00,$00,$00,$00
        FCB     $00,$00,$01,$D0,$00,$00,$00,$00,$00
        FCB     $00,$00,$01,$D0,$00,$00,$00,$00,$00
        FCB     $00,$00,$01,$1D,$60,$00,$00,$00,$00
        FCB     $00,$00,$0D,$11,$55,$DD,$60,$00,$00
        FCB     $00,$00,$06,$51,$5D,$D5,$DC,$00,$00
        FCB     $00,$00,$06,$D1,$45,$15,$58,$50,$00
        FCB     $00,$00,$00,$65,$D8,$55,$4C,$48,$40
        FCB     $00,$00,$00,$08,$5D,$88,$CC,$C4,$40
        FCB     $00,$00,$00,$00,$8D,$1D,$DD,$D0,$00
        FCB     $00,$00,$00,$00,$08,$8E,$88,$DD,$00
        FCB     $00,$00,$00,$00,$0C,$80,$88,$E0,$00
        FCB     $00,$00,$00,$00,$08,$CC,$CC,$80,$00
        FCB     $00,$00,$00,$0E,$CC,$EE,$00,$00,$00
        FCB     $00,$00,$00,$08,$EE,$C0,$00,$00,$00
        FCB     $00,$00,$00,$00,$08,$C0,$00,$00,$00
        FCB     $00,$00,$00,$00,$6C,$80,$00,$00,$00
;*AAFF091478B0FFF4FFF4FFF4FFF4FFF4
;*00FF70580F3F51E81490CD111FA40A67
SRUN2L  FDB     $0814!DMAFIX                                                    ;;Fixme was: !XDMAFIX
        FCB     $00,$03,$D6,$00,$00,$00,$00,$00
        FCB     $04,$C4,$91,$00,$00,$00,$00,$00
        FCB     $00,$08,$19,$00,$00,$00,$00,$00
        FCB     $00,$0D,$D0,$00,$00,$00,$00,$00
        FCB     $00,$0D,$D0,$00,$00,$00,$00,$00
        FCB     $00,$01,$D0,$00,$00,$00,$00,$00
        FCB     $00,$01,$1D,$60,$00,$00,$00,$00
        FCB     $00,$05,$11,$55,$DD,$60,$00,$00
        FCB     $00,$0D,$51,$5D,$D5,$DC,$00,$00
        FCB     $00,$06,$51,$C5,$15,$58,$50,$00
        FCB     $00,$00,$65,$D8,$55,$CC,$48,$00
        FCB     $00,$00,$08,$DD,$88,$CC,$44,$40
        FCB     $00,$00,$00,$8D,$1D,$DD,$D0,$00
        FCB     $00,$00,$00,$08,$88,$68,$DD,$00
        FCB     $00,$00,$0E,$CC,$C8,$E0,$00,$00
        FCB     $00,$00,$8C,$CE,$8C,$E0,$00,$00
        FCB     $00,$00,$CE,$00,$0C,$80,$00,$00
        FCB     $00,$08,$80,$00,$0F,$80,$00,$00
        FCB     $00,$08,$00,$00,$EC,$80,$00,$00
        FCB     $00,$00,$00,$00,$CC,$E0,$00,$00
;*AAFF091478B0FFF4FFF4FFF4FFF4FFF4
;*00FF70580F3F51E81490CD111FA40A67
SRUN3L  FDB     $0814!DMAFIX                                                    ;;Fixme was: !XDMAFIX
        FCB     $00,$03,$D6,$00,$00,$00,$00,$00
        FCB     $E4,$C4,$91,$00,$00,$00,$00,$00
        FCB     $00,$08,$19,$00,$00,$00,$00,$00
        FCB     $00,$0D,$D0,$00,$00,$00,$00,$00
        FCB     $00,$0D,$D0,$00,$00,$00,$00,$00
        FCB     $00,$01,$D0,$00,$00,$00,$00,$00
        FCB     $00,$01,$1D,$60,$00,$00,$00,$00
        FCB     $00,$05,$11,$55,$DD,$60,$00,$00
        FCB     $00,$0D,$51,$5D,$D5,$DC,$00,$00
        FCB     $00,$06,$51,$C5,$15,$58,$50,$00
        FCB     $00,$00,$65,$D8,$55,$CC,$48,$00
        FCB     $00,$00,$08,$DD,$88,$CC,$44,$40
        FCB     $00,$00,$00,$8D,$1D,$DD,$D0,$00
        FCB     $00,$00,$00,$88,$80,$06,$DD,$00
        FCB     $00,$00,$08,$CE,$8C,$80,$00,$00
        FCB     $00,$00,$E8,$C0,$08,$CE,$00,$00
        FCB     $00,$0E,$CC,$00,$08,$C8,$00,$00
        FCB     $00,$EC,$80,$00,$0E,$C8,$00,$00
        FCB     $00,$88,$E0,$00,$00,$8C,$00,$00
        FCB     $00,$CE,$E0,$00,$00,$CC,$00,$00
;*AAFF091478B0FFF4FFF4FFF4FFF4FFF4
;*00FF70580F3F51E81490CD111FA40A67
SRUN4L  FDB     $0814!DMAFIX                                                    ;;Fixme was: !XDMAFIX
        FCB     $00,$3D,$60,$00,$00,$00,$00,$00
        FCB     $4C,$49,$10,$00,$00,$00,$00,$00
        FCB     $00,$81,$90,$00,$00,$00,$00,$00
        FCB     $00,$0D,$60,$00,$00,$00,$00,$00
        FCB     $00,$01,$60,$00,$00,$00,$00,$00
        FCB     $00,$01,$D0,$00,$00,$00,$00,$00
        FCB     $00,$01,$1D,$00,$00,$00,$00,$00
        FCB     $00,$0D,$11,$55,$DD,$60,$00,$00
        FCB     $00,$06,$51,$5D,$D5,$DC,$00,$00
        FCB     $00,$06,$D1,$C5,$15,$58,$50,$00
        FCB     $00,$00,$65,$D8,$55,$CC,$48,$00
        FCB     $00,$00,$08,$DD,$88,$CC,$44,$40
        FCB     $00,$00,$00,$8D,$1D,$DD,$D0,$00
        FCB     $00,$00,$00,$88,$E8,$86,$DD,$00
        FCB     $00,$00,$00,$EC,$80,$CC,$E0,$00
        FCB     $00,$00,$00,$0C,$80,$EC,$80,$00
        FCB     $00,$00,$00,$EC,$00,$0C,$00,$00
        FCB     $00,$00,$00,$88,$00,$0C,$00,$00
        FCB     $00,$00,$00,$CE,$00,$0C,$80,$00
        FCB     $00,$00,$0C,$C0,$00,$0C,$C0,$00
;*AAFF081378B0FFF4FFF4FFF4FFF4FFF4
;*00FF70580F3F51E81490CD111FA40A67
SRUNSL  FDB     $0713!DMAFIX                                                    ;;Fixme was: !XDMAFIX
        FCB     $00,$3D,$30,$00,$00,$00,$00
        FCB     $EC,$49,$D0,$00,$00,$00,$00
        FCB     $48,$81,$90,$00,$00,$00,$00
        FCB     $06,$16,$00,$00,$00,$00,$00
        FCB     $0D,$10,$00,$00,$00,$00,$00
        FCB     $0D,$D0,$00,$00,$00,$00,$00
        FCB     $01,$D0,$00,$00,$00,$00,$00
        FCB     $05,$11,$55,$DD,$60,$00,$00
        FCB     $0D,$51,$5D,$D5,$DC,$00,$00
        FCB     $06,$51,$C5,$15,$58,$50,$00
        FCB     $00,$65,$D8,$55,$CC,$48,$00
        FCB     $00,$08,$DD,$88,$CC,$44,$40
        FCB     $00,$00,$8D,$1D,$DD,$D0,$00
        FCB     $00,$00,$8C,$88,$86,$DD,$00
        FCB     $00,$08,$CE,$C8,$00,$00,$00
        FCB     $00,$EC,$EC,$80,$00,$00,$00
        FCB     $0E,$CE,$CE,$00,$00,$00,$00
        FCB     $EC,$EC,$E0,$00,$00,$00,$00
        FCB     $CE,$CC,$00,$00,$00,$00,$00
;*AAFF090E78B0FFF4FFF4FFF4FFF4FFF4
;*00FF70580F3F51E81490CD111FA40A67
SFLY1L  FDB     $080E!DMAFIX                                                    ;;Fixme was: !XDMAFIX
        FCB     $00,$03,$D6,$00,$00,$00,$00,$00
        FCB     $E4,$C4,$91,$00,$00,$00,$00,$00
        FCB     $00,$08,$19,$00,$00,$00,$00,$00
        FCB     $00,$0D,$10,$00,$00,$00,$00,$00
        FCB     $00,$0D,$10,$00,$00,$00,$00,$00
        FCB     $00,$01,$D0,$99,$77,$90,$00,$00
        FCB     $00,$01,$D6,$CD,$51,$D6,$00,$00
        FCB     $00,$05,$1D,$C5,$15,$51,$60,$00
        FCB     $00,$06,$DD,$6D,$51,$55,$D6,$00
        FCB     $00,$00,$86,$85,$C5,$55,$DD,$00
        FCB     $00,$00,$0E,$CC,$CC,$CD,$68,$40
        FCB     $00,$00,$88,$4C,$4C,$86,$84,$80
        FCB     $00,$0C,$EC,$E4,$88,$EE,$08,$00
        FCB     $00,$00,$E8,$E8,$E0,$00,$00,$00
;*AAFF0A0D78B0FFF4FFF4FFF4FFF4FFF4
;*00FF70580F3F51E81490CD111FA40A67
SFLY3L  FDB     $090D!DMAFIX                                                    ;;Fixme was: !XDMAFIX
        FCB     $00,$00,$00,$00,$00,$00,$00,$8C,$00
        FCB     $00,$00,$3D,$60,$00,$00,$0D,$40,$C0
        FCB     $0E,$4C,$49,$D0,$00,$00,$DD,$44,$00
        FCB     $00,$00,$81,$90,$00,$09,$48,$84,$40
        FCB     $00,$00,$D1,$00,$00,$9C,$88,$CC,$00
        FCB     $00,$00,$D1,$00,$09,$58,$CC,$CC,$C0
        FCB     $00,$00,$61,$D9,$85,$D8,$C5,$C0,$00
        FCB     $00,$00,$6D,$1D,$D5,$CD,$D5,$CC,$00
        FCB     $00,$00,$06,$11,$15,$1D,$D4,$80,$00
        FCB     $00,$00,$00,$6D,$11,$11,$55,$C4,$00
        FCB     $00,$00,$00,$0C,$D1,$C8,$85,$4C,$40
        FCB     $00,$00,$00,$00,$88,$8E,$E0,$45,$40
        FCB     $00,$00,$00,$00,$80,$0E,$88,$00,$00
;*
;*      OSTRICH
;*       (RIGHT)
;*
;*AA00FF70580F3F51E81490CD111FA40A670914
ORUN1R  FDB     $0814!DMAFIX                                                    ;;Fixme was: !XDMAFIX
        FCB     $00,$00,$00,$00,$00,$08,$F8,$00
        FCB     $00,$00,$00,$00,$00,$0F,$7F,$50
        FCB     $00,$00,$00,$00,$00,$08,$F0,$00
        FCB     $00,$00,$00,$00,$00,$0E,$FE,$00
        FCB     $00,$00,$00,$00,$00,$00,$8F,$00
        FCB     $09,$70,$00,$00,$00,$00,$8F,$00
        FCB     $07,$17,$97,$66,$66,$00,$8F,$00
        FCB     $00,$69,$76,$71,$77,$98,$FE,$00
        FCB     $00,$06,$96,$07,$97,$7F,$80,$00
        FCB     $00,$00,$97,$96,$77,$79,$00,$00
        FCB     $00,$00,$66,$98,$99,$60,$00,$00
        FCB     $00,$00,$88,$8E,$88,$00,$00,$00
        FCB     $00,$0F,$F8,$00,$F8,$00,$00,$00
        FCB     $00,$0E,$FF,$08,$F0,$00,$00,$00
        FCB     $00,$00,$08,$FF,$80,$00,$00,$00
        FCB     $00,$00,$00,$EF,$FE,$00,$00,$00
        FCB     $00,$00,$00,$EF,$88,$00,$00,$00
        FCB     $00,$00,$00,$EF,$80,$00,$00,$00
        FCB     $00,$00,$00,$EF,$80,$00,$00,$00
        FCB     $00,$00,$00,$E8,$F8,$00,$00,$00
;*
;*AA00FF70580F3F51E81490CD111FA40A670914
ORUN2R  FDB     $0814!DMAFIX                                                    ;;Fixme was: !XDMAFIX
        FCB     $00,$00,$00,$00,$00,$8F,$80,$00
        FCB     $00,$00,$00,$00,$00,$F7,$F5,$00
        FCB     $00,$00,$00,$00,$00,$8F,$00,$00
        FCB     $00,$00,$00,$00,$00,$0F,$80,$00
        FCB     $00,$00,$00,$00,$00,$08,$F0,$00
        FCB     $09,$70,$00,$00,$00,$00,$8F,$00
        FCB     $07,$17,$97,$66,$66,$00,$8F,$00
        FCB     $00,$69,$76,$71,$77,$98,$F8,$00
        FCB     $00,$06,$96,$07,$97,$7F,$80,$00
        FCB     $00,$00,$97,$99,$11,$77,$00,$00
        FCB     $00,$00,$69,$97,$77,$96,$00,$00
        FCB     $00,$00,$06,$88,$88,$60,$00,$00
        FCB     $00,$00,$00,$0F,$F8,$00,$00,$00
        FCB     $00,$00,$00,$8F,$8E,$00,$00,$00
        FCB     $00,$00,$0E,$8F,$F8,$00,$00,$00
        FCB     $00,$00,$0E,$F8,$0F,$F8,$00,$00
        FCB     $00,$00,$08,$F0,$00,$EF,$00,$00
        FCB     $00,$00,$08,$F0,$00,$08,$80,$00
        FCB     $00,$00,$08,$F8,$00,$00,$80,$00
        FCB     $00,$00,$0E,$FF,$00,$00,$00,$00
;*
;*AA00FF70580F3F51E81490CD111EA40A670914
ORUN3R  FDB     $0814!DMAFIX                                                    ;;Fixme was: !XDMAFIX
        FCB     $00,$00,$00,$00,$00,$8F,$80,$00
        FCB     $00,$00,$00,$00,$00,$F7,$F5,$00
        FCB     $00,$00,$00,$00,$00,$8F,$00,$00
        FCB     $00,$00,$00,$00,$00,$0F,$80,$00
        FCB     $00,$00,$00,$00,$00,$08,$F0,$00
        FCB     $09,$70,$00,$00,$00,$00,$8F,$00
        FCB     $07,$17,$97,$67,$76,$00,$8F,$00
        FCB     $00,$69,$70,$71,$77,$98,$F8,$00
        FCB     $00,$06,$96,$67,$97,$7F,$80,$00
        FCB     $00,$00,$97,$71,$17,$79,$00,$00
        FCB     $00,$00,$69,$67,$77,$96,$00,$00
        FCB     $00,$00,$06,$88,$88,$60,$00,$00
        FCB     $00,$00,$00,$F8,$FF,$E0,$00,$00
        FCB     $00,$00,$08,$F8,$EF,$00,$00,$00
        FCB     $00,$00,$0F,$80,$EF,$80,$00,$00
        FCB     $00,$00,$EF,$80,$08,$F8,$00,$00
        FCB     $00,$00,$8F,$E0,$00,$8F,$E0,$00
        FCB     $00,$00,$8F,$00,$00,$08,$FE,$00
        FCB     $00,$00,$F8,$00,$00,$0E,$88,$00
        FCB     $00,$00,$FF,$00,$00,$0E,$EF,$00
;*
;*AA00FF70580F3F51E8149018111FA40A670914
ORUN4R  FDB     $0814!DMAFIX                                                    ;;Fixme was: !XDMAFIX
        FCB     $00,$00,$00,$00,$00,$08,$F8,$00
        FCB     $00,$00,$00,$00,$00,$0F,$7F,$50
        FCB     $00,$00,$00,$00,$00,$08,$F0,$00
        FCB     $00,$00,$00,$00,$00,$0E,$F0,$00
        FCB     $00,$00,$00,$00,$00,$00,$8F,$00
        FCB     $09,$70,$00,$00,$00,$00,$8F,$00
        FCB     $07,$17,$97,$66,$66,$00,$8F,$00
        FCB     $00,$69,$76,$71,$17,$98,$F8,$00
        FCB     $00,$06,$96,$07,$77,$98,$80,$00
        FCB     $00,$00,$67,$96,$76,$69,$00,$00
        FCB     $00,$00,$66,$98,$99,$60,$00,$00
        FCB     $00,$00,$88,$8E,$88,$00,$00,$00
        FCB     $00,$0E,$FF,$00,$F8,$00,$00,$00
        FCB     $00,$08,$FE,$08,$F0,$00,$00,$00
        FCB     $00,$0F,$F0,$08,$F0,$00,$00,$00
        FCB     $00,$08,$F0,$08,$F0,$00,$00,$00
        FCB     $00,$00,$F0,$00,$FE,$00,$00,$00
        FCB     $00,$0E,$F0,$00,$88,$00,$00,$00
        FCB     $00,$08,$F0,$00,$EF,$00,$00,$00
        FCB     $00,$08,$F0,$00,$0F,$F0,$00,$00
;*
;*AA00FF70580F3F51E81490CD111FA40A670911
ORUNSR  FDB     $0812!DMAFIX                                                    ;;Fixme was: !XDMAFIX
        FCB     $00,$00,$00,$00,$00,$0E,$88,$00
        FCB     $00,$00,$00,$00,$00,$00,$7F,$50
        FCB     $00,$00,$00,$00,$00,$00,$FF,$00
        FCB     $00,$00,$00,$00,$00,$00,$88,$00
        FCB     $00,$97,$00,$00,$00,$00,$8F,$00
        FCB     $09,$19,$69,$70,$00,$00,$8F,$00
        FCB     $09,$97,$97,$71,$17,$AA,$8F,$00
        FCB     $00,$61,$70,$71,$11,$9A,$FF,$00
        FCB     $00,$07,$99,$66,$97,$7F,$F8,$00
        FCB     $00,$00,$97,$71,$77,$7F,$80,$00
        FCB     $00,$00,$67,$1F,$F7,$76,$00,$00
        FCB     $00,$00,$06,$8F,$F8,$80,$00,$00
        FCB     $00,$00,$00,$0F,$F8,$E0,$00,$00
        FCB     $00,$00,$00,$00,$F8,$F0,$00,$00
        FCB     $00,$00,$00,$00,$EF,$8F,$00,$00
        FCB     $00,$00,$00,$00,$08,$F8,$F0,$00
        FCB     $00,$00,$00,$00,$00,$EF,$EF,$00
        FCB     $00,$00,$00,$00,$00,$0F,$FE,$F0
;*
;*AAFF0A0D78B0FFF4FFF4FFF4FFF4FFF4
;*00FF70580F3F51E81490CD111FA40A67
OFLY1R  FDB     $090D!DMAFIX                                                    ;;Fixme was: !XDMAFIX
        FCB     $00,$00,$00,$00,$00,$00,$08,$F8,$00
        FCB     $00,$00,$00,$00,$00,$00,$0F,$7F,$50
        FCB     $00,$00,$00,$00,$00,$00,$0F,$80,$00
        FCB     $00,$00,$00,$00,$00,$00,$0F,$80,$00
        FCB     $00,$00,$00,$00,$00,$00,$0F,$E0,$00
        FCB     $00,$69,$77,$79,$96,$00,$EF,$E0,$00
        FCB     $09,$61,$19,$77,$79,$9E,$8F,$00,$00
        FCB     $00,$66,$07,$17,$77,$98,$F8,$00,$00
        FCB     $00,$09,$61,$76,$71,$98,$80,$00,$00
        FCB     $00,$00,$66,$06,$17,$99,$00,$00,$00
        FCB     $00,$00,$EE,$99,$99,$9E,$00,$00,$00
        FCB     $00,$00,$E8,$88,$EE,$8E,$00,$00,$00
        FCB     $00,$00,$00,$00,$00,$E8,$00,$00,$00
;*
;*      AND THE EVER POPULAR COPYRIGHT MESSAGE
;*
        FCC     'JOUST (C) 1982 WILLIAMS ELECTRONICS INC.'
;*AAFF090D78B074F774F67476F4F67474
;*00FF70580F3F51E81490CD111FA40A67
OFLY3R  FDB     $090D!DMAFIX                                                    ;;Fixme was: !XDMAFIX
        FCB     $07,$96,$00,$00,$00,$00,$8F,$80,$00
        FCB     $01,$17,$79,$00,$00,$00,$F7,$F5,$00
        FCB     $00,$77,$79,$00,$00,$00,$F8,$00,$00
        FCB     $00,$11,$79,$00,$00,$00,$F8,$00,$00
        FCB     $00,$07,$77,$90,$00,$00,$F8,$00,$00
        FCB     $00,$01,$17,$97,$00,$00,$F8,$00,$00
        FCB     $00,$00,$77,$77,$79,$08,$C8,$00,$00
        FCB     $09,$D7,$60,$7D,$D7,$9F,$FE,$00,$00
        FCB     $09,$69,$96,$6D,$D6,$9F,$E0,$00,$00
        FCB     $00,$00,$99,$96,$69,$98,$00,$00,$00
        FCB     $00,$00,$EE,$99,$99,$9E,$00,$00,$00
        FCB     $00,$00,$E8,$88,$EE,$8E,$00,$00,$00
        FCB     $00,$00,$00,$00,$00,$E8,$00,$00,$00
;*
;*      OSTRICH
;*       (LEFT)
;*
;*AA00FF70580F3F51E81490CD111FA40A670914
ORUN1L  FDB     $0814!DMAFIX                                                    ;;Fixme was: !XDMAFIX
        FCB     $00,$8F,$80,$00,$00,$00,$00,$00
        FCB     $05,$F7,$F0,$00,$00,$00,$00,$00
        FCB     $00,$0F,$80,$00,$00,$00,$00,$00
        FCB     $00,$EF,$E0,$00,$00,$00,$00,$00
        FCB     $00,$F8,$00,$00,$00,$00,$00,$00
        FCB     $00,$F8,$00,$00,$00,$00,$07,$90
        FCB     $00,$F8,$00,$66,$66,$79,$71,$70
        FCB     $00,$EF,$89,$77,$17,$67,$96,$00
        FCB     $00,$08,$F7,$79,$70,$69,$60,$00
        FCB     $00,$00,$97,$77,$69,$79,$00,$00
        FCB     $00,$00,$06,$99,$89,$66,$00,$00
        FCB     $00,$00,$00,$88,$E8,$88,$00,$00
        FCB     $00,$00,$00,$8F,$00,$8F,$F0,$00
        FCB     $00,$00,$00,$0F,$80,$FF,$E0,$00
        FCB     $00,$00,$00,$08,$FF,$80,$00,$00
        FCB     $00,$00,$00,$EF,$FE,$00,$00,$00
        FCB     $00,$00,$00,$88,$FE,$00,$00,$00
        FCB     $00,$00,$00,$08,$FE,$00,$00,$00
        FCB     $00,$00,$00,$08,$FE,$00,$00,$00
        FCB     $00,$00,$00,$8F,$8E,$00,$00,$00
;*
;*AA00FF70580F3F51E81490CD111FA40A670914
ORUN2L  FDB     $0714!DMAFIX                                                    ;;Fixme was: !XDMAFIX
        FCB     $08,$F8,$00,$00,$00,$00,$00
        FCB     $5F,$7F,$00,$00,$00,$00,$00
        FCB     $00,$F8,$00,$00,$00,$00,$00
        FCB     $08,$F0,$00,$00,$00,$00,$00
        FCB     $0F,$80,$00,$00,$00,$00,$00
        FCB     $F8,$00,$00,$00,$00,$07,$90
        FCB     $F8,$00,$66,$66,$79,$71,$70
        FCB     $8F,$89,$77,$17,$67,$96,$00
        FCB     $08,$F7,$79,$70,$69,$60,$00
        FCB     $00,$77,$11,$99,$79,$00,$00
        FCB     $00,$69,$77,$79,$96,$00,$00
        FCB     $00,$06,$88,$88,$60,$00,$00
        FCB     $00,$00,$8F,$F0,$00,$00,$00
        FCB     $00,$00,$E8,$F8,$00,$00,$00
        FCB     $00,$00,$8F,$F8,$E0,$00,$00
        FCB     $00,$8F,$F0,$8F,$E0,$00,$00
        FCB     $00,$FE,$00,$0F,$80,$00,$00
        FCB     $08,$80,$00,$0F,$80,$00,$00
        FCB     $08,$00,$00,$8F,$80,$00,$00
        FCB     $00,$00,$00,$FF,$E0,$00,$00
;*
;*AA00FF70580F3F51E81490CD111EA40A670914
ORUN3L  FDB     $0714!DMAFIX                                                    ;;Fixme was: !XDMAFIX
        FCB     $08,$F8,$00,$00,$00,$00,$00
        FCB     $5F,$7F,$00,$00,$00,$00,$00
        FCB     $00,$F8,$00,$00,$00,$00,$00
        FCB     $08,$F0,$00,$00,$00,$00,$00
        FCB     $0F,$80,$00,$00,$00,$00,$00
        FCB     $F8,$00,$00,$00,$00,$07,$90
        FCB     $F8,$00,$67,$76,$79,$71,$70
        FCB     $8F,$89,$77,$17,$07,$96,$00
        FCB     $08,$F7,$79,$76,$69,$60,$00
        FCB     $00,$97,$71,$17,$79,$00,$00
        FCB     $00,$69,$77,$76,$96,$00,$00
        FCB     $00,$06,$88,$88,$60,$00,$00
        FCB     $00,$0E,$FF,$8F,$00,$00,$00
        FCB     $00,$00,$FE,$8F,$80,$00,$00
        FCB     $00,$08,$FE,$08,$F0,$00,$00
        FCB     $00,$8F,$80,$08,$FE,$00,$00
        FCB     $0E,$F8,$00,$0E,$F8,$00,$00
        FCB     $EF,$80,$00,$00,$F8,$00,$00
        FCB     $88,$E0,$00,$00,$8F,$00,$00
        FCB     $FE,$E0,$00,$00,$FF,$00,$00
;*
;*AA00FF70580F3F51E8149018111FA40A670914
ORUN4L  FDB     $0814!DMAFIX                                                    ;;Fixme was: !XDMAFIX
        FCB     $00,$8F,$80,$00,$00,$00,$00,$00
        FCB     $05,$F7,$F0,$00,$00,$00,$00,$00
        FCB     $00,$0F,$80,$00,$00,$00,$00,$00
        FCB     $00,$0F,$E0,$00,$00,$00,$00,$00
        FCB     $00,$F8,$00,$00,$00,$00,$00,$00
        FCB     $00,$F8,$00,$00,$00,$00,$07,$90
        FCB     $00,$F8,$00,$66,$66,$79,$71,$70
        FCB     $00,$8F,$89,$71,$17,$67,$96,$00
        FCB     $00,$08,$89,$77,$70,$69,$60,$00
        FCB     $00,$00,$96,$67,$69,$76,$00,$00
        FCB     $00,$00,$06,$99,$89,$66,$00,$00
        FCB     $00,$00,$00,$88,$E8,$88,$00,$00
        FCB     $00,$00,$00,$8F,$00,$FF,$E0,$00
        FCB     $00,$00,$00,$0F,$80,$EF,$80,$00
        FCB     $00,$00,$00,$0F,$80,$0F,$F0,$00
        FCB     $00,$00,$00,$0F,$80,$0F,$80,$00
        FCB     $00,$00,$00,$EF,$00,$0F,$00,$00
        FCB     $00,$00,$00,$88,$00,$0F,$E0,$00
        FCB     $00,$00,$00,$FE,$00,$0F,$80,$00
        FCB     $00,$00,$0F,$F0,$00,$0F,$80,$00
;*
;*AA00FF70580F3F51E81490CD111FA40A670911
ORUNSL  FDB     $0812!DMAFIX                                                    ;;Fixme was: !XDMAFIX
        FCB     $00,$88,$E0,$00,$00,$00,$00,$00
        FCB     $05,$F7,$00,$00,$00,$00,$00,$00
        FCB     $00,$FF,$00,$00,$00,$00,$00,$00
        FCB     $00,$88,$00,$00,$00,$00,$00,$00
        FCB     $00,$F8,$00,$00,$00,$00,$79,$00
        FCB     $00,$F8,$00,$00,$07,$96,$91,$90
        FCB     $00,$F8,$AA,$71,$17,$79,$79,$90
        FCB     $00,$FF,$A9,$11,$17,$07,$16,$00
        FCB     $00,$8F,$F7,$79,$66,$99,$70,$00
        FCB     $00,$08,$F7,$77,$17,$79,$00,$00
        FCB     $00,$00,$67,$7F,$F1,$76,$00,$00
        FCB     $00,$00,$08,$8F,$F8,$60,$00,$00
        FCB     $00,$00,$0E,$8F,$F0,$00,$00,$00
        FCB     $00,$00,$0F,$8F,$00,$00,$00,$00
        FCB     $00,$00,$F8,$FE,$00,$00,$00,$00
        FCB     $00,$0F,$8F,$80,$00,$00,$00,$00
        FCB     $00,$FE,$FE,$00,$00,$00,$00,$00
        FCB     $0F,$EF,$F0,$00,$00,$00,$00,$00
;*
;*AAFF0A0D78B0FFF4FFF4FFF4FFF4FFF4
;*00FF70580F3F51E81490CD111FA40A67
OFLY1L  FDB     $090D!DMAFIX                                                    ;;Fixme was: !XDMAFIX
        FCB     $00,$8F,$80,$00,$00,$00,$00,$00,$00
        FCB     $05,$F7,$F0,$00,$00,$00,$00,$00,$00
        FCB     $00,$08,$F0,$00,$00,$00,$00,$00,$00
        FCB     $00,$08,$F0,$00,$00,$00,$00,$00,$00
        FCB     $00,$0E,$F0,$00,$00,$00,$00,$00,$00
        FCB     $00,$0E,$FE,$00,$69,$97,$77,$96,$00
        FCB     $00,$00,$F8,$E9,$97,$77,$91,$16,$90
        FCB     $00,$00,$8F,$89,$77,$71,$70,$66,$00
        FCB     $00,$00,$08,$89,$17,$67,$16,$90,$00
        FCB     $00,$00,$00,$99,$71,$60,$66,$00,$00
        FCB     $00,$00,$00,$E9,$99,$99,$EE,$00,$00
        FCB     $00,$00,$00,$E8,$EE,$88,$8E,$00,$00
        FCB     $00,$00,$00,$8E,$00,$00,$00,$00,$00
;*AAFF090D78B074F774F67476F4F67474
;*00FF70580F3F51E81490CD111FA40A67
OFLY3L  FDB     $090D!DMAFIX                                                    ;;Fixme was: !XDMAFIX
        FCB     $00,$08,$F8,$00,$00,$00,$00,$69,$70
        FCB     $00,$5F,$7F,$00,$00,$00,$97,$71,$10
        FCB     $00,$00,$8F,$00,$00,$00,$97,$77,$00
        FCB     $00,$00,$8F,$00,$00,$00,$97,$11,$00
        FCB     $00,$00,$8F,$00,$00,$09,$77,$70,$00
        FCB     $00,$00,$8F,$00,$00,$79,$71,$10,$00
        FCB     $00,$00,$8C,$80,$97,$77,$77,$00,$00
        FCB     $00,$00,$EF,$F9,$7D,$D7,$06,$7D,$90
        FCB     $00,$00,$0E,$F9,$6D,$D6,$69,$96,$90
        FCB     $00,$00,$00,$89,$96,$69,$99,$00,$00
        FCB     $00,$00,$00,$E9,$99,$99,$EE,$00,$00
        FCB     $00,$00,$00,$E8,$EE,$88,$8E,$00,$00
        FCB     $00,$00,$00,$8E,$00,$00,$00,$00,$00
;*
;*      BUZZARD IMAGES
;*
_BUZARD EQU     *
BRSKID  FDB     BSKIDR,$00F4,BRUNSR
        FDB     BSKIDL,$01F4,BRUNSL
BRSTND  FDB     BSTNDR,$00F3,BRUN4R     ;BSTNDR,$00F3,BRUN0R
        FDB     BSTNDL,$00F3,BRUN4L     ;BSTNDL,$00F3,BRUN0L
BRRUN1  FDB     BSTNDR,$00F3,BRUN1R
        FDB     BSTNDL,$00F3,BRUN1L
BRRUN2  FDB     BSTNDR,$00F3,BRUN2R
        FDB     BSTNDL,$01F3,BRUN2L
BRRUN3  FDB     BSTNDR,$00F3,BRUN3R
        FDB     BSTNDL,$01F3,BRUN3L
BRRUN4  FDB     BSTNDR,$00F3,BRUN4R
        FDB     BSTNDL,$00F3,BRUN4L
BRFLAP  FDB     BWNG1R,$00F2,BFLY1R
        FDB     BWNG1L,$00F2,BFLY1L
BRFLOP  FDB     BWNG2R,$00ED,BFLY1R     ;,BFLY2R
        FDB     BWNG2L,$00ED,BFLY1L     ;,BFLY2L
BRFLIP  FDB     BWNG3R,$00ED,BFLY3R
        FDB     BWNG3L,$00ED,BFLY3L
;*
;*      BUZZARDS COLISION DETECT DATA
;*
BWNG1R
BWNG2R
BWNG3R  FDB     7+COFF,9+COFF
        FDB     7+COFF,9+COFF
        FDB     7+COFF,8+COFF
        FDB     6+COFF,10+COFF
        FDB     6+COFF,17+COFF
        FDB     6+COFF,10+COFF
        FDB     5+COFF,11+COFF
        FDB     4+COFF,14+COFF
        FDB     3+COFF,14+COFF
        FDB     4+COFF,14+COFF
        FDB     5+COFF,13+COFF
        FDB     5+COFF,12+COFF
        FDB     5+COFF,13+COFF
        FDB     $8100,$8100
        FDB     $8100,$8100     ;1 EXTRA END OF POINTER ENTRY
;*
BWNG1L
BWNG2L
BWNG3L  FDB     10+COFF,12+COFF
        FDB     10+COFF,12+COFF
        FDB     11+COFF,12+COFF
        FDB     9+COFF,13+COFF
        FDB     2+COFF,13+COFF
        FDB     9+COFF,13+COFF
        FDB     8+COFF,14+COFF
        FDB     5+COFF,15+COFF
        FDB     5+COFF,16+COFF
        FDB     5+COFF,15+COFF
        FDB     6+COFF,14+COFF
        FDB     7+COFF,14+COFF
        FDB     6+COFF,14+COFF
        FDB     $8100,$8100     ;1 EXTRA END OF POINTER ENTRY
;*
BSKIDR  FDB     $8000,$8000     ;NO COLISION ON THIS LINE
        FDB     $8000,$8000     ;NO COLISION ON THIS LINE
        FDB     7+COFF,9+COFF
        FDB     7+COFF,9+COFF
        FDB     7+COFF,8+COFF
        FDB     6+COFF,10+COFF
        FDB     6+COFF,10+COFF
        FDB     6+COFF,10+COFF
        FDB     6+COFF,11+COFF
        FDB     5+COFF,11+COFF
        FDB     5+COFF,11+COFF
        FDB     3+COFF,11+COFF
        FDB     3+COFF,11+COFF
        FDB     3+COFF,11+COFF
        FDB     $8100,$8100
        FDB     $8100,$8100
        FDB     $8100,$8100
        FDB     $8100,$8100
        FDB     $8100,$8100
        FDB     $8100,$8100
        FDB     $8100,$8100     ;1 EXTRA END OF POINTER ENTRY
;*
BSTNDR  FDB     7+COFF,9+COFF
        FDB     7+COFF,9+COFF
        FDB     7+COFF,8+COFF
        FDB     6+COFF,10+COFF
        FDB     6+COFF,17+COFF
        FDB     7+COFF,10+COFF
        FDB     6+COFF,14+COFF
        FDB     5+COFF,14+COFF
        FDB     4+COFF,14+COFF
        FDB     3+COFF,14+COFF
        FDB     3+COFF,14+COFF
        FDB     2+COFF,14+COFF
        FDB     $8100,$8100
        FDB     $8100,$8100
        FDB     $8100,$8100
        FDB     $8100,$8100
        FDB     $8100,$8100
        FDB     $8100,$8100
        FDB     $8100,$8100
        FDB     $8100,$8100
        FDB     $8100,$8100     ;1 EXTRA END OF POINTER ENTRY
;*
BSKIDL  FDB     $8000,$8000     ;NO COLISION ON THIS LINE
        FDB     $8000,$8000     ;NO COLISION ON THIS LINE
        FDB     10+COFF,12+COFF
        FDB     10+COFF,12+COFF
        FDB     11+COFF,12+COFF
        FDB     9+COFF,13+COFF
        FDB     9+COFF,13+COFF
        FDB     9+COFF,13+COFF
        FDB     8+COFF,13+COFF
        FDB     8+COFF,14+COFF
        FDB     8+COFF,14+COFF
        FDB     8+COFF,16+COFF
        FDB     8+COFF,16+COFF
        FDB     8+COFF,16+COFF
        FDB     $8100,$8100
        FDB     $8100,$8100
        FDB     $8100,$8100
        FDB     $8100,$8100
        FDB     $8100,$8100
        FDB     $8100,$8100
        FDB     $8100,$8100     ;1 EXTRA END OF POINTER ENTRY
;*
BSTNDL  FDB     10+COFF,12+COFF
        FDB     10+COFF,12+COFF
        FDB     11+COFF,12+COFF
        FDB     9+COFF,13+COFF
        FDB     2+COFF,13+COFF
        FDB     9+COFF,12+COFF
        FDB     5+COFF,13+COFF
        FDB     5+COFF,14+COFF
        FDB     5+COFF,15+COFF
        FDB     5+COFF,16+COFF
        FDB     5+COFF,16+COFF
        FDB     5+COFF,17+COFF
        FDB     $8100,$8100
        FDB     $8100,$8100
        FDB     $8100,$8100
        FDB     $8100,$8100
        FDB     $8100,$8100
        FDB     $8100,$8100
        FDB     $8100,$8100
        FDB     $8100,$8100
        FDB     $8100,$8100     ;1 EXTRA END OF POINTER ENTRY
;*
;*      VULTURE IMAGES
;*               (RIGHT)
;*
;*      BUZZARD RIGHT FACED IMAGES
;*
;*AAFF0A0E78B6FFF4FFF4FFF4FFF4FFF4
;*00FF70580F3F51E81490CD111FA40A67
BRUN1R  FDB     $090E!DMAFIX                                                    ;;Fixme was: !XDMAFIX
        FCB     $00,$00,$00,$B6,$60,$00,$0F,$F8,$00
        FCB     $00,$00,$06,$33,$31,$D0,$0F,$55,$50
        FCB     $00,$00,$6B,$33,$3B,$1B,$0E,$F0,$50
        FCB     $00,$0B,$0B,$BD,$B1,$1D,$08,$F0,$00
        FCB     $00,$B0,$BB,$32,$BB,$1F,$FF,$80,$00
        FCB     $0B,$6B,$B3,$33,$BD,$D8,$F8,$00,$00
        FCB     $00,$0B,$3B,$BB,$88,$00,$00,$00,$00
        FCB     $00,$BB,$00,$0F,$F0,$00,$00,$00,$00
        FCB     $00,$00,$00,$8F,$FF,$00,$00,$00,$00
        FCB     $00,$00,$00,$F8,$08,$80,$00,$00,$00
        FCB     $00,$00,$00,$F0,$00,$F0,$00,$00,$00
        FCB     $00,$00,$00,$F8,$00,$F0,$00,$00,$00
        FCB     $00,$00,$00,$8F,$80,$00,$00,$00,$00
        FCB     $00,$00,$00,$0E,$FF,$E0,$00,$00,$00
;*AAFF090E78B6FFF4FFF4FFF4FFF4FFF4
;*00FF70580F3F51E81490CD111FA40A67
BRUN2R  FDB     $090E!DMAFIX                                                    ;;Fixme was: !XDMAFIX
        FCB     $00,$00,$0B,$36,$60,$00,$FF,$80,$00
        FCB     $00,$00,$6B,$33,$31,$DE,$F5,$55,$00
        FCB     $00,$06,$B3,$33,$BB,$DE,$EF,$05,$00
        FCB     $00,$6B,$0B,$3D,$B1,$18,$8F,$00,$00
        FCB     $00,$B0,$B3,$32,$3B,$FF,$FF,$00,$00
        FCB     $03,$6B,$B3,$33,$BD,$8F,$FE,$00,$00
        FCB     $00,$0B,$B3,$8B,$88,$00,$00,$00,$00
        FCB     $00,$3B,$3B,$8F,$F0,$00,$00,$00,$00
        FCB     $00,$BB,$00,$FF,$F0,$00,$00,$00,$00
        FCB     $00,$00,$0F,$F0,$FF,$FF,$80,$00,$00
        FCB     $00,$00,$0F,$00,$00,$0F,$F8,$00,$00
        FCB     $00,$00,$0F,$80,$00,$80,$0F,$00,$00
        FCB     $00,$00,$00,$F8,$00,$00,$00,$00,$00
        FCB     $00,$00,$00,$EF,$FE,$00,$00,$00,$00
;*AAFF090E78B6FFF4FFF4FFF4FFF4FFF4
;*00FF70580F3F51E81490CD111FA40A67
BRUN3R  FDB     $090E!DMAFIX                                                    ;;Fixme was: !XDMAFIX
        FCB     $00,$00,$0B,$36,$60,$00,$FF,$80,$00
        FCB     $00,$00,$63,$33,$B1,$DE,$F5,$55,$00
        FCB     $00,$06,$BB,$33,$3D,$DE,$EF,$05,$00
        FCB     $00,$6B,$03,$3D,$B1,$18,$8F,$00,$00
        FCB     $00,$B0,$BB,$23,$BC,$FF,$FF,$00,$00
        FCB     $03,$BB,$B3,$3B,$BD,$8F,$FE,$00,$00
        FCB     $00,$0B,$33,$8B,$88,$00,$00,$00,$00
        FCB     $00,$3B,$3B,$88,$F8,$00,$00,$00,$00
        FCB     $00,$BB,$0F,$FE,$FF,$E0,$00,$00,$00
        FCB     $00,$00,$8F,$E0,$0F,$F0,$00,$00,$00
        FCB     $00,$00,$FE,$00,$00,$8F,$00,$00,$00
        FCB     $00,$00,$FE,$00,$00,$08,$F0,$00,$00
        FCB     $00,$00,$8F,$80,$00,$0E,$FF,$00,$00
        FCB     $00,$00,$EF,$F8,$00,$08,$08,$F0,$00
;*AAFF0A0E78B6FFF4FFF4FFF4FFF4FFF4
;*00FF70580F3F51E81490CD111FA40A67
BRUN4R  FDB     $090E!DMAFIX                                                    ;;Fixme was: !XDMAFIX
        FCB     $00,$00,$0B,$36,$60,$00,$0F,$F8,$00
        FCB     $00,$00,$63,$33,$31,$D0,$0F,$55,$50
        FCB     $00,$06,$B3,$33,$3B,$1C,$0E,$F0,$50
        FCB     $00,$6B,$03,$3D,$B1,$1F,$08,$F0,$00
        FCB     $00,$B0,$BB,$32,$BB,$1F,$FF,$80,$00
        FCB     $03,$BB,$BB,$3B,$BD,$D8,$F8,$00,$00
        FCB     $00,$0B,$33,$8E,$88,$00,$00,$00,$00
        FCB     $03,$3B,$EF,$88,$FE,$00,$00,$00,$00
        FCB     $0B,$BE,$F8,$EF,$80,$00,$00,$00,$00
        FCB     $00,$0F,$80,$0F,$E0,$00,$00,$00,$00
        FCB     $00,$00,$F0,$08,$F0,$00,$00,$00,$00
        FCB     $00,$00,$FF,$00,$0F,$00,$00,$00,$00
        FCB     $00,$0F,$00,$F0,$EF,$FE,$00,$00,$00
        FCB     $00,$00,$00,$00,$80,$FF,$00,$00,$00
;*AAFF090D78B4FFF4FFF4FFF4FFF4FFF4
;*00FF70580F3F51E81490CD111FA40A67
BRUNSR  FDB     $090D!DMAFIX                                                    ;;Fixme was: !XDMAFIX
        FCB     $00,$0B,$22,$36,$00,$0F,$F8,$00,$00
        FCB     $00,$32,$33,$BB,$B0,$0F,$55,$50,$00
        FCB     $00,$B0,$30,$66,$6B,$08,$F0,$50,$00
        FCB     $00,$00,$0B,$66,$31,$D0,$88,$00,$00
        FCB     $00,$BB,$BB,$B3,$3B,$1E,$8F,$00,$00
        FCB     $03,$30,$BB,$BD,$31,$1F,$F8,$00,$00
        FCB     $06,$3B,$B3,$32,$BD,$D8,$E0,$00,$00
        FCB     $00,$00,$63,$38,$8D,$80,$00,$00,$00
        FCB     $00,$00,$00,$E8,$FF,$E8,$00,$00,$00
        FCB     $00,$00,$00,$00,$E8,$FE,$80,$00,$00
        FCB     $00,$00,$00,$00,$00,$F8,$E8,$00,$00
        FCB     $00,$00,$00,$00,$00,$0F,$8E,$80,$00
        FCB     $00,$00,$00,$00,$00,$E8,$EF,$E8,$00
;*AAFF0A0878B5FFF4FFF4FFF4FFF4FFF4
;*00FF70580F3F51E81490CD111FA40A67
BFLY1R  FDB     $0908!DMAFIX                                                    ;;Fixme was: !XDMAFIX
        FCB     $00,$00,$06,$B3,$6B,$60,$00,$00,$00
        FCB     $00,$00,$62,$63,$36,$B6,$8F,$80,$00
        FCB     $00,$0B,$32,$36,$6B,$B6,$8F,$55,$00
        FCB     $00,$63,$3B,$3B,$BB,$B3,$88,$05,$00
        FCB     $00,$33,$33,$B6,$B3,$BB,$36,$00,$00
        FCB     $03,$3B,$0B,$0B,$30,$33,$B3,$B0,$00
        FCB     $00,$6B,$EE,$E0,$B3,$03,$30,$33,$00
        FCB     $00,$00,$E8,$8E,$0B,$30,$23,$02,$30
;*AAFF0A0D78B0FFF4FFF4FFF4FFF4FFF4
;*00FF70580F3F51E81490CD111FA40A67
BFLY3R  FDB     $090D!DMAFIX                                                    ;;Fixme was: !XDMAFIX
        FCB     $03,$03,$B0,$00,$00,$00,$00,$00,$00
        FCB     $03,$20,$3B,$00,$00,$00,$00,$00,$00
        FCB     $0B,$33,$BB,$00,$00,$00,$00,$00,$00
        FCB     $02,$03,$3B,$B0,$00,$00,$00,$00,$00
        FCB     $0B,$30,$BB,$66,$00,$00,$00,$00,$00
        FCB     $03,$B3,$3B,$B6,$BE,$00,$00,$00,$00
        FCB     $00,$2B,$33,$B6,$6B,$BE,$00,$00,$00
        FCB     $00,$03,$3B,$BB,$BB,$DB,$E8,$F8,$00
        FCB     $00,$00,$63,$3B,$BB,$BD,$88,$F5,$50
        FCB     $00,$0B,$06,$36,$B0,$11,$FF,$E0,$50
        FCB     $03,$B3,$B0,$EE,$BB,$0D,$8E,$00,$00
        FCB     $0B,$B6,$E8,$8E,$EE,$8E,$00,$00,$00
        FCB     $00,$60,$E8,$EE,$0E,$00,$80,$00,$00
;*
;*               (LEFT)
;*
;*AAFF0A0E78B6FFF4FFF4FFF4FFF4FFF4
;*00FF70580F3F51E81490CD111FA40A67
BRUN1L  FDB     $090E!DMAFIX                                                    ;;Fixme was: !XDMAFIX
        FCB     $00,$8F,$F0,$00,$06,$6B,$00,$00,$00
        FCB     $05,$55,$F0,$0D,$13,$33,$60,$00,$00
        FCB     $05,$0F,$E0,$B1,$B3,$33,$B6,$00,$00
        FCB     $00,$0F,$80,$D1,$1B,$DB,$B0,$B0,$00
        FCB     $00,$08,$FF,$F1,$BB,$23,$BB,$0B,$00
        FCB     $00,$00,$8F,$8D,$DB,$33,$3B,$B6,$B0
        FCB     $00,$00,$00,$00,$88,$BB,$B3,$B0,$00
        FCB     $00,$00,$00,$00,$0F,$F0,$00,$BB,$00
        FCB     $00,$00,$00,$00,$FF,$F8,$00,$00,$00
        FCB     $00,$00,$00,$08,$80,$8F,$00,$00,$00
        FCB     $00,$00,$00,$0F,$00,$0F,$00,$00,$00
        FCB     $00,$00,$00,$0F,$00,$8F,$00,$00,$00
        FCB     $00,$00,$00,$00,$08,$F8,$00,$00,$00
        FCB     $00,$00,$00,$0E,$FF,$E0,$00,$00,$00
;*AAFF090E78B6FFF4FFF4FFF4FFF4FFF4
;*00FF70580F3F51E81490CD111FA40A67
BRUN2L  FDB     $080E!DMAFIX                                                    ;;Fixme was: !XDMAFIX
        FCB     $08,$FF,$00,$06,$63,$B0,$00,$00
        FCB     $55,$5F,$ED,$13,$33,$B6,$00,$00
        FCB     $50,$FE,$ED,$BB,$33,$3B,$60,$00
        FCB     $00,$F8,$81,$1B,$D3,$B0,$B6,$00
        FCB     $00,$FF,$FF,$B3,$23,$3B,$0B,$00
        FCB     $00,$EF,$F8,$DB,$33,$3B,$B6,$30
        FCB     $00,$00,$00,$88,$B8,$3B,$B0,$00
        FCB     $00,$00,$00,$0F,$F8,$B3,$B3,$00
        FCB     $00,$00,$00,$0F,$FF,$00,$BB,$00
        FCB     $00,$08,$FF,$FF,$0F,$F0,$00,$00
        FCB     $00,$8F,$F0,$00,$00,$F0,$00,$00
        FCB     $00,$F0,$08,$00,$08,$F0,$00,$00
        FCB     $00,$00,$00,$00,$8F,$00,$00,$00
        FCB     $00,$00,$00,$EF,$FE,$00,$00,$00
;*AAFF090E78B6FFF4FFF4FFF4FFF4FFF4
;*00FF70580F3F51E81490CD111FA40A67
BRUN3L  FDB     $080E!DMAFIX                                                    ;;Fixme was: !XDMAFIX
        FCB     $08,$FF,$00,$06,$63,$B0,$00,$00
        FCB     $55,$5F,$ED,$1B,$33,$36,$00,$00
        FCB     $50,$FE,$ED,$D3,$33,$BB,$60,$00
        FCB     $00,$F8,$81,$1B,$D3,$30,$B6,$00
        FCB     $00,$FF,$FF,$CB,$32,$BB,$0B,$00
        FCB     $00,$EF,$F8,$DB,$B3,$3B,$BB,$30
        FCB     $00,$00,$00,$88,$B8,$33,$B0,$00
        FCB     $00,$00,$00,$8F,$88,$B3,$B3,$00
        FCB     $00,$00,$0E,$FF,$EF,$F0,$BB,$00
        FCB     $00,$00,$0F,$F0,$0E,$F8,$00,$00
        FCB     $00,$00,$F8,$00,$00,$EF,$00,$00
        FCB     $00,$0F,$80,$00,$00,$EF,$00,$00
        FCB     $00,$FF,$E0,$00,$08,$F8,$00,$00
        FCB     $0F,$80,$80,$00,$8F,$FE,$00,$00
;*AAFF0A0E78B6FFF4FFF4FFF4FFF4FFF4
;*00FF70580F3F51E81490CD111FA40A67
BRUN4L  FDB     $090E!DMAFIX                                                    ;;Fixme was: !XDMAFIX
        FCB     $00,$8F,$F0,$00,$06,$63,$B0,$00,$00
        FCB     $05,$55,$F0,$0D,$13,$33,$36,$00,$00
        FCB     $05,$0F,$E0,$C1,$B3,$33,$3B,$60,$00
        FCB     $00,$0F,$80,$F1,$1B,$D3,$30,$B6,$00
        FCB     $00,$08,$FF,$F1,$BB,$23,$BB,$0B,$00
        FCB     $00,$00,$8F,$8D,$DB,$B3,$BB,$BB,$30
        FCB     $00,$00,$00,$00,$88,$E8,$33,$B0,$00
        FCB     $00,$00,$00,$00,$EF,$88,$FE,$B3,$30
        FCB     $00,$00,$00,$00,$08,$FE,$8F,$EB,$B0
        FCB     $00,$00,$00,$00,$0E,$F0,$08,$F0,$00
        FCB     $00,$00,$00,$00,$0F,$80,$0F,$00,$00
        FCB     $00,$00,$00,$00,$F0,$00,$FF,$00,$00
        FCB     $00,$00,$00,$EF,$FE,$0F,$00,$F0,$00
        FCB     $00,$00,$00,$FF,$08,$00,$00,$00,$00
;*AAFF090D78B4FFF4FFF4FFF4FFF4FFF4
;*00FF70580F3F51E81490CD111FA40A67
BRUNSL  FDB     $080D!DMAFIX                                                    ;;Fixme was: !XDMAFIX
        FCB     $00,$8F,$F0,$00,$63,$22,$B0,$00
        FCB     $05,$55,$F0,$0B,$BB,$33,$23,$00
        FCB     $05,$0F,$80,$B6,$66,$03,$0B,$00
        FCB     $00,$88,$0D,$13,$66,$B0,$00,$00
        FCB     $00,$F8,$E1,$B3,$3B,$BB,$BB,$00
        FCB     $00,$8F,$F1,$13,$DB,$BB,$03,$30
        FCB     $00,$0E,$8D,$DB,$23,$3B,$B3,$60
        FCB     $00,$00,$08,$D8,$83,$36,$00,$00
        FCB     $00,$00,$8E,$FF,$8E,$00,$00,$00
        FCB     $00,$08,$EF,$8E,$00,$00,$00,$00
        FCB     $00,$8E,$8F,$00,$00,$00,$00,$00
        FCB     $08,$E8,$F0,$00,$00,$00,$00,$00
        FCB     $8E,$FE,$8E,$00,$00,$00,$00,$00
;*AAFF0A0878B5FFF4FFF4FFF4FFF4FFF4
;*00FF70580F3F51E81490CD111FA40A67
BFLY1L  FDB     $0908!DMAFIX                                                    ;;Fixme was: !XDMAFIX
        FCB     $00,$00,$00,$06,$B6,$3B,$60,$00,$00
        FCB     $00,$08,$F8,$6B,$63,$36,$26,$00,$00
        FCB     $00,$55,$F8,$6B,$B6,$63,$23,$B0,$00
        FCB     $00,$50,$88,$3B,$BB,$B3,$B3,$36,$00
        FCB     $00,$00,$63,$BB,$3B,$6B,$33,$33,$00
        FCB     $00,$0B,$3B,$33,$03,$B0,$B0,$B3,$30
        FCB     $00,$33,$03,$30,$3B,$0E,$EE,$B6,$00
        FCB     $03,$20,$32,$03,$B0,$E8,$8E,$00,$00
;*AAFF0A0D78B0FFF4FFF4FFF4FFF4FFF4
;*00FF70580F3F51E81490CD111FA40A67
BFLY3L  FDB     $090D!DMAFIX                                                    ;;Fixme was: !XDMAFIX
        FCB     $00,$00,$00,$00,$00,$00,$0B,$30,$30
        FCB     $00,$00,$00,$00,$00,$00,$B3,$02,$30
        FCB     $00,$00,$00,$00,$00,$00,$BB,$33,$B0
        FCB     $00,$00,$00,$00,$00,$0B,$B3,$30,$20
        FCB     $00,$00,$00,$00,$00,$66,$BB,$03,$B0
        FCB     $00,$00,$00,$00,$EB,$6B,$B3,$3B,$30
        FCB     $00,$00,$00,$EB,$B6,$6B,$33,$B2,$00
        FCB     $00,$8F,$8E,$BD,$BB,$BB,$B3,$30,$00
        FCB     $05,$5F,$88,$DB,$BB,$B3,$36,$00,$00
        FCB     $05,$0E,$FF,$11,$0B,$63,$60,$B0,$00
        FCB     $00,$00,$E8,$D0,$BB,$EE,$0B,$3B,$30
        FCB     $00,$00,$00,$E8,$EE,$E8,$8E,$6B,$B0
        FCB     $00,$00,$08,$00,$E0,$EE,$8E,$06,$00
;*
;*      PLAYER 1'S POINTERS
;*
_PLYR1  FDB     0,$02EF,PLY1R   ;RIDER ON SKIDDING HORSE
        FDB     0,$00EF,PLY1L
        FDB     0,$02ED,PLY1R   ;RIDER NORMALLY ON HORSE
        FDB     0,$00ED,PLY1L
;*
;*
;*      RIDER FACEING RIGHT SIDE
;*
PLY1R   FDB     $0707!DMAFIX                                                    ;;Fixme was: !XDMAFIX
        FCB     $00,$55,$50,$00,$00,$00,$00
        FCB     $00,$57,$70,$00,$00,$00,$00
        FCB     $00,$55,$00,$00,$00,$00,$00
        FCB     $05,$55,$55,$00,$00,$00,$00
        FCB     $05,$55,$55,$75,$55,$55,$50
        FCB     $05,$55,$55,$00,$00,$00,$00
        FCB     $00,$55,$55,$50,$00,$00,$00
;*
;*      RIDER FACEING LEFT SIDE
;*
PLY1L   FDB     $0707!DMAFIX                                                    ;;Fixme was: !XDMAFIX
        FCB     $00,$00,$00,$00,$05,$55,$00
        FCB     $00,$00,$00,$00,$07,$75,$00
        FCB     $00,$00,$00,$00,$00,$55,$00
        FCB     $00,$00,$00,$00,$55,$55,$50
        FCB     $05,$55,$55,$57,$55,$55,$50
        FCB     $00,$00,$00,$00,$55,$55,$50
        FCB     $00,$00,$00,$05,$55,$55,$00
;*
;*      PLAYER 2'S POINTERS
;*
_PLYR2  FDB     0,$02EF,PLY2R   ;RIDER ON SKIDDING HORSE
        FDB     0,$00EF,PLY2L
        FDB     0,$02ED,PLY2R   ;RIDER NORMALLY ON HORSE
        FDB     0,$00ED,PLY2L
;*
;*      RIDER FACEING RIGHT
;*
PLY2R   FDB     $0707!DMAFIX                                                    ;;Fixme was: !XDMAFIX
        FCB     $00,$77,$70,$00,$00,$00,$00
        FCB     $00,$75,$50,$00,$00,$00,$00
        FCB     $00,$77,$00,$00,$00,$00,$00
        FCB     $07,$77,$77,$00,$00,$00,$00
        FCB     $07,$77,$77,$57,$77,$77,$70
        FCB     $07,$77,$77,$00,$00,$00,$00
        FCB     $00,$77,$77,$70,$00,$00,$00
;*
;*      RIDER FACEING LEFT SIDE
;*
PLY2L   FDB     $0707!DMAFIX                                                    ;;Fixme was: !XDMAFIX
        FCB     $00,$00,$00,$00,$07,$77,$00
        FCB     $00,$00,$00,$00,$05,$57,$00
        FCB     $00,$00,$00,$00,$00,$77,$00
        FCB     $00,$00,$00,$00,$77,$77,$70
        FCB     $07,$77,$77,$75,$77,$77,$70
        FCB     $00,$00,$00,$00,$77,$77,$70
        FCB     $00,$00,$00,$07,$77,$77,$00
;*
;*
;*      PL7YER 3'S POINTERS
;*
_PLYR3  FDB     0,$02EF,PLY3R   ;RIDER ON SKIDDING HORSE
        FDB     0,$00EF,PLY3L
        FDB     0,$02ED,PLY3R   ;RIDER NORMALLY ON HORSE
        FDB     0,$00ED,PLY3L
        FDB     CEGGMN,$00F5,PLY3S
;*
;*      RIDER FACEING RIGHT SIDE
;*
PLY3R   FDB     $0707!DMAFIX                                                    ;;Fixme was: !XDMAFIX
        FCB     $00,$44,$40,$00,$00,$00,$00
        FCB     $00,$49,$90,$00,$00,$00,$00
        FCB     $00,$44,$00,$00,$00,$00,$00
        FCB     $04,$44,$44,$00,$00,$00,$00
        FCB     $04,$41,$11,$11,$11,$11,$10
        FCB     $04,$44,$44,$00,$00,$00,$00
        FCB     $00,$44,$44,$40,$00,$00,$00
;*
;*      RIDER FACEING LEFT SIDE
;*
PLY3L   FDB     $0707!DMAFIX                                                    ;;Fixme was: !XDMAFIX
        FCB     $00,$00,$00,$00,$04,$44,$00
        FCB     $00,$00,$00,$00,$09,$94,$00
        FCB     $00,$00,$00,$00,$00,$44,$00
        FCB     $00,$00,$00,$00,$44,$44,$40
        FCB     $01,$11,$11,$11,$11,$14,$40
        FCB     $00,$00,$00,$00,$44,$44,$40
        FCB     $00,$00,$00,$04,$44,$44,$00
;*
;*      RIDER STANDING (LEFT & RIGHT)
;*
;*AAFF050C78B0FFF4FFF4FFF4FFF4FFF4
;*00FF70580F3F51E814905D111FA40A67
PLY3S   FDB     $050C!DMAFIX                                                    ;;Fixme was: !XDMAFIX
        FCB     $00,$00,$00,$01,$00
        FCB     $00,$E4,$4E,$01,$00
        FCB     $00,$49,$9E,$01,$00
        FCB     $00,$E4,$4E,$01,$00
        FCB     $04,$44,$40,$4D,$00
        FCB     $4E,$E4,$40,$44,$00
        FCB     $00,$E4,$46,$6D,$00
        FCB     $00,$44,$4E,$61,$00
        FCB     $00,$4E,$E4,$61,$00
        FCB     $0E,$4E,$E4,$61,$00
        FCB     $08,$80,$04,$81,$00
        FCB     $88,$80,$E8,$81,$00
;*
;*
;*      PLAYER 4'S POINTERS
;*
_PLYR4  FDB     0,$02EF,PLY4R   ;RIDER ON SKIDDING HORSE
        FDB     0,$00EF,PLY4L
        FDB     0,$02ED,PLY4R   ;RIDER NORMALLY ON HORSE
        FDB     0,$00ED,PLY4L
        FDB     CEGGMN,$00F5,PLY4S
;*
;*      RIDER FACEING RIGHT SIDE
;*
PLY4R   FDB     $0707!DMAFIX                                                    ;;Fixme was: !XDMAFIX
        FCB     $00,$DD,$D0,$00,$00,$00,$00
        FCB     $00,$D4,$40,$00,$00,$00,$00
        FCB     $00,$DD,$00,$00,$00,$00,$00
        FCB     $0D,$DD,$DD,$00,$00,$00,$00
        FCB     $0D,$D1,$11,$11,$11,$11,$10
        FCB     $0D,$DD,$DD,$00,$00,$00,$00
        FCB     $00,$DD,$DD,$D0,$00,$00,$00
;*
;*      AND THE EVER POPULAR COPYRIGHT MESSAGE
;*
        FCC     'JOUST (C) 1982 WILLIAMS ELECTRONICS INC.'
;*
;*      RIDER FACEING LEFT SIDE
;*
PLY4L   FDB     $0707!DMAFIX                                                    ;;Fixme was: !XDMAFIX
        FCB     $00,$00,$00,$00,$0D,$DD,$00
        FCB     $00,$00,$00,$00,$04,$4D,$00
        FCB     $00,$00,$00,$00,$00,$DD,$00
        FCB     $00,$00,$00,$00,$DD,$DD,$D0
        FCB     $01,$11,$11,$11,$11,$1D,$D0
        FCB     $00,$00,$00,$00,$DD,$DD,$D0
        FCB     $00,$00,$00,$0D,$DD,$DD,$00
;*
;*      PLAYER STANDING (LEFT & RIGHT)
;*
;*AAFF040C7DB0FFF4FFF4FFF4FFF4FFF4
;*00FF704D0F3F41ED14904D111FA40A67
PLY4S   FDB     $050C!DMAFIX                                                    ;;Fixme was: !XDMAFIX
        FCB     $00,$00,$00,$01,$00
        FCB     $00,$9D,$D9,$01,$00
        FCB     $00,$D4,$4E,$01,$00
        FCB     $00,$ED,$D6,$01,$00
        FCB     $0D,$DD,$D9,$DA,$00
        FCB     $D9,$6D,$D9,$DD,$00
        FCB     $00,$6D,$D6,$6A,$00
        FCB     $00,$DD,$DE,$61,$00
        FCB     $00,$D9,$9D,$61,$00
        FCB     $09,$DE,$ED,$61,$00
        FCB     $03,$30,$0D,$31,$00
        FCB     $33,$30,$93,$31,$00
;*
;*
;*      PLAYER 5'S POINTERS
;*
_PLYR5  FDB     0,$02EF,PLY5R   ;RIDER ON SKIDDING HORSE
        FDB     0,$00EF,PLY5L
        FDB     0,$02ED,PLY5R   ;RIDER NORMALLY ON HORSE
        FDB     0,$00ED,PLY5L
        FDB     CEGGMN,$00F5,PLY5S
;*
;*      RIDER FACEING RIGHT SIDE
;*
PLY5R   FDB     $0707!DMAFIX                                                    ;;Fixme was: !XDMAFIX
        FCB     $00,$99,$90,$00,$00,$00,$00
        FCB     $00,$95,$50,$00,$00,$00,$00
        FCB     $00,$99,$00,$00,$00,$00,$00
        FCB     $09,$99,$99,$00,$00,$00,$00
        FCB     $09,$91,$11,$11,$11,$11,$10
        FCB     $09,$99,$99,$00,$00,$00,$00
        FCB     $00,$99,$99,$90,$00,$00,$00
;*
;*      RIDER FACEING LEFT SIDE
;*
PLY5L   FDB     $0707!DMAFIX                                                    ;;Fixme was: !XDMAFIX
        FCB     $00,$00,$00,$00,$09,$99,$00
        FCB     $00,$00,$00,$00,$05,$59,$00
        FCB     $00,$00,$00,$00,$00,$99,$00
        FCB     $00,$00,$00,$00,$99,$99,$90
        FCB     $01,$11,$11,$11,$11,$19,$90
        FCB     $00,$00,$00,$00,$99,$99,$90
        FCB     $00,$00,$00,$09,$99,$99,$00
;*
;*      RIDER STANDING (LEFT & RIGHT)
;*AAFF050C78B0FFF4FFF4FFF4FFF4FFF4
;*00FF70580F3F51E814905D111FA40A67
PLY5S   FDB     $050C!DMAFIX                                                    ;;Fixme was: !XDMAFIX
        FCB     $00,$00,$00,$01,$00
        FCB     $00,$E9,$9E,$01,$00
        FCB     $00,$95,$5E,$01,$00
        FCB     $00,$E9,$9E,$01,$00
        FCB     $09,$99,$90,$9D,$00
        FCB     $9E,$E9,$90,$99,$00
        FCB     $00,$E9,$96,$6D,$00
        FCB     $00,$99,$9E,$61,$00
        FCB     $00,$96,$69,$61,$00
        FCB     $0E,$9E,$E9,$61,$00
        FCB     $03,$30,$09,$31,$00
        FCB     $33,$30,$E3,$31,$00
;*
;*      EGG STILLS & HATCHING
;*
_EGGI   FDB     CEGGUP,$00FA,EGGUP
        FDB     CEGGLF,$00FB,EGGLF
        FDB     CEGGRT,$00FB,EGGRT
        FDB     CEGGUP,$00FB,EGGB1
        FDB     CEGGMN,$FFF6,EGGB2
        FDB     CEGGMN,$FEF5,EGGB3
        FDB     CEGGMN,$00F5,PLY4S
;*
CEGGUP
        FDB     3+COFF,6+COFF
        FDB     2+COFF,7+COFF
        FDB     2+COFF,7+COFF
        FDB     2+COFF,7+COFF
        FDB     2+COFF,7+COFF
        FDB     2+COFF,7+COFF
        FDB     3+COFF,6+COFF
        FDB     $8100,$8100
CEGGLF
        FDB     $8000,$8000
        FDB     2+COFF,6+COFF
        FDB     1+COFF,7+COFF
        FDB     1+COFF,7+COFF
        FDB     1+COFF,7+COFF
        FDB     2+COFF,7+COFF
        FDB     3+COFF,6+COFF
        FDB     $8100,$8100
CEGGRT
        FDB     $8000,$8000
        FDB     3+COFF,6+COFF
        FDB     2+COFF,7+COFF
        FDB     1+COFF,7+COFF
        FDB     1+COFF,7+COFF
        FDB     1+COFF,6+COFF
        FDB     2+COFF,5+COFF
        FDB     $8100,$8100     ;ENDING TERMINATOR
CEGGMN
        FDB     3+COFF,6+COFF
        FDB     3+COFF,6+COFF
        FDB     3+COFF,6+COFF
        FDB     2+COFF,4+COFF
        FDB     1+COFF,4+COFF
        FDB     3+COFF,8+COFF
        FDB     3+COFF,8+COFF
        FDB     3+COFF,6+COFF
        FDB     3+COFF,6+COFF
        FDB     2+COFF,7+COFF
        FDB     1+COFF,8+COFF
        FDB     $8100,$8100     ;ENDING TERMINATOR
;*
;*
;*      EGG FALLING SEQUENCE
;*
;*AAFF050778B0FFF4FFF4FFF4FFF4FFF4
;*00FF70580F3F51E814905D111FA40A67
EGGUP   FDB     $0407!DMAFIX                                                    ;;Fixme was: !XDMAFIX
        FCB     $00,$B2,$2B,$00
        FCB     $0B,$21,$12,$B0
        FCB     $02,$11,$11,$20
        FCB     $02,$15,$15,$20
        FCB     $02,$51,$55,$20
        FCB     $03,$25,$52,$30
        FCB     $00,$32,$23,$00
;*AAFF050678B0FFF4FFF4FFF4FFF4FFF4
;*00FF70580F3F51E814905D111FA40A67
EGGRT   FDB     $0406!DMAFIX                                                    ;;Fixme was: !XDMAFIX
        FCB     $00,$25,$52,$00
        FCB     $02,$51,$15,$B0
        FCB     $32,$11,$11,$30
        FCB     $35,$11,$52,$B0
        FCB     $B2,$55,$23,$00
        FCB     $0B,$33,$30,$00
;*AAFF050678B0FFF4FFF4FFF4FFF4FFF4
;*00FF70580F3F51E814905D111FA40A67
EGGLF   FDB     $0406!DMAFIX                                                    ;;Fixme was: !XDMAFIX
        FCB     $02,$55,$20,$00
        FCB     $B5,$11,$52,$00
        FCB     $31,$11,$12,$30
        FCB     $B2,$51,$15,$30
        FCB     $03,$25,$52,$B0
        FCB     $00,$33,$3B,$00
;*AAFF060678B074F774F67476F4F67474
;*00FF70580F3F51E814905D111FA40A67
EGGB1   FDB     $0506!DMAFIX                                                    ;;Fixme was: !XDMAFIX
        FCB     $02,$00,$63,$53,$00
        FCB     $25,$36,$4E,$52,$30
        FCB     $51,$5E,$63,$51,$30
        FCB     $21,$52,$E2,$15,$30
        FCB     $32,$12,$35,$22,$00
        FCB     $0B,$22,$32,$3B,$00
;*AAFF080B78B074F774F67476F4F67474
;*00FF70580F3F51E814905D111FA40A67
EGGB2   FDB     $080B!DMAFIX                                                    ;;Fixme was: !XDMAFIX
        FCB     $00,$00,$63,$36,$00,$00,$00,$00
        FCB     $00,$00,$B6,$46,$00,$00,$00,$00
        FCB     $55,$00,$B3,$3E,$00,$00,$00,$00
        FCB     $32,$03,$33,$E0,$80,$00,$05,$00
        FCB     $00,$B0,$E3,$B0,$00,$00,$23,$00
        FCB     $00,$00,$0B,$B3,$35,$30,$00,$00
        FCB     $02,$30,$06,$6E,$31,$30,$00,$00
        FCB     $01,$03,$36,$63,$23,$00,$00,$00
        FCB     $01,$15,$36,$E0,$00,$00,$05,$00
        FCB     $02,$11,$23,$E0,$21,$03,$11,$00
        FCB     $00,$22,$22,$E2,$12,$33,$23,$00
;*AAFF0A0C78B074F774F67476F4F67474
;*00FF70580F3F51E814905D111FA40A67
EGGB3   FDB     $0A0C!DMAFIX                                                    ;;Fixme was: !XDMAFIX
        FCB     $00,$00,$00,$00,$00,$01,$00,$00,$00,$00
        FCB     $15,$00,$00,$6D,$D6,$01,$00,$00,$00,$00
        FCB     $32,$00,$00,$34,$43,$01,$00,$00,$05,$00
        FCB     $00,$00,$00,$ED,$D3,$01,$00,$00,$52,$00
        FCB     $00,$00,$03,$3D,$D0,$DD,$00,$00,$00,$00
        FCB     $00,$00,$DE,$63,$D0,$2D,$00,$00,$00,$00
        FCB     $00,$00,$00,$63,$36,$6D,$00,$00,$00,$00
        FCB     $05,$00,$00,$32,$3E,$61,$00,$00,$00,$00
        FCB     $03,$20,$00,$D6,$63,$61,$00,$00,$01,$00
        FCB     $00,$00,$03,$3E,$E2,$61,$00,$00,$12,$00
        FCB     $00,$00,$03,$30,$03,$31,$00,$00,$00,$00
        FCB     $00,$00,$33,$30,$E3,$31,$00,$00,$00,$00
;*
;*      LAVA TROLL GRABBING HAND
;*
_ILAVAT FDB     0,$00FB,GRAB1
        FDB     0,$00F8,GRAB2
        FDB     0,$00F8,GRAB3
        FDB     0,$00F2,GRAB4
        FDB     0,$00F0,GRAB5
        FDB     0,$00EF,GRAB6

;*
;*      LAVA TROOL HAND SEQUENCES
;*
;*AAFF040678B0FFF4FFF4FFF4FFF4FFF4
;*00FF70580F3F51E814905D111FA40A67
GRAB1   FDB     $0306!DMAFIX                                                    ;;Fixme was: !XDMAFIX
        FCB     $44,$8E,$00
        FCB     $0E,$44,$E0
        FCB     $00,$04,$80
        FCB     $00,$0E,$40
        FCB     $00,$00,$40
        FCB     $00,$00,$40
;*AAFF040978B0FFF4FFF4FFF4FFF4FFF4
;*00FF70580F3F51E814905D111FA40A67
GRAB2   FDB     $0409!DMAFIX                                                    ;;Fixme was: !XDMAFIX
        FCB     $00,$00,$0C,$00
        FCB     $00,$00,$E4,$00
        FCB     $00,$00,$44,$00
        FCB     $00,$0E,$44,$00
        FCB     $0E,$44,$4E,$00
        FCB     $E4,$44,$E0,$00
        FCB     $44,$E0,$00,$00
        FCB     $48,$00,$00,$00
        FCB     $4E,$00,$00,$00
;*AAFF070978B0FFF4FFF4FFF4FFF4FFF4
;*00FF70580F3F51E814905D111FA40A67
GRAB3   FDB     $0609!DMAFIX                                                    ;;Fixme was: !XDMAFIX
        FCB     $00,$00,$00,$40,$04,$00
        FCB     $00,$04,$00,$40,$04,$E0
        FCB     $00,$04,$0E,$40,$E4,$E0
        FCB     $00,$04,$4C,$C4,$44,$00
        FCB     $00,$04,$4A,$CC,$4E,$00
        FCB     $00,$E4,$AA,$44,$E0,$00
        FCB     $00,$4A,$A4,$E0,$00,$00
        FCB     $04,$A8,$E0,$00,$00,$00
        FCB     $4E,$00,$00,$00,$00,$00
;*AAFF070F78B0FFF4FFF4FFF4FFF4FFF4
;*00FF70580F3F51E814905D111FA40A67
GRAB4   FDB     $060F!DMAFIX                                                    ;;Fixme was: !XDMAFIX
        FCB     $00,$00,$A0,$00,$80,$00
        FCB     $00,$00,$A0,$0E,$A0,$00
        FCB     $08,$00,$A8,$0A,$80,$00
        FCB     $EA,$0E,$A8,$8A,$80,$A0
        FCB     $AA,$08,$AA,$AA,$0A,$A0
        FCB     $CA,$0A,$AA,$A8,$8A,$80
        FCB     $8C,$AA,$AA,$AA,$AC,$00
        FCB     $EC,$AA,$AA,$AC,$4E,$00
        FCB     $08,$CA,$CA,$A4,$E0,$00
        FCB     $0E,$4C,$AC,$4E,$00,$00
        FCB     $00,$4C,$C4,$E0,$00,$00
        FCB     $00,$44,$4E,$00,$00,$00
        FCB     $0E,$44,$E0,$00,$00,$00
        FCB     $E4,$4E,$00,$00,$00,$00
        FCB     $4E,$00,$00,$00,$00,$00
;*AAFF081178B0FFF4FFF4FFF4FFF4FFF4
;*00FF70580F3F51E814905D111FA40A67
GRAB5   FDB     $0711!DMAFIX                                                    ;;Fixme was: !XDMAFIX
        FCB     $00,$00,$00,$80,$00,$00,$00
        FCB     $00,$00,$0E,$80,$0A,$00,$00
        FCB     $00,$00,$0E,$E0,$8E,$0E,$E0
        FCB     $0A,$00,$08,$EE,$80,$08,$80
        FCB     $E8,$00,$E8,$08,$80,$88,$00
        FCB     $88,$00,$EA,$A8,$E8,$80,$00
        FCB     $EA,$80,$88,$5F,$AA,$0E,$80
        FCB     $0A,$AF,$FE,$8F,$5E,$88,$E0
        FCB     $0E,$A8,$F8,$AA,$AA,$80,$00
        FCB     $08,$AA,$8A,$AA,$E8,$00,$00
        FCB     $0E,$88,$8F,$5F,$80,$00,$00
        FCB     $00,$8A,$A5,$FA,$E0,$00,$00
        FCB     $08,$8E,$8A,$8E,$00,$00,$00
        FCB     $04,$AA,$8E,$E0,$00,$00,$00
        FCB     $E4,$C4,$CE,$00,$00,$00,$00
        FCB     $84,$48,$E0,$00,$00,$00,$00
        FCB     $48,$E0,$00,$00,$00,$00,$00
;*AAFF081278B0FFF4FFF4FFF4FFF4FFF4
;*00FF70580F3F51E814905D111FA40A67
GRAB6   FDB     $0712!DMAFIX                                                    ;;Fixme was: !XDMAFIX
        FCB     $00,$00,$00,$00,$AA,$F0,$00
        FCB     $00,$00,$00,$8A,$88,$E8,$80
        FCB     $00,$00,$0E,$F8,$EA,$EA,$A0
        FCB     $00,$00,$0F,$AE,$08,$88,$E0
        FCB     $00,$00,$AF,$AE,$8A,$AF,$F0
        FCB     $00,$0E,$AA,$EE,$EE,$08,$80
        FCB     $00,$08,$88,$8E,$8A,$FF,$80
        FCB     $00,$EA,$FE,$A8,$E0,$88,$00
        FCB     $0E,$8F,$88,$FA,$0F,$08,$00
        FCB     $08,$4A,$88,$8E,$81,$E0,$00
        FCB     $04,$A4,$8E,$08,$F1,$E0,$00
        FCB     $04,$A8,$E0,$0F,$8F,$E0,$00
        FCB     $04,$CE,$00,$0F,$EF,$E0,$00
        FCB     $08,$CE,$00,$00,$F8,$E0,$00
        FCB     $0E,$48,$00,$00,$00,$00,$00
        FCB     $00,$48,$00,$00,$00,$00,$00
        FCB     $04,$4E,$00,$00,$00,$00,$00
        FCB     $48,$E0,$00,$00,$00,$00,$00
;*
;*      LAVA FLAME
;*
_IFLAME FDB     0,$00F2,FLAME1
        FDB     0,$00F1,FLAME2
        FDB     0,$00F1,FLAME3
        FDB     0,$00F5,FLAME4
;*
;*      FLAME SEQUENCES
;*
;*AAFF050F78B0FFF4FFF4FFF4FFF4FFF4
;*00FF70580F3F51E814905D111FA40A67
FLAME1  FDB     $040F!DMAFIX                                                    ;;Fixme was: !XDMAFIX
        FCB     $00,$00,$40,$00
        FCB     $00,$0E,$44,$00
        FCB     $00,$04,$C4,$00
        FCB     $00,$04,$A8,$00
        FCB     $00,$08,$50,$00
        FCB     $00,$00,$50,$00
        FCB     $00,$00,$00,$00
        FCB     $00,$00,$00,$00
        FCB     $0E,$80,$00,$00
        FCB     $00,$4E,$00,$00
        FCB     $00,$E4,$40,$00
        FCB     $00,$E4,$C4,$00
        FCB     $00,$8C,$5A,$E0
        FCB     $0E,$CA,$55,$C0
        FCB     $E4,$A5,$55,$A0
;*AAFF041078B0FFF4FFF4FFF4FFF4FFF4
;*00FF70580F3F51E814905D111FA40A67
FLAME2  FDB     $0410!DMAFIX                                                    ;;Fixme was: !XDMAFIX
        FCB     $00,$0E,$4E,$00
        FCB     $00,$0E,$44,$00
        FCB     $00,$00,$4A,$00
        FCB     $00,$00,$04,$00
        FCB     $00,$00,$00,$00
        FCB     $00,$00,$00,$00
        FCB     $00,$00,$00,$00
        FCB     $04,$EE,$00,$00
        FCB     $0E,$48,$E0,$00
        FCB     $0E,$44,$80,$00
        FCB     $00,$44,$CE,$00
        FCB     $00,$4C,$A8,$00
        FCB     $00,$4A,$5C,$00
        FCB     $0E,$C5,$5C,$00
        FCB     $08,$A5,$5C,$00
        FCB     $4A,$55,$5A,$00
;*AAFF051078B0FFF4FFF4FFF4FFF4FFF4
;*00FF70580F3F51E814905D111FA40A67
FLAME3  FDB     $0510!DMAFIX                                                    ;;Fixme was: !XDMAFIX
        FCB     $00,$00,$00,$4E,$00
        FCB     $00,$00,$00,$E4,$00
        FCB     $00,$00,$00,$00,$00
        FCB     $00,$00,$00,$00,$00
        FCB     $00,$00,$00,$00,$00
        FCB     $00,$00,$40,$00,$00
        FCB     $00,$04,$00,$40,$00
        FCB     $0E,$44,$0E,$40,$00
        FCB     $04,$4E,$0C,$40,$00
        FCB     $04,$C0,$4A,$80,$00
        FCB     $0C,$54,$C8,$E0,$00
        FCB     $0A,$5A,$C4,$00,$00
        FCB     $0A,$55,$C4,$00,$00
        FCB     $05,$55,$A8,$00,$00
        FCB     $05,$55,$A8,$00,$00
        FCB     $4A,$55,$A8,$00,$00
;*AAFF040C78B0FFF4FFF4FFF4FFF4FFF4
;*00FF70580F3F51E814905D111FA40A67
FLAME4  FDB     $040C!DMAFIX                                                    ;;Fixme was: !XDMAFIX
        FCB     $00,$00,$04,$00
        FCB     $00,$04,$44,$00
        FCB     $00,$4C,$48,$00
        FCB     $0E,$CA,$40,$00
        FCB     $04,$AE,$00,$00
        FCB     $04,$00,$00,$00
        FCB     $04,$00,$00,$00
        FCB     $84,$80,$00,$00
        FCB     $4C,$CE,$00,$00
        FCB     $4A,$5C,$E0,$00
        FCB     $45,$55,$A0,$00
        FCB     $4A,$55,$AE,$00
;*
;*******************************************************************************
;*      PLAYER DEATH POOF IMAGES
;*       FROM KEN LANTZ
;*
_POOF1  POSOFF  0,$01,$18,FL1
_POOF2  POSOFF  0,$01,$1E,FL2
_POOF3  POSOFF  0,$00,$23,FL3
;*
FL1     FDB     $0305!DMAFIX                                                    ;;Fixme was: !XDMAFIX
        FCB     $00,$04,$00
        FCB     $00,$44,$40
        FCB     $04,$41,$44
        FCB     $00,$44,$40
        FCB     $00,$04,$00
;*
FL2     FDB     $0509!DMAFIX                                                    ;;Fixme was: !XDMAFIX
        FCB     $00,$00,$70,$00,$00
        FCB     $07,$00,$70,$07,$00
        FCB     $00,$70,$00,$70,$00
        FCB     $00,$05,$05,$00,$00
        FCB     $77,$00,$00,$07,$70
        FCB     $00,$05,$05,$00,$00
        FCB     $00,$70,$00,$70,$00
        FCB     $07,$00,$70,$07,$00
        FCB     $00,$00,$70,$00,$00
;*
FL3     FDB     $060B!DMAFIX                                                    ;;Fixme was: !XDMAFIX
        FCB     $00,$07,$00,$07,$00,$00
        FCB     $00,$00,$07,$00,$00,$00
        FCB     $07,$00,$00,$00,$07,$00
        FCB     $00,$07,$01,$07,$00,$00
        FCB     $00,$00,$00,$00,$00,$00
        FCB     $70,$71,$00,$01,$70,$70
        FCB     $00,$00,$00,$00,$00,$00
        FCB     $00,$07,$01,$07,$00,$00
        FCB     $07,$00,$00,$00,$07,$00
        FCB     $00,$00,$07,$00,$00,$00
        FCB     $00,$07,$00,$07,$00,$00
;*
;*      PTERODACTYL, FLYING ONLY IMAGES
;*
_IPTERO POSOFF  PT1RC,1,11,PT1R
        POSOFF  PT1LC,1,11,PT1L
        POSOFF  PT2RC,1,07,PT2R
        POSOFF  PT2LC,0,07,PT2L
        POSOFF  PT3RC,0,10,PT3R
        POSOFF  PT3LC,0,10,PT3L
;*
PT1RC   FDB     $8000,$8000
        FDB     $8000,$8000
        FDB     $8000,$8000
        FDB     $8000,$8000
        FDB     9+COFF,14+COFF
        FDB     9+COFF,22+COFF
        FDB     5+COFF,26+COFF
        FDB     3+COFF,24+COFF
        FDB     5+COFF,21+COFF
        FDB     8+COFF,15+COFF
        FDB     $8100,$8100
        FDB     $8100,$8100
        FDB     $8100,$8100             ;TERMINATING POINTER
;*
PT2RC   FDB     $8000,$8000
        FDB     $8000,$8000
        FDB     $8000,$8000
        FDB     $8000,$8000
        FDB     20+COFF,24+COFF
        FDB     10+COFF,27+COFF
        FDB     7+COFF,25+COFF
        FDB     5+COFF,25+COFF
        FDB     7+COFF,26+COFF
        FDB     5+COFF,21+COFF
        FDB     3+COFF,7+COFF
        FDB     $8100,$8100
        FDB     $8100,$8100             ;TERMINATING POINTER
;*
PT3RC   FDB     $8000,$8000
        FDB     27+COFF,28+COFF
        FDB     23+COFF,27+COFF
        FDB     22+COFF,26+COFF
        FDB     20+COFF,25+COFF
        FDB     9+COFF,27+COFF
        FDB     6+COFF,25+COFF
        FDB     4+COFF,26+COFF
        FDB     6+COFF,21+COFF
        FDB     8+COFF,16+COFF
        FDB     5+COFF,12+COFF
        FDB     $8100,$8100
        FDB     $8100,$8100             ;TERMINATING POINTER
;*
PT1LC   FDB     $8000,$8000
        FDB     $8000,$8000
        FDB     $8000,$8000
        FDB     $8000,$8000
        FDB     15+COFF,20+COFF
        FDB     7+COFF,20+COFF
        FDB     3+COFF,24+COFF
        FDB     5+COFF,26+COFF
        FDB     8+COFF,24+COFF
        FDB     14+COFF,21+COFF
        FDB     $8100,$8100
        FDB     $8100,$8100
        FDB     $8100,$8100             ;TERMINATING POINTER
;*
PT2LC   FDB     $8000,$8000
        FDB     $8000,$8000
        FDB     $8000,$8000
        FDB     $8000,$8000
        FDB     5+COFF,9+COFF
        FDB     2+COFF,19+COFF
        FDB     4+COFF,22+COFF
        FDB     4+COFF,24+COFF
        FDB     3+COFF,22+COFF
        FDB     12+COFF,24+COFF
        FDB     22+COFF,26+COFF
        FDB     $8100,$8100
        FDB     $8100,$8100             ;TERMINATING POINTER
;*
PT3LC   FDB     $8000,$8000
        FDB     1+COFF,2+COFF
        FDB     2+COFF,6+COFF
        FDB     3+COFF,7+COFF
        FDB     4+COFF,9+COFF
        FDB     2+COFF,20+COFF
        FDB     4+COFF,23+COFF
        FDB     3+COFF,25+COFF
        FDB     8+COFF,23+COFF
        FDB     13+COFF,21+COFF
        FDB     17+COFF,24+COFF
        FDB     $8100,$8100
        FDB     $8100,$8100             ;TERMINATING POINTER
;*
;*AAFF0E0E80C2FF00FF40FF00FF00FF00
;*00FF70580F3F51E814905D111FA40A67
PT1R    FDB     $0D0A!DMAFIX                                                    ;;Fixme was: !XDMAFIX
        FCB     $99,$99,$F6,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
        FCB     $00,$09,$44,$F7,$90,$00,$00,$00,$00,$00,$00,$00,$00
        FCB     $00,$00,$00,$44,$CF,$79,$00,$00,$00,$00,$00,$00,$00
        FCB     $00,$00,$00,$09,$44,$FF,$70,$00,$00,$00,$00,$00,$00
        FCB     $00,$00,$00,$94,$4F,$79,$00,$00,$00,$00,$00,$00,$00
        FCB     $00,$00,$00,$94,$CF,$70,$00,$0D,$1F,$FD,$00,$00,$00
        FCB     $00,$99,$44,$88,$F4,$14,$90,$00,$04,$00,$D1,$1F,$00
        FCB     $99,$64,$8C,$FF,$CC,$C5,$FF,$CA,$88,$FF,$DD,$00,$00
        FCB     $00,$99,$44,$CD,$FF,$88,$4F,$FC,$34,$E0,$00,$00,$00
        FCB     $00,$00,$09,$44,$48,$86,$E0,$00,$00,$00,$00,$00,$00
;*
;*AAFF0E077FCBFF00FF40FF00FF00FF00
;*00FF70580F3F51E814905D111FA40A67
;*
PT2R    FDB     $0D07!DMAFIX                                                    ;;Fixme was: !XDMAFIX
        FCB     $00,$00,$00,$00,$00,$00,$00,$00,$0D,$1F,$FD,$00,$00
        FCB     $00,$00,$00,$06,$36,$9F,$F1,$90,$00,$04,$00,$11,$10
        FCB     $00,$00,$69,$94,$9F,$FC,$F9,$A0,$00,$EC,$8F,$80,$00
        FCB     $00,$69,$4E,$94,$FC,$D8,$E8,$9C,$9F,$FD,$C9,$F0,$00
        FCB     $00,$00,$94,$FC,$99,$6E,$98,$AD,$CF,$8E,$00,$ED,$00
        FCB     $00,$94,$DD,$66,$0E,$E6,$88,$E0,$00,$00,$00,$00,$00
        FCB     $94,$F4,$90,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
;*
;*AAFF0F0B7FC8FF00FF40FF00FF00FF00
;*00FF70580F3F51E814905D111FA40A67
;*
PT3R    FDB     $0F0B!DMAFIX                                                    ;;Fixme was: !XDMAFIX
        FCB     $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$8F,$00
        FCB     $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$FD,$ED,$10,$00
        FCB     $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$0F,$00,$DF,$00,$00
        FCB     $00,$00,$00,$00,$00,$00,$00,$00,$00,$0F,$14,$F1,$C0,$00,$00
        FCB     $00,$00,$00,$00,$63,$69,$86,$00,$00,$00,$0F,$DC,$E8,$40,$00
        FCB     $00,$00,$06,$99,$AA,$AC,$FC,$A6,$00,$00,$CD,$43,$F0,$00,$00
        FCB     $00,$06,$94,$84,$C3,$FF,$F1,$8A,$CD,$FF,$D8,$00,$ED,$00,$00
        FCB     $00,$00,$06,$64,$6F,$FC,$F9,$8C,$DC,$F8,$E0,$00,$00,$00,$00
        FCB     $00,$00,$00,$06,$4C,$78,$66,$8E,$00,$00,$00,$00,$00,$00,$00
        FCB     $00,$00,$99,$4C,$AA,$F7,$00,$00,$00,$00,$00,$00,$00,$00,$00
        FCB     $99,$44,$CA,$AA,$FF,$D7,$D0,$00,$00,$00,$00,$00,$00,$00,$00
;*
;*AAFF0E0E80C2FF00FF40FF00FF00FF00
;*00FF70580F3F51E814905D111FA40A67
PT1L    FDB     $0D0A!DMAFIX                                                    ;;Fixme was: !XDMAFIX
        FCB     $00,$00,$00,$00,$00,$00,$00,$00,$00,$6F,$99,$99,$00
        FCB     $00,$00,$00,$00,$00,$00,$00,$09,$7F,$44,$90,$00,$00
        FCB     $00,$00,$00,$00,$00,$00,$97,$FC,$44,$00,$00,$00,$00
        FCB     $00,$00,$00,$00,$00,$07,$FF,$44,$90,$00,$00,$00,$00
        FCB     $00,$00,$00,$00,$00,$00,$97,$F4,$49,$00,$00,$00,$00
        FCB     $00,$00,$DF,$F1,$D0,$00,$07,$FC,$49,$00,$00,$00,$00
        FCB     $F1,$1D,$00,$40,$00,$09,$41,$4F,$88,$44,$99,$00,$00
        FCB     $00,$DD,$FF,$88,$AC,$FF,$5C,$CC,$FF,$C8,$46,$99,$00
        FCB     $00,$00,$0E,$43,$CF,$F4,$88,$FF,$DC,$44,$99,$00,$00
        FCB     $00,$00,$00,$00,$00,$0E,$68,$84,$44,$90,$00,$00,$00
;*
;*AAFF0E077FCBFF00FF40FF00FF00FF00
;*00FF70580F3F51E814905D111FA40A67
;*
PT2L    FDB     $0E07!DMAFIX                                                    ;;Fixme was: !XDMAFIX
        FCB     $00,$00,$DF,$F1,$D0,$00,$00,$00,$00,$00,$00,$00,$00,$00
        FCB     $01,$11,$00,$40,$00,$09,$1F,$F9,$63,$60,$00,$00,$00,$00
        FCB     $00,$08,$F8,$CE,$00,$0A,$9F,$CF,$F9,$49,$96,$00,$00,$00
        FCB     $00,$0F,$9C,$DF,$F9,$C9,$8E,$8D,$CF,$49,$E4,$96,$00,$00
        FCB     $00,$DE,$00,$E8,$FC,$DA,$89,$E6,$99,$CF,$49,$00,$00,$00
        FCB     $00,$00,$00,$00,$00,$0E,$88,$6E,$E0,$66,$DD,$49,$00,$00
        FCB     $00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$09,$4F,$49,$00
;*
;*AAFF0F0B7FC8FF00FF40FF00FF00FF00
;*00FF70580F3F51E814905D111FA40A67
;*
PT3L    FDB     $0F0B!DMAFIX                                                    ;;Fixme was: !XDMAFIX
        FCB     $F8,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
        FCB     $01,$DE,$DF,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
        FCB     $00,$FD,$00,$F0,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
        FCB     $00,$0C,$1F,$41,$F0,$00,$00,$00,$00,$00,$00,$00,$00,$00,$00
        FCB     $04,$8E,$CD,$F0,$00,$00,$00,$68,$96,$36,$00,$00,$00,$00,$00
        FCB     $00,$0F,$34,$DC,$00,$00,$6A,$CF,$CA,$AA,$99,$60,$00,$00,$00
        FCB     $00,$DE,$00,$8D,$FF,$DC,$A8,$1F,$FF,$3C,$48,$49,$60,$00,$00
        FCB     $00,$00,$00,$0E,$8F,$CD,$C8,$9F,$CF,$F6,$46,$60,$00,$00,$00
        FCB     $00,$00,$00,$00,$00,$00,$E8,$66,$87,$C4,$60,$00,$00,$00,$00
        FCB     $00,$00,$00,$00,$00,$00,$00,$00,$7F,$AA,$C4,$99,$00,$00,$00
        FCB     $00,$00,$00,$00,$00,$00,$00,$0D,$7D,$FF,$AA,$AC,$44,$99,$00
;*
;*      PTERODACTYL DISSOULVE
;*
_ASH1R
_ASH1L
;* PTERA1
        FCB     $D0,$1C,$01
        FCB     $B0,$2C,$14,$01
        FCB     $C0,$14,$01
        FCB     $B0,$14,$1C,$01
        FCB     $40,$34,$30,$24,$1C,$1C,$01
        FCB     $30,$14,$3C,$14,$20,$14,$2C,$01
        FCB     $20,$24,$2C,$34,$2C,$10,$14,$01
        FCB     $30,$34,$5C,$01
        FCB     $30,$24,$3C,$01
        FCB     $20,$2C,$01
        FCB     $24,$5C,$00
;* PTERA2
        FCB     $D0,$14,$01
        FCB     $B0,$24,$1E,$01
        FCB     $C0,$2E,$01
        FCB     $B0,$1E,$14,$01
        FCB     $40,$3E,$30,$2E,$1E,$14,$01
        FCB     $30,$2E,$24,$1E,$20,$1E,$24,$01
        FCB     $20,$3E,$14,$2E,$10,$1E,$14,$2E,$01
        FCB     $30,$1E,$10,$2E,$24,$24,$01
        FCB     $30,$1E,$2E,$24,$01
        FCB     $20,$3E,$14,$01
        FCB     $3E,$24,$24,$00
;* PTERA3
        FCB     $E0,$01
        FCB     $B0,$1E,$14,$1E,$01
        FCB     $C0,$2E,$01
        FCB     $B0,$1E,$1E,$01
        FCB     $40,$2E,$40,$2E,$1E,$1E,$01
        FCB     $30,$1E,$10,$1E,$14,$1E,$20,$1E,$14,$1E,$01
        FCB     $30,$2E,$10,$1E,$20,$1E,$10,$2E,$01
        FCB     $50,$2E,$1E,$14,$1E,$14,$01
        FCB     $40,$2E,$1E,$14,$01
        FCB     $20,$2E,$1E,$01
        FCB     $1E,$2E,$20,$1E,$14,$00
;*
LENGTH  EQU     *       ;CURRENT TOTAL LENGTH OF IMAGES
        IF *-$3B10 > 0                                          ;;Fixme was: IFGT       *-$3B10
         FCB    $1111   ;OVERFLOW PAST $3B10
        ENDIF
;       END     ;$E000