;;
;;                     JJJJ   OOO   U   U   SSSS  TTTTT
;;                        J  O   O  U   U  S        T
;;                        J  O   O  U   U   SSS     T
;;                    J   J  O   O  U   U      S    T
;;                     JJJ    OOO    UUU   SSSS     T
;;
;;      Video Sound ROM 4 programmed by John Kotlarik, started 06/15/1982
;;      Walsh Function Sound Machine by Tim Murphy, 11/10/1981
;;
;;      Re-targeted for Macroassembler {AS} by SynaMax - 01/29/2024
;;
;;======================================================================
;;
;;   To build the Joust Sound ROM, type the following:
;;
;;   asl VSNDRM4.ASM -o vsndrm4.p
;;
;;   p2bin vsndrm4.p video_sound_rom_4_std_780.ic12 -l 00 -r $F000-$FFFF
;;
;;======================================================================
;;  Macro Assembler AS Instructions
        CPU     6800
;;======================================================================
;       NAM     JOUST SOUND ROM STARTED 06/15/1982
;       SUBTTL
;*COPYRIGHT WILLIAMS ELECTRONICS INC. 1982
;*PROGRAMMERS: EUGENE P. JARVIS, SAM DICKER,RANDY PFEIFFER,JOHN KOTLARIK
;*              PAUL G. DUSSAULT,CARY W. KOLKER,TIM  MURPHY
;*                      AND A CAST OF THOUSANDS......
;*
;*
;*SYSTEM CONSTANTS
;*
ROM     EQU     $F000
SOUND   SET     $400
CKORG   EQU     $EF00   ;CHECKSUM PROG ORG
ENDRAM  SET     $7F
VECTOR  EQU     $FFF8   ;RESET,INT VECTORS
WVELEN  EQU     72
;*
;* SCREAM EQUATES
;*
ECHOS   EQU     4
FREQ    EQU     0
TIMER   EQU     1
;*
;*GLOBALS
;*
        ORG     0
HI      RMB     1       ;RANDOM SEED
LO      RMB     1       ;RANDOM SEED
XDECAY  RMB     2
AMP0    RMB     1
;*
;*
;*TEMPORARIES
;*
TMPRAM  EQU     *       ;TEMPORARY RAM
TEMPX   RMB     2       ;X TEMPS
XPLAY   RMB     2
XPTR    RMB     2
TEMPA   RMB     1       ;ACCA TEMP
TEMPB   RMB     1
LOCRAM  EQU     *
;*
;*GWAVE PARAMETERS
;*
        ORG     LOCRAM
GECHO   RMB     1       ;ECHO FLAG
GCCNT   RMB     1       ;CYCLE COUNT
GECDEC  RMB     1       ;# OF DECAYS PER ECHO
GDFINC  RMB     1       ;DELTA FREQ INC
GDCNT   RMB     1       ;DELTA FREQ COUNT
GWFRM   RMB     2       ;WAVEFORM ADDRESS
;*TEMPORARY OR COMPUTED PARAMETERS
PRDECA  RMB     1       ;PRE-DECAY FACTOR
GWFRQ   RMB     2       ;FREQ TABLE ADDR
FRQEND  RMB     2       ;END ADDR FREQ TABLE
WVEND   RMB     2       ;WAVE END ADDR
GPER    RMB     1       ;PERIOD
GECNT   RMB     1       ;# OF ECHOES COUNTER
FOFSET  RMB     1       ;FREQUENCY OFFSET
;*
;*GWAVE TABLES
;*
GWTAB   RMB     WVELEN  ;WAVE TABLE
;*
;*VARIWAVE PARAMETERS
;*
        ORG     LOCRAM
LOPER   RMB     1       ;LO PERIOD
HIPER   RMB     1       ;HIPERIOD
LODT    RMB     1       ;PERIOD DELTAS
HIDT    RMB     1
HIEN    RMB     1       ;END PERIOD
SWPDT   RMB     2       ;SWEEP PERIOD
LOMOD   RMB     1       ;BASE FREQ MOD
VAMP    RMB     1       ;AMPLITUDE
LOCNT   RMB     1       ;PERIOD COUNTERS
HICNT   RMB     1
;* BOMB RAM
        ORG     LOCRAM
TIMEBOM RMB     1                                                               ;;Fixme was: TIME (This is a reserved label for {AS})
TABLE   RMB     2
FREQZ   RMB     1
;*
;* KNOCKER RAM
;*
        ORG     LOCRAM
PERIOD  RMB     1
AMP     RMB     1
SNDTMP  RMB     2       ;INDEX TMEP
;*
;* FLASH LOCAL RAM
        ORG     LOCRAM
FREQ1   RMB     1       ;FREQUENCY CONSTANT 1
FREQ2   RMB     1       ;FREQUENCY CONSTANT 2
FREQ3   RMB     1       ;FREQUENCY CONSTANT 3
FREQ4   RMB     1       ;FREQUENCY CONSTANT 4
DELTA1  RMB     1       ;DELTA AMPLITUDE 1
DELTA2  RMB     1       ;DELTA AMPLITUDE 2
DELTA3  RMB     1       ;DELTA AMPLITUDE 3
DELTA4  RMB     1       ;DELTA AMPLITUDE 4
FREQ1S  RMB     1       ;FREQUENCY COUNTER 1                                    ;;Fixme was: FREQ1$ (invalid symbol - can't use $)
FREQ2S  RMB     1       ;FREQUENCY COUNTER 2                                    ;;Fixme was: FREQ2$
FREQ3S  RMB     1       ;FREQUENCY COUNTER 3                                    ;;Fixme was: FREQ3$
FREQ4S  RMB     1       ;FREQUENCY COUNTER 4                                    ;;Fixme was: FREQ4$
CYCLE1  RMB     1       ;CYCLE CONSTANT 1
CYCLE2  RMB     1       ;CYCLE CONSTANT 2
CYCLE3  RMB     1       ;CYCLE CONSTANT 3
CYCLE4  RMB     1       ;CYCLE CONSTANT 4
DFREQ1  RMB     1       ;DELTA FREQUENCY 1
DFREQ2  RMB     1       ;DELTA FREQUENCY 2
DFREQ3  RMB     1       ;DELTA FREQUENCY 3
DFREQ4  RMB     1       ;DELTA FREQUENCY 4
EFREQ1  RMB     1       ;END FREQUENCY 1
EFREQ2  RMB     1       ;END FREQUENCY 2
EFREQ3  RMB     1       ;END FREQUENCY 3
EFREQ4  RMB     1       ;END FREQUENCY 4
CYCL1S  RMB     1       ;CYCLE COUNTER 1                                        ;;Fixme was: CYCL1$
CYCL2S  RMB     1       ;CYCLE COUNTER 2                                        ;;Fixme was: CYCL2$
CYCL3S  RMB     1       ;CYCLE COUNTER 3                                        ;;Fixme was: CYCL3$
CYCL4S  RMB     1       ;CYCLE COUNTER 4                                        ;;Fixme was: CYCL4$
SNDX1   RMB     1

RANDOM  EQU     LO      ;SINGLE BYTE RANDOM
        ORG     LOCRAM+1
FREQS   RMB     1       ;START FREQUENCY                                        ;;Fixme was: FREQ$
CSFRQ   RMB     1       ;CYCLES AT FREQUENCY                                    ;;Fixme was: C$FRQ
DSFRQ   RMB     1       ;DELTA FREQUENCY                                        ;;Fixme was: D$FRQ
ESFRQ   RMB     1       ;END FREQUENCY                                          ;;Fixme was: E$FRQ
CSAMP   RMB     1       ;CYCLES AT AMPLITUDE                                    ;;Fixme was: C$AMP
DSAMP   RMB     1       ;DELTA AMPLITUDE                                        ;;Fixme was: D$AMP
CSAMPS  RMB     1       ;CYCLE COUNTER                                          ;;Fixme was: C$AMP$
CSFRQS  RMB     1       ;CYCLE COUNTER                                          ;;Fixme was: C$FRQ$
;*
;*
;*FILTERED NOISE ROUTINE PARAMETERS
;*
        ORG     LOCRAM
FMAX    RMB     1       ;MAXIMUM_FREQUENCY
FHI     RMB     1       ;FREQUENCY
FLO     RMB     1
LOFRQ   RMB     1
SAMPC   RMB     2       ;SAMPLE COUNT
FDFLG   RMB     1       ;FREQUENCY DECREMENT FLAG
DSFLG   RMB     1       ;DISTORTION FLAG
;*
;*
;*
;*NOISE/CROWD ROAR ROUTINE PARAMETERS
;*
        ORG     LOCRAM
DECAY   RMB     1
NAMP    RMB     1
CYCNT   RMB     1
NFRQ1   RMB     2
NFFLG   RMB     1
LFREQ   RMB     1
DFREQ   RMB     1
GALPAM  EQU     *
CYCNT2  RMB     1
NAMP2   RMB     1
DECAY2  RMB     1
NFFLG2  RMB     1
NFR2    RMB     1
GALCNT  RMB     1
WHIS    RMB     1       ;CROWD ROAR AMP
WFRQ    RMB     1       ;CROWD WHISTLE FREQ
WCNT    RMB     1       ;WHISTLE PASSCOUNTER
PTRHI   RMB     2       ;WHIS ADR PTR
WFRQ2   RMB     1
WCNT2   RMB     1
CURVAL  RMB     1       ;WHISTLING NOISE OUTPUT
ATP     RMB     1       ;INTERM NOISE VAL
MINWIS  RMB     1       ;MIN WHISTLE FREQ
CY2     RMB     1       ;NOISE CYCLE COUNTER
DFRQ    RMB     1       ;WHISTLE FREQ CHANGE
DFRQ2   RMB     1       ;INIT WHISTLE FREQ CHANGE
NNOIS   RMB     1       ;NEXT NOISE VALUE
NFRQ    RMB     1       ;NOISE FREQ
NFRQ2   RMB     1       ;INIT NOISE FREQ
RCNT2   RMB     1

;* CHECKSUM CALCULATOR & RELOCATOR                                              ;;This is not included in the final ROM
;*
        ORG     CKORG
CKSUM   LDX     #$FFFF  ;INDEX TO END OF ROM
        CLRB            ;ZERO CHECKSUM
CKSUM1  ADCB    0,X     ;ADD IN PROGRAM BYTE
        DEX             ;TO NEXT BYTE
        CPX     #$F000  ;DONE YET?
        BNE     CKSUM1  ;NOPE...
        STAB    0,X     ;SAVE CHECKSUM AT BEGINNING
        WAI             ;TURN OFF LEDS
FROM    RMB     2
        RMB     2       ;FOR POINTER
;*
;* MAIN PROGRAM
;*
        ORG     ROM
        FCB     $74     ;CHECKSUM BYTE
;*
;*
SETUP   SEI             ;SET INTERRUPT MASK
        LDS     #ENDRAM ;INITIALIZE STACK POINTER
        LDX     #SOUND  ;INDEX TO PIA
        CLR     1,X     ;ACCESS DDRA
        CLR     3,X     ;ACCESS DDRB
        LDAA    #$FF    ;PA0-PA7
        STAA    0,X     ;SET SIDE A AS OUTPUTS
        CLR     2,X     ;SET B SIDE AS INPUTS
        LDAA    #$37    ;CB2 LOW, IRQ ALLOWED
        STAA    3,X     ;PROGRAM B CONTROL REG
        LDAA    #$3C    ;CA2 SET INIT HIGH, NO IRQS
        STAA    1,X     ;PROGRAM A SIDE
        STAA    HI      ;START RANDOM GENERATOR
        CLI             ;CLEAR INTERRUPTS
        BRA     *       ;WAIT FOR INTERRUPT
;*
;*
;* THREE OSCILLATOR SOUND GENERATOR
;*
PLAY    STX     XPLAY   ;SAVE CURRENT INDEX
        LDX     #DECAYZ ;SET TO MAXIMUM AMPLITUDE
        STX     XDECAY  ;AND SAVE
        LDAA    #$80    ;LOAD ZERO AMPLITUDE
PLAY1   LDAB    FREQ4   ;CHECK WHITE NOISE COUNTER
        BPL     PLAY3   ;NOT IN WHITE MODE
        LDAB    RANDOM  ;GET RANDOM NUMBER
        LSRB            ;REDUCE IT
        LSRB
        LSRB
        INCB            ;NOW NON-ZERO
PLAY2   DECB            ;TIME OUT COUNT
        BNE     PLAY2
PLAY3   DEC     FREQ1S  ;COUNT DOWN OSC. 1
        BEQ     PLAY7   ;DO AN UPDATE
        DEC     FREQ2S  ;COUNT DOWN OSC. 2
        BEQ     PLAY8   ;DO AN UPDATE
        DEC     FREQ3S  ;COUNT DOWN OSC. 3
        BEQ     PLAY9   ;DO AN UPDATE
        DEC     FREQ4S  ;COUNT DOWN WHITE NOISE
        BNE     PLAY1   ;DO THEM AGAIN
        LDAB    FREQ4   ;CHECK WHITE NOISE CONSTANT
        BEQ     PLAY1   ;FORGET IT
        ANDB    #$7F    ;STRIP FLAG BIT
        STAB    FREQ4S  ;SAVE WHITE NOISE COUNT
        LDAB    RANDOM  ;GET CURRENT RANDOM
        ASLB            ;DOUBLE
        ADDB    RANDOM  ;TRIPLE
        ADDB    #$0B    ;ADD IN 11
        STAB    RANDOM  ;VOILA...NEW RANDOM NUMBER
        DEC     CYCL4S  ;COUNT DOWN DECAY
        BNE     PLAY6   ;DON'T DECAY
        LDAB    CYCLE4  ;RELOAD COUNT
        STAB    CYCL4S  ;AND SAVE
        LDX     XDECAY  ;GET DECAY JUMP POINTER
        DEX             ;MOVE TO LESS AMPLITUDE
        CPX     #RDECAY+1  ;DONE?
        BEQ     PLAY12  ;YUP...BYE BYE
        STX     XDECAY  ;SAVE NEW POINTER
PLAY6   LDAB    RANDOM  ;GET RANDOM AMPLITUDE
        BMI     PLAY6A  ;SKIP IF NEGATIVE
        ANDB    DELTA4  ;REDUCE AMPLITUDE
        ANDB    #$7F    ;STRIP SIGN BIT
        BRA     PLAY6B
PLAY6A  ANDB    DELTA4  ;REDUCE AMPLITUDE
        ANDB    #$7F    ;REMOVE SIGN BIT
        NEGB    ;NEGATE
PLAY6B  PSHA
        ABA             ;ADD WHITE NOISE
        TAB
        PULA
        LDX     XDECAY  ;GET DECAY POINTER
        JSR     0,X     ;OUTPUT NOISE
        BRA     PLAY1   ;DO SOME MORE
PLAY7   LDX     #FREQ1  ;INDEX TO SET 1
        BRA     PLAY10
PLAY8   LDX     #FREQ2  ;INDEX TO SET 2
        BRA     PLAY10
PLAY9   LDX     #FREQ3  ;INDEX TO SET 3
PLAY10  TST     24,X    ;CHECK CYCLES AT FREQUENCY
        BEQ     PLAY11  ;ZERO, DON'T CHANGE
        DEC     24,X    ;COUNT DOWN
        BNE     PLAY11  ;NOT TIME TO CHANGE...
        LDAB    12,X    ;LOAD CYCLES AT FREQUENCY
        STAB    24,X    ;SAVE IN COUNTER
        LDAB    00,X    ;GET CURRENT FRQUENCY
        ADDB    16,X    ;ADD DELTA
        CMPB    20,X    ;COMPARE TO END
        BEQ     PLAY12  ;DONE...
        STAB    00,X    ;SAVE NEW CURRENT FREQUENCY
PLAY11  LDAB    0,X     ;GET CURRENT FREQUENCY
        STAB    8,X     ;SAVE IN FREQUENCY COUNTER
        ADDA    4,X     ;ADD IN AMPLITUDE
        NEG     4,X     ;NEGATE AMPLITUDE
        TAB             ;SAVE DATA
        LDX     XDECAY  ;INDEX TO DECAY
        JSR     0,X     ;OUTPUT SOUND
        JMP     PLAY1   ;REPEAT
PLAY12  LDX     XPLAY   ;RESTORE INDEX
        RTS
;*
;* ECHO AND DECAY ROUTINE
;*
RDECAY  LSRB
        LSRB
        LSRB
        LSRB
        LSRB
        LSRB
        LSRB
        LSRB
DECAYZ  STAB    SOUND
        RTS
;*
;* 3 OSCILLATOR CALLING ROUTINES
;*
THNDR   LDX     #VEC01  ;THUNDER SOUND
THNDR1  LDAB    #28     ;NEED TO TRANSFER
        JSR     TRANS   ;28 BYTES FOR PLAY
        JSR     PLAY    ;NOW PLAY IT
        RTS
SND4    LDX     #VEC04  ;SOUND 4
        BRA     THNDR1
SND5    LDX     #VEC05  ;SOUND 5
        BRA     THNDR1
;*
;*
;*
;* THE BOMB OOOOOH NOOOOO!
WHIST   LDAA    #$80
        STAA    FREQZ
        LDAA    #SINTBL/$100
        STAA    TABLE
WHIST0  LDAA    #$80
        STAA    TEMPA
WHIST1  LDAA    #18
WHIST2  DECA
        BNE     WHIST2
        LDAA    TIMEBOM                                                 ;;Fixme was: LDAA  TIME
        ADDA    FREQZ
        STAA    TIMEBOM                                                 ;;Fixme was: STAA  TIME
        LSRA
        LSRA
        LSRA
        ADDA    #SINTBL&$FF                                             ;;Fixme was: ADDA  #SINTBL!.$FF
        STAA    TABLE+1
        LDX     TABLE
        LDAA    ,X
        STAA    SOUND
        DEC     TEMPA
        BNE     WHIST1
        DEC     FREQZ
        LDAA    FREQZ
        CMPA    #$20
        BNE     WHIST0
        RTS
;*     SINE TABLE
SINTBL  FCB     $80,$8C,$98,$A5,$B0,$BC,$C6,$D0
        FCB     $DA,$E2,$EA,$F0,$F5,$FA,$FD,$FE
        FCB     $FF,$FE,$FD,$FA,$F5,$F0,$EA,$E2
        FCB     $DA,$D0,$C6,$BC,$B0,$A5,$98,$8C
        FCB     $80,$73,$67,$5A,$4F,$43,$39,$2F
        FCB     $25,$1D,$15,$0F,$0A,$05,$02,$01
        FCB     $00,$01,$02,$05,$0A,$0F,$15,$1D
        FCB     $25,$2F,$39,$43,$4F,$5A,$67,$73
;*
;* KNOCKER ROUTINE
;*
KNOCK   CLR     SOUND+2 ;FULL BLAST
        LDX     #KNKTAB
        STX     SNDTMP
SQLP    LDX     SNDTMP  ;RESTORE X REG
        LDAA    ,X      ;GET PERIOD
        BEQ     END     ;END ON ZERO
        LDAB    1,X     ;GET AMP
        ANDB    #$F0
        STAB    AMP
        LDAB    1,X
        INX
        INX
        STX     SNDTMP  ;SAVE X
        STAA    PERIOD
        ANDB    #$F
LP0     LDAA    AMP
        STAA    SOUND
        LDAA    PERIOD
LP1     LDX     #5      ;DELAY
LP11    DEX
        BNE     LP11
        DECA
        BNE     LP1
        CLR     SOUND
        LDAA    PERIOD
LP2     LDX     #5      ;DELAY
LP22    DEX
        BNE     LP22
        DECA
        BNE     LP2
        DECB
        BNE     LP0
        BRA     SQLP
END     LDAA    #$80    ;OVERRIDE OFF
        STAA    SOUND+2
        RTS
;*
;*
;* KNOCKER PATTERN
;*
KNKTAB  FDB     $01FC,$02FC,$03F8,$04F8,$06F8,$08F4,$0CF4
        FDB     $10F4,$20F2,$40F1,$60F1,$80F1,$A0F1,$C0F1,0
;*
;*
;* SINGLE OSCILLATOR SOUND CALLS
;*
PERK1   JSR     MOVE
        JSR     SING
        RTS
ATARI   LDX     #VEC02X
        BRA     PERK1

PERKS1  BSR     PERK1                                                   ;;Fixme was: PERK$1
        BSR     ECHO
        BRA     PERKS1

PERKSS  LDAA    #$FF                                                    ;;Fixme was: PERK$$
        STAA    AMP0
        LDX     #VEC06X
        BRA     PERKS1
;*
;*      RANDOM SQUIRTS
;*
SQRT    LDAB    #$30
SQRT1   LDX     #VEC09X
        BSR     MOVE
SQRT2   LDAA    RANDOM
        ASLA
        ADDA    RANDOM
        ADDA    #$0B
        STAA    RANDOM
        LSRA
        LSRA
        ADDA    #$0C
        STAA    FREQS
        BSR     SING
        DECB
        BNE     SQRT2
        RTS
;*
;*      ECHO FUNCTION
;*
ECHO    LDAA    AMP0
        SUBA    #$08
        BPL     ECHO1
        STAA    AMP0
        RTS
ECHO1   PULA
        PULA
        RTS
;*
;*      MOVE PARAMETERS
;*
MOVE    LDAA    0,X
        STAA    FREQS
        LDAA    1,X
        STAA    CSFRQ
        LDAA    2,X
        STAA    DSFRQ
        LDAA    3,X
        STAA    ESFRQ
        LDAA    4,X
        STAA    CSAMP
        LDAA    5,X
        STAA    DSAMP
        RTS
;*
;*      DELTA F, DELTA A ROUTINE
;*
SING    LDAA    AMP0    ;GET STARTING AMPLITUDE
SINGS   PSHB            ;SAVE B                                         ;;Fixme was: SING$
        LDAB    CSAMP   ;GET CYCLES AT AMPLITUDE
        STAB    CSAMPS  ;SAVE AS COUNTER
        LDAB    CSFRQ   ;GET CYCLES AT FREQUENCY
        STAB    CSFRQS  ;SAVE AS COUNTER
SING1   COMA            ;INVERT AMPLITUDE
        LDAB    FREQS   ;GET FREQUENCY COUNTER
        STAA    SOUND   ;OUTPUT TO D/A
SING2   DECB
        BNE     SING2
        COMA            ;INVERT AMPLITUDE
        LDAB    FREQS   ;GET FREQUENCY COUNTER
        BRA     *+2     ;-I
        INX             ;-I
        DEX             ;-I--- SYNC, 20 CYCLES
        INX             ;-I
        DEX             ;-I
        STAA    SOUND   ;OUTPUT TO D/A
SING3   DECB
        BNE     SING3
        DEC     CSFRQS  ;CHECK CYCLES AT FREQUENCY
        BEQ     SING4   ;GO CHANGE FREQUENCY
        DEC     CSAMPS  ;CHECK CYCLES AT AMPLITUDE
        BNE     SING1   ;ALL OK, GO OUTPUT
        COMA            ;INVERT AMPLITUDE
        LDAB    CSAMP   ;GET CYCLES AT AMPLITUDE
        STAA    SOUND   ;OUTPUT TO D/A
        STAB    CSAMPS  ;SAVE AS COUNTER
        LDAB    FREQS   ;GET FREQUENCY COUNT
        ADDA    DSAMP   ;ADD AMPLITUDE DELTA
        BMI     SING6   ;RETURN FROM SUBROUTINE
        NOP             ;SYNC, 2 CYCLES
        BRA     SING5
SING4   INX             ;-I
        DEX             ;-I--- SYNC, 10 CYCLES
        NOP             ;-I
        COMA            ;INVERT AMPLITUDE
        LDAB    CSFRQ   ;GET CYCLES AT FREQUENCY
        STAA    SOUND   ;OUTPUT TO D/A
        STAB    CSFRQS  ;SAVE AS COUNTER
        LDAB    FREQS   ;GET FREQUENCY COUNT
        SUBB    DSFRQ   ;SUBTRACT FREQUENCY DELTA
        CMPB    ESFRQ   ;COMPARE TO END FREQUENCY
        CMPB    ESFRQ   ;SYNC, 3 CYCLES
        BEQ     SING6   ;RETURN FROM SUBROUTINE
SING5   STAB    FREQS   ;SAVE FREQUENCY COUNT
        SUBB    #$05    ;SYNC TO FREQUENCY COUNTDOWN
        BRA     SING2   ;JUMP INTO COUNTDOWN LOOP
SING6   PULB            ;RESTORE B
        RTS
;*
;*
SNDTBL  FCB     $DA,$FF,$DA,$80,$26,$01,$26,$80
        FCB     $07,$0A,$07,$00,$F9,$F6,$F9,$00
NOTTBL  FCB     $3A,$3E,$50,$46,$33,$2C,$27,$20
        FCB     $25,$1C,$1A,$17,$14,$11,$10,$33
WAVFRM  FCB     $08,$03,$02,$01,$02,$03,$04,$05
        FCB     $06,$0A,$1E,$32,$70,$00
VEC01   FDB     $FFFF,$FF90,$FFFF,$FFFF,$FFFF
        FDB     $FF90,$FFFF,$FFFF,$FFFF,$FFFF
        FDB     $0000,$0000,$0000,$0000
VEC02   FDB     $4801,$0000,$3F3F,$0000,$4801
        FDB     $0000,$0108,$0000,$8101,$0000
        FDB     $01FF,$0000,$0108,$0000
VEC03   FDB     $0110,$0000,$3F3F,$0000,$0110
        FDB     $0000,$0505,$0000,$0101,$0000
        FDB     $31FF,$0000,$0505,$0000
VEC04   FDB     $3000,$0000,$7F00,$0000,$3000
        FDB     $0000,$0100,$0000,$7F00,$0000
        FDB     $0200,$0000,$0100,$0000
VEC05   FDB     $0400,$0004,$7F00,$007F,$0400
        FDB     $0004,$FF00,$00A0,$0000,$0000
        FDB     $0000,$0000,$FF00,$00A0
VEC06   FDB     $0C68,$6800,$071F,$0F00,$0C80
        FDB     $8000,$FFFF,$FF00,$0000,$0000
        FDB     $0000,$0000,$FFFF,$FF00
VEC016  FDB     $0104,$0000,$3F7F,$0000,$0104
        FDB     $0000,$05FF,$0000,$0100,$0000
        FDB     $4800,$0000,$05FF,$0000
VEC017  FDB     $0280,$0030,$0A7F,$007F,$0280
        FDB     $0030,$C080,$0020,$0110,$0015
        FDB     $C010,$0000,$C080,$0000
VEC01X  FDB     $FF01,$02C3,$FF00
VEC02X  FDB     $0103,$FF80,$FF00
VEC03X  FDB     $2003,$FF50,$FF00
VEC04X  FDB     $5003,$0120,$FF00
VEC05X  FDB     $FE04,$0204,$FF00
VEC06X  FDB     $4803,$010C,$FF00
VEC07X  FDB     $4802,$010C,$FF00
VEC08X  FDB     $E001,$0210,$FF00
VEC09X  FDB     $50FF,$0000,$6080
VEC10X  FDB     $FF02,$0106,$FF00
;*
;*VARI LOADER
;*
VARILD  TAB
        ASLA            ;X2
        ASLA            ;X4
        ASLA            ;X8
        ABA             ;X9
        LDX     #LOCRAM
        STX     XPTR    ;SET XSFER
        LDX     #VVECT
        JSR     ADDX
        LDAB    #9      ;GET COUNT
VTRAN   JMP     TRANS
;*
;*VARIABLE DUTY CYCLE SQUARE WAVE ROUTINE
;*
VARI    LDAA    VAMP
        STAA    SOUND
VAR0    LDAA    LOPER
        STAA    LOCNT
        LDAA    HIPER
        STAA    HICNT
V0      LDX     SWPDT
V0LP    LDAA    LOCNT   ;LO CYCLE
        COM     SOUND
V1      DEX
        BEQ     VSWEEP
        DECA
        BNE     V1
        COM     SOUND
        LDAA    HICNT   ;HI CYCLE
V2      DEX
        BEQ     VSWEEP
        DECA
        BNE     V2
        BRA     V0LP    ;LOOP BACK
VSWEEP  LDAA    SOUND
        BMI     VS1
        COMA
VS1     ADDA    #0
        STAA    SOUND   ;OUTPUT
        LDAA    LOCNT
        ADDA    LODT
        STAA    LOCNT
        LDAA    HICNT
        ADDA    HIDT
        STAA    HICNT
        CMPA    HIEN
        BNE     V0
        LDAA    LOMOD
        BEQ     VARX
        ADDA    LOPER
        STAA    LOPER
        BNE     VAR0
VARX    RTS

;*
;*TURBO
;*
TURBO   LDX     #TRBO
        JMP     NOISLG
TRBO    FCB     $10,$FF,1,1,1
;*CROWD ROAR
CDR     LDX     #WS1    ;1ST WHISTLE PARAMS
        STX     PTRHI
        JSR     WISLD
        LDX     #$A500  ;SEED
        STX     HI
        LDX     #CR1    ;1ST CROWD ROAR NOISE PARAMS
        JSR     NOISLD
        JSR     NINIT
        LDX     #CR2
        JSR     NOISLD
        JMP     NINIT2
;*WHISTLE PARAMS
WS1     FCB     $90,$10,2,$14,$40
        FCB     $B4,$40,$FF,$14,$30
        FCB     $D0,$32,$2,$10,$60
        FCB     $EE,$20,2,8,$54
        FCB     $E9,$54,$FF,$20,$28
        FCB     $C0,$30,2,$14,$58
        FCB     $AC,$20,$2,$8,$58
        FCB     $A6,$58,$FF,$18,$22
        FCB     0
CR1     FCB     $30,$10,$FC,0,1
CR2     FCB     $30,$FC,1,0,1
GALMD   FCB     $10,$F0,$F0,1,$30
;*
;*MAIN GALLOP LOOP
;*
MGAW    LDX     #GALMD
        BSR     NOISLD
GLP     BSR     GP1
        BSR     GP1
        LDAA    #$28
        STAA    NFRQ2
        COM     NFFLG
        BSR     NOIN
        COM     NFFLG
        LDAA    #$1E
        BSR     DELAY
        BRA     GLP
GP1     LDAA    #$30
        STAA    NFRQ2
        BSR     NOIN
        LDAA    #2
        BSR     DELAY
        RTS
DELAY   TAB
        LDX     #$400
DLP1    TBA
DLP     DECA
        BNE     DLP
        DEX
        CPX     #0
        BNE     DLP1
        LDAA    #$F0
        STAA    NAMP
        RTS
;*
;*WHITE NOISE ROUTINE
;*NFRQ=INIT PERIOD, NAMP=INIT AMP, DECAY AMPLITUDE RATE
;*CYCNT=CYCLE COUNT, NFFLG= FREQ DECAY FLAG
;*NFFLG=0 NO FREQ CHANGE;=POS DECAY;=MINUS INC FREQ
;*NOISE LOAD PROG-ENTER WITH XREG POINTING TO DATA
;*
NOISLD  LDAA    ,X                                                      ;;Fixme was: LDAA  X
        STAA    CY2
        LDAA    1,X
        STAA    NAMP
        LDAA    2,X
        STAA    DECAY
        LDAA    3,X
        STAA    NFFLG
        LDAA    4,X
        STAA    NFRQ2
NEND    RTS
;*
;*LOAD NOISE AND GO
;*
NOISLG  BSR     NOISLD
;*
;*NOISE INIT
;*
NOIN    BSR     NSUB    ;CY2&NFRQ2 TO CYCNT&NFRQ
;*
;*NOISE LOOP
;*
NO1     BSR     RNT     ;FREQ CHECK
        LDAA    NFRQ    ;FREQ REINITED?
        CMPA    NFRQ2
        BNE     NO1     ;IF NOT KEEEP DELAYING
        ROLB            ;RESTORE        MAX AMPLITUDE TO NOISE
        STAB    SOUND   ;OUTPUT TO DAC
        BSR     NOISE1  ;PREPARE NEXT RAND NO
        BSR     NOISE2
        BSR     RNA     ;AMPLITUDE &CYCL3 COUNT CECK
        TST     NAMP    ;SEE IF DONE
        BEQ     NEND    ;RTS IF FINISHED
        TST     CYCNT   ;SEE IF NEXT FREQ
        BNE     NO1     ;IF NOT GO FREQ DELAY LOOP
        TST     NFFLG   ;SEE IF SWEEP MODE
        BEQ     NO1     ;IF NO SWEEP GO DELAY
        BMI     NO3     ;SWEEP DOWN
        INC     NFRQ2
        BRA     NO1
NO3     DEC     NFRQ2
        DEC     NFRQ
        BRA     NO1
NSUB    CLR     CYCNT
        LDAA    NFRQ2
        STAA    NFRQ    ;NOISE FREQ
        CLR     NNOIS
        RTS
;* 23 CYCLES FOR EACH SUBROUTINE PLUS CALLING OVERHEAD
;*
;*
NOISE1  LDAA    LO      ;GET RANDOM BIT
        LSRA
        LSRA
        LSRA
        EORA    LO
        STAA    ATP     ;INTERMED RAND NO
        INX
        ANDA    #$7     ;FOR 3 BIT RANDOM NO
;*
        RTS
;*
NOISE2  LDAA    ATP
        LSRA
        ROR     HI
        ROR     LO
        LDAA    #$0
        BCC     NOISE3
        LDAA    NAMP
NOISE3  STAA    NNOIS   ;NEXT NOISE VALUE
;*
        RTS
;*
RNT     LDAA    NFRQ2   ;NOISE FREQ
        DEC     NFRQ
        BEQ     NW0
        INX
        DEX             ;TEQ
        BRA     NNW1
NW0     STAA    NFRQ    ;REINIT FREQ
        LDAB    NNOIS   ;SAVE NEXT NOISE VAL IN B REG
        LSRB            ;HALF AMPLITUDE
        INC     CYCNT   ;NOISE CYCLE COUNT AT NAMP
;*
NNW1    RTS
;*
RNA     LDAA    CY2     ;NOISE AMPL CHANGE
        CMPA    CYCNT
        BEQ     NW2
        INX
        DEX
        BRA     NW3     ;TEQ
NW2     CLR     CYCNT
        LDAA    NAMP
        SUBA    DECAY
        STAA    NAMP
;*
NW3     RTS
;*
;* NOISE WITH WHISTLE MAIN LOOP
NINIT   CLR     WFRQ
        CLR     DFRQ
        LDAA    #$E     ;CYCLE OFFSET FOR WHISTLE
        STAA    WCNT
        CLR     CURVAL  ;CLR WHISTLE VALUES
NINIT2  BSR     NSUB    ;CLR CYCNT AND INIT FREQ
WIN     BSR     NOISE1
        JSR     TRIDR
        BSR     NOISE2
        JSR     TRIDR
        BSR     RNT
        BSR     TRIDR
        BSR     RNA
        BSR     TRIDR
        BSR     TRICNT
        BSR     TRIDR
        BSR     TRIFRQ
        BSR     TRIDR
        BSR     NNW
        BRA     WIN
;*
TRICNT  LDAA    WCNT2   ;#CYCLES AT WHISTLE FREQ
        DEC     WCNT
        BEQ     NW4
        FCB     $B6     ;LDAA EXTENDED
        FDB     NAMP
        BNE     NW5     ;TEQ
        BRA     NSEND   ;END NOISE
NW4     STAA    WCNT
        LDAA    WFRQ
        ADDA    DFRQ
        STAA    WFRQ
;*
NW5     RTS
;*
TRIFRQ  LDAA    WFRQ    ;WHISTLE END TEST
        CMPA    MINWIS
        BEQ     NW6
        INX             ;TEQ
        LDAA    NAMP    ;END TEST
        BNE     NW7     ;TEQ
        BRA     PEND    ;END NOISE
NW6     CLR     WFRQ    ;TURN OFF WHISTLE
        CLR     DFRQ
        CLR     CURVAL
        LDX     PTRHI   ;SET UP FOR NEXT WHISTLE
WISLD   LDAA    ,X                                                      ;;Fixme was: LDAA  X
        STAA    WHIS
        BEQ     NW7
        LDAA    1,X
        STAA    WFRQ2
        LDAA    2,X
        STAA    DFRQ2
        LDAA    3,X
        STAA    WCNT2
        LDAA    4,X
        STAA    MINWIS
        LDAA    #5
        JSR     ADDX
        STX     PTRHI
;*
NW7     RTS
PEND    PULA
        PULA            ;STACK ADJ
        RTS
;*
NNW     LDAA    WHIS    ;WHISTLE INIT
        BEQ     NW8     ;ALREADY INITED
        CMPA    NAMP
        BNE     NW9
        BRA     WINIT   ;GO INIT WHISTLE
NW8     INX
        DEX             ;TEQ
NW9     RTS
WINIT   CLR     WHIS
        LDAA    WFRQ2
        STAA    WFRQ
        LDAA    DFRQ2
        STAA    DFRQ
        RTS
;******************
TRIDR   LDAA    CURVAL
        ADDA    WFRQ
        STAA    CURVAL
        BPL     GO
        COMA
GO      ABA
        STAA    SOUND
NSEND   RTS
;*

;*
;*LIGHTNING
;*
LITE    LDAA    #1
        STAA    DFREQ
        LDAB    #3
        BRA     LITEN
;*
;*LIGHTNING+APPEAR NOISE ROUTINE
;*
LITEN   STAA    LFREQ
        LDAA    #$FF    ;HIGHEST AMP
        STAA    SOUND
        STAB    CYCNT
LITE0   LDAB    CYCNT
LITE1   LDAA    LO      ;GET RANDOM
        LSRA
        LSRA
        LSRA
        EORA    LO
        LSRA
        ROR     HI
        ROR     LO
        BCC     LITE2
        COM     SOUND
LITE2   LDAA    LFREQ   ;COUNT FREQ
LITE3   DECA
        BNE     LITE3
        DECB            ;COUNT CYCLES
        BNE     LITE1
        LDAA    LFREQ
        ADDA    DFREQ
        STAA    LFREQ
        BNE     LITE0
        RTS
;*
;*
;*WHITE NOISE ROUTINE
;*X=INIT PERIOD, ACCB=INIT AMP, ACCA DECAY RATE
;*CYCNT=CYCLE COUNT, NFFLG= FREQ DECAY FLAG
;*
MOISE   STAA    DECAY
MOISE0  STX     NFRQ1
MOIS00  STAB    NAMP
        LDAB    CYCNT
MOISE1  LDAA    LO      ;GET RANDOM BIT
        LSRA
        LSRA
        LSRA
        EORA    LO
        LSRA
        ROR     HI
        ROR     LO
        LDAA    #$0
        BCC     MOISE2
        LDAA    NAMP
MOISE2  STAA    SOUND
        LDX     NFRQ1   ;INCREASING DELAY
MOISE3  DEX
        BNE     MOISE3
        DECB            ;FINISH CYCLE COUNT?
        BNE     MOISE1  ;NO
        LDAB    NAMP    ;DECAY AMP
        SUBB    DECAY
        BEQ     MSEND
        LDX     NFRQ1   ;INC FREQ
        INX
        LDAA    NFFLG   ;DECAY FREQ?
        BEQ     MOIS00  ;NO
        BRA     MOISE0
MSEND   RTS
;*
;*
;*PARAMETER TRANSFER
;*
TRANS   PSHA
TRANS1  LDAA    0,X
        STX     XPLAY
        LDX     XPTR
        STAA    0,X
        INX
        STX     XPTR
        LDX     XPLAY
        INX
        DECB
        BNE     TRANS1
        PULA
        RTS
;*
;*
;*GWAVE LOADER
;*
GWLD    TAB             ;MULKT BY 7
        ASLB
        ABA
        ABA
        ABA
        LDX     #SVTAB  ;SOUND VECTOR TABLE
        JSR     ADDX
        LDAA    ,X
        TAB
        ANDA    #$F
        STAA    GCCNT   ;GET CYCLE COUNT
        LSRB
        LSRB
        LSRB
        LSRB
        STAB    GECHO   ;GET #ECHOS
        LDAA    1,X
        TAB
        LSRB
        LSRB
        LSRB
        LSRB
        STAB    GECDEC
        ANDA    #$F     ;WAVE #
        STAA    TEMPA   ;SAVE
        STX     TEMPX   ;SAVE INDEX
        LDX     #GWVTAB ;CALC WAVEFORM ADDR
GWLD2   DEC     TEMPA   ;WAVE FORM #
        BMI     GWLD3   ;FINIS
        LDAA    ,X
        INCA
        JSR     ADDX
        BRA     GWLD2
GWLD3   STX     GWFRM
        JSR     WVTRAN  ;XSFER WAVE TO RAM
        LDX     TEMPX   ;RESTORE INDEX
        LDAA    2,X     ;GET PREDECAY
        STAA    PRDECA
        JSR     WVDECA  ;DECAY IT
        LDX     TEMPX
        LDAA    3,X     ;GET FREQ INC
        STAA    GDFINC
        LDAA    4,X     ;GET DELTA FREQ COUNT
        STAA    GDCNT
        LDAA    5,X     ;GET PATTERN COUNT
        TAB             ;SAVE
        LDAA    6,X     ;PATTERN OFFSET
        LDX     #GFRTAB
        JSR     ADDX
        TBA             ;GET PATTERN LENGTH
        STX     GWFRQ   ;FREQ TABLE ADDR
        CLR     FOFSET
        JSR     ADDX
        STX     FRQEND
        RTS
;*
;*GWAVE ROUTINE
;*ACCA= FREQ PATTERN LENGTH, X= FREQ PAT ADDR
;*
GWAVE   LDAA    GECHO
        STAA    GECNT
GWT4    LDX     GWFRQ
        STX     XPLAY
GPLAY   LDX     XPLAY   ;GET NEW PERIOD
        LDAA    ,X
        ADDA    FOFSET
        STAA    GPER
        CPX     FRQEND
        BEQ     GEND    ;FINISH ON ZERO
        LDAB    GCCNT   ;CYCLE COUNT
        INX
        STX     XPLAY
GOUT    LDX     #GWTAB  ;SETUP WAVEFORM POINTER
GOUTLP  LDAA    GPER
GPRLP   DECA            ;WAIT FOR PERIOD
        BNE     GPRLP
        LDAA    ,X      ;OUTPUT SOUND
        STAA    SOUND
GPR1    INX
        CPX     WVEND   ;END OF WAVE?
        BNE     GOUTLP
        DECB
        BEQ     GPLAY
        INX
        DEX
        INX
        DEX
        INX
        DEX
        INX
        DEX
        NOP
        NOP
        BRA     GOUT    ;SYNC 36
GEND    LDAA    GECDEC
        BSR     WVDECA
GEND40  DEC     GECNT   ;ECHO ON?
        BNE     GWT4    ;YES
        BNE     GEND1
GEND50  LDAA    GDFINC  ;CONTINUE FOR FREQ MOD SOUNDS
        BEQ     GEND1   ;NO
        DEC     GDCNT   ;DELTA FREQ OVER?
        BEQ     GEND1   ;YES...
        ADDA    FOFSET  ;UPDATE FREQ OFFSET
GEND60  STAA    FOFSET
GEND61  LDX     GWFRQ   ;GET INDEX
        CLRB            ;START FOUND FLAG INIT CLEAR
GW0     LDAA    FOFSET  ;INC OR DEC?
        TST     GDFINC
        BMI     GW1     ;DEC
        ADDA    ,X      ;INC
        BCS     GW2     ;CARRY=OVERFLOW
        BRA     GW2A
GW1     ADDA    ,X      ;DEC
        BEQ     GW2     ;OVERFLOW ON EQ
        BCS     GW2A    ;OVERFLOW IF CARRY CLEAR
GW2     TSTB            ;FOUND START YET?
        BEQ     GW2B    ;NO
        BRA     GW3     ;YES, THIS IS THE END
GW2A    TSTB
        BNE     GW2B    ;ALREADY FOUND START
        STX     GWFRQ   ;FOUND START
        INCB
GW2B    INX
        CPX     FRQEND
        BNE     GW0     ;NOT OVER YET
        TSTB            ;FOUND START?
        BNE     GW3     ;YES
        RTS             ;ALL OVER
GW3     STX     FRQEND
        LDAA    GECDEC  ;RE:XSFER WAVE?
        BEQ     GEND0   ;NO
        BSR     WVTRAN  ;XSFER WAVE
        LDAA    PRDECA
        BSR     WVDECA
GEND0   JMP     GWAVE
GEND1   RTS             ;TERMINATE
;*
;*WAVE TRANSFER ROUTINE
;*
WVTRAN  LDX     #GWTAB
        STX     XPTR
        LDX     GWFRM
        LDAB    ,X      ;GET WAVE LENGTH
        INX
        JSR     TRANS
        LDX     XPTR
        STX     WVEND   ;GET END ADDR
        RTS
;*
;*WAVE DECAY ROUTINE/ DECAY AMOUNT IN ACCA(1/16 PER DECAY)
;*
WVDECA  TSTA
        BEQ     WVDCX   ;NO DECAY
        LDX     GWFRM   ;ROM WAVE INDEX
        STX     XPLAY
        LDX     #GWTAB
        STAA    TEMPB   ;DECAY FACTOR
WVDLP   STX     XPTR
        LDX     XPLAY
        LDAB    TEMPB
        STAB    TEMPA   ;DECAY FACTOR TEMP
        LDAB    1,X     ;OFFSET FOR WAVE LENGTH
        LSRB
        LSRB
        LSRB
        LSRB            ;CALC 1/16TH
        INX
        STX     XPLAY
        LDX     XPTR
        LDAA    ,X
WVDLP1  SBA             ;DECAY
        DEC     TEMPA
        BNE     WVDLP1
        STAA    ,X
        INX
        CPX     WVEND   ;END OF WAVE?
        BNE     WVDLP   ;NO
WVDCX   RTS
;*
;* INTERRUPT PROCESSING
;*
IRQ     LDS     #ENDRAM ;RE-INITIALIZE STACK
        LDAA    SOUND+2 ;GET INPUT TRIGGER
        LDX     #DECAYZ ;RANDY'S BRAIN DAMAGE
        STX     XDECAY
        LDX     #FREQ1
        STX     XPTR
        LDAB    #$AF
        STAB    AMP0
        CLI             ;NOW ALLOW IRQS
        COMA            ;INVERT INPUT
        ANDA    #$3F    ;MASK GARB
        TSTA
        BEQ     IRQ3
        DECA
        CMPA    #$12+2
        BHI     .1S
        JSR     GWLD
        JSR     GWAVE
        BRA     IRQ3
;*
.1S     CMPA    #$1D+2                                                  ;;Fixme was: 1$
        BHI     .3S
        SUBA    #$13+2
        LDX     #JMPTBL
        ASLA
        JSR     ADDX
        LDX     ,X
        JSR     ,X
        BRA     IRQ3

.3S     CMPA    #$20+2                                                  ;;Fixme was: 3$
        BHI     .4S
        SUBA    #$1E+2          ;NOISE REQUEST
        JSR     JKNOIS
        BRA     IRQ3

.4S     CMPA    #$24+2                                                  ;;Fixme was: 4$
        BHI     IRQ3
        SUBA    #$21+2
        JSR     WALSH

IRQ3    BRA     *
;*
;* ADD A TO INDEX REGISTER
;*
ADDX    STX     XPLAY
        ADDA    XPLAY+1
        STAA    XPLAY+1
        BCC     ADDX1
        INC     XPLAY
ADDX1   LDX     XPLAY
        RTS
;*
;* DIAGNOSTIC PROCESSING HERE
;*
NMI     SEI
        LDS     #ENDRAM ;RESET THE STACK
        LDX     #$FFFF
        CLRB
NMI1    ADCB    0,X
        DEX
        CPX     #$F000
        BNE     NMI1
        CMPB    0,X
        BEQ     NMI2
        WAI
NMI2    JSR     KNOCK
        BRA     NMI     ;KEEP LOOPING
;*
;*SPECIAL ROUTINE JUMP TABLE
;*
JMPTBL  FDB     LITE                            ;$14
        FDB     SND4,SND5,THNDR,ATARI           ; 15,16,17,18
        FDB     PERKSS,SQRT                     ; 19,1A
        FDB     KNOCK,WHIST                     ; 1B,1C
        FDB     SETUP,WINGDN                    ; 1D,1E
;*
;*VARI VECTORS
;*
VVECT   EQU     *
;*      NONE AS OF YET
;*
;*
;*WAVE TABLE
;*1ST BYTE= WAVELENGTH
;*
GWVTAB  EQU     *
GS2     FCB     8,127,217,255,217,127,36,0,36
GSSQ2   FCB     8,0,64,128,0,255,0,128,64
GS1     FCB     16,127,176,217,245,255,245,217,176
        FCB     127,78,36,9,0,9,36,78
GS12    FCB     16,127,197,236,231,191,141,109,106
        FCB     127,148,146,113,64,23,18,57
GSQ22   FCB     16,$FF,$FF,$FF,$FF,0,0,0,0
        FCB     $FF,$FF,$FF,$FF,0,0,0,0
GS72    FCB     72,138,149,160,171,181,191,200,209
        FCB     218,225,232,238,243,247,251,253,254,255
        FCB     254,253,251,247,243,238,232,225,218
        FCB     209,200,191,181,171,160,149,138,127
        FCB     117,106,95,84,74,64,55,46,37,30,23,17,12
        FCB     8,4,2,1,0
        FCB     1,2,4,8,12,17,23,30,37,46,55,64,74,84
        FCB     95,106,117,127
GS1.7   FCB     16,89,123,152,172,179,172,152,123
        FCB     89,55,25,6,0,6,25,55
;*****************************************************
GSQ2    FCB     8,$FF,$FF,$FF,$FF,$00,$00,$00,$00
GS1234  FCB     16,118,255,184,208,157,230,106,130
        FCB     118,234,129,134,78,156,50,99
MW1     FCB     16,0,$F4,0,$E8,0,$DC,0,$E2
        FCB     0,$DC,0,$E8,0,$F4,0,0
SIN3.SR FCB     36                                      ;WAVE C
        FCB     $7F,$B0,$D6,$E8,$E3,$C9,$A3,$7B,$5E,$54,$5E,$7B
        FCB     $A3,$C9,$E3,$E8,$D6,$B0,$7F,$4C,$26,$14,$19,$33
        FCB     $5A,$81,$9E,$A8,$9E,$81,$5A,$33,$19,$14,$26,$4C

;*
;*GWAVE SOUND VECTOR TABLE
;*VECTOR FORMAT
;*BYTE 0: GECHO,GCCNT
;*BYTE 1: GECDEC,WAVE#
;*BYTE 2: PREDECAY FACTOR
;*BYTE 3: GDFINC
;*BYTE 4: VARIABLE FREQ COUNT
;*BYTE 5: FREQ PATTERN LENGTH
;*BYTE 6: FREQ PATTERN OFFSET
;*
SVTAB   EQU     *
DP1V    FCB     $11,$05,$11,1,15,1,SWPAT-GFRTAB         ;1
PROTV   FCB     $21,$35,$11,$FF,0,13,SPNSND-GFRTAB      ;2
SPNRV   FCB     $15,$00,0,$FD,0,1,SPNR-GFRTAB           ;3
CLDWNV  FCB     $31,$11,0,1,0,3,COOLDN-GFRTAB           ;4
ED10    FCB     $F6,$53,3,0,2,6,ED10FP-GFRTAB           ;5
HUNV    FCB     $14,$17,$00,$00,$00,14,HBTSND-GFRTAB    ;6
STRT    FCB     $13,$10,$00,$FF,$00,09,YUKSND-GFRTAB    ;7
BMPV    FCB     $F2,$19,$00,$00,$00,22,BWSSND-GFRTAB    ;8
SF10    FCB     $41,$02,$D0,$00,$00,39,STDSND-GFRTAB    ;9
SV0     FCB     $52,$36,$00,$00,$00,$10,HBDSND-GFRTAB   ;A
SV1     FCB     $73,$29,$03,$00,$00,$10,GVA1-GFRTAB     ;B
SV2     FCB     $11,$40,$03,$ED,$09,$09,TRBPAT-GFRTAB   ;C
SVA     FCB     $16,$82,$03,$0E,$01,$0E,GV27-GFRTAB     ;D
SVB     FCB     $11,$29,$00,$F0,$05,$08,GVB1-GFRTAB     ;E
SVF     FCB     $63,$26,$06,$00,$00,$10,GVA1-GFRTAB     ;F
        FCB     $21,$25,$00,$03,$0A,03,COOLDN-GFRTAB    ;10
        FCB     $43,$0A,$00,$04,$02,13,SPNSND-GFRTAB    ;11
ED17    FCB     $1F,$12,$00,$FF,$10,04,SPNR-GFRTAB      ;12
CYNEW   FCB     $11,$10,$00,$0A,$00,01,YUKSND-GFRTAB    ;13
WIRDV   FCB     $21,$30,$00,$FF,$00,27,HBTSND-GFRTAB    ;14
WIRDV2  FCB     $22,$21,$00,$FE,$00,27,HBTSND-GFRTAB    ;15

;*GWAVE FREQ PATTERN TABLE
;*
GFRTAB  EQU     *
;*HUNDRED POINT SOUND
HBTSND  FCB     1,1,2,2,4,4,8,8,$10,$10,$30,$60,$C0,$E0
;*SPINNER SOUND
SPNSND  FCB     1,1,2,2,3,4,5,6,7,8,9,$A,$C
;*TURBINE START UP
TRBPAT  FCB     $80,$7C,$78,$74,$70,$74,$78,$7C,$80
;*HEARTBEAT DISTORTO
HBDSND  FCB     1,1,2,2,4,4,8,8,$10,$20,$28
        FCB     $30,$38,$40,$48,$50,$60,$70,$80,$A0,$B0,$C0
;*SWEEP PATTERN
SWPAT   EQU     *
;*BIGBEN SOUNDS
BBSND   FCB     8,64,8,64,8,64,8,64,8,64
        FCB     8,64,8,64,8,64,8,64,8,64
;*SPINNER SOUND "DRIP"
SPNR    FCB     $40
;*COOL DOWNER
COOLDN  FCB     $10,8,1
;*START DISTORTO SOUND
STDSND  FCB     1,1,1,1,2,2,3,3,4,4,5,6,8,$A,$C,$10
        FCB     $14,$18,$20,$30,$40,$50,$40,$30
        FCB     $20,$10,$C,$A,8,7,6,5,4,3,2,2,1,1,1
;*ED'S SOUND 10
ED10FP  FCB     7,8,9,$A,$C,8
GV27    FCB     $0C
YUKSND  FCB     $8,$80,$10,$78,$18,$70,$20,$60,$28,$58,$30
        FCB     $50,$40,$48,$00
BWSSND  FCB     $01,$40,$02,$42,$3,$43,$4,$44,$5,$45,$6,$46,$7,$47
        FCB     $8,$48,$9,$49,$A,$4A,$B,$4B,$00
GVA1    FCB     $14,$18,$20,$30,$40,$50,$40,$30
        FCB     $20,$10,$0C,$0A,$08,$07,$06,$05
GVB1    FCB     $CC,$BB,$60,$10,$EE,$AA,$50,$00

;*      AND THE EVER POPULAR COPYRIGHT MESSAGE
        FCC     "(C)1982 WILLIAMS ELECTRONICS"

;*      NAM     WALSH FUNCTION SOUND MACHINE V2

;* T. MURPHY  11/10/81

MINPER  EQU     25      ;6*25 = 150 MICROSECS IS MIN SAMPLE PERIOD
SOUND   SET     $400

WORG
        ORG     0

        RMB     8       ;GLOBALS

FCMDPT  RMB     2       ;PTR TO CURRENT FILTER COMMAND (USER INITIALIZED)
PCMDPT  RMB     2       ;SAME FOR PITCH PROGRAM
SMPPER  RMB     2       ;HI BYTE * 6 IS SAMPLE DELAY
HRMTBL  RMB     2       ;PTR TO HARMONIC FN VALUE TABLE

WAVSRT  RMB     16      ;WAVEFORM

PERVEL  RMB     2       ;ADDED TO SMPPER EACH WAVE (PITCH CONTROL)
GLBPRO  RMB     1       ;GLOBAL PERIOD OFFSET
TMPPER  RMB     1       ;= SMPPER + GLBPRO
PERACM  RMB     1       ;USED TO CALCULATE SMALL PITCH ADJUSTS

PWVCNT  EQU     *       ;#OF WAVES TO PLAY BEFORE NEXT PITCH CMD (P PROGRAM)
PSTK    RMB     2       ;TOP OF PITCH RETURN/COUNT STACK
PWAVPT  RMB     2       ;PTR TO CURRENT SAMPLE BEING PLAYED
PCMD    RMB     1       ;CURRENT PITCH CMD
PTEMP   RMB     2

FVECT   RMB     3       ;JUMP TO CURRENT FILTER STATE (FILTER PGM CONTROL)
FCNT    EQU     *       ;MISC CTR, WAVE DELAY IF <0
FSTK    RMB     2       ;TOP OF FILTER RETURN/COUNT STACK
HAPTR   RMB     2       ;PTR TO AMPLITUDE OF CURRENT HARMONIC

FWVPTR  RMB     2       ;PTS TO WAVE PT BEING ALTERED (FILTER GUTS)
HAMP    RMB     1       ;CURRENT HARMONIC AMPLITUDE
FMSK    RMB     1       ;BIT MASK SELECTS HARMONIC FN VALUE
;*                      ;NEXT 3 MUST BE IN ORDER
FNHI    RMB     1       ;HOLDS CURRENT HARMONIC FN VALUES AS BITS
FNLO    RMB     1       ;ALSO USED AS TEMPORARIES
FCMD    RMB     1       ;CURRENT INSTRUCTION BEING EXECUTED

FBTM    EQU     *-3     ;FILTER STACK GROWS UP
        ORG     95
PBTM    EQU     *       ;PITCH STACK GROWS DOWN

        RMB     1       ;ADD2HA FOR CONST WAVE
ADD2HA  RMB     8       ;ADD ADD2HA(8-I)*HARM(I) TO WAVE
CNAMP   RMB     1       ;CURRENT AMP OF CONST FUNCTION
CURHA   RMB     8       ;CURHA(8-I) = <WAVE!HARM(I)>

ENDRAM  SET     127

        ORG     WORG

;       SUBTTL  WAVE PLAYER AND PITCH MODIFICATION

;* PLAY A SAMPLE, REMAINING DELAY IN B.  TOTAL DELAY = MIN (60,B*6) MICS.

NTHRVC  SUBB    #13             ;LOOP DELAY IS 78 CYCLES
        PSHB
        JSR     FVECT   ;(62)
        PULB

NXTSMP  CMPB    #20             ;CALL HERE
        BHI     NTHRVC          ;MODIFY WAVE IF WE HAVE ENOUGH TIME

        NOP
        LDAA    PERACM
        ADDA    PERVEL+1
        STAA    PERACM
        ADCB    #-10            ;MINIMUM DELAY + FRACTION

        DECB                    ;WASTE SMALL TIME
        BPL     *-1

        LDAA    PWAVPT+1        ;PT TO NEXT BYTE OF 16 BYTE WAVE
        INCA
        ANDA    #15
        ORAA    #WAVSRT         ;! WAVSRT MUST BE DIVISIBLE BY 16 !
        STAA    PWAVPT+1

        LDX     PWAVPT
        LDAB    ,X
        STAB    SOUND

        ANDA    #15             ;0 IFF RESTARTING WAVE
        RTS

;* PLAYS WAVE AND ALTERS PITCH ACCORDING TO PITCH CMDS.
;* SMPPER IS INITIAL PITCH,  PCMDPT IS START PITCH PROGRAM,
;* FCMDPT IS START WAVE MODIFIER (FILTER) PROGRAM.

WSM     CLRA
        LDX     #WAVSRT
        LDAB    #CURHA+8-WAVSRT
.1S     STAA    ,X
        INX
        DECB
        BNE     .1S
        LDAB    #PBTM
        STAB    PSTK+1
        LDAB    #FBTM
        STAB    FSTK+1
        LDAB    #126
        STAB    FVECT
        LDX     #NXTFCM
        STX     FVECT+1
        LDAB    SMPPER
        STAB    TMPPER

PPLPE1  SUBB    #3
PPLPE2  JSR     NXTSMP
        INX

PPLP    LDAB    TMPPER
        SUBB    #2              ;LOOP DELAY IS 18-6 = 12
        JSR     NTHRVC
        BNE     PPLP            ;ESCAPE ON WAVE BOUNDARY

        LDAB    PERVEL  ;7 (ALL TIMES ARE SINCE RTS FROM LAST NXTSMP)
        LDAA    PERVEL+1
        ADDA    SMPPER+1        ;UPDATE SAMPLE RATE ONCE EACH WAVE PLAY
        ADCB    SMPPER
        STAA    SMPPER+1
        STAB    SMPPER  ;24

        ADDB    GLBPRO
        LDAA    #MINPER         ;AVOID SYNC ERRORS BY LIMITING PITCH.
        CBA                     ;MAX. PITCH ALLOWS AT LEAST 1 FILTER
        BCC     *+3             ;CALL PER SAMPLE.
        FCB     129
        TAB
        STAB    TMPPER  ;41
        NOP
        SUBB    #9
        JSR     NXTSMP  ;54

        LDAA    FCNT            ;COUNT WAVE PLAYS FOR FILTER
        TAB                     ;(ONLY IF <0)
        ASLA
        ADCB    #0
        STAB    FCNT    ;13

        LDAB    TMPPER
        SUBB    #5
        LDAA    PWVCNT
        BPL     PAWAKE

        INC     PWVCNT          ;UPDATE DELAY COUNT IF <0
        NOP
        BRA     PPLPE1  ;37

PAWAKE  DECB                    ;ELSE WE ARE ALIVE
        JSR     NXTSMP  ;36

        LDX     PCMDPT
        LDAA    ,X
        BPL     PPLP1           ;MOST CMDS ARE >0

        CMPA    #128
        BEQ     STOPR   ;19     EXCEPT FOR END = 128

        INCA
        STAA    PWVCNT          ;OR A NEGATIVE NUMBER -N
        INX                     ;WHICH WAITS N WAVE PLAYS
        FCB     -1,0,PCMDPT     ;BEFORE FETCHING THE NEXT COMMAND

PPLP35  LDAB    TMPPER
        SUBB    #6
        JMP     PPLPE1  ;43

PPLP1   INX
        LDAB    ,X              ;GET NEXT CMD STRING BYTE ON STACK
        PSHB
        INX
        STX     PCMDPT  ;35

        STAA    PCMD
        ANDA    #$70
        LSRA
        LSRA
        LSRA
        CLRB

        ADDA    #PCMDJT&255                                                     ;;Fixme was: ADDA  #PCMDJT!.255
        ADCB    #PCMDJT/256
        STAA    PTEMP+1
        STAB    PTEMP   ;61

        LDAB    TMPPER
        LDAB    TMPPER
        SUBB    #13
        JSR     NXTSMP  ;78

        CLRB
        LDX     PTEMP           ;EXECUTE CMD
        LDX     ,X
        JMP     ,X      ;16

;* PITCH COMMAND ROUTINES.  UNLESS OTHERWISE STATED, N IS A SIGNED 8 BIT
;* NUMBER = BYTE FOLLOWING OPCODE.

;* LDP N  IS  SMPPER := N,  ADP N  IS SMPPER := SMPPER + N

LDPR    LDAA    PCMD            ;BIT 0 = 1 FOR LOAD
        ASRA
        SBCB    #0
        ANDB    SMPPER
        PULA
        SBA
        ADDA    SMPPER
        STAA    SMPPER  ;39
        INX
LDPRE   LDAB    TMPPER
        SUBB    #10
        JMP     PPLPE2  ;51

;* LDO N IS  GLBPRO := N,  ADO N IS  GLBPRO := GLBPRO + N

LDOR    LDAA    PCMD            ;BIT 0 = 1 FOR LOAD
        ASRA
        SBCB    #0
        ANDB    GLBPRO
        PULA
        SBA
        ADDA    GLBPRO
        STAA    GLBPRO
        BRA     LDPRE

;* ESC EXECUTES MACHINE LANGUAGE IMMEDIATELY FOLLOWING

ESCR    PULA
        LDX     PCMDPT
        DEX
        JMP     ,X      ;32

;* STOP EITHER REPEATS A CALL, RETURNS FROM A CALL, OR ENDS SOUND.

STOPR   LDAA    PSTK+1
        CMPA    #PBTM
        BMI     *+3     ;28
        RTS

        LDAB    TMPPER
        SUBB    #7
        JSR     NXTSMP  ;42

        LDX     PSTK
        DEC     2,X
        BMI     PRET    ;15     ;DONE

        LDX     ,X              ;ELSE REPEAT
        LDAA    ,X
        PSHA
        INX
        STX     PCMDPT  ;39

        FCB     -10,0,TMPPER
        SUBB    #9
        JSR     NXTSMP  ;54

        BRA     PTORE1

PRET    LDX     ,X
        INX
        STX     PCMDPT
        LDAA    PSTK+1
        ADDA    #3
        STAA    PSTK+1

        LDAB    TMPPER
        SUBB    #7
        NOP
        JMP     PPLPE1  ;49

;* LDV N IS  PERVEL := N,  ADV N IS  PERVEL := PERVEL + N
;* IN THIS CASE  N IS A 12 BIT NUMBER, THE UPPER 4 BITS OF WHICH
;* ARE LO 4 BITS OF THE OPCODE BYTE.

ADVR    INX
        BRA     *+6

LDVR    STAB    PERVEL          ;CLEAR PERVEL FOR LOAD
        STAB    PERVEL+1 ;24

        LDAB    PCMD
        ANDB    #15             ;SIGN EXTEND
        ADDB    #-8
        EORB    #-8     ;34

        PULA
        ADDA    PERVEL+1
        ADCB    PERVEL
        STAA    PERVEL+1
        STAB    PERVEL  ;52

        FCB     -10,0,TMPPER
        SUBB    #9
        JMP     PPLPE1  ;61

;* DO R,N  CALLS RTN AT *+N  R TIMES.

PDOR    LDAA    PSTK+1
        SUBA    #3
        STAA    PSTK+1  ;25

        LDX     PSTK
        LDAA    PCMDPT+1        ;STACK ENTRY PTS TO DISPLACEMENT
        LDAB    PCMDPT
        ADDA    #-1
        ADCB    #-1
        STAB    ,X
        STAA    1,X     ;53
        LDAB    PCMD            ;LO OPCODE BITS ARE REPEAT CNT
        ANDB    #15
        STAB    2,X     ;64

        LDAB    TMPPER
        SUBB    #12
        JSR     NXTSMP  ;78

        INX                     ;SYNC W/NEXT RTN
PTORE1  INX
        INX
        CLRB
        NOP

;* TO N  SETS LOC TO BE *+N.

PTOR    PULA            ;20
        ASRA
        ROLA
        SBCB    #0
        ADDA    PCMDPT+1
        ADCB    PCMDPT
        STAA    PCMDPT+1
        FCB     -9,0,PCMDPT ;41

        LDAB    TMPPER
        SUBB    #7
        JMP     PPLPE1  ;49


PCMDJT  FDB     LDPR,LDOR,LDVR,ADVR,LDPR,ESCR,PDOR,PTOR
;*                 0    1    2    3    4    5    6    7
FCMDJT  FDB     ADHR,LDTR,ETBR,HIDR,FINR,ZTBR,FDOR,FTOR


;       SUBTTL  WAVE MODIFICATION

;* FENDR OVERLAY GETS RETURN ADDR FROM STACK.

FRTURN  LDX     FSTK
        LDX     3,X
        INX                     ;NEXT INSTR IS AFTER DISPLACEMENT BYTE
        STX     FCMDPT  ;19
        JSR     FCMDNX  ;41
        INX
        RTS

;* REPEAT CALL.

FDOAGN  LDX     ,X              ;PT TO DISPLACEMENT BYTE
        STX     FCMDPT  ;35
        LDX     #FTOR           ;JUMP RTN IS NEXT
        STX     FVECT+1
        NOP
        RTS             ;50

;* FIN DOES  REPEAT CALL, RETURN TO CALLER, STOP RTN DEPENDING ON STACK.

FINR    LDAA    FSTK+1
        CMPA    #FBTM
        BLS     ALLDON  ;9      ;LAST END STATEMENT

        LDX     FSTK
        DEC     2,X             ;NO, CHECK TOP OF STACK
        BPL     FDOAGN  ;24     STILL REPEATING

        SUBA    #3
        STAA    FSTK+1
        LDX     #FRTURN         ;ELSE RETURN
        STX     FVECT+1 ;38
        TST     ,X
        RTS

ALLDON  LDX     #WAST50
        STX     FVECT+1
        NOP             ;19
        BRA     WAST27

WAST50  INX
        INX
        NOP
WAST40  BSR     WAST5
WAST27  BSR     WAST5
WAST14  TST     ,X
WAST7   NOP
WAST5   RTS

;* CALL WITH REPEAT. REPEAT CNT 0(=1) TO 15 (=16) IS LO 4 BITS OF OPCODE.
;* NEXT BYTE IS DISPLACEMENT AS IN GO INSTRUCTION.  THE CTR AND RETURN
;* ADDRESS ARE SAVED ON A STACK.

FDOR    LDX     FSTK
        LDAA    FCMDPT          ;SAVE ADDR OF DISPLACEMENT BYTE
        STAA    3,X
        LDAA    FCMDPT+1
        STAA    4,X
        LDAA    FCMD
        ANDA    #15
        STAA    5,X     ;33

        INX
        LDX     #.1S
        STX     FVECT+1
        RTS             ;50

;* OVERLAY FOR CALL RTN.

.1S     LDAA    FSTK+1
        ADDA    #3
        STAA    FSTK+1
        LDX     #FTOR
        STX     FVECT+1 ;17     GET READY TO JUMP
        NOP
        BRA     WAST27

;* GET NEXT FILTER COMMAND

NXTFCM  TST     FCNT
        BNE     WAST40          ;IN A DELAY

        LDX     FCMDPT
        LDAA    ,X
        INX
        STX     FCMDPT
        STAA    FCMD
        BPL     .1S     ;36

        STAA    FCNT            ;NEGATIVE CMD IS NEG OF WAVE DELAY
        LDAA    ,X
        RTS             ;50

.1S     LDX     #EXFCMD         ;POSITIVE IS FROM TABLE
        FCB     -1,0,FVECT+1
        RTS             ;50


EXFCMD  CLRB
        LDAA    FCMD
        ANDA    #$70            ;B4 - B7 IS INSTRUCTION
        LSRA
        LSRA
        LSRA
        ADDA    #FCMDJT&255                                                     ;;Fixme was: ADDA  #FCMDJT!.255
        ADCB    #FCMDJT/256
        STAB    FNHI
        STAA    FNLO    ;25

        LDX     FNHI
        LDX     ,X
        STX     FVECT+1
        STX     FVECT+1
        RTS             ;50

;* SET UP FOR REPEATED TABLE ADD.

ETBR    LDAA    FCMD
        ANDA    #15
        INCA
        INCA
        STAA    FCNT
        BRA     FHA1    ;17

;* LOOK FOR A NONZERO HARMONIC CHANGE AND PERFORM IT.  IF ENTIRE TABLE
;* IS ZERO WE HAVE FINISHED THE LAST COMMAND AND PICK UP THE NEXT ONE.

FINDHA  INC     HAPTR+1
        LDX     HAPTR
        CPX     #CNAMP          ;END TABLE?
        BEQ     FHA1    ;17

        LDAA    ,X              ;NO, LOOK AT CURRENT ENTRY
        LDX     #ADDINI
        STAA    HAMP
        BEQ     *+5
        JMP     *+6
        LDX     #FINDHA         ;LOOK AGAIN IF 0
        STX     FVECT+1         ;SET FOR ADD IF <>0
        INX
        RTS

FHA1    LDAA    #ADD2HA-2       ;RESTART TABLE
        FCB     $B7,0,HAPTR+1
        LDX     #FINDHA         ;MAYBE REPEAT
        DEC     FCNT
        BEQ     *+5
        JMP     *+6
FCMDNX  LDX     #NXTFCM ;40
        STX     FVECT+1
        RTS

;* RELATIVE JUMP.

FTOR    LDX     FCMDPT
        CLRB
        LDAA    ,X
        INCA                    ;DISPLACEMENT IS FROM NEXT INSTRUCTION
        ASRA
        ROLA
        SBCB    #0
        ADDA    FCMDPT+1
        ADCB    FCMDPT
        STAA    FCMDPT+1
        STAB    FCMDPT

        BRA     FCMDNX  ;37

;* SET UP FOR ADD OF HAMP * HARMONIC TO WAVE.

ADDINI  LDAA    HAPTR+1
        SUBA    #ADD2HA-1
        ASLA
        CLRB
        ADDA    HRMTBL+1        ;GET PTR TO HARMONIC IN FNHI, FNLO
        ADCB    HRMTBL
        STAB    FNHI
        STAA    FNLO    ;23

        LDAA    #128
        STAA    FMSK

        LDX     #.2S
        STX     FVECT+1 ;37
        LDX     #WAVSRT
        STX     FWVPTR
        RTS

.2S     LDX     FNHI            ;GET HARMONIC FN TO FNHI,FNLO
        LDX     ,X
        STX     FNHI
        LDX     #ADDLP
        STX     FVECT+1 ;23

        LDX     HAPTR
        LDAA    9,X
        ADDA    HAMP
        STAA    9,X     ;41     ;RECORD CHANGE
        INX
        RTS

;* ADD HAMP * HARMONIC FN TO WAVEFORM.

ADDLP   LDAA    FMSK            ;MSK PTS TO CURRENT HARMONIC VALUE
        BEQ     .1S             ;NEED NEW MASK AFTER 8 SAMPLES

        LSR     FMSK
        LDX     FWVPTR
        LDAB    ,X
        ANDA    FNHI            ;ADD/SUBTRACT HAMP FROM SAMPLE ON
        BNE     .2S     ;29     ;SIGN OF HARMONIC.
        FCB     -5,0,HAMP
        STAB    ,X
        INC     FWVPTR+1
        RTS             ;50

.2S     FCB     -16,0,HAMP
        STAB    ,X
        INC     FWVPTR+1
        RTS

.1S     LDAB    FWVPTR+1
        CMPB    #WAVSRT+16
        BEQ     .3S     ;16     ;DONE
        LDAB    FNLO
        STAB    FNHI            ;ELSE SET FOR NEXT 8 SAMPLES
        LDAB    #128
        FCB     -9,0,FMSK
        BRA     .16S    ;34

.3S     LDX     #NXTFCM         ;RETURN TO THE RIGHT PLACE
        LDAB    FCNT
        BNE     *+5             ;FCNT <>0 MEANS IN TABLE LOOP
        JMP     *+6             ;FCNT = 0 MEANS EXECUTING COMMANDS
        LDX     #FINDHA
        STX     FVECT+1 ;34

.16S    TST     ,X
        INX
        RTS

;* ADH H,N  LDH H,N  USE SAME RTN

ADHR
LDHR    LDAA    FCMD
        ANDA    #7              ;HARMONIC #
        ADDA    #ADD2HA
        STAA    HAPTR+1

        LDX     FCMDPT
        LDAA    ,X
        INX
        STX     FCMDPT
        STAA    HAMP    ;33     SAVE VALUE

        LDX     #.1S
        STX     FVECT+1
        INX
        RTS

.1S     LDX     HAPTR
        CLRB
        LDAA    FCMD
        ADDA    #-8             ;CARRY IF LD
        SBCB    #0
        ANDB    9,X             ;LD NEW = SUB OLD + ADD NEW
        NEGB
        ADDB    HAMP

ADHRE   STAB    HAMP    ;27
        LDX     #ADDINI
        STX     FVECT+1
        INX
        INX
        NOP
        RTS

;* HARMONIC INCREMENT OR DECREMENT

HIDR    LDAB    FCMD
        LSRB
        ANDB    #7
        ORAB    #ADD2HA         ;! ADD2HA MUST BE DIVISIBLE BY 8 !
        STAB    HAPTR+1         ;PT TO THIS HARMONIC

        LDAB    #-1             ;CARRY IF INCREMENT (BIT 0 OF FCMD = 1)
        ADCB    #0
        ADCB    #0
        BRA     ADHRE   ;23

;* CLEAR ADD2HA OR ALTER 0TH AMPLITUDE.

ZTBR    LDAA    FCMD            ;LO BIT 0 IF ZT
        ASRA
        BCS     ADCR

        LDX     #0
        STX     ADD2HA
        STX     ADD2HA+2
        STX     ADD2HA+4
        STX     ADD2HA+6 ;32
        INX

ATBRE   LDX     #NXTFCM
        FCB     -1,0,FVECT+1
ATBRE1  RTS

ADCR    BITA    #2
        BNE     ESC1    ;15     BIT 2 FCMD =1 FOR ESCAPE
        LDAB    #ADD2HA-1
        STAB    HAPTR+1 ;21
        LDX     #ADCRO
ADCRE   STX     FVECT+1
        JMP     WAST14

ESC1    FCB     -2,0,FCMDPT
        BRA     ADCRE   ;24

ADCRO   CLRB
        LDAA    FCMD
        ADDA    #-82            ;CARRY IF LDH
        SBCB    #0
        ANDB    CNAMP
        LDX     FCMDPT
        LDAA    ,X
        INX
        STX     FCMDPT  ;30
        SBA
        STAA    HAMP
        LDX     #ADDINI
        FCB     -1,0,FVECT+1
        RTS

;* CHANGE SOME ADD2HA ENTRIES.

LDTR    LDAB    #ADD2HA         ;ASSUME FIRST ENTRY IS H #8
        STAB    HAPTR+1
        LDX     FCMDPT
        LDAB    ,X              ;EACH BIT INDICATES PRESENCE OF ENTRY
        STAB    FNHI
        INX
        STX     FCMDPT  ;28
        LDAB    FCMD            ;LO BIT 1 IF ENTRY FOR 0 IS PRESENT
        LSRB
        BCC     .5S
        LDX     #.6S
        STX     FVECT+1
        RTS

.4S     CLRB
        LDAA    FNLO            ;LO BIT 0 IF REPLACE, 1 IF ADD TO CURRENT
        ASRA
        SBCB    #0
        LDX     HAPTR
        ANDB    ,X
        ABA
        STAA    ,X      ;26
        INC     HAPTR+1         ;PT TO NEXT GUY
        LDAA    ,X

.5S     LDX     #.1S
        STX     FVECT+1
        RTS

.1S     ASL     FNHI
        BCS     .2S
        BEQ     .3S             ;NO MORE IF 0
        INC     HAPTR+1
        JMP     WAST27

.3S     JSR     FCMDNX  ;36
        TST     ,X
        NOP
        RTS

.6S     DEC     HAPTR+1         ;SET FOR 0TH ENTRY
        INX

.2S     LDAA    ,X
        LDX     FCMDPT
        LDAA    ,X
        INX
        STX     FCMDPT  ;33
        STAA    FNLO
        LDX     #.4S
        STX     FVECT+1
        RTS


;* FILTER TIMING
;* COMMAND      # OF FILTER CALLS TO EXECUTE

;* LDH, ADH     24

;* LDT, ADT     3+(2*N)  (N = # OF ENTRIES ALTERED)

;* ZT           3

;* DT  R                3+(R*{ 9+(22*NZH)})  WHERE
;*              R IS # OF TABLE REPEATS
;*              NZH IS # OF NONZERO ADD2HA ENTRIES

;* IH, DH       23

;* FIN          4  ( SAME FOR REPEAT AND RETURN)

;* DO           5

;* TO           3

;* WAIT N       1+ (N* WAVE PERIOD)

; NLIST
;* MACROS FOR PITCH AND FILTER COMMANDS MAKE DULL READING.

;C MACRO "C
; LIST
;*                      "C
; NLIST
; ENDM


LBL     MACRO   L,C                                             ;;Fixme was: LBL        MACRO "L,"C
; LIST
L       EQU     *               ;"C
; NLIST
        ENDM


ESC     MACRO
; LIST
        FCB     $55             ;ESC
; NLIST
        ENDM


WAIT    MACRO   N                                               ;;Fixme was: WAIT       MACRO   "N
; LIST
        FCB     -N              ;WAIT   "N                      ;;Fixme was: FCB         -"N
; NLIST
        ENDM


DO      MACRO   R,A                                             ;;Fixme was: DO MACRO "R,"A
; LIST
        FCB 95+R,A-*-2          ;DO     "R,"A                   ;;Fixme was: FCB 95+"R,"A-*-2
; NLIST
        ENDM


TO      MACRO   A                                               ;;Fixme was: TO MACRO "A
; LIST
        FCB 112,A-*-2           ;TO     "A                      ;;Fixme was: FCB 112,"A-*-2
; NLIST
        ENDM


;* PITCH COMMANDS


LDP     MACRO   N                                               ;;Fixme was: LDP MACRO "N
; LIST
        FCB     1, N            ;LDP    "N                      ;;Fixme was: FCB 1,"N
; NLIST
        ENDM


ADP     MACRO   N                                               ;;Fixme was: ADP MACRO "N
; LIST
        FCB     0,N             ;ADP    "N                      ;;Fixme was: FCB 0,"N
; NLIST
        ENDM


LDV     MACRO   N                                               ;;Fixme was: LDV MACRO "N
ZQ0     SET     $2000+((N)&$FFF)                                ;;Fixme was: ZQ0 SET $2000+("N!.$FFF) (parentheses allow negative values!)
; LIST
        FDB     ZQ0             ;LDV    "N
; NLIST
        ENDM
;
ADV     MACRO   N                                               ;;Fixme was: ADV MACRO "N
ZQ0     SET     $3000+((N)&$FFF)                                ;;Fixme was: ZQ0 SET $3000+("N!.$FFF) (parentheses allow negative values!)
; LIST
        FDB     ZQ0             ;ADV    "N
; NLIST
        ENDM
;
LDO     MACRO   N                                               ;;Fixme was: LDO MACRO "N
; LIST
        FCB     17,N            ;LDO    "N                      ;;Fixme was: FCB 17,"N
; NLIST
        ENDM
;
ADO     MACRO   N                                               ;;Fixme was: ADO MACRO "N
; LIST
        FCB     16,N            ;ADO    "N                      ;;Fixme was: FCB 16,"N
; NLIST
        ENDM


STOP    MACRO
; LIST
        FCB     128             ;STOP
; NLIST
        ENDM


NOT     MACRO   N                                               ;;Fixme was: NOT MACRO "N
; LIST
        FCB     N               ;NOT    "N                      ;;Fixme was: FCB        "N
; NLIST
        ENDM


;* FILTER COMMANDS

FIN     MACRO
; LIST
        FCB     64              ;FIN
; NLIST
        ENDM


ADH     MACRO  H,N                                              ;;Fixme was: ADH MACRO "H,"N
        IF H = 0                                                ;;Fixme was: IFE "H
; LIST
        FCB     81,N            ;ADH    0,"N                    ;;Fixme was: FCB  81,"N
; NLIST
        ELSE
; LIST
        FCB 8-H,N               ;ADH    "H,"N                   ;;Fixme was: FCB 8-"H,"N
; NLIST
        ENDIF
        ENDM
;
LDH     MACRO  H, N                                             ;;Fixme was: LDH MACRO "H,"N
        IF H = 0                                                ;;Fixme was: IFE "H
; LIST
        FCB     83,N            ;LDH    0,"N                    ;;Fixme was: FCB  83,"N
; NLIST
        ELSE
; LIST
        FCB     16-H,N          ;LDH    "H,"N                   ;;Fixme was: FCB 16-"H,"N
; NLIST
        ENDIF
        ENDM
;
DT      MACRO  R                                                ;;Fixme was: DT MACRO "R
        IFB R                                                   ;;Fixme was: IFB <"R>
; LIST
        FCB     32                      ;DT
; NLIST
        ELSE
; LIST
        FCB     31+R            ;DT     "R                      ;;Fixme was: FCB 31+"R
; NLIST
        ENDIF
        ENDM
;
IH      MACRO  H                                                ;;Fixme was: IH MACRO "H
; LIST
        FCB     65-H-H          ;IH     "H                      ;;Fixme was: FCB 65-"H-"H
; NLIST
        ENDM
;
DH      MACRO  H                                                ;;Fixme was: DH MACRO "H
; LIST
        FCB     64-H-H          ;DH     "H                      ;;Fixme was: FCB 64-"H-"H
; NLIST
        ENDM
;
ZT      MACRO
; LIST
        FCB     80              ;ZT
; NLIST
        ENDM


LT MACRO C,q0,q00,q1,q11,q2,q22,q3,q33,q4,q44,q5,q55,q6,q66,q7,q77,q8,q88       ;;Fixme was: LT MACRO "C,"0,"1,"2,"3,"4,"5,"6,"7,"8 (separating all values was the answer!!)
ZQ1     SET     16
ZQ2     SET     0
        IRP I,0,1,2,3,4,5,6,7,8                                 ;;Fixme was: IRPC %I,012345678
ZB_I    SET     0                                               ;;Fixme was: ZB%I SET 0
        ENDM                                                    ;;Fixme was: ENDR
        LTA 0,q0,q00                                            ;;Fixme was: LTA 0,"0
        LTA 1,q1,q11                                            ;;Fixme was: LTA 1,"1
        LTA 2,q2,q22                                            ;;Fixme was: LTA 2,"2
        LTA 3,q3,q33                                            ;;Fixme was: LTA 3,"3
        LTA 4,q4,q44                                            ;;Fixme was: LTA 4,"4
        LTA 5,q5,q55                                            ;;Fixme was: LTA 5,"5
        LTA 6,q6,q66                                            ;;Fixme was: LTA 6,"6
        LTA 7,q7,q77                                            ;;Fixme was: LTA 7,"7
        LTA 8,q8,q88                                            ;;Fixme was: LTA 8,"8
; LIST
        FCB     ZQ1,ZQ2         ;LT <"0>,<"1>,<"2>,<"3>,<"4>,<"5>,<"6>,<"7>,<"8>
; NLIST
        LT_C                                                    ;;Fixme was: LT"C
        ENDM



LTA     MACRO   II,H,A,P                                        ;;Fixme was: LTA MACRO "I,"H,"A,"P (added another I to avoid errors)
ZQ3     SET     0
        IFNB    P                                               ;;Fixme was: IFNB <"P>
ZQ3     SET     1
        ENDIF
        IFNB    H                                               ;;Fixme was: IFNB <"H>
        IF      H = 0                                           ;;Fixme was: IFE "H
ZQ1     SET     17
        ELSE
ZQ2     SET     ZQ2|(2^(H-1))                                   ;;Fixme was: ZQ2 SET ZQ2!+(2!^("H-1))
        ENDIF
ZB_II   SET     (A)+(A)+ZQ3                                     ;;Fixme was: ZB"I SET "A+"A+ZQ3 (parentheses allow negative values!)
        ENDIF
        ENDM


LT_0    MACRO                                                   ;;Fixme was: LT_0
; LIST
        FCB     ZB_0                                            ;;Fixme was: FCB ZB0
; NLIST
        ENDM


LT_1    MACRO                                                   ;;Fixme was: LT_1
; LIST
        FCB     ZB_0,ZB_1                                       ;;Fixme was: FCB ZB0,ZB1
; NLIST
        ENDM


LT_2    MACRO                                                   ;;Fixme was: LT_2
; LIST
        FCB     ZB_0,ZB_1,ZB_2                                  ;;Fixme was: FCB ZB0,ZB1,ZB2
; NLIST
        ENDM


LT_3    MACRO                                                   ;;Fixme was: LT_3
; LIST
        FCB     ZB_0,ZB_1,ZB_2                                  ;;Fixme was: FCB ZB0,ZB1,ZB2
        FCB     ZB_3                                            ;;Fixme was: FCB ZB3

; NLIST
        ENDM


LT_4    MACRO                                                   ;;Fixme was: LT_4
; LIST
        FCB     ZB_0,ZB_1,ZB_2                                  ;;Fixme was: FCB ZB0,ZB1,ZB2
        FCB     ZB_3,ZB_4                                       ;;Fixme was: FCB ZB3,ZB4
; NLIST
        ENDM


LT_5    MACRO                                                   ;;Fixme was: LT_5
; LIST
        FCB     ZB_0,ZB_1,ZB_2                                  ;;Fixme was: FCB ZB0,ZB1,ZB2
        FCB     ZB_3,ZB_4,ZB_5                                  ;;Fixme was: FCB ZB3,ZB4,ZB5
; NLIST
        ENDM


LT_6    MACRO                                                   ;;Fixme was: LT_6
; LIST
        FCB     ZB_0,ZB_1,ZB_2                                  ;;Fixme was: FCB ZB0,ZB1,ZB2
        FCB     ZB_3,ZB_4,ZB_5                                  ;;Fixme was: FCB ZB3,ZB4,ZB5
        FCB     ZB_6                                            ;;Fixme was: FCB ZB6
; NLIST
        ENDM


LT_7    MACRO                                                   ;;Fixme was: LT_7
; LIST
        FCB     ZB_0,ZB_1,ZB_2                                  ;;Fixme was: FCB ZB0,ZB1,ZB2
        FCB     ZB_3,ZB_4,ZB_5                                  ;;Fixme was: FCB ZB3,ZB4,ZB5
        FCB     ZB_6,ZB_7                                       ;;Fixme was: FCB ZB6,ZB7
; NLIST
        ENDM


LT_8    MACRO                                                   ;;Fixme was: LT_8
; LIST
        FCB     ZB_0,ZB_1,ZB_2                                  ;;Fixme was: FCB ZB0,ZB1,ZB2
        FCB     ZB_3,ZB_4,ZB_5                                  ;;Fixme was: FCB ZB3,ZB4,ZB5
        FCB     ZB_6,ZB_7,ZB_8                                  ;;Fixme was: FCB ZB6,ZB7,ZB8
; NLIST
        ENDM


; LIST
; NCLIST

; SUBTTL SOUND PROGRAMS

;* OPCODES ( ! SEPERATES NYBBLES  SPACES SEPERATE BYTES)

;* COMMON
;* WAIT N       -N              ( 1<= N<= 127)
;* DO R,RTN     $6!(R-1)  RTN - NEXT LOC
;* TO RTN       $70   RTN - NEXT LOC
;* ESC          $55

;* FREQUENCY CONTROL
;* STOP         $80
;* LDP N                $01 N
;* ADP N                $00 N
;* LDV N                $2!(N&$F00) N&255
;* ADV N                $3!(N&$F00) N&255
;* LDO N                $11 N
;* ADO N                $10 N

;* WAVE CONTROL
;* FIN          $40
;* ZT           $50
;* ADH 0,N      $51 N
;* LDH 0,N      $53 N
;*      ( IN WHAT FOLLOWS 1<=H<=8  HHH = 8-H, A 3 BIT NUMBER)
;* ADH H,N      $0!0HHH
;* LDH H,N      $0!1HHH
;* IH H         $3!HHH1
;* DH H         $3!HHH0
;* DT R         $2!(R-1)
;* LT A0,...,A8 $1!000C 8765!4321 B0,...,B8
;*              WHERE C=1 IF ENTRY 0 IS ALTERED
;*                    N=1 IF ENTRY N IS ALTERED (N=1,...,8)
;*              BN=AN+AN+P WHERE P=1 IF AN IS TO BE ADDED TO ENTRY N
;*                               P=0 IF AN REPLACES ENTRY N
;*              BN IS PRESENT ONLY IF ENTRY N IS TO BE ALTERED

;* HARMONIC FUNCTIONS.  EACH BIT POSITION CORRESPONDS TO A WAVEFORM
;* POSITION.  IF THE BIT = 0, THE VALUE IS +1  IF THE BIT = 1, THE
;* VALUE IS -1.

;* THE HARMONICS ARE TREATED IN ORDER OF DECREASING AVERAGE FREQUENCY.

ODDTBL
 FDB %0000000000000000          ;0  CONSTANT IS WEIRDO FOR NOW
 FDB %0101010101010101          ;8
 FDB %1010101001010101          ;7
 FDB %0101101001011010          ;6
 FDB %1001011001101001          ;5
 FDB %0110011001100110          ;4
 FDB %1100110000110011          ;3
 FDB %0011110000111100          ;2
 FDB %0000111111110000          ;1

;* WAVE PROGRAMS

; NLIST

 LBL SCREMW,FPF                                 ;;Fixme was: LBL SCREMW,<FPF> (Not sure what "FPF" is)
 LT 7,8,1,7,1,6,1,5,1,4,1,3,1,2,1,1,1           ;;Fixme was: LT 7,<8,1>,<7,1>,<6,1>,<5,1>,<4,1>,<3,1>,<2,1>,<1,1>
 DT 16
 DT 16
 ZT
 LT 0,8,-1                                      ;;Fixme was: LT 0,<8,-1>
 DT 16
 LT 0,7,-1                                      ;;Fixme was: LT 0,<7,-1>
 DT 16
 LT 1,8,0,6,-1                                  ;;Fixme was: LT 1,<8,0>,<6,-1>
 DT 16
 LT 1,7,0,5,-1                                  ;;Fixme was: LT 1,<7,0>,<5,-1>
 DT 16
 LT 1,6,0,4,-1                                  ;;Fixme was: LT 1,<6,0>,<4,-1>
 DT 16
 LT 1,5,0,3,-1                                  ;;Fixme was: LT 1,<5,0>,<3,-1>
 DT 16
 LT 1,4,0,2,-1                                  ;;Fixme was: LT 1,<4,0>,<2,-1>
 DT 16
 LT 1,3,0,1,-1                                  ;;Fixme was: LT 1,<3,0>,<1,-1>
 DT 16
 LT 0,2,0                                       ;;Fixme was: LT 0,<2,0>
 DT 16
 LT 0,1,0                                       ;;Fixme was: LT 0,<1,0>
 DT 16
 TO SCREMW

 LBL PPLD
 ADP 1
 ADP -1
 ADP -1
 ADP 1
 STOP

 LBL SCREMP
 NOT 60
 LDV -512
 WAIT 16
 LDV 0
 WAIT 100
 LBL SCRMA
 LDV 80
 DO 13,PPLD
 LDV 64
 DO 4,PPLD
 STOP

 LBL SCDNP
 NOT 28
 TO SCRMA

 LBL SKIDW
 LDH 3,32
 LDH 4,48
 FIN

 LBL PPVA
 ADP 2
 WAIT 1
 ADP -2
 WAIT 2
 STOP

 LBL SKIDP
 NOT 48
 DO 4,PPVB
 LBL PPVC
 LDV -32
 DO 8,PPVA
 STOP

 LBL PPVB
 ADV 2
 WAIT 2
 ADP -2
 WAIT 2
 ADP 2
 WAIT 2
 ADP -2
 WAIT 2
 ADP 2
 WAIT 2
 ADP -2
 WAIT 2
 ADP 6
 WAIT 3
 ADV -256
 WAIT 5
 ADV 256
 ADP 2
 STOP

 LBL SKIDEP
 NOT 49
 LDV 6
 DO 1,PPVB
 TO PPVC

; LIST

JNOIST  FCB 13,64,-16,-1,18     ;$1F WING UP
        FCB 8,168,24,1,8        ; 20 CLIP
        FCB 4,168,24,1,16       ; 21 CLOP
        FCB 4,32,-8,-1,32       ; 1E WING DOWN PART 1
        FCB 16,-16,16,1,1       ;"              "  2

WINGDN  LDAA    #3
        BSR     JKNOIS
        LDAA    #4

JKNOIS  LDX     #$D939          ;GOOD SEED
        STX     HI
        TAB
        ASLA
        ASLA
        ABA
        LDX     #JNOIST
        JSR     ADDX
        JMP     NOISLG

WALSHT  FDB     SCREMW,SCREMP   ;$22 PTERODACTYL SCREAM
        FDB     SCREMW,SCDNP    ; 23 END OF ABOVE
        FDB     SKIDW,SKIDP     ; 24 OSTRICH STOP
        FDB     SKIDW,SKIDEP    ; 25 END SKID FOR SHORT ONES

WALSH   CLRB
        STAB    SMPPER+1
        ASLA
        ASLA
        ADDA    #WALSHT&255                                                     ;;Fixme was: ADDA  #WALSHT!.255
        ADCB    #WALSHT/256
        STAB    PCMDPT
        STAA    PCMDPT+1
        LDX     PCMDPT
        LDX     ,X                                                              ;;Fixme was: LDX  X
        STX     FCMDPT
        LDX     PCMDPT
        LDX     2,X
        LDAB    ,X                                                              ;;Fixme was: LDAB  X
        STAB    SMPPER
        INX
        STX     PCMDPT
        LDX     #ODDTBL
        STX     HRMTBL
        JMP     WSM


;*
;* VECTORS HERE
;*
        ORG     VECTOR
IRQV    FDB     IRQ
SWIV    FDB     SETUP
NMIV    FDB     NMI
RESETV  FDB     SETUP
        END     ;CKSUM