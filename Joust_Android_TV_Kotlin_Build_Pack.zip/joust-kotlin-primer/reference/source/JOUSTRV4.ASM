;       NAM PFUTZ
;       SUBTTL  WILLIAMS 1982, JOUST GAME
;*
;******************************************************************
;*      WILLIAMS ELECTRONICS 1982
;*      ORGINAL GAME NAME; JOUST
;*      GAME DESIGNER; JOHN NEWCOMER
;*      MAIN PROGRAMMER; BILL PFUTZENREUTER
;*      OTHER PROGRAMMERS; CARY KOLKER
;*                         KEN LANTZ
;*      STARTED PROGRAMMING; FEB 10, 1982
;*      FILE: JOUST GAME PROGRAMS
;*
;       NLIST
;       INCLUDE SHRAMDEF.SRC    DONT FORGET STANDARD DEFINITIONS                ;;We don't need these
;       INCLUDE SHORTEQU.SRC    CMOS                                            ;;Was a shorter EQU file needed because of the BSO assembler's limited symbol table size?
;       INCLUDE MESSEQU.SRC     MESSAGES
;       LIST
;*************************************************************************
;*                                                                       *
;*      PATCHES RAM AREA                                                 *
;*                                                                       *
;*************************************************************************
;*
        ORG     $B300           ;NEW RAM FOR THE LAVA TROLL
LAVKLL  RMB     2       ;TIME LEFT TILL LAVA TROLL GETS REAL STRONG
CLVGRA  RMB     2       ;LAVA TROLL CURRENT GRAVITY
;*
;*
;*
;*      CONSTANTS
;*
HIDE    EQU     $5A             ;A SIMPLE WAY TO HIDE ASCII DATA
HIDE2   EQU     $30             ; (ETC.)                                        ;;Fixme was: HIDE2  EQU '0
LAND5   EQU     210             ;START OF LAND
CEILNG  EQU     $0020           ;CEILING (HIGHEST POSITION) OF GAME)
FLOOR   EQU     $00DF           ;THE FLOOR (LOWEST POSITION OF GAME)
ELEFT   EQU     -10             ;EXTREME LEFT SIDE OF WRAP AROUND SCREEN
ERIGHT  EQU     292             ;EXTREME RIGHT SIDE OF WRAP AROUND SCREEN
MAXVX   EQU     8               ;MAXIMUM X +- VELOCITY
MAXVY   EQU     $1000           ;MAXIMUM Y + VELOCITY (FALLING)
MINVY   EQU     $0400           ;MAXIMUM Y - VELOCITY (RISING)
PLYID   EQU     $09             ;PLAYERS I.D. WHEN DEAD
EMYID   EQU     $0F             ;ENEMIES I.D. WHEN DEAD
EGGID   EQU     $02             ;EGGS I.D. WHEN DEAD
SCRID   EQU     $03             ;EGGS SCORE I.D.
CATID   EQU     $04             ;EGGS CAUGHT IN THE AIR SCORE I.D.
PTEID   EQU     $17             ;PTERODACTYL I.D.
SLOID   EQU     $18             ;SLOW I.D.
LAVID   EQU     $15
EGGCOL  EQU     $2              ;CATCH THE EGG IN THE AIR COLOR
PL1     EQU     $5              ;YELLOW, FOR PLAYER 1
LTBLUE  EQU     $7              ; PLAYER 1'S VISOR
PL2     EQU     $7              ;GREEN, FOR PLAYER 2
YELLOW  EQU     $5              ; PLAYER 2'S VISOR
PTC     EQU     $4              ;RED FOR PTERODACTYL KILLED SCORE
WHI     EQU     $1              ;WHITE FOR MESSAGES, ETC.
GRY     EQU     $D              ;LITE GREY FOR TRANSPORTER EFFECT
DKB     EQU     $E              ;DARK BROWN CLIFF COLOR
LIB     EQU     $8              ;LIGHT BROWN CLIFF COLOR
MEB     EQU     $8              ;MEDIUM BROWN CLIFF COLOR
;;ATX1  EQU     $11     ;'WELCOME TO JOUST'                                     ;;Already defined in MESSEQU2.ASM
;;ATX2  EQU     $12     ;'TO FLY,'                                              ;;Already defined in MESSEQU2.ASM
;*                      ;'REPEATEDLY PRESS 'FLAP' BUTTON'
;;ATX3  EQU     $13     ;'TO SURVIVE A JOUST                                    ;;Already defined in MESSEQU2.ASM
;*                      ;'THE HIGHEST LANCE WINS'
;*                      ;'IN A COLLISION'
;;ATX4  EQU     $14     ;'PICK UP THE EGGS'                                     ;;Already defined in MESSEQU2.ASM
;*                      ;'BEFORE THEY HATCH'
;;ATX5  EQU     $15     ;'MEET THY ENEMIES'                                     ;;Already defined in MESSEQU2.ASM
;;ATX6  EQU     $16     ;'BOUNDER (500)'                                        ;;Already defined in MESSEQU2.ASM
;;ATX7  EQU     $17     ;'HUNTER (750)'                                         ;;Already defined in MESSEQU2.ASM
;;ATX8  EQU     $18     ;'SHADOW LORD (1500)'                                   ;;Already defined in MESSEQU2.ASM
;;ATX9  EQU     $19     ;'PRESS 1 PLAYER TO START'                              ;;Already defined in MESSEQU2.ASM
;*                      ;'OR'
;*                      ;'INSERT ADDITIONAL COIN FOR'
;*                      ;'2 PLAYER EXCITMENT'
;;ATX10 EQU     $1A     ;'READY FOR 2 PLAYER'                                   ;;Already defined in MESSEQU2.ASM
;*                      ;'JOUST'
;;ATX11 EQU     $1B     ;'PTERODACTYL BEWARE'                                   ;;Already defined in MESSEQU2.ASM
;;ATX13 EQU     $1D     ;'TEMPORARY SAFETY'                                     ;;Already defined in MESSEQU2.ASM
;*                      ;'UNTIL A CONTROL IS PRESSED'
;*
;*      FREE TRANSPORTER TABLE OFFSETS
;*
        ORG     $0
FXREV   RMB     1       ;X POSITION'S WRAP DIRECTION
FXMIN   RMB     2       ;X PIXEL POSITION MINIMUM
FXMAX   RMB     2       ;X PIXEL POSITION MAXIMUM
FLEVEL  RMB     2       ;THIS TRANSPORTERS "IN USE" FLAG ADDRESS
FTLEN   RMB     0       ;LENGTH OF THIS MINI-TABLE
;*
;*      TRANSPORTER LOCATION TABLE
;*
        ORG     $0
TIMAGE  RMB     2               ;SOURCE ADDRESS OF IMAGE
TPOSX   RMB     2               ;TRANSPORTER X PIXEL POSITION
TPOSY   RMB     2               ;TRANSPORTER Y PIXEL POSITION
TCURUSE RMB     2               ;TRANSPORTER "IN USE" FLAG ADDRESS
;*
;*      DECISION BLOCK
;*
        ORG     $0
DJOY    RMB     2       ;PLAYERS JOYSTICK/DUMB LINE TRACKING ENEMY
DSMART  RMB     2       ;A SMARTER ENEMY
DSCORE  RMB     2       ;SCORE RAM LOCATION
DSCLOC  RMB     2       ;SCORE SCREEN LOCATION
DSCPLY  RMB     2       ;SCORE'S AREAS IMAGES OF A PERSON SITTING DOWN
DPLYR   RMB     2       ;RIDERS IMAGE
DTREFF  RMB     2       ;TRANSPORTERS COLOR EFFECTS
DCRE    RMB     2       ;DECISION TO BE RECREATED BY WHOM
DDEAD   RMB     2       ;DEATH WISH ROUTINE (REG.X VICTOR, REG.U LOSER)
DEGGS   RMB     2       ;EGG KILLED COUNTER
DSTART  RMB     2       ;DECISION TO BE ENABLED AFTER TRANSPORTER
DVALUR  RMB     2       ;SCORE'S ROUTINE TO CALL FOR SCORES VALUE
DGLAD   RMB     2       ;GLADIATOR/TEAM WAVE RAM POINTER
DTIME   RMB     2       ;ADDRESS OF RUNNING/FLYING NAP TIME
DSNWU   RMB     2       ;SOUND OF WINGS GOING UP
DSNWD   RMB     2       ;SOUND OF WINGS GOING DOWN
DSNSK   RMB     2       ;SOUND OF SKIDDING
DSNSK2  RMB     2       ;END OF SKIDDING SOUND
DSNRU1  RMB     2       ;SOUND OF RUNNING (CLIP) (FIRST LEG)
DSNRU2  RMB     2       ;SOUND OF RUNNING (CLOP) (SECOND LEG)
DSNFAL  RMB     2       ;SOUND OF FALLING
DSNTREF RMB     2       ;KILL SOUND OF TRANSPORTER EFFECT
DSNCRE  RMB     2       ;THE SOUND OF A TRANSPORTER EFFECT
DCONST  RMB     1       ;COLOR NIBBLE OF PLAYER
DVALUE  RMB     1       ;SCORE WHEN KILLED (IN THOUSANDS/HUNDREDS)
DGAMO   RMB     1       ;PUT UP PLAYER 1/2 GAME OVER MESSAGE
;*
;*      PICTURES FRAME NUMBER (FOR PIMAGE,U)
;*
        ORG     $0
SKID    RMB     12
STAND   RMB     12
RUN1    RMB     12
RUN2    RMB     12
RUN3    RMB     12
RUN4    RMB     12
FLY1    RMB     12
FLY2    RMB     12
FLY3    RMB     12
;*
;*      WAVE PROCESS OFFSETS
;*
        ORG     PPOSX
PWAVE   RMB     2
PDELWV  RMB     2       ;TIME LEFT TO DELAY INBETWEEN WAVES
PDELAY  RMB     2       ;DELAY COUNTER
PINTEL  RMB     2       ;TEMP STORE AREA FOR INTELLIGENCE
PWRTS   RMB     2       ;RETURN ADDRESS FOR SOME SUBROUTINES
PWRTS2  RMB     2       ;RETURN ADDRESS FOR SOME SUBROUTINES
PWPREV  RMB     2       ;PREVIOUS WAVE CLEAN-UP SUBROUTINE ADDRESS
PWREGD  RMB     2       ;SAVE AREA FOR REG.D
PWREGY  RMB     2       ;SAVE AREA FOR REG.Y (EGG WAVE)
PWREGA  RMB     1       ;SAVE AREA FOR REG.A (EGG WAVE)
PEGGTM  RMB     1       ;TIME TILL EGGS HATCH FOR EGG WAVE
PBAITN  RMB     1       ;WORD OFFSET TO TIME TABLE OF NEXT BAITER SEND OFF
PBAITS  RMB     1       ;START TIME TABLE;TABLE NUMBER TILL NEXT BAITER SEND OFF
PWHCH   RMB     1       ;IF >0 A PRE-MATURE HATCHING EGG TO BE CREATED
PMSGA   RMB     1       ;CURRENT MESSAGE BEING DISPLAYED
PMSG0   RMB     4       ;MSG FOR WAVE 'XX'
PMSG1   RMB     4       ;MSG NBR & COLOR & SCREEN ADDRESS
PMSG2   RMB     4       ;MSG NBR & COLOR & SCREEN ADDRESS
PMSG3   RMB     4       ;MSG NBR & COLOR & SCREEN ADDRESS
PMSG4   RMB     4       ;MSG NBR & COLOR & SCREEN ADDRESS
PMSG5   RMB     4       ;MSG NBR & COLOR & SCREEN ADDRESS
        IF PNBR-* > 0                                                           ;;Fixme was: IFGT  PNBR-*
         FCB    $1111   ;CIA PROCESS BLOCK OVERFLOW!
        ENDIF
;*
;*      WAVE OFFSETS
;*
        ORG     $0
WBOUND  RMB     0       ;NBR OF BOUNDERS IN THIS WAVE (UPPER NIBBLE)
WHUNT   RMB     1       ;NBR OF HUNTERS IN THIS WAVE (LOWER NIBBLE)
WLORD   RMB     0       ;NBR OF SHADOW LORDS IN THIS WAVE (UPPER NIBBLE)
WPERSUE RMB     1       ;NBR OF PERSUERS IN THIS WAVE (LOWER NIBBLE)
WPTEN   RMB     1       ;NBR OF PTERODACTYLS IN THIS WAVE
WSTATUS RMB     1       ;STATUS BYTE FOR THIS WAVE
WLEN    EQU     *
;*
;*      WAVE STATUS BYTE, BIT DEFINITION
;*
WBPER   EQU     $01     ;IF=1, PERSUE WILL BE INSTANTANIOUSLY
WBJSR0  EQU     $02     ;THESE 3 BITS ARE A JSR TABLE OFFSET
WBJSR1  EQU     $04     ; (0 = AN NOP, OTHERS ARE 2,4,6,8,10,12,14)
WBJSR2  EQU     $08
WBCL1L  EQU     $10     ;IF=1, CLIFF1L IS DISABLED (OR DESTROYED)
WBCL1R  EQU     $20     ;IF=1, CLIFF1R IS DISABLED (OR DESTROYED)
WBCL2   EQU     $40     ;IF=1, CLIFF2 IS DISABLED (OR DESTROYED)
WBCL4   EQU     $80     ;IF=1, CLIFF4 IS DISABLED (OR DESTROYED)
WBCL1   EQU     WBCL1L+WBCL1R
WBCL12  EQU     WBCL1+WBCL2
WBCL14  EQU     WBCL1+WBCL4
WBCL24  EQU     WBCL4+WBCL2
WBCLS   EQU     WBCL1+WBCL2+WBCL4
;*
;*      DYNAMIC GAME ADJUST TABLE OFFSETS
;*
        ORG     $0
DYWST0  RMB     2       ;WORD START 0,1,2,3
DYWST1  RMB     2       ;WORD START 4,5,6
DYWST2  RMB     2       ;WORD START 7,8,9
DYWEND  RMB     2       ;WORD END VALUE
DYWTIM  RMB     5       ;NIBBLE TIMES BEFORE NEXT ADJUSTMENTS
DYWINC  RMB     1       ;BYTE LENGTH,INCREMENT
DYWLEN  RMB     0
;*
DYWORD  MACRO START1,START2,START3,INCRE,ENDV,TIM1,TIM2,TIM3
         FDB    START1,START2,START3,ENDV,TIM1,TIM2
         FCB    TIM3,INCRE
        ENDM
;*
        ORG     GAMORG
;*
;*      THE PROGRAM'S VECTORS
;*
        JMP     ATTRCT          ;POWER UP VECTOR
        JMP     ATTRC2          ;RETURN HERE AFTER H.S.T.D.
        FDB     GSTART          ;GAME START BUTTON MONITOR ROUTINE
        JMP     SCREDIT         ;DISPLAY CURRENT NUMBER OF CREDITS LEFT
        FDB     SNHIGH          ;HIGH SCORE TO DATES SOUND
        JMP     HSTD            ;TEMPORARY GO TO H.S.T.D. PAGE
        JMP     DCREDIT         ;DISPLAY CREDITS
        JMP     GAMSIM          ;SIMULATION GAME OR INSTRUCTIONAL PAGE
        JMP     DCRE2           ;DISPLAY CREDITS (VARIABLE BACKGROUND)
        FDB     NULL            ;COLOR RAM OF ALL ZEROS
;*
;*      GAME SIMULATION OR INSTRUCTIONAL PAGE
;*
GAMSIM  LDA     #$7F            ;GAME SIMULATION MODE
        STA     GOVER
        LDA     #3              ;3 LIVES FOR EACH PLAYER
        STA     NLIVES
        STA     NPLYRS          ;& 2 PLAYERS
        JMP     SIM1A           ;START THE PAGE
;*
SIM2A   CLR     NSMART          ;NO-ONE IS SMART IN THIS GAME!
        CLR     WSMART
;*
;*      GENERATE BACKGROUND LANDING & COLISION TABLES
;*
        LDX     #BCKXD1         ;GENERATE BACKGROUND COLISION TABLE AREA
.3S     LDD     ,X                                                              ;;Fixme was: .3S
        ANDA    #$80
        ANDB    #$80
        STD     ,X++
        CMPX    #BCKXD2
        BLO     .3S
;*
        PCNAP   1
        LDX     #LNDXD1         ;GENERATE BACKGROUND LANDING TABLE AREA
.5S     LDA     ,X                                                              ;;Fixme was: .5S
        ANDA    #$20            ;FOR NOW, JUST CLIFF 5 LANDS AT ALL POINTS
        STA     ,X+
        CMPX    #LNDXD2
        BLO     .5S
;*
PAMSG   EQU     PHORSE          ;MESSAGE AREAS PHORSE,PRIDER
;*
        LDD     #0
        STD     LEVPAS          ;NO LEVEL PASSES DURING ATTRACT MODE
        STD     PAMSG+0,U       ;INIT MESSAGE AREAS
        STD     PAMSG+2,U
        LDA     #-1
        STA     CURTR1          ;BREAK DOWN ALL BUT 1 TRANSPORTER
        STA     CURTR2          ; (THE BOTTOM ONE IS OPERATIONAL)
        STA     CURTR3
        JSR     DCREDIT         ;DISPLAY CREDITS
        LDX     #ATMST-5        ;       START SIMULATION MODE
        STX     PDIST,U
.10S    LDX     PDIST,U                                                         ;;Fixme was: .10S
        LEAX    5,X
        STX     PDIST,U
        CMPX    #ATMEND
        LBHS    SIM3A           ;BR=END OF SIMULATION
        LDA     4,X             ;ERASE OLD MESSAGE
        BEQ     .11S
        LEAX    PAMSG,U
.12S    CMPA    ,X+             ;IS THE MESSAGE IN THIS SPOT?                   ;;Fixme was: .12S
        BNE     .12S            ; BR=NO
        CLR     ,-X             ;ERASE QUE'D WRITTING
        TSTA
        BLT     *+2+3+2         ;!!!!!!!!!BECAREFULL!!!!!!!!!!
        JSR     ETEXT           ;!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        BRA     .11S            ;!!!!!!!!!BECAREFULL!!!!!!!!!!
;*                              ;!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        ANDA    #$7F            ;!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        JSR     ETEXT35
.11S    PCNAP   8                                                               ;;Fixme was: .11S
        LDX     PDIST,U
        LDA     2,X             ;SEND NEW MESSAGE
        BSR     .25S
        PCNAP   8
        LDX     PDIST,U
        JSR     [,X]
        LDX     PDIST,U
        LDA     3,X             ;SLEEP TIME
        STA     PJOYT,U
.19S    LDA     #60/2/3                                                         ;;Fixme was: .19S
        STA     PEGG,U
.20S    LDA     PAMSG+0,U                                                       ;;Fixme was: .20S
        BSR     .30S
        PCNAP   2
        LDA     PAMSG+1,U
        BSR     .30S
        PCNAP   2
        LDA     PAMSG+2,U
        BSR     .30S
        PCNAP   2
        DEC     PEGG,U
        BNE     .20S
        DEC     PJOYT,U
        BNE     .19S
        BRA     .10S
;*
;*      PUT MESSAGE IN QUE & WRITE IT
;*
.25S    BEQ     .40S                                                            ;;Fixme was: .25S
        LEAX    PAMSG,U
        TST     ,X+             ;THIS SLOT EMPTY? !!!!!!!!!BECAREFULL!!!!!!!!!!
        BNE     *-2             ; BR=NO          !!!!!!!!!BECAREFULL!!!!!!!!!!
        STA     ,-X             ;NOW THIS SLOT IS FULL
;*
;*      WRITE TEXT OR TEXT35
;*
.30S    BEQ     .40S            ;!!!!!!!!!BECAREFULL!!!!!!!!!!                  ;;Fixme was: .30S
        BLT     *+2+3           ;!!!!!!!!!BECAREFULL!!!!!!!!!!
        JMP     TEXT            ;!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
;*                              ;!!!!!!!!!BECAREFULL!!!!!!!!!!
        ANDA    #$7F            ;!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        JMP     TEXT35          ;!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
.40S    RTS                                                                     ;;Fixme was: .40S
;*
ATMRTS  RTS
ATMST   FDB     ATMRTS,ATX1*256+2       ;INTRO MESSAGE
        FCB     0
        FDB     FLYLES,ATX2*256+9       ;FLYING LESSIONS
        FCB     0
        FDB     DIELES,ATX3*256+7       ;DYING LESSIONS
        FCB     ATX2
        FDB     EGGLES,ATX4*256+5       ;EGG LESSION
        FCB     ATX3
        FDB     LAVLES,ATX5*256+2       ;ENEMY LESSIONS
        FCB     ATX4
        FDB     BOULES,ATX6*256+2       ;BOUNDER
        FCB     0
        FDB     HUNLES,ATX7*256+2       ;HUNTER
        FCB     ATX6
        FDB     SHALES,ATX8*256+1       ;SHADOW LORD
        FCB     ATX7
        FDB     ATMRTS,1                   ;ERASE ENEMY LESSIONS AREA
        FCB     ATX5
        FDB     ATMRTS,5                   ;ERASE SHADOW LORD AREA
        FCB     ATX8
        FDB     ATMRTS,(ATX13+$80)*256+6    ;ERASE SHADOW LORD AREA
        FCB     0                       ;TRANSPORTER
        FDB     OFFLES,2
        FCB     ATX1
        FDB     PTELES,ATX11*256+10     ;PTERODACTYL
        FCB     ATX13+$80
        FDB     ATMRTS,0*256+5
        FCB     ATX11
ATMEND  EQU     *
;*
;*
;*      FLYING LESSIONS
;*
FLYLES  LDD     #L1FLY
        LDX     TARPL2
        STD     PJOY,X
        LDA     #128+32
        STA     PJOYT,X
        STA     PEGG,X
        RTS
;*
L1FLY   DEC     PJOYT,U
        BPL     .20S
        INC     PJOYT,U
        LDD     PVELY,U         ;FLY UP
        CMPD    #-$0040
        BMI     .20S
.10S    LDA     PPOSY+1,U
        CMPA    #AOFFL2-9       ;FLY UP TO JUST ABOVE LINE TRACK OF 2
        BHI     .40S
        LDD     #.35S
        STD     PJOY,U
.20S    CLRB                                                                    ;;Fixme was: .20S
.30S    CLRA                                                                    ;;Fixme was: .30S
        STD     CURJOY
        RTS
;*
.35S    LDA     PVELY,U
        BMI     .20S
        BRA     .10S
;*
.40S    LDD     #.50S
        STD     PJOY,U
        LDA     PEGG,U
        LSRA
        LSRA
        INCA
        STA     PJOYT,U
.45S    LDB     #1              ;FLAP WINGS
        BRA     .30S
;*
.50S    DEC     PJOYT,U
        BNE     .45S
        LDA     PEGG,U          ;RESET FLAP TIMER
        LSRA
        STA     PEGG,U
        STA     PJOYT,U
        LDD     #L1FLY
        STD     PJOY,U
        BRA     .20S
;*
;*      DIEING LESSION(S)
;*
DIELES  LDX     #P4DEC
        JSR     ATTEMY          ;ATTRACT MODE ENEMIES
        LDD     #LINET          ;LINE TRACKING BOUNDAR
        STD     PJOY,Y
        LDD     #ERIGHT-1       ;X POSITION
        STD     PPOSX,Y
        STD     PCOLX,Y
        LDD     #AOFFL2         ;Y POSITION
        STD     PPOSY,Y
        STB     PCOLY1,Y
        STB     PCOLY2,Y
        STB     PFACE,Y         ;FACE LEFT
        LDD     #L2EGG
        LDX     TARPLY
        STD     PJOY,X
        LDA     #$60
        STA     PJOYT,X
        RTS
;*
;*      START ATTRACT MODES ENEMY
;*       INPUT REG.X - INTELLIGENCE
;*       ADDITIONMAL INPUT; SET "PJOY,Y"
;*
ATTEMY  PSHS    X               ;       ENEMIES INTELLIGENCE
        LDU     TARPL2          ;START ENEMY AFTER COLISION ROUTINE
.9S     LDU     PLINK,U
        LDA     PID,U
        CMPA    #$20            ;OPPCOL COLISION ROUTINE?
        BNE     .9S             ; BR=NO
        LDD     #($80+EMYID)*256+$FF    ;START THE ENEMY';S PROCESS
        LDX     #STFALL
        JSR     VCUPROC
        LDB     #PPOSX                  ;CLEAR OUT THIS GUYS WORKSPACE
.10S    CLR     B,Y
        INCB
        CMPB    #PNBR
        BLO     .10S
        LDU     PEXEC                   ;RESTORE PROCESS AREA
        PULS    X
        STX     PDECSN,Y
        INC     NENEMY
        INC     NRIDER
        LDD     BUZARD          ;START HORSE
        STD     PHORSE,Y
        LDD     [DPLYR,X]
        STD     PRIDER,Y
;********       CLR     PVELX,Y
;********       CLR     PBUMPY,Y
;********       CLR     PBUMPX,Y
;********       LDD     #0
;********       STD     PPICH,Y
;********       STD     PPICR,Y
        LDA     #4              ;MAXIMUM NUMBER OF EGGS TO LAY
        STA     PEGG,Y
;********       CLR     PCHASE,Y        NOT CHASING THE PLAYER
        RTS
;*
;*      EGG LESSION
;*
EGGLES  LDD     #L1EGG
        LDX     TARPL2
        STD     PJOY,X
        RTS
;*
L1EGG   LDD     PSTATE,U
        BEQ     .15S
        LDA     PVELX,U
        CMPA    #-4*2   ;MAXIMUM GOING LEFT SPEED?
        BEQ     .17S
.10S    LDD     #$FF00
.11S    STD     CURJOY
        RTS
;*
.15S    LDA     PVELX,U
        BGT     .16S
        LDD     #$0101
        BRA     .11S
;*
.16S    LDD     #$0000
        BRA     .11S
;*
.17S    LDD     #.20S
        STD     PJOY,U
.20S    LDA     PVELX,U
        BMI     .10S
        LDD     #.30S
        STD     PJOY,U
.30S    LDA     PVELX,U
        BNE     .10S
        LDA     PFACE,U
        BPL     .10S
        BRA     .16S
;*
;*      LAVA TROLL LESSIONS (REALLY ONLY A WARNING)
;*
LAVLES  LDX     #$74DC
        LDD     #MSW19*256+$44          ;'HOME OF THE'
        JSR     OUTP35
        LDX     #$76E3
        LDD     #MSW20*256+$44          ;'LAVA TROLL'
        JMP     OUTP35
;*
;*      BOUNDER LESSION
;*
BOULES  LDX     #P4DEC
        JSR     ATTEMY
        LDD     #60*6+8+8
        BRA     EMYLES
;*
;*      HUNTER LESSION
;*
HUNLES  LDX     #P5DEC
        JSR     ATTEMY
        LDD     #60*4+8
        BRA     EMYLES
;*
;*      SHADOW LORDS LESSION
;*
SHALES  LDX     #P6DEC
        JSR     ATTEMY
        LDD     #60*2+8
EMYLES  STD     PDIST,Y
        LDD     #8
        STD     PPOSX,Y
        STD     PCOLX,Y
        LDB     #$D3-1
        STB     PPOSY+1,Y
        STB     PCOLY1,Y
        STB     PCOLY2,Y
;********       CLR     PFACE,Y
        LDD     #L1EMY
        STD     PJOY,Y
        RTS
;*
L1EMY   LDD     PDIST,U
        ADDD    #-1
        STD     PDIST,U
        BLE     .20S
        LDA     #1              ;GO RIGHT
        LDB     PVELX,U
        CMPB    #1*2
        BNE     .10S
.5S     CLRA
.10S    CLRB
        STD     CURJOY
        RTS
;*
.20S    LDX     PDECSN,U
        LDD     DSMART,X                ;ATTRACT MODE KILL
        STD     PJOY,U
        BRA     .5S
;*
;*      REMOVE ENEMIES
;*
OFFLES  LDU     PLINK,U
        BEQ     .30S
        LDA     PID,U
        CMPA    #$80+EMYID
        BNE     OFFLES
        LDD     #AUTOFF
        STD     PJOY,U
        BRA     OFFLES
;*
.30S    LDU     PEXEC
        RTS
;*
;*      PTERODACTYL LESSION
;*
PTELES  LDU     PLINK,U
        LDX     PLINK,U         ;FIND END OF LINK
        BNE     PTELES
        LDD     #PTEID*256+$FF
        LDX     #PTERST
        JSR     VCUPROC
        LDU     PEXEC
        RTS
;*
L2EGG   LDA     PJOYT,U
        BEQ     .20S
        DEC     PJOYT,U
        LDA     PVELX,U
        BNE     G2JOY
        LDD     #$0100
.10S    STD     CURJOY
        RTS
;*
.20S    LDA     PVELX,U
        BEQ     G2JOY
        LDA     PFACE,U
        BMI     G2JOY
        LDD     #$FF00
        BRA     .10S
;*
;*      GAME SIMULATION PLAYER COMMANDS
;*
G2JOY
G1JOY   TFR     U,X
.10S    LDX     PLINK,X
        BEQ     .20S
        LDA     PID,X
        CMPA    #PTEID+$80
        BNE     .10S
        LDA     PFACE,X         ;FACE OPPOSITE DIRECTION OF PTERODACTYL
        STA     PFACE,U
.20S    LDD     #0
        STD     CURJOY
        RTS
;*
;*      GAME OVER
;*
GAMOVR  LDA     #$80            ;DISABLE CREDIT DISPLAY PAGE
        STA     CRDCHG
        CLR     GOVER           ;STATE OF GAME = OVER
        PCNAP   8
        PROCCR  GSTART,$48      ;START GAME START SWITCH MONITOR
        JSR     DCREDIT         ;DISPLAY NUMBER OF CREDITS LEFT IN THE GAME
        CLR     WSMART          ;NO-ONE WILL BE SMART
        LDX     [PDUMMY]
GOVID   LDX     PLINK,X         ;NEXT PROCESS
        BEQ     GOVWAT
        LDA     PID,X           ;ALL PROCESSES FLAGGED FOR COLISION DETECT
        BPL     GOVID
        CMPA    #$80+PTEID      ;IGNORE PTERODACTYLS
        BEQ     GOVID
        LDY     PDECSN,X        ;INTELLIGENCE IS NOW NILL
      IF DEBUG <> 0             ;???????????? DEBUG PARAMATER ?????????         ;;Fixme was: IFN DEBUG
        CMPY    #P1DEC
        BLO     .1S
        CMPY    #P7DEC
        BLS     .2S
.1S     SWI                     ;THIS IS NOT A DECISION BLOCK
      ENDIF                     ;???????????? END OF DEBUG ????????????
.2S     LDA     PID,X           ;CARD THIS PROCESS
      IF DEBUG <> 0     ;???????????? DEBUG PARAMATER ?????????                 ;;Fixme was: IFN DEBUG
        CMPA    #$80+EGGID      ;PASS ONLY EGGS & BUZARDS & PTERODACTYLS
        BEQ     .3S
        CMPA    #$80+EMYID
        BEQ     .3S
        SWI
        BRA     GOVID
      ENDIF                     ;???????????? END OF DEBUG ????????????
;*
.3S     LDY     DJOY,Y
      IF DEBUG <> 0     ;???????????? DEBUG PARAMATER ?????????                 ;;Fixme was: IFN DEBUG
        CMPY    #LINET
        BEQ     .4S
        SWI
.4S     LDA     PID,X   ;REG.X=WORKSPACE REG.A=ID REG.Y=DJOY ADDRESS
      ENDIF                     ;???????????? END OF DEBUG ????????????
        STY     PJOY,X
        BRA     GOVID
;*
;*      GAME OVER MESSAGE
;*
GOVERM  LDX     #$3090
        LDD     #256*MSGOVR+WHI*$11     ;PUT UP GAME OVER MESSAGE
        JMP     OUTPHR
;*
GOVWAT  LDA     #11             ;8*11 OR 88 TICK WAIT
        STA     PRAM,U
.1S     JSR     GOVERM
        PCNAP   8               ;WAIT FOR A WHILE
        DEC     PRAM,U
        BNE     .1S
        LDX     #HSPP1          ;CLEAR OUT OLD HIGHLITED H.S.T.D. LETTERS
.2S     CLR     ,X+
        CMPX    #HSPP22+2
        BLO     .2S
        JMP     GAMEND          ;CHECK FOR H.S.T.D.
;*
ATTRC2  CLR     CRDCHG          ;RESET CHANGE IN CREDITS
        LDA     ANYONE          ;BACK FROM H.S.T.D. CHECKS/ENTRIES
        BEQ     .10S            ; BR=NO-ONE ENTERED THEIR NAME
        LDX     #SNHI2          ;SOMEONE ENTERED THEIR NAME
        JSR     VSND            ; MAKE AN ENTERED NAME SOUND
        BRA     SIM3A
;*
;*
.10S    LDA     #109            ;8*11 OR 88 TICK WAIT
        STA     PRAM,U
.1S     JSR     GOVERM
        PCNAP   8               ;WAIT FOR A WHILE
        DEC     PRAM,U
        BNE     .1S
SIM3A   PKILL   $00,$00         ;KILL EVERYONE
HSTD    LDX     #NULL
        JSR     VDCOLOR         ;BLANK THE COLOR RAM
        PCNAP   4
        JSR     SCCLR           ;BLANK THE SCREEN, PASS INTO ATTRACT MODE
;*
;* ATTRACT MODE
;*
ATTRCT  CLR     GOVER           ;STATE OF GAME = OVER
        LDA     #$31            ;ATTRACT MODE PROCESS I.D.
        STA     PID,U
        PROCCR  GSTART,$48      ;START GAME START BUTTON MONITOR
        LDA     N2SHIP+1        ;H.S.T.D. PAGE ALLOWED?
        RORA
        BCC     .20S            ; BR=NO, GO TO NEXT MENU
        LDD     #15*60          ;15 SECONDS OF HIGH SCORE TO DATE PAGE
        STD     PRAM,U
        CLR     PRAM+3,U
        LDX     #HICOLR         ;HIGH SCORE TO DATE COLORS
        JSR     VDCOLOR
        JSR     HIGH            ;DISPLAY HIGH SCORE TO DATE
        JSR     DCREDIT         ;DISPLAY NUMBER OF CREDITS IN GAME
.10S    PCNAP   1
        INC     RAMCOL+2        ;CONTINUALLY CHANGE 1 COLOR WORD
        LDD     PRAM,U
        BEQ     .20S
        ADDD    #-1
        STD     PRAM,U
        BRA     .10S
;*
.20S    JSR     READEM
        SUBD    #$0201
        BNE     .30S
        LDA     #60
        STA     PRAM+3,U
        BRA     .10S
;*
.30S    DEC     PRAM+3,U
        BGT     .10S
        PROCCR  HSTDBK,$49      ;GO BACK TO H.S.T.D. PAGE MONITOR
        JMP     $D000
;*
;*      GO BACK TO H.S.T.D. PAGE
;*
HSTDBK  PCNAP   5
        JSR     READEM
        SUBD    #$0201          ;RIGHT1,LEFT2
        BNE     HSTDBK
        BRA     SIM3A
;*
HICOLR  FCB     @000            ;BACKGROUND
        FCB     @007    ;160    ;LT GREEN TOP BUZZARDS
        FCB     @300            ;CENTER SECTION
        FCB     @106    ;240    ;BOTTOM CHAMPIONS
        FCB     @300
        FCB     @077            ;YELLOW PLAYER 1 ON H.S.T.D. TABLE
        FCB     @300
        FCB     @350            ;LT BLUE PLAYER 2 ON H.S.T.D. TABLE
NULL    FCB     @000
        FCB     @000
        FCB     @000
        FCB     @000
        FCB     @000
        FCB     @000
        FCB     @000
        FCB     @000
        FCB     @000
        FCB     @000
        FCB     @000
        FCB     @000
        FCB     @000
        FCB     @000
        FCB     @000
        FCB     @000
;*
;*       MARKETING MESSAGES
;*
MARKET  PCNAP   4               ;EMPTY BUFFERS
        LDA     #30             ;TIME OUT (IN SECONDS) FOR THIS MESSAGE PAGE
        STA     PRAM,U
        JSR     SCCLR           ;CLEAR THE SCREEN
        LDX     VCOLOR1         ;LOAD COLOR TABLE
        JSR     VDCOLOR
        JSR     DCREDIT         ;DISPLAY CREDITS
        LDA     #ATX9           ;ASSUME CREDITS FOR 1 PLAYER
        LDB     CREDIT          ;CHECK HOW MANY CREDITS THERE ARE
        DECB
        BEQ     .10S            ; BR=1 CREDIT
        LDA     #ATX10          ;O.K. TO PLAY TWO PLAYERS
.10S    JSR     TEXT
.20S    PCNAP   60
        DEC     PRAM,U          ;WATCH FOR TIME OUT
        BNE     .20S
        JMP     HSTD
;*
;*      SOUND OF INCREMENTING NUMBER OF CREDITS
;*       (TO BE DISPLAYED LATER)
;*
SCREDIT LDX     #SNCRED         ;MAKE A CREDITS SOUND
        JSR     VSND
        INC     CRDCHG          ;INDICATE A COIN CHANGED CREDITS
;*
;*      DISPLAY NUMBER OF CREDITS
;*
DCREDIT LDY     #$1200          ;CLEAR CREIDT AREA
DCRE2   LDD     #$37E2
        LDX     #CRDLEN
        JSR     GENDMA
        LDD     #MSCRED*256+$22
        LDX     #$38E3          ;SCREEN ADDRESS
        JSR     OUTPHR
        LDA     CREDIT          ;REMEMBER LAST CREDIT VALUE
        BITA    #$F0            ;SURPRESS LEADING ZERO
        BNE     .1S
        ORA     #$F0
.1S     JMP     OUTBCD          ;DISPLAY NBR
;*
CRDLEN  FDB     $1F09
;*
;*      MONITOR THE GAME START SWITCHES
;*
GSTART  PKILL   $48,$FF         ;STOP COPIES OF ITSELF
.4S     PCNAP   1
        LDA     CRDCHG          ;HAVE CREDITS CHANGED?
        BLE     .41S            ; BR=NO
        CLR     CRDCHG
        PKILL   $00,$00         ;STOP ALL OTHER ATTRACT MODE PROCESSES
        PROCCR  MARKET,$30
.41S    LDB     WPIAA
        ANDB    #$30            ;PLAYER 1 OR 2 PRESSED?
        BEQ     .4S             ; BR=NO
        LDX     #COINSL         ;INFINITE FREE PLAY??
        JSR     RCMSA
        CMPA    #$09            ; (CODE FOR FREE PLAYS)
        BEQ     .1S             ; BR=YES
        LDA     CREDIT          ;ANY CREDITS LEFT?
        BEQ     .4S             ; BR=NO
        CMPA    #$02            ;ENOUGH FOR A 2 PLAYER GAME?
        BHS     .3S
        BITB    #$10            ;ONLY CREDITS FOR1 PLAYER, A 2 PLAYER GAME?
        BNE     .4S             ; BR=YES, IGNORE REQUEST
.3S     BITB    #$10            ;2 PLAYER GAME?
        BEQ     .2S             ; BR=NO, MUST BE 1 PLAYER GAME
        ADDA    #$99
        DAA
.2S     ADDA    #$99            ;       1 LESS CREDIT
        DAA
        STA     CREDIT          ;NEW CREDITS LEFT
        LDX     #CREDST         ;REMEMBER IN CMOS FOR FUTURE POWER-UP
        JSR     WCMSA
.1S     LDA     #8              ;ASSUME BOOKS SINGLE PLAYER START
        CLR     NPLYRS          ;ASSUME 1 PLAYER GAME
        BITB    #$10            ;2 PLAYER GAME
        BEQ     GAM1P           ; BR=1 PLAYER GAME
        LDA     #9              ;ASSUME BOOKS DUAL PLAYER START
        INC     NPLYRS          ;2 PLAYER GAME
        LDB     #10             ;BOOKS, NBR OF CREDITS STARTED (TOTAL 2)
        JSR     AUDIT1
GAM1P   TFR     A,B             ;GET AUDIT OFFSET IN REG.B
        JSR     AUDIT1
        LDB     #10             ;BOOKS, NBR OF CREDITS STARTED
        JSR     AUDIT1
        LDX     #NSHIP          ;NUMBER OF LIVES FOR THE PLAYER(S)
        JSR     RCMSB
        JSR     BCDHX           ;BCD TO HEX CONVERT
        STB     NLIVES
        CLR     GOVER           ;RESET TO TRUE GAME OVER
        PKILL   $00,$00         ;KILL EVERYONE
        LDA     #$30
        STA     PID,U           ;LEDGE REFRESH ROUTINE WILL BE ID=30
        LDX     #SNGS           ;GAME STARTING SOUND
        JSR     VSND
SIM1A   PCNAP   4               ;WAIT UNTIL BUFFERS ARE EMPTY
        JSR     SCCLR
        LDX     VCOLOR1         ;LOAD COLOR TABLE
        JSR     VDCOLOR
     IF DEBUG
        LDX     #$10F9
        LDD     #MSCOPY*256+$11
        JSR     OUTPHR          ;COPY RIGHT MESSAGE
      ELSE
        LDU     #MSCOP2         ;ALTERNATE HIDDEN COPYRIGHT MESSAGE
        LDX     ,U++            ;START LOCATION
        LDD     ,U++            ;START LETTER & COLOR
.80S    SUBA    #HIDE2
        EORA    #HIDE
        JSR     OUTCHR
        LDA     ,U+
        BNE     .80S
     ENDIF
;*
;*      INITILIZE SOME VARIABLES
;*
        LDU     PEXEC
        LDX     #SPLY1          ;CLEAR PLAYER 1 & 2 SCORE AREA
.10S    CLR     ,X+
        CMPX    #SPLY2+10
        BLO     .10S
;********       LDD     #0
;********       STD     SPLY1+0         CLEAR SCORE, PLAYER 1
;********       STD     SPLY1+2
;********       STD     SPLY1+4         CLEAR NUMBER OF LIVES A PLAYER HAS
;********       STD     SPLY1+6         CLEAR AUX NBR OF LIVES & LEVPAS OFFSET
        CLR     EGGS1           ;RESET NUMBER OF EGG KILLED
;********       STD     SPLY2+0         CLEAR SCORE, PLAYER 2
;********       STD     SPLY2+2
;********       STD     SPLY2+4         CLEAR NUMBER OF LIVES A PLAYER HAS
;********       STD     SPLY2+6         CLEAR AUX NBR OF LIVES & LEVPAS OFFSET
        CLR     EGGS2           ;RESET NUMBER OF EGG KILLED
;*
        CLR     NRIDER          ;RESET NUMBER OF RIDERS IN THE GAME
        LDX     #REPLAY         ;READ CMOS LEVEL PASS
        JSR     RCMSB
        CLRA                    ;JUSTIFY IT FOR SCOREING BOUNDS
        ASLB
        ROLA
        ASLB
        ROLA
        ASLB
        ROLA
        ASLB
        ROLA
        STD     LEVPAS          ;SAVE IT FOR FUTURE USE
        STD     SPLY1+8         ;SET LEVEL TO PASS FOR PLAYER 1
        STD     SPLY2+8         ;SET LEVEL TO PASS FOR PLAYER 2
;*
        LDX     #GA1            ;GET GAME ADJUST
        JSR     RCMSA
        CLR     ,-S             ;EXTRA RAM FOR START OFFSET
        CMPA    #3              ;GAME ADJUST 0,1,2,3 ?
        BLS     .1S             ; BR=NO
        INC     ,S
        CMPA    #6              ;GAME ADJUST 4,5,6?
        BLS     .1S             ; BR=NO
        INC     ,S
.1S     LDX     #DYTBL          ;ROM INITILIZATION
        LDY     #DYNADJ         ;RAM AREA
.2S     LDB     ,S              ;START VALUE OFFSET
        ASLB
        LDD     B,X
        STD     ,Y
        LDA     #2
        STA     2,Y
        LEAX    DYWLEN,X
        LEAY    3,Y
        CMPX    #DYEND
        BLO     .2S
;*
        LDA     #4              ;INITILIZE GRAVITY
        STA     GRAV
        LDA     #3
        STA     TBRIDGE         ;WAVE NBR TO DESTROY BRIDGE
        LDA     #1              ;NUMBER OF WAVES AFTER BRIDGE DESTROY TILL TROLL
        STA     TTROLL          ; COMES OUT IN THE OPEN
        STA     EMYTIM          ;ENEMY SLOW DOWN TIME
        LDA     #90             ;1 1/2 SECOND OF DELAY BEFORE TARGETING PLAYER
        STA     TARTIM
        CLR     LAVNBR          ;NO LAVA TROLLS IN BEGINNING
        LDA     #$EA            ;START LEVEL OF LAVA FOR BUBBLING LAVA ROUTINE
        STA     SAFRAM
        LDA     #13             ;NARROWER TRANSPORTER SAFTY ZONE 2ND PTE WAVE
        STA     TRSMALL
        LDD     #0
        STD     CURTR1          ;FREE UP ALL TRANSPORTERS
        STD     CURTR3          ; TR1 TO TR4
        STD     TARPLY          ;RESET TARGETED PLAYER(S)
        STD     TARPL2
        STD     NPSERV          ;& LPSERV, RESET TRANSPORTER "TAKE A NUMBER"
        STD     NESERV          ;& LESERV, RESET TRANSPORTER "TAKE A NUMBER"
        CLR     WPTER           ;PRESENT NBR OF PTERODACTYLS OF PTERO-WAVE
        CLR     NSMART          ;NO ONE WAS SMART
        CLR     NENEMY          ;NO ENEMIES ARE ON THE SCREEN
;*
;*      GENERATE BACKGROUND LANDING & COLISION TABLES
;*
        LDX     #BCKXD1         ;GENERATE BACKGROUND COLISION TABLE AREA
BCKXUP  LDD     BCKXS1-BCKXD1,X
        STD     ,X++
        CMPX    #BCKXD2
        BLO     BCKXUP
;*
        PCNAP   1
        LDX     #LNDXD1         ;GENERATE BACKGROUND LANDING TABLE AREA
LNDXUP  LDA     LNDXS1-LNDXD1,X
        ORA     #$20            ;FOR NOW, CLIFF 5 LANDS AT ALL POINTS
        STA     ,X+
        CMPX    #LNDXD2
        BLO     LNDXUP
;*
;*      PUT UP THE BACKGROUND
;*
BCKUP
        JSR     VNEWCL5         ;UN-COMPACT CLIF5
        PCNAP   1
        LDY     #BRIDGE         ;BRIDGE THE LAVA
        JSR     BCKYUP
        LDD     ,Y              ;NEW DMA CONTROL INFORMATION
        STD     ,X
        LDY     #BRIDG2         ;2ND HALF OF THE BRIDGE FOR THE LAVA
        JSR     BCKYUP
        LDD     ,Y              ;NEW DMA CONTROL INFORMATION
        STD     ,X
        LDA     GOVER           ;GAME SIMULATION?
        BGT     .20S            ; BR=YES
        LDU     #CLIF1L         ;PUT UP ALL OF THE BACKGROUND MANNUALLY
.10S    LDY     ,U++            ;WRITE THIS BCKGND BLOCK
        JSR     BCKYUP          ;WRITE THIS OBJECT
        CMPU    #CLIF5
        BLO     .10S
;*
        PCNAP   2               ;ALLOW CLIFFS TO APPEAR UPON SCREEN
        DEC     GOVER           ;STATE OF GAME = STARTING THE GAME (.NE.)
        SECCR   CIA,$11         ;CIA WILL BE I.D $11
.20S    SECCR   OPPCOL,$20      ;CREATE OPPONENTS COLISION DETECT ROUTINE
;*
        PROCCR  PLAYR,PLYID     ;CREATE PLAYER #1
        LDD     OSTRICH         ;START HORSE (OSTRICH)
        STD     PHORSE,Y
        CLR     PFACE,Y         ;PLAYER IS FACING RIGHT
        LDX     #100            ;START X POSITION
        STX     PPOSX,Y
        LDX     #G1DEC          ;ASSUME GAME SIMULATION
        LDA     GOVER           ;GAME SIMULATION?
        BGT     .30S            ; BR=YES
        LDX     #P1DEC
.30S    STX     PDECSN,Y        ;PLAYER 1'S JOYSTICK
        LDA     NLIVES          ;NBR OF LIVES FOR THIS PLAYER
        JSR     PLYRUP
        LDA     NPLYRS          ;CREATE PLAYER #2?
        BEQ     NOPLY2          ; BR=NO
        PROCCR  PLAYR,PLYID     ;CREATE PLAYER #2
        LDD     STORK           ;START HORSE
        STD     PHORSE,Y
        LDB     #$FF            ;OSTRICH & RIDER ARE FACEING LEFT
        STB     PFACE,Y
        LDX     #200            ;START X POSITION
        STX     PPOSX,Y
        LDX     #G2DEC          ;ASSUME GAME SIMULATION
        LDA     GOVER           ;GAME SIMULATION?
        BGT     .40S            ; BR=YES
        LDX     #P2DEC
.40S    STX     PDECSN,Y        ;PLAYER 2'S JOYSTICK
        LDA     NLIVES          ;NBR OF LIVES FOR THIS PLAYER
        JSR     PLYRUP
        PCNAP   8
NOPLY2  PROCCR  PLYCOL,$20      ;CREATE PLAYERS COLISION DETECT ROUTINE
        LDX     VLAVA           ;START LAVA PROCESS
        LDD     #$68FF          ;I.D. $68 SECONDARY PROCESS
        JSR     VCUPROC         ; CREATE THE LAVA BUBBLING PROCESS
     IF DEBUG = 0                                                               ;;Fixme was: IFE DEBUG
        SECCR   KZAP,$23
     ENDIF
        SECCR   SCODSP,$21      ;PLAYER 1'S SCORE UPDATE
        LDD     #SCRPL1
        STD     PRAM,Y
        LDA     NPLYRS          ;2 PLAYER GAME?
        BEQ     NOSPL2          ; BR=NO
        SECCR   SCODSP,$22      ;PLAYER 2'S SCORE UPDATE
        LDD     #SCRPL2
        STD     PRAM,Y
NOSPL2  EQU     *
        LDA     GOVER           ;GAME SIMULATION?
        LBGT    SIM2A           ; BR=YES
     IF DEBUG = 0                                                               ;;Fixme was: IFE DEBUG
        PCNAP   2
        JSR     JZAP
     ENDIF
        PROCCR  THORSE,$6F
;*
;*      REFRESH BACKGROUND LEDGES
;*
        LDA     #$FF            ;SECONDARY PROCESS
        STA     PID,U
LEDGE   CLR     PRAM,U          ;START IMAGE TO REFRESH(IF ANY)
        CLR     PRAM+2,U        ;START CLIFF BIT
        CLR     BCKRFS          ;NOTHING TO REFRESH IN THE BEGINNING
NOBCKR  PCNAP   2
        LDA     BCKRFS          ;ANY BACKGROUND TO REFRESH?
        BEQ     NOBCKR
;*
        LDD     PRAM+1,U        ;GET CLIFF OFFSET (REG.A), & CLIFF BIT REG.B
BCKNBT  ADDA    #2              ;NEXT CLIFF
        ASLB
        BNE     BCKN0
        INCB
        CLRA
BCKN0   BITB    BCKRFS          ;THIS CLIFF BIT TO REFRESH??
        BEQ     BCKNBT          ; BR=NO
        STD     PRAM+1,U        ;SAVE NEW CLIFF BIT & OFFSET BEING REFRESHED
        EORB    BCKRFS
        STB     BCKRFS          ;TURN THIS CLIFFS REFRESH BIT OFF
        LDY     [PRAM,U]        ;GET CLIFF ADDRESS
        LEAY    2+6-2,Y         ;POINT PAST COLISION DETECT & FULL OBJ SIZE
        BSR     BCKYUP          ;WRITE THIS OBJECT
        LDB     PRAM+2,U        ;GET REFRESHEING BIT
        BPL     NOBCKR          ;BR=NOT REFRESHING CLIFF5 (THE BIG ONE)
        PCNAP   1
        LDY     CLIF5           ;GET CLIFF5 LEFT SIDED ADDRESS
        LEAY    2+6-2+6,Y       ;POINT PAST COLISION DETECT & FULL OBJ SIZE
        BSR     BCKYUP          ;WRITE THIS OBJECT
        PCNAP   1
        LDY     CLIF5           ;GET CLIF5 RIGHT SIDED ADDRESS
        LEAY    2+6-2+6+6,Y     ;POINT PAST COLISION DETECT & FULL OBJ SIZE
        BSR     BCKYUP          ;WRITE THIS OBJECT
        BRA     NOBCKR          ;LOOP FOREVER
;*
;*      PUT UP BACKGROUND, POINTED TO BY REG.Y
;*
BCKYUP  LDB     WCLENY,Y                ;CALC LOWEST POINT
        EORB    #4                                                              ;;Fixme was: !WDMAFIX
        ADDB    WCY,Y
        JSR     VWR1ALL
        LDA     #$0A            ;WRITE THE BACKGROUND OBJECT
        STA     WCDMA,X
        LDD     WCDEST,Y
        STD     WCDEST,X
        LDD     WCSRC,Y
        STD     WCSRC,X
        LDD     WCLEN,Y
        STD     WCLEN,X
        RTS
;*
BRIDGE  FDB     $1200+LIB*$11,0,$00D3,$1B03!DMAFIX                              ;;Fixme was: !XDMAFIX
BRIDG2  FDB     $1200+LIB*$11,0,$78D3,$1E03!DMAFIX                              ;;Fixme was: !XDMAFIX
;*
     IF DEBUG = 0                                                               ;;Fixme was: IFE DEBUG
;*
;*      AND THE EVER POPULAR COPYRIGHT MESSAGE
;*
        FCC     'JOUST (C) 1982 WILLIAMS ELECTRONICS '
     ENDIF
        FCB     $20     ;A DO NOTHING
        FCB     $99     ;FUDGE TO MAKE THIS PROM ($6000) ADD UP TO $85
        FCB     $67     ;FUDGE FOR LZAPPER TO SUM CORRECTLY
        FCB     $09     ;FUDGE TO ADJUST BACK TO THE $6000 SUM OF $85
;*
;*      PTERODACTYL INTELLIGENCE
;*
PTERO   DEC     PPVELX,U        ;TIME TO ZOOM IN ON THE PLAYER?
        BNE     .47S            ; BR=NO
        LDA     PFEET,U
        STA     PPVELX,U        ;INITIALIZE NEXT LOOK-AT-PLAYER TIME
        CLR     PRDIR,U         ;ASSUME NO SELECTED PLAYER
        JSR     SELPLY          ;SELECT TARGETED PLAYER
        LBEQ    PTELEV          ; BR=NO PLAYERS AVAILABLE
        LDA     PFEET,U
        CMPA    #15             ;MINIMUM TIME TO LOOK-AT-PLAYER
        BLS     .48S
        DEC     PFEET,U
.48S    LDD     PPOSX,X         ;SAVE HIS CO-ORDINATES
        STD     PDIST,U
        LDB     PPOSY+1,X
        CMPB    #$D3-1          ;NEVER SEEK HIM BELOW CLIFF5
        BLO     .98S
        LDB     #$D3-1
.98S    SUBB    #5              ;ADJUSTMENT FOR CENTER OF BIRD/PTERODACTYL
        JSR     PATCH4          ;PTERODACTYL BETTER KILLER (AIM LOWER)
;********       STB     PRDIR,U         X=PDIST, Y=PRDIR
.47S    LDB     PRDIR,U         ;GET VICTIMS Y POSITION
        BEQ     PTELEV          ; BR=NO VICTIM
        CMPB    PPOSY+1,U
        LBLO    PTEUP           ; BR=GO UP
        SUBB    #15             ;PART OF PATCH4 (ALSO AIM HIGHER)
;********       SUBB    #15
        CMPB    PPOSY+1,U
        LBHI    PTEDN           ; BR=GO DOWN
        LDA     #128            ;ATTACK SEQUENCE TIME-OUT TIME.
        JSR     PATCH5          ;PTERODACTYL, SLOW DOWN TO KILL PLAYER
;********       STA     PEGG,U
        LDX     #SNPTE          ;PTERODACTYL CALL
        JSR     VSND
        LDD     #PTEATK
        STD     PJOY,U
;*
PTEATK
        JSR     PATCH9
;********       DEC     PEGG,U          ATTACK SEQUENCE TIME OUT?
        BEQ     .3S             ; BR=YES
        LDD     PDIST,U         ;WITHIN ATTACK X WINDOW?
        SUBD    PPOSX,U
        BMI     .1S
        SUBD    #13
        BPL     .2S             ; BR=NO
        BRA     .3S             ;YES, SELECT NEXT VICTUM
.1S     ADDD    #13
        BMI     .2S             ; BR=NO
.3S     LDD     #PTERO          ;HERE IF ENDING ATTACK SEQUENCE
        STD     PJOY,U
        CLR     PRDIR,U         ;NO LONGER CHASE AFTER PLAYER
        CLRB
        JMP     PTEDIR
;*
.2S     LDA     PIMAGE,U        ;ATTACKE FRAME?
        CMPA    #FLY3-FLY1
        BNE     .20S
        LDA     #10
        STA     PACCX,U         ;STAY ON ATTACK FRAME
.20S    LDA     PPOSY+1,U       ;STAY ON CENTER LINE, (OF THE PLAYER)
        CMPA    PRDIR,U
        BEQ     PTEALE          ;ATTACKING, LEVEL FLIGHT
        BLO     PTEADN          ;ATTACKING, GO DOWN
        LDA     PVELY,U         ;NEED TO GO UP, ALREADY GOING UP?
        BMI     .21S            ; BR=YES, NOT TIME TO GO UP YET
        LDD     PVELY,U
        SUBD    #$0010
        STD     PVELY,U         ;GO UP
.21S    BRA     PTEDIR
;*
PTEADN  LDA     PVELY,U         ;NEED TO GO DOWN, ALREADY GOING DOWN?
        BGT     PTEDIR          ; BR=YES, NOT TIME TO GO DOWN YET
        LDD     PVELY,U
        ADDD    #$0010
        STD     PVELY,U         ;GO DOWN
        BRA     PTEDIR
;*
PTEALE  CLR     PVELY,U         ;NO NEED TO GO UP/DOWN
        BRA     PTEDIR
;*
PTELEV  LDA     #AOFFL1-2       ;ASSUME NEAR TRACKING LINE 1
        LDB     PPOSY+1,U
        CMPB    #AOFFL1+AOFFUD
        BLO     .10S            ; BR=TRACK ON LINE 1
        LDA     #AOFFL2-2       ;ASSUME NEAR TRACKING LINE 2
        CMPB    #AOFFL2+AOFFUD
        JSR     PATCH6          ;ZOOM INBETWEEN  CLIF3U & CLIF3L,CLIF3R
        NOP
;********       BLO     .10S             BR=TRACK ON LINE 2
;********       LDA     #AOFFL3-2       ASSUME NEAR TRACKING LINE 3
.10S    SUBA    PPOSY+1,U       ;ABOVE OR BELOW LINE?
        BEQ     .30S
        BMI     .20S            ;BR=ABOVE THE LINE
        LDD     PVELY,U
        CMPD    #$0100
        BGE     PTEDIS
        ADDD    #$0020
        STD     PVELY,U
        BRA     PTEDIS
;*
.20S    LDD     PVELY,U
        CMPD    #-$0100
        BLE     PTEDIS
        SUBD    #$0020
        STD     PVELY,U
        BRA     PTEDIS
;*
.30S    LDD     PVELY,U
        ASRA
        RORB
        ASRA
        RORB
        STD     PVELY,U
;*
PTEDIS  TST     PBUMPX,U
        BEQ     .30S
        BMI     .20S
        LDA     #4
        BRA     .10S
;*
.30S    LDA     #4              ;ASSUME GOING RIGHT
        TST     PVELX,U         ;MAINTAIN SLOWER VELOCITY!
        BPL     .10S            ; BR=GOING RIGHT
.20S    LDA     #-4             ;REALLY GOING LEFT
.10S    STA     PVELX,U         ;SPEED
        STA     PFACE,U         ; & FACING DIRECTION
        LDD     #0
        STD     CURJOY
        RTS
;*
PTEDIR  LDA     PFACE,U         ;FLY IN DIRECTION OF FACING
        STA     PVELX,U
        TST     PBUMPX,U
        BEQ     .30S
        BMI     .20S
        LDA     #4*2
        BRA     .10S
;*
.30S    LDA     #4*2            ;ASSUME GOING RIGHT
        TST     PVELX,U         ;MAINTAIN SLOWER VELOCITY!
        BPL     .10S            ; BR=GOING RIGHT
.20S    LDA     #-4*2           ;REALLY GOING LEFT
.10S    STA     PVELX,U         ;SPEED
        STA     PFACE,U         ; & FACING DIRECTION
        LDD     #0
        STD     CURJOY
        RTS
;*
PTEUP   LDD     PVELY,U
        CMPD    #-$00C0
        BLE     PTEDN2
        ADDD    #-$0040         ;DO NOT GO UP TOO FAST
        STD     PVELY,U         ;DO NOT GO UP TOO FAST
PTEDN2  LDD     #PTEUP2
        STD     PJOY,U
        LDA     #2              ;WING DOWN TIME
        STA     PJOYT,U
        BRA     PTEDIS
;*
PTEUP2  DEC     PJOYT,U
        BGT     PTEDIS
        LDD     #PTERO
        STD     PJOY,U
        BRA     PTEDIS
;*
PTEDN   LDD     PVELY,U
        CMPD    #$0100
        BGE     PTEDN2
        ADDD    #$0010
        STD     PVELY,U          ;DO NOT GO DOWN TOO FAST
        BRA     PTEDN2
;*
;*      AUTO MATIC REMOVAL OF PTERODACTYL
;*
PTEOFF  LDD     PPOSX,U         ;OFF SCREEN?
        CMPD    #ELEFT+3
        BLT     PTEGON
        CMPD    #ERIGHT-3
        BGT     PTEGON
        LDA     #AOFFL1-2       ;ASSUME NEAR TRACKING LINE 1
        LDB     PPOSY+1,U
        CMPB    #AOFFL1+AOFFUD
        BLO     .10S            ; BR=TRACK ON LINE 1
        LDA     #AOFFL2-2       ;ASSUME NEAR TRACKING LINE 2
        CMPB    #AOFFL2+AOFFUD
        BLO     .10S            ; BR=TRACK ON LINE 2
        LDA     #AOFFL3-2       ;ASSUME NEAR TRACKING LINE 3
.10S    SUBA    PPOSY+1,U       ;ABOVE OR BELOW LINE?
        BEQ     .30S
        BMI     .20S            ;BR=ABOVE THE LINE
        LDD     PVELY,U
        CMPD    #$0100
        BGE     .11S
        ADDD    #$0020
        STD     PVELY,U
.11S    JMP     PTEDIR
;*
.20S    LDD     PVELY,U
        CMPD    #-$0100
        BLE     .21S
        SUBD    #$0020
        STD     PVELY,U
.21S    JMP     PTEDIR
;*
.30S    LDD     PVELY,U
        ASRA
        RORB
        ASRA
        RORB
        STD     PVELY,U
        JMP     PTEDIR
;*
PTEGON  JSR     CPLYR           ;ERASE PLAYER FOR THE LAST TIME
        LDA     #$7F            ;NO LONGER COLIDE WITH PTERODACTYL
        ANDA    PID,U
        STA     PID,U
        PCNAP   60
        JMP     VSUCIDE
;*
;*      THE INTELLIGENCE OF A KILLED PTERODACTYL
;*
PTEKLP  LDB     #FLY2-FLY1
        STB     PIMAGE,U
        JSR     SRCADP
        PCNAP   4
        BRA     PTEKL2
;*
PTEKLL  COM     PFACE,U
        LDA     PCHASE,U        ;KILLED A BAITER?
        BEQ     PTEKL2
        DEC     NBAIT
        JSR     PATC10
;********       CLR     PCHASE,U
PTEKL2  JSR     CPLYR           ;ERASE THE PTERODACTYL
        LDB     #FLY3-FLY1
        STB     PIMAGE,U
        JSR     SRCADP
        PCNAP   4
        JSR     CPLYR           ;ERASE THE PTERODACTYL
        LDA     PJOYT,U
        ANDA    #~$03           ;FACE RIGHT 1/2 WAY THROUGH THE DEATH DANCE     ;;Fixme was: ANDA  #!N$03
        BNE     .10S
        CLR     PFACE,U
.10S    DEC     PJOYT,U         ;TIME OUT?
        BPL     PTEKLP
;*
        LDA     #3              ;3 FRAME ANIMATION
        STA     PFRAME+2,U
        LDD     ASH1R           ;PTERODACTYL ASHES TO ASHES
        STD     PFRAME+3,U
.20S    LDY     PFRAME+3,U
        BSR     PTEASH
        PCNAP   2
        LDY     PFRAME+3,U
        BSR     PTEASH
        STY     PFRAME+3,U      ;we must maintain our why
        PCNAP   6               ;while we sleep a little
        DEC     PFRAME+2,U
        BNE     .20S
        JSR     CPLYR           ;ERASE THE PTERODACTYL
        LDD     #$1200          ; (THE ENTIRE BOX)
        STD     WCDMA,X
;*
        PCNAP   2               ;WAIT FOR ERASED PTERODACTYL
        LDD     #MSGTH1*256+($11*PTC)   ;PTERODACTYLE SCORE & COLOR
        STD     PRDIR,U
        JMP     SCRAIR
;*
;*
PTEASH  LDD     PPOSX,U         ;GET DESTINATION OF ANIMATION
        RORA
        RORB
        TFR     B,A
        LDB     PPOSY+1,U
        SUBB    #11-1           ;GO FROM BOTTOM OF PTERO TO TOP OF IT
;**PTE  SUBB    #13-1   11-1    ;       GO FROM BOTTOM OF PTERO TO TOP OF IT
        STD     PFRAME,U        ;Adjust destination for centering on cliffs
        JMP     CLIFER
;*
;*      PTERODACTYL (FOR A WAVE)
;*
PTERST  CLR     PCHASE,U        ;NOT A BAITER
;*
;*      BAITER PTERODACTYL (USER MUST PRESET PCHASE,U TO NON-ZERO)
;*
BAITST  LDA     PCHASE,U        ;SAVE THIS REGISTER
        LDB     #PPOSX          ;CLEAR OUT PTERODACTYLS WORKSPACE
.10S    CLR     B,U
        INCB
        CMPB    #PNBR
        BLO     .10S
        STA     PCHASE,U
;********CLR    PFACE,U         ASSUME BUZZARD COMING IN FROM LEFT HAND SIDE
        LDA     #2
        STA     PVELX,U         ;AT MAXIMUM WARP SPEED
        LDX     #ELEFT+1
        JSR     VRAND
        BCC     .1S
        COM     PFACE,U
        NEG     PVELX,U         ;AT REVERSED SPEED
        LDX     #ERIGHT-1
.1S     STX     PPOSX,U
        LDD     #0
        STD     AREA1           ;AREA2, FIND A CLEAR AREA TO APPEAR FROM
        CLR     AREA3
;********STD    PVELY,U         INITIAL Y VELOCITY
;********STD    PSTATE,U        FLYING STATE
;********STD    PPICH,U
;********STD    PPICR,U
        LDX     TARPLY          ;NEAR PLAYER1?
        BEQ     .2S             ; BR=NO PLAYER1
        JSR     SELARE
        LDX     TARPL2
        BEQ     .2S             ; BR=NO PLAYER2
        JSR     SELARE
.2S     LDX     #$D3-2          ;FOR BOTTOM CLIF5 AREA
        LDA     AREA3
        BEQ     .3S
        LDX     #$8A-10         ;FOR MIDDLE CLIF3 AREA
        LDA     AREA2
        BEQ     .3S
        LDX     #$51-20         ;FOR TOP CLIF1 AREA
.3S     STX     PPOSY,U
        LDD     #PTERO          ;INTELLIGENCE
        STD     PJOY,U
        LDX     #SNPTEI         ;PTERODACTYL INTRODUCTION CALL
        JSR     VSND
        LDA     #$80            ;ENABLE COLISIONS
        ORA     PID,U
        STA     PID,U
        LDA     #$80            ;A VERY HIGH LANTZ
        STA     PLANTZ,U        ; (TO KILL PLAYER)
;********CLR    PBUMPY,U        ;RESET BUMP REGISTERS
;********CLR    PBUMPX,U
        LDD     #P7DEC          ;THE 7TH INTELLIGENT PERSON IN THE GAME
        STD     PDECSN,U
;********CLR    PACCX,U         ;CHANGE ANIMATION FRAME NOW!
;********CLR    PIMAGE,U
;********CLR    PFRAME,U
        LDA     #120            ;2 SEC DELAY BETWEEN ATTACKS
        STA     PFEET,U
        LSRA                    ;1 SECOND WAIT TILL FIRST SEEK
        JSR     PATCH8
;********       STA     PPVELX,U
        CLR     PTIMUP,U        ;NEEDS TO BE DONE
        BRA     PTESTF
;*
;*      PTERODACTYL FLYING METHODS
;*
PTEFLY  PCNAP   1
        JSR     AIROVR          ;FLYING OVERHEAD
PTESTF  DEC     PACCX,U         ;DECREMENT FRAME HOLDING TIME
        BGT     .30S            ; BR=STILL THIS FRAME
        LDB     PFRAME,U        ;NEXT FRAME
        SUBB    #2
        BPL     .20S            ; BR=DO NOT RESET SEQUENCE
        LDB     #(4-1)*2        ;RESET SEQUENCE
.20S    STB     PFRAME,U
        LDX     #PTESEQ         ;GET MORE DATA FROM SEQUENCE TABLE OF FRAMES
        LDD     B,X
        STA     PIMAGE,U        ;NEW IMAGE TO SHOW
        STB     PACCX,U         ;TIME TILL NEXT FRAME CHANGE
.30S
;*
        LDX     #FLYXP          ;ADD IN BUMPX,Y; AND VELX,Y; NO GRAVITY!
        LDD     PVELY,U
        JSR     ADDGRX          ;ADD IN GRAVITY
        BSR     SRCADP
        BRA     PTEFLY
;*
;*      SOURCE ADDRESS FOR IMAGE CALCULATION
;*       AND WRITE THE BIRD
;*       AND CHECK IF HIT BACKGROUND
;*       PIMAGE,U HAS FRAME OFFSET
;*
SRCADP
        LDB     PIMAGE,U        ;GET IMAGE NBR
        LDA     PFACE,U         ;FACE OFFSET
        BPL     .1S
        ADDB    #6
.1S     LDX     IPTERO          ;CALCULATE PTERODACTYL FRAME OFFSET
        ABX
        STX     PPICH,U
        LDB     PPOSY+1,U       ;COLISION DETECT DATA
        CMPB    #$D3-1          ;MINIMUM POSITION IN THE Y DIRECTION
        BLO     .12S
        CLR     PVELY,U         ;STOP FALLING
        CLR     PVELY+1,U
        LDB     #$D3-1
        STB     PPOSY+1,U
.12S    STB     PCOLY1,U        ;MAINTAIN BOTTOM LINE OF COLISION BOX
;**PTE  SUBB    #11-1           ;MAINTAIN TOP LINE OF COLISION BOX
        SUBB    #11-1           ;MAINTAIN TOP LINE OF COLISION BOX
        STB     PCOLY2,U
        LDD     PPOSX,U
        ADDD    #28-1
        STD     PCOLX,U         ;MAINTAIN COLISION DETECT POINTERS
        JSR     WNORIA          ;WRITE THE BIRD ONLY!
        LDA     NRIDER          ;WAVE OVER?
        BEQ     .48S            ; BR=YES
        LDA     DBAIT           ;BAITERS SHOULD REMOVE THEMSELVES?
        BEQ     .49S            ; BR=NO
        LDA     PCHASE,U        ;IS THIS A BAITER?
        BEQ     .49S            ; BR=NO
        CLR     PCHASE,U        ;NO LONGER A BAITER
        DEC     NBAIT           ;BUT, KEEP TABS ON 1 LESS BAITER
      IF DEBUG <> 0     ;???????????? DEBUG PARAMATER ?????????                 ;;Fixme was: IFN DEBUG
        BPL     .47S
        SWI
.47S
      ENDIF                     ;???????????? END OF DEBUG ????????????

.48S    LDD     PJOY,U          ;ALREADY IN AUTO OFF ROUTINE?
        SUBD    #PTEOFF
        BHS     .49S            ; BR=YES
        LDD     #PTEOFF         ;NO, END ALL PTERODACTYLS
        STD     PJOY,U
.49S
;*
;*      CHECK IF PTERODACTYL HIT BACKGROUND
;*
CKPTER  LDX     PPOSX,U
        LDY     PPOSY,U
        LDA     BCKXTB,X
;**PTE  ORA     BCKXTB+6,X
        ORA     BCKXTB+28-18,X
        ANDA    BCKYTB+6,Y
;**PTE  ANDA    BCKYTB+7,Y      CLIFF COLISION AREA
;********       TFR     A,B
;********       ORB     BCKRFS          REFRESH CLIFF AREA
;********       STB     BCKRFS
        ANDA    BCKYTB+7,Y
        BEQ     .1S
        JMP     BCKCOL          ;COLIDE WITH BACKGROUND
.1S     RTS
;*
;*      PTERODACTYLS FLYING ANIMATION SEQUENCE
;*
PTESEQ  FCB     FLY1-FLY1,8
        FCB     FLY2-FLY1,8
        FCB     FLY3-FLY1,8
        FCB     FLY2-FLY1,8
;*
;*      PTERODACTYLS X VELOCITY TABLE
;*
        FDB     -$0300
        FDB     -$0180
        FDB     -$00C0
        FDB     -$0060
FLYXP   FDB     $0000
        FDB     $0060
        FDB     $00C0
        FDB     $0180
        FDB     $0300
     IF DEBUG = 0                                                               ;;Fixme was: IFN DEBUG
        FCB     $5F     ;JZAPPER FUDGE
     ENDIF
;*
;*      LAVA TROLL PART 1 - THIS IMAGE WILL BE BEHIND THE BIRD
;*                      THE HAND WILL COME UP FOLOWING THE PLAYER
;*                      THEN TRACK THE PLAYER IN THE Y DIRECTION,
;*                      UNTIL EITHER THE HAND MISSES OR GETS ITS TARGET.
;*
LAVATC  JSR     CLAVAT          ;ERASE LAVA TROLL
LAVAT1  JSR     LAVVFY          ;MAKE SURE TARGET STILL EXISTS
        STD     PPOSX,U         ;GOT HIS X POSITION
        LDA     PFRAME,U        ;GRAB FRAME ?
        DEC     PJOYT,U         ;TIME FOR NEXT FRAME?
        BGT     LT1TRK          ; BR=NO
        LDA     LAVTIM          ;RESET TIMER
        STA     PJOYT,U
        LDA     PFRAME,U        ;NEXT FRAME
        CMPA    #5*6            ;CURRENT FRAME HAND EXTENTED FRAME?
        BEQ     LT1HT           ; BR=YES
      IF DEBUG <> 0                                                             ;;Fixme was: IF DEBUG (Is this needed?)
        BLO     .1S
        SWI                     ;PROBLEMS HERE!!
        LDA     #5*6
        BRA     LT1HT
.1S
      ENDIF
        ADDA    #6
        STA     PFRAME,U
LT1TRK  JSR     WLAVAT          ;WRITE THE LAVA TROLL
        NAPGO   1,LAVATC        ;WAKE-UP AT CLEAR LOOP
;*
LT1HT   LDB     PPOSY+1,Y
        ADDB    #10-7           ;OFFSET FOR PROPER HAND GRIP
        CMPB    PPOSY+1,U
        BEQ     LT1GRP          ;GO GRAB THE PLAYER
        BHI     .1S             ;BR=HAND TOO HIGH GO DOWN
        DEC     PPOSY+1,U       ;RAISE THE HAND
        BRA     .2S
;*
.1S     INC     PPOSY+1,U
.2S     JSR     WLAVAT
        PCNAP   1
        JSR     CLAVAT
        JSR     LAVVFY          ;MAKE SURE TARGET STILL EXISTS
        STD     PPOSX,U         ;GOT HIS X POSITION
        BRA     LT1HT           ;LOOP UNTIL THE CORRECT HEIGHT
;*
;*      LAVA TROLL CAN GRIP THE PLAYER
;*
LT1GRP  LDX     #SNTROL         ;MAKE THE SOUND OF THE LAVA TROLL
        JSR     VSND            ; GRIPPING THE PLAYER
        LDD     PID,U           ;(& PPRI,U)CREATE PROCESS TO GRIP THE BIRD
        INCA                    ;LAVA TROLL GRAP I.D. = LAVA TROLL +1
        LDU     PLINK,U         ;GET VICTIMS WORKSPACE
        LDX     #ADDLAV         ;THE VICTIMS GRAVITY IS NOW BASED UPON
        STX     PADGRA,U        ; THE LAVA TROLLS GRAVITY
        LDX     #LAVAT2
        JSR     VCUPROC         ;HOLD THE BIRD IS AFTER THE VICTEM WORKSPACE
        LDU     PEXEC           ;GET WORKSPACE BACK
        LDD     PPOSX,U         ;TRANSFER POSITION TO NEW PROCESS
        STD     PPOSX,Y
        LDD     PPOSY,U
        STD     PPOSY,Y
        LDD     PJOY,U          ;GIVE THE VICTIM'S PROCESS ADDRESS
        STD     PJOY,Y
        STU     PDIST,Y         ;GIVE LAVAT2 LAVAT1'S PROCESS ADDRESS
        LDD     #0
        JSR     PATCH1          ;APPLY A LAVA TROLL PATCH
;*******        STD     PPICH,Y         RESET PICTURE AREA IN CASE OF PREMATURE CLEAR
.1S     PCNAP   2
        JSR     LAVVFY          ;MAKE SURE TARGET STILL EXISTS
        BRA     .1S             ;LOOP UNTIL SOMETHING HAPPENS
;*
;************************************
;*
;*      LAVA TROLL PULLING DOWN PLAYER (HANDLED IN PLAYER)
;*       ACTUALLY THE LAVA TROLL JUST FOLLOWS THE PLAYER DOWN
;*
LAV2LP  JSR     CLAVAT
LAVAT2  LDY     PPREV           ;NOW THE VICTIM IS BEFORE THIS ROUTINE
        JSR     LAVVI2          ;MAKE SURE TARGET STILL EXISTS
        BNE     LT2SUC          ; BR=OUT OF ITS HANDS
        LDX     PDIST,U         ;MAINTAIN POSITION IN LAVAT1
        STD     PPOSX,U         ;GOT HIS X POSITION
        STD     PPOSX,X
        LDD     PPOSY,Y
        ADDB    #-7+17          ;CORRECT HAND HOLD
        STD     PPOSY,U
        STD     PPOSY,X
        LDA     #6*6            ;FINAL HOLDING FRAME
        STA     PFRAME,U
        JSR     WLAVAT
        LDX     #LAV2LP
        LDA     #1              ;NAP 1
        JMP     PATCH2
;********       JMP     VNAPTIM
;*
LT2DIE  JSR     CLAVAT
LT2SUC  JMP     VSUCIDE
;*
;*      VICTIM WITHIN RANGE DETERMINATION.
;*       REG.D = TRACKING PPOSX
;*       STATUS - RETURNS IF IN RANGE
;*       STATUS - JMPS TO LAVATF ROUTINE IF OUT OF RANGE
;*
LAVVFY  BSR     LAVVIC          ;CHECK IF VICTIM IS STILL WITHIN RANGE
        BNE     LAVATF          ; BR=NO
        RTS
;*
;*      VICTIM WITHIN RANGE DETERMINATION.
;*       REG.D = TRACKING PPOSX
;*       STATUS .EQ. STILL WITHIN RANGE
;*       STATUS .NE. OUT OF RANGE
;*
LAVVIC  LDY     PLINK,U         ;IS PROCESS STILL THERE?
LAVVI2  CMPY    PJOY,U
        BNE     LVVOUT          ; BR=NO
LAVVI3  LDA     PID,Y           ;IS THE PROCESSES IMAGE STILL ALIVE
        BPL     LVVOUT          ; BR=NO
        LDA     PSTATE,Y        ;THIS OBJECT IS STILL IN THE AIR?
        BNE     LVVOUT          ; BR=NO
        LDA     PPOSY+1,Y       ;IS IMAGE TOO HIGH?
        CMPA    #FLOOR+7-32
        BLO     LVVOUT          ; BR=YES
        LDD     PPOSX,Y         ;OUT OF REACH LEFT SIDE
        ADDD    #-2             ;FUDGE FOR EXACT X CO-ORDINATE MATCH
        CMPD    #54-14
        BLE     LVVIN
        CMPD    #240            ;(CLIF5 BOUNDS)
        BLT     LVVOUT
LVVIN   ORCC    #$04            ;.EQ. IN RANGE
        RTS
;*
LVVOUT  ANDCC   #~$04           ;.NE. OUT OF RANGE (FOR ONE REASON OR ANOTHER)  ;;Fixme was: ANDCC  #!N$04
        RTS
     IF DEBUG = 0                                                               ;;Fixme was: IFE DEBUG
;*
;*      JZAP
;*
JZAP    LDX     JZAPST
        CLRA
.1S     ADDA    ,-X
        CMPX    #$D000
        BNE     .1S
        EORA    #$A1            ;JZAPPER DATA
        BEQ     .2S
        INC     LXPOS2+1
.2S     RTS
     ENDIF
;*
;*
;*      LAVA TROLL RELEASING HIS GRIP
;*              DROP HAND
;*
LAVATF  LDA     PFRAME,U        ;NEXT FRAME
        ADDA    #-6
        STA     PFRAME,U
        BLE     LT1DON          ; BR=OUT OF FRAMES
LT1DRP  JSR     WLAVAT          ;WRITE THE LAVA TROLL
        LDA     #5
        LDX     #LAVATC         ;WAKE-UP AT BEGINNINNG
        JMP     VNAPTIM
;*
LT1DON  DEC     LAVNBR          ;FREE UP LAVA TROLL(S)
        JMP     VSUCIDE
;*
;*      ERASE LAST "PPICH,U" LAVA TROLL IMAGE
;*
CEGG    EQU     *               ;CLEAR EGG ROUTINE
CLAVAT  LDY     PPICH,U         ;AND CLEAR LAVA TROLL ROUTINE
        BEQ     WLARTS
        CLR     PPICH,U
        CLR     PPICH+1,U
        JSR     CLREGY          ;ERASE THE IMAGE
        JMP     CLIPER          ;CLIP THE IMAGE (CLOSE TO THE BOTTOM)
WLARTS  RTS
;*
;*      WRITE "PFRAME,U" LAVA TROLL IMAGE
;*
WLAVAT  LDA     PFRAME,U
        SUBA    #6
        BMI     WLARTS          ;BR=NO LEGAL FRAME TO DISPLAY
        LDY     ILAVAT
        LEAY    A,Y
        STY     PPICH,U
        JSR     VWR1CLS
WLADMA  JSR     WRHOR2
        JMP     CLIPER          ;CLIP THE IMAGE (CLOSE TO THE BOTTOM)
;*
;*      THORSE
;*
THORSE  PCNAP   30
        LDD     #$2502          ;LEFT1,FLAP1,CREDIT1,RIGHT2
        BSR     .80S
        BNE     THORSE
.10S    BSR     .80S
        BEQ     .10S
        PCNAP   15              ;1/4 SECOND TILL NEXT SWITCH CLOSURES
        LDD     #$1204          ;RIGHT1,CREDIT2,FLAP2
        BSR     .80S
        BNE     THORSE
.15S    BSR     .80S
        BEQ     .15S
        PCNAP   15
        LDD     #$0506          ;LEFT1,FLAP1,RIGHT2,FLAP2
        BSR     .80S
        BNE     .10S
        JSR     SCCLR
        ORCC    #$FF
        LDD     #$00FF
        STD     $C000
      IF DEBUG <> 0                                                             ;;Fixme was: IFN DEBUG
        LDA     #ATX11+1
        JSR     TEXT
        BRA     .50S
      ENDIF
        LDU     #TROMSG
        LDX     #$1030
        PSHS    X
        LDB     #$11
.30S    LDA     ,U+
        EORA    #$9B
        SUBA    #$35
        BMI     .50S
        BEQ     .40S
        JSR     OUTCHR
        BRA     .30S
;*
.40S    LDX     ,S
        LEAX    $10,X
        STX     ,S
        BRA     .30S
;*
.50S    LDX     #14285/2                ;1/2 SEC DEBOUNCE
.55S    LDA     #WDATA
        STA     WDOG
        BSR     READEM
        SUBD    #$0506
        BEQ     .50S
        LEAX    -1,X
        BNE     .55S
      IF DEBUG <> 0                                                             ;;Fixme was: IFN DEBUG
        JMP     [$EFFE]
      ELSE
        JMP     [$FFFE]
      ENDIF
;*
.80S    STD     PRAM,U
        LDD     ,S++
        STD     PRAM+2,U
        PCNAP   1
        BSR     READEM
        TFR     D,X
        LDD     PRAM,U
        CMPX    PRAM,U
        JMP     [PRAM+2,U]
;*
READEM  LDA     #$08
        ORA     WCPIAB
        STA     WCPIAB
        LDA     WPIAA
        ANDA    #$37
        LDB     #~$08                                                           ;;Fixme was: LDB  #!N$08
        ANDB    WCPIAB
        STB     WCPIAB
        LDB     WPIAA
        ANDB    #$07
        RTS
;*
     IF DEBUG = 0                                                               ;;Fixme was: IFE DEBUG
JZAPST  FDB     $9000
     ENDIF
;*
;*
;*      Centrial Intelligence Agency
;*      INITILIZATION
;*
;*
CIA     CLR     WAVBCD          ;WAVE STARTS AT ZERO
        LDD     #WAVRTS
        STD     PWPREV,U        ;NO PREVIOUS WAVE TO COMPLETE
        LDD     #WAVTBL-WLEN
        STD     PWAVE,U
        LDA     #BAISND-BAISBL-1        ;RESET BAITER TIME TABLE
        STA     PBAITS,U
        PCNAP   32
        BRA     IWAVE2
;*
;*      INTER WAVE SET-UP & MESSAGES MAIN LOOP
;*
IWAVE   LDA     TRSMALL         ;SMALLER TRANSPORTER AREA?
        BEQ     .1S             ; BR=NO
        DEC     TRSMALL
.1S     LDX     #GA1            ;GET GAME ADJUST
        JSR     RCMSA
        STA     ,-S             ;EXTRA RAM FOR ADJUST OFFSET
        LDX     #DYTBL          ;ROM INITILIZATION
        LDY     #DYNADJ         ;RAM AREA
.2S     LDB     2,Y             ;TIME TO CHANGE THE VALUE?
        BEQ     .4S             ; BR=YES
        DEC     2,Y
        BNE     .15S            ; BR=NO
.4S     LDB     ,S              ;DIFFICULTY LEVEL
        ADDB    #DYWTIM*2       ;GET OFFSET FOR TIME TABLE
        ASRB                    ;GET BYTE OFFSET
        LDB     B,X             ;GET TIME BYTE
        BCS     .5S             ; BR=LOWER NIBBLE
        LSRB
        LSRB
        LSRB
        LSRB
.5S     ANDB    #$0F
        STB     2,Y             ;NEW TIME
        LDB     DYWINC,X
        SEX
        BMI     .6S
        ADDD    ,Y              ;NEW VARIABLE
        CMPD    DYWEND,X
        BLT     .8S
        BRA     .7S
;*
.6S     ADDD    ,Y              ;NEW VARIABLE
        CMPD    DYWEND,X
        BGT     .8S
.7S     LDD     DYWEND,X
.8S     STD     ,Y
.15S    LEAX    DYWLEN,X
        LEAY    3,Y
        CMPX    #DYEND
        BLO     .2S
        PULS    A               ;RESTORE STACK
;*
        LDA     SAFRAM          ;RASIE LAVA IF POSSIBLE
        CMPA    #$E0
        BLS     IWAVE2          ; BR=AT TOP LEVEL
        SUBA    #$5
        STA     SAFRAM
IWAVE2  LDA     TBRIDGE         ;TIME TILL BURNS YOUR BRIDGES BEHIND YOU
        BEQ     WTROLL
        DEC     TBRIDGE
        BNE     WNRM
        JSR     STBRID          ;START BRIDGE COLAPSING ROUTINE, LEFT TO RT.
        LDD     #-$20           ;START POSITION IN X DIRECTION
        STD     PDIST,Y
        LDA     #1              ;OFFSET FOR FLAME FROM LANDING TABLE
        STA     PVELX,Y
        LDA     #1              ;DIRECTION TO TRAVEL
        STA     PJOYT,Y
        JSR     STBRID          ;START BRIDGE COLAPSING ROUTINE RT. TO LEFT
        LDD     #$13F           ;START POSITION IN X DIRECTION
        STD     PDIST,Y
        LDA     #7              ;OFFSET FOR FLAME FROM LANDING TABLE
        STA     PVELX,Y
        LDA     #-1             ;DIRECTION TO TRAVEL
        STA     PJOYT,Y
        BRA     WNRM
;*
WTROLL  LDA     TTROLL          ;TIME TILL LAVE TROLL STARTS
        BEQ     WNRM
        DEC     TTROLL
        BNE     WNRM            ; BR=LAVA TROLL NOT AWAKE YET
         LDX    #LAVAF          ;LAVA FLAMES
         LDD    #$69FF
         LDU    PDUMMY          ;ENTER AS 2ND PROCESS IN TOTAL PROCESS LIST
         JSR    VCUPROC
        LDD     #FLOOR+16       ;START FLAME UNDER LAVA
        STD     PPOSY,Y         ; LEFT & RIGHT FLAME Y POSITION
        LDD     #ELEFT+30       ; LEFT FLAME X POSITION
        STD     PPOSX,Y
        CLR     PFRAME,Y
         LDX    #LAVAF          ;LAVA FLAMES
         LDD    #$69FF
         JSR    VCUPROC
         LDU    PEXEC
        LDD     #FLOOR+16       ;START FLAME UNDER LAVA
        STD     PPOSY,Y         ; LEFT & RIGHT FLAME Y POSITION
        LDD     #ERIGHT-30      ; RIGHT FLAME X POSITION
        STD     PPOSX,Y
        LDA     #2
        STA     PFRAME,Y
        LDA     #4              ;MAKE THIS FLAME OUT OF SYNC OF THE OTHER
        STA     PNAP,Y
WNRM    CLR     EGGS1           ;RESET NUMBER OF EGGS KILLED BY PLAYER 1
        CLR     EGGS2           ;RESET NUMBER OF EGGS KILLED BY PLAYER 2
        CLR     WSMART          ;RESET NUMBER OF ALLOWED SMART ENEMIES
      IF DEBUG <> 0     ;???????????? DEBUG PARAMATER ?????????                 ;;Fixme was: IFN DEBUG
        LDA     NSMART          ;THIS HAD BETTER BE ZERO!!!!!!!!!!
        BEQ     .41S
        SWI
.41S    LDA     NENEMY          ;THIS HAD BETTER BE ZERO!!!!!!!!!!
        BEQ     .42S
        SWI
.42S
      ENDIF                     ;???????????? END OF DEBUG ????????????
        LDA     #255
        STA     WENEMY          ;MAXIMIM ENEMIES FOR A NORMAL WAVE
        LDA     #1              ;NO ENEMY SLOW DOWN
        STA     EMYTIM
        CLR     PMSG0,U         ;RESET WAVE N MESSAGE SENT AREA
        CLR     PMSG1,U         ;RESET MESSAGE BUFFERS
        CLR     PMSG2,U
        CLR     PMSG3,U
        CLR     PMSG4,U
        CLR     PMSG5,U
        LDA     WAVBCD          ;BCD WAVE NUMBER
        ADDA    #$01            ; NEXT WAVE NUMBER 0-99
        DAA
        STA     WAVBCD
;*
;*      CLEAN UP THE END OF A WAVE
;*
        JSR     [PWPREV,U]      ;CALL END OF WAVE ROUTINE
        JSR     PATC11          ;CLEAN UP GLADIATOR WAVE
;********       JSR     EMSGS           ERASE ANY END OF WAVE MESSAGES
        PCNAP   1
        JSR     WAVEN           ;PUT UP WAVE NUMBER
        LDD     #WAVRTS
        STD     PWPREV,U        ;NO PREVIOUS WAVE TO COMPLETE
        LDX     PWAVE,U         ;GET WAVE TABLE ADDRESS
        LDA     WSTATUS,X       ;GET OLD CLIFF STATE
        LEAX    WLEN,X
        CMPX    #WTBEND         ;AT END OF TABLE??
        BLO     .1S
        LDX     #WTBRST         ;YES, RESTART AT NEW POINT
.1S     STX     PWAVE,U         ;NEW TABLE ADDRESS
        EORA    WSTATUS,X       ;ANY CLIFFS CHANGED?
        ANDA    #WBCLS          ;ALL CLIFFS; WBCL1+WBCL2+WBCL4
        BEQ     .4S
        LDB     WSTATUS,X       ;GET CORRECT STATE OF CLIFF
        LDX     #WCLFTB         ;CLIFF INFORMATION
        JSR     WCLFEW          ;CLIFF1L ERASE/WRITE ROUTINE
        LDX     #WCLFT2
        JSR     WCLFEW          ;CLIFF1R ERASE/WRITE ROUTINE
        LDX     #WCLFT3
        JSR     WCLFEW          ;CLIFF2 ERASE/WRITE ROUTINE
        LDX     #WCLFT4
        JSR     WCLFEW          ;CLIFF4 ERASE/WRITE ROUTINE
.4S     LDX     PWAVE,U         ;GET WAVE AREA TO WORK FROM
        LDA     WSTATUS,X       ;EARLY PERSUE?
        BITA    #WBPER
        BEQ     .44S            ; BR=NO
        LDA     WPERSUE,X       ;SET PERSUE VARIABLE
        ANDA    #$0F
        STA     WSMART
.44S    LDB     WSTATUS,X               ;CALL WAVE STARTER ROUTINE
        ANDB    #WBJSR0+WBJSR1+WBJSR2   ;MASK OFF OTHER BITS
        LDX     #WJSRTB         ;JSR TABLE
        JSR     [B,X]
WPAUSE  LDA     #180/6          ;WAIT A SECOND
WPAUS2  JSR     WAVDEL
        JSR     WATWAV          ;WAIT TILL END OF WAVE
WPAUS3  JSR     EMSGS           ;ERASE ALL MESSAGES
        LDA     [PWAVE,U]       ;INTRODUCE BOUNDARS
        LSRA
        LSRA
        LSRA
        LSRA
        BEQ     .2S             ;BR=NO BOUNDARS
        LDX     #P4DEC          ;(INTELLIGENCE)
        JSR     WCREATE         ;CREATE THEM
.2S     LDA     [PWAVE,U]       ;INTRODUCE BOUNDARS
        ANDA    #$0F
        BEQ     .3S             ;BR=NO BOUNDARS
        LDX     #P5DEC          ;(INTELLIGENCE)
        JSR     WCREATE         ;CREATE THEM
.3S     LDX     PWAVE,U
        LDA     WLORD,X         ;INTRODUCE SHADOW LORDS
        LSRA
        LSRA
        LSRA
        LSRA
        BEQ     .4S             ;BR=NO BOUNDARS
        LDX     #P6DEC          ;(INTELLIGENCE)
        JSR     WCREATE         ;CREATE THEM
.4S
WBEGIN  LDA     GOVER           ;IS THE GAME OVER?
        BEQ     .5S             ; BR=YES
        LDX     PWAVE,U
        LDA     WPERSUE,X       ;SET PERSUE VARIABLE
        ANDA    #$0F
        STA     WSMART
.5S     LDA     PBAITS,U        ;GET BAITERS TABLE DRIVEN TIME
        BEQ     .6S
        DEC     PBAITS,U
.6S     LDX     #BAISBL
        LDA     A,X             ;GET TIME TABLE START POSITION
        STA     PBAITN,U
        INCA
        ASLA
        LDX     #BAITBL
        LDD     A,X             ;BAITER INITIAL SLEEP TIME
        STD     CBAIT
        CLR     NBAIT           ;NUMBER OF BAITERS ON THE SCREEN
        CLR     DBAIT           ;NO BAITER DELAY
;*
;*      GAME PLAY - DETECT END OF WAVE, BAITER SENDOFF, INTELLIGENCE INCREMENT
;*
EMY2    LDA     #112            ;AFTER 15 SECONDS BUMP NBR OF INTELLIGENT PEOPLE
        STA     PDELAY,U
EMYOK   PCNAP   8
        LEAX    ,U
        LDA     NRIDER          ;ALL ENEMIES DEAD?
        LBEQ    IWAVE           ; BR=YES, END OF WAVE
        LDA     DBAIT           ;DELAY BAITERS?
        BEQ     .9S             ; BR=NO
        DEC     DBAIT           ;TIME TO DECREMENT BAITER CLOCK?
        BNE     .11S            ; BR=NO
.9S     LDD     CBAIT
        SUBD    #1
        BGT     .10S
        LDA     NBAIT
        CMPA    #3-1            ;ONLY ALLOW 3 BAITERS ON THE SCREEN
        BHI     .11S            ; BR=3 BAITERS ON SCREEN, BUT READY
        SECCR   BAITST,PTEID
        INC     NBAIT           ;1 MORE BAITER ON THE SCREEN
        LDA     #-1
        STA     PCHASE,Y        ;BAITER TYPE PTERODACTYL'S
        LDA     PBAITN,U
        BEQ     .100S
        DEC     PBAITN,U
.100S   ASLA
        LDX     #BAITBL
        LDD     A,X             ;BAITER INITIAL SLEEP TIME
.10S    STD     CBAIT
.11S    LDA     NENEMY          ;NBR OF ACTIVE ENEMIES >0 ???
        BEQ     EMYOK           ;BR=NO ACTIVE ENEMIES, SO NO DECREMENT
        DEC     PDELAY,U        ;SOMEONE IS ALIVE
        BNE     EMYOK
        LDA     GOVER           ;IS THE GAME OVER?
        BEQ     EMY2            ; BR=YES
        INC     WSMART
        BNE     EMY2
        DEC     WSMART
        BRA     EMY2
;*
;*      BAITER SEND OFF TIME TABLE
;*
BAITBL
;********       FDB     1*60/8          MAKE THE BAITER MORE FIERCE
;********       FDB     3*60/8
;********       FDB     5*60/8
;********       FDB     7*60/8
;********       FDB     15*60/8
;********       FDB     15*60/8
;********       FDB     15*60/8
;********       FDB     15*60/8
;********       FDB     15*60/8
;********       FDB     15*60/8
;********       FDB     15*60/8
;********BWAVN  FDB     30*60/8
;********BWAV2  FDB     45*60/8
;********BWAV1  FDB     60*60/8
;*
        FDB     1*60/8                  ;A FASTER SEND OFF OF BAITERS (V4)
        FDB     1*60/8                  ;THIS IS PATCH7
        FDB     1*60/8
        FDB     1*60/8
        FDB     1*60/8
        FDB     1*60/8
        FDB     3*60/8
        FDB     5*60/8
        FDB     7*60/8
        FDB     15*60/8
        FDB     15*60/8
BWAVN   FDB     30*60/8
BWAV2   FDB     45*60/8
BWAV1   FDB     60*60/8
;*
;*      BAITER START TABLE OFFSET
;*
BAISBL  FCB     (BWAVN-BAITBL-2)/2      ;START OFFSET FOR WAVE N
        FCB     (BWAV2-BAITBL-2)/2      ;START OFFSET FOR WAVE 2
        FCB     (BWAV1-BAITBL-2)/2      ;START OFFSET FOR WAVE 1
BAISND  EQU     *
;*
;*      START BRIDGE COLAPSING ROUTINE
;*
STBRID  LDU     PPREV           ;USE PREVIOUSES PROCESSES WORKSPACE
        LDX     #LAVAB
        LDD     #$6AFF
        JSR     VCUPROC
        LDU     PEXEC           ;GET OLD WORKSPACE BACK
        LDD     #FLOOR          ;GIVE IT SOME INITIAL CO-ORDINATES
        STD     PPOSY,Y
        CLR     PFRAME,Y        ;START AT FRAME 0
        RTS
;*
;*      CREATE ENEMIES, INPUT STACK, RETURN ADDRESS
;*                              REG.X INTELLIGENCE
;*                              REG.A NUMBER OF PEOPLE
WCREATE STA     PDELAY,U
        LDD     ,S++
        STD     PWRTS2,U        ;SAVE RETURN ADDRESS
        STX     PINTEL,U        ;THAT'S INTELLIGENCE
.10S    PCNAP   61
        SECCR   CREEM,EMYID
        INC     NENEMY          ;1 MORE ENEMY ON THE SCREEN
        INC     NRIDER          ;1 MORE RIDER ON THE SCREEN
        LDD     PINTEL,U
        STD     PDECSN,Y
        LDD     BUZARD          ;START HORSE
        STD     PHORSE,Y
        LDA     #4              ;MAXIMUM NUMBER OF EGGS TO LAY
        STA     PEGG,Y
        CLR     PCHASE,Y        ;NOT CHASING THE PLAYER
        LDA     TBRIDGE         ;1ST, OR 2ND WAVE?
        BEQ     .20S            ; BR=NO
        LDA     #2
        STA     EMYTIM          ;SLOW DOWN THE ENEMY ONLY!
.20S    DEC     PDELAY,U
        BNE     .10S
        JMP     [PWRTS2,U]
;*
;*      WAIT TILL TRUE END OF WAVE (OR GAME OVER)
;*
WATWAV  LDX     ,S++
        STX     PWRTS,U         ;RETURN ADDRESS
.1S     BSR     REWMSG
        LDA     GOVER           ;GAME OVER?
        BEQ     .2S             ; BR=YES, END OF WAVE
        LDX     PLINK,U
        BNE     .1S
.2S     JMP     [PWRTS,U]
;*
;*      WAVE DELAY BY REG.A AMOUNT
;*
WAVDEL  LDX     ,S++
        STX     PWRTS,U         ;RETURN ADDRESS
        STA     PDELAY,U
.1S     BSR     REWMSG
        DEC     PDELAY,U
        BNE     .1S
        JMP     [PWRTS,U]
;*
;*      RE-WRITE ALL MESSAGES
;*
REWMSG  PULS    D               ;SAVE RETURN ADDRESS
        STD     PWRTS2,U
        LDA     GOVER           ;GAME OVER?
        BEQ     .1S
        LDA     #PMSG1          ;REMEMBER TO START AT MESSAGE 1
        STA     PMSGA,U
        LDA     PMSG0,U         ;THIS MESSAGE O.K. TO PUT OUT?
        BEQ     .2S             ; BR=NO
        JSR     WAVEN
.2S     PCNAP   1
        LDA     PMSGA,U         ;GET CURRENT MESSAGE TO WRITE
        CMPA    #PMSG5          ;LAST MESSAGE WAS THE LAST ONE?
        BHI     .1S             ; BR=YES, RETURN TO CALLER
        LEAY    A,U
        ADDA    #PMSG2-PMSG1    ;NEXT MESSAGE TO WRITE
        STA     PMSGA,U
        BSR     WMSG2
        BRA     .2S
;*
.1S     JMP     [PWRTS2,U]
;*
;*      INITIAL WRITE & SAVE MESSAGE NBR & SCREEN LOCATION
;*
WAVMSG  LEAY    PMSG1-4,U
.1S     LEAY    4,Y
        TST     ,Y
        BNE     .1S
        LDA     GOVER
        BEQ     WVMRTS
        LDD     ,X
        STD     ,Y
        LDD     2,X
        STD     2,Y
WMSG2   LDA     ,Y
        BEQ     WVMRTS
        LDB     1,Y
        LDX     2,Y
        JMP     OUTPHR
WVMRTS  RTS
;*
;*      ERASE ALL MESSAGES
;*
EMSGS   LDA     PMSG0,U         ;WAVE MESSAGE SENT TO SCREEN?
        BEQ     .11S            ; BR=NO
        JSR     WAVEN2          ;ERASE WAVE NUMBER
.11S    LEAY    PMSG1,U         ;MESSAGE 1
        BSR     .1S
        LEAY    PMSG2,U         ;MESSAGE 2
        BSR     .1S
        LEAY    PMSG3,U         ;MESSAGE 3
        BSR     .1S
        LEAY    PMSG4,U         ;MESSAGE 4
        BSR     .1S
        LEAY    PMSG5,U         ;MESSAGE 5
.1S     LDA     ,Y
        BEQ     .2S
        CLR     ,Y              ;FORGET ABOUT THIS MESSAGE
        CLRB
        LDX     2,Y
        JMP     OUTPHR
.2S     RTS
;*
;*      ERASE/WRITE THE CLIFF,
;*       MODIFY LANDING TABLE
;*              COLISION TABLE
;*       UPDATE/DESTROY THE CLIFF
;*      SAVES REG.D, REG.X
;*
WCLFEW  PSHS    D,X
        BITA    ,X              ;CLIFF1 CHANGING?
        BEQ     .1S             ; BR=NO
        BITB    ,X              ;YES, DESTROY OR CREATE?
        BEQ     .2S             ; BR=CREATE
.11S    LDY     5,X             ;HERE TO DESTROY, DESTROY TRANSPORTER AREA
        BEQ     .31S
        LDA     #-1
        STA     ,Y
.31S    LDA     1,X             ;DESTROY LANDING AREA
        BEQ     .12S
        COMA
        LDX     #LNDXD1         ; START ADDRESS
        LDY     #LNDXD2-LNDXD1  ; LENGTH
        JSR     CLRBIT
        LDX     2,S
        LDA     2,X             ;DO NOT REFRESH THIS CLIFF
        COMA                    ; (REAL TIME CHECK)
        ANDA    BCKRFS
        STA     BCKRFS
        LDA     2,X             ;DESTROY BUMPING (COLISION) AREA
        COMA
        LDX     #BCKXD1         ; START ADDRESS
        LDY     #BCKXD2-BCKXD1  ; LENGTH
        JSR     CLRBIT
;*
.12S    LDX     #SNCLIF         ;CLIFF DESTROYING SOUND
        JSR     VSND
        SECCR   CLFDES,$27      ;START CLIFF DESTROYER ROUTINE
        LDX     2,S
        LDD     [3,X]           ;GET CLIFF ADDRESS
        STD     PFRAME-2,Y      ;PASS IT TO CLIFF DESTROYER
.1S     PULS    D,X,PC
;*
.2S     LDY     5,X             ;HERE TO CREATE, ENABLE TRANSPORTER
        BEQ     .20S            ; (AYE, AYE SCOTTY)
        CLR     ,Y
.20S    LDA     1,X             ;GET BIT TO PASS FOR CREATING THE CLIFF
        STA     ,-S             ;A DUMB WAY TO PUSH NBRS, BUT ALLOWED
        LDX     #LNDXD1         ;LANDING AREA IN RAM
        LDY     #LNDXS1         ;LANDING AREA IN ROM
.22S    LDA     ,S              ;GET CHANGING BIT
        COMA
        ANDA    ,X
        STA     ,X
        LDA     ,S              ;GET VALID BITS FROM ROM
        ANDA    ,Y+
        ADDA    ,X              ;PUT IN RAM
        STA     ,X+
        CMPX    #LNDXD2
        BLO     .22S
        LDX     1+2,S
        LDA     2,X             ;GET BIT TO PASS FOR CREATING THE CLIFF
        STA     ,S              ;SAVE ON STACK
        ORA     BCKRFS          ;REFRESH THIS CLIFF (MAKE IT APPEAR)
        STA     BCKRFS
        LDX     #BCKXD1         ;LANDING AREA IN RAM
        LDY     #BCKXS1         ;LANDING AREA IN ROM
.23S    LDA     ,S              ;GET CHANGING BIT
        COMA
        ANDA    ,X
        STA     ,X
        LDA     ,S              ;GET VALID BITS FROM ROM
        ANDA    ,Y+
        ADDA    ,X              ;PUT IN RAM
        STA     ,X+
        CMPX    #BCKXD2
        BLO     .23S
        LDA     ,S+             ;REMOVE DATA
        PULS    D,X
        STD     PWREGD,U        ;SAVE REG.D
        LDD     ,S++            ;SAVE RETURN ADDRESS
        STD     PWRTS,U
        PCNAP   1               ;FREE UP SOME TIME
        LDD     PWREGD,U        ;RESTORE REGISTER D
        JMP     [PWRTS,U]       ;RETURN
;*
;*      CLEAR BIT
;*       REG.X = START/CURRENT ADDRESS
;*       REG.Y = LENGTH IN BYTES
;*       REG.A = BIT PATTERN TO CLEAR
;*
CLRBIT  TFR     A,B
        ANDB    ,X
        STB     ,X+
        LEAY    -1,Y
        BNE     CLRBIT
        RTS
;*
;*      PRINT THE WAVE NUMBER
;*
WAVEN   LDD     #MSW06*256+WHI*$11      ;PUT UP 'WAVE XX'
        STA     PMSG0,U         ;THIS MESSAGE HAS BEEN PUT UP
        BRA     WAVEN3
WAVEN2  LDD     #MSW06*256+$00  ;ERASE 'WAVE XX'
        CLR     PMSG0,U         ;THIS MESSAGE HAS BEEN ERASED
WAVEN3  LDX     #$3A60
        JSR     OUTPHR
        LDA     WAVBCD
        BITA    #$F0
        BNE     .1S
        ORA     #$F0
.1S     JMP     OUTBCD
;*
;*      CLIF DESTROY/CREATE DATA TABLE
;*
WCLFTB  FCB     WBCL1L,$01,$03
         FDB     CLIF1L,0
WCLFT2  FCB     WBCL1R,$00,$00
         FDB     CLIF1R,0
WCLFT3  FCB     WBCL2,$02,$04
         FDB     CLIF2,CURTR1
WCLFT4  FCB     WBCL4,$10,$40
         FDB     CLIF4,0
;*
INTRO1  FDB     MSW00*256+WHI*$11,$2D7D ;INTRO #1
INTRO2  FDB     MSW01*256+WHI*$11,$339B ;INTRO #2
COOP1   FDB     MSW02*256+WHI*$11,$367D ;CO-OP (TEAM) WAVE INTRO #1
COOP2   FDB     MSW03*256+WHI*$11,$1C9B ;CO-OP (TEAM) WAVE INTRO #2
COOP3   FDB     MSW04*256+WHI*$11,$1AB6 ; NO BONUS AWARDED
COOP4   FDB     MSW05*256+WHI*$11,$0BB6 ; BONUS AWARDED
SURV1   FDB     MSW14*256+WHI*$11,$317D ;SURVIVAL WAVE INTRO #1
SURV3   FDB     MSW16*256+WHI*$11,$26B6 ; NO BONUS AWARDED
SURV4   FDB     MSW15*256+PL1*$11,$08B6 ; BONUS AWARDED (RED GUY)
SURV5   FDB     MSW15*256+PL2*$11,$3FB6 ; BONUS AWARDED (GREEN GUY)
GLAD1   FDB     MSW08*256+WHI*$11,$307F ;GLAD WAVE INTRO #1
GLAD2   FDB     MSW09*256+WHI*$11,$2E90 ;GLAD WAVE INTRO #2
GLAD3   FDB     MSW10*256+WHI*$11,$1C9B ;GLAD WAVE INTRO #3
GLAD4   FDB     MSW11*256+WHI*$11,$32B6 ; NO AWARD
GLAD5   FDB     MSW12*256+PL1*$11,$10B6 ; RED - 3000 POINT BOUNTY
GLAD6   FDB     MSW12*256+PL2*$11,$4FB6 ; GREEN - 3K POINT BOUNTY
EGG1    FDB     MSW13*256+WHI*$11,$387D ;EGG WAVE INTRO
PTER1   FDB     MSW07*256+WHI*$11,$1178 ;1478   PTERODACTYL BEWARE
;*
;*      WAVE TABLE
;*
        FCB     $40,$01,0,0                     ;WAVE 0 (FOR INITILIZATION)
WAVTBL
        FCB     $30,$01,0,2                     ;WAVE 1 - NEEDS INTRO MESSAGE
        FCB     $40,$01,0,4                     ;WAVE 2 - COOP/TEAM/SURVIVE WAVE
        FCB     $60,$02,0,0                     ;WAVE 3
        FCB     $33,$01,0,6                     ;WAVE 4 - GLADIATOR WAVE
        FCB     $60,$01,0,8                     ;WAVE 5 - EGG WAVE

        FCB     $33,$03,0,WBPER+WBCL2+0         ;WAVE 6
        FCB     $24,$02,0,WBPER+WBCL12+4        ;WAVE 7 - COOP/TEAM/SURVIVE WAVE
        FCB     $06,$01,1,WBPER+WBCL12+10       ;WAVE 8- PTERODACTYL WAVE
        FCB     $06,$02,0,WBPER+WBCLS+6         ;WAVE 9 - GLADIATOR WAVE
        FCB     $80,$03,0,8                     ;WAVE 10- EGG WAVE

        FCB     $35,$03,0,WBPER+0               ;WAVE 11
        FCB     $26,$02,0,WBPER+WBCL4+4         ;WAVE 12- COOP/TEAM/SURVIVE WAVE
        FCB     $07,$03,1,WBPER+WBCLS+10        ;WAVE 13- PTERODACTYL WAVE
        FCB     $08,$04,0,WBPER+WBCLS+6         ;WAVE 14- GLADIATOR WAVE
        FCB     $06,$02,0,8                     ;WAVE 15- EGG WAVE

        FCB     $05,$1F,0,0                     ;WAVE 16
        FCB     $05,$1F,0,4                     ;WAVE 17- COOP/TEAM/SURVIVE WAVE
        FCB     $05,$1F,2,10                    ;WAVE 18- PTERODACTYL WAVE
        FCB     $04,$2F,0,6                     ;WAVE 19- GLADIATOR WAVE
        FCB     $06,$03,0,8                     ;WAVE 20- EGG WAVE

        FCB     $03,$3F,0,WBPER+WBCL1+0         ;WAVE 21
        FCB     $02,$4F,0,WBPER+WBCL1+4         ;WAVE 22- COOP/TEAM/SURVIVE WAVE
        FCB     $02,$4F,2,WBPER+WBCL14+10       ;WAVE 23- PTERODACTYL WAVE
        FCB     $02,$4F,0,WBPER+WBCL14+6        ;WAVE 24- GLADIATOR WAVE
        FCB     $06,$04,0,8                     ;WAVE 25- EGG WAVE

        FCB     $03,$5F,0,WBPER+WBCLS+0         ;WAVE 26
        FCB     $03,$5F,0,WBPER+WBCLS+4         ;WAVE 27- COOP/TEAM/SURVIVE WAVE
        FCB     $02,$4F,2,WBPER+WBCLS+10        ;WAVE 28- PTERODACTYL WAVE
        FCB     $03,$5F,0,WBPER+WBCLS+6         ;WAVE 29- GLADIATOR WAVE
        FCB     $06,$03,0,8                     ;WAVE 30- EGG WAVE

        FCB     $04,$4F,0,WBPER+0               ;WAVE 31
        FCB     $02,$6F,0,WBPER+4               ;WAVE 32- COOP/TEAM/SURVIVE WAVE
        FCB     $02,$4F,2,WBPER+WBCL2+10        ;WAVE 33- PTERODACTYL WAVE
        FCB     $02,$6F,0,WBPER+WBCL2+6         ;WAVE 34- GLADIATOR WAVE
        FCB     $08,$05,0,8                     ;WAVE 35- EGG WAVE

        FCB     $02,$6F,0,WBPER+WBCL4+0         ;WAVE 36
        FCB     $00,$8F,0,WBPER+WBCL4+4         ;WAVE 37- COOP/TEAM/SURVIVE WAVE
        FCB     $00,$6F,2,WBPER+WBCL24+10       ;WAVE 38- PTERODACTYL WAVE
        FCB     $00,$8F,0,WBPER+WBCL24+6        ;WAVE 39- GLADIATOR WAVE
        FCB     $08,$05,0,8                     ;WAVE 40- EGG WAVE

        FCB     $03,$7F,0,WBPER+WBCL1+0         ;WAVE 41
        FCB     $00,$AF,0,WBPER+WBCL14+4        ;WAVE 42- COOP/TEAM/SURVIVE WAVE
        FCB     $00,$7F,3,WBPER+WBCL14+10       ;WAVE 43- PTERODACTYL WAVE
        FCB     $00,$AF,0,WBPER+WBCLS+6         ;WAVE 44- GLADIATOR WAVE
        FCB     $08,$06,0,8                     ;WAVE 45- EGG WAVE

        FCB     $03,$7F,0,WBPER+0               ;WAVE 46
        FCB     $00,$AF,0,WBPER+4               ;WAVE 47- COOP/TEAM/SURVIVE WAVE
        FCB     $00,$7F,3,WBPER+10              ;WAVE 48- PTERODACTYL WAVE
        FCB     $00,$AF,0,WBPER+WBCL4+6         ;WAVE 49- GLADIATOR WAVE
        FCB     $08,$06,0,8                     ;WAVE 50- EGG WAVE

        FCB     $03,$7F,0,WBPER+WBCL1+0         ;WAVE 51
        FCB     $00,$AF,0,WBPER+WBCL14+4        ;WAVE 52- COOP/TEAM/SURVIVE WAVE
        FCB     $00,$7F,3,WBPER+WBCL14+10       ;WAVE 53- PTERODACTYL WAVE
        FCB     $00,$AF,0,WBPER+WBCLS+6         ;WAVE 54- GLADIATOR WAVE
        FCB     $08,$0F,0,8                     ;WAVE 55- EGG WAVE

        FCB     $03,$7F,0,WBPER+0               ;WAVE 56
        FCB     $00,$AF,0,WBPER+4               ;WAVE 57- COOP/TEAM/SURVIVE WAVE
        FCB     $00,$7F,3,WBPER+010             ;WAVE 58- PTERODACTYL WAVE
        FCB     $00,$AF,0,WBPER+WBCL4+6         ;WAVE 59- GLADIATOR WAVE
        FCB     $00,$63,0,8                     ;WAVE 60- EGG WAVE

        FCB     $00,$AF,0,WBPER+WBCL1+0         ;WAVE 61
        FCB     $00,$AF,0,WBPER+WBCL14+4        ;WAVE 62- COOP/TEAM/SURVIVE WAVE
        FCB     $00,$7F,3,WBPER+WBCL14+10       ;WAVE 63- PTERODACTYL WAVE
        FCB     $00,$AF,0,WBPER+WBCLS+6         ;WAVE 64- GLADIATOR WAVE
        FCB     $00,$64,0,8                     ;WAVE 65- EGG WAVE

        FCB     $00,$AF,0,WBPER+0               ;WAVE 66
        FCB     $00,$AF,0,WBPER+4               ;WAVE 67- COOP/TEAM/SURVIVE WAVE
        FCB     $00,$7F,3,WBPER+10              ;WAVE 68- PTERODACTYL WAVE
        FCB     $00,$AF,0,WBPER+WBCL4+6         ;WAVE 69- GLADIATOR WAVE
        FCB     $00,$65,0,8                     ;WAVE 70- EGG WAVE

        FCB     $00,$AF,0,WBPER+WBCL1+0         ;WAVE 71
        FCB     $00,$AF,0,WBPER+WBCL14+4        ;WAVE 72- COOP/TEAM/SURVIVE WAVE
        FCB     $00,$7F,3,WBPER+WBCL14+10       ;WAVE 73- PTERODACTYL WAVE
        FCB     $00,$AF,0,WBPER+WBCLS+6         ;WAVE 74- GLADIATOR WAVE
        FCB     $00,$6F,0,8                     ;WAVE 75- EGG WAVE

        FCB     $00,$AF,0,WBPER+0               ;WAVE 76
        FCB     $00,$AF,0,WBPER+4               ;WAVE 77- COOP/TEAM/SURVIVE WAVE
        FCB     $00,$7F,3,WBPER+10              ;WAVE 78- PTERODACTYL WAVE
        FCB     $00,$AF,0,WBPER+WBCL4+6         ;WAVE 79- GLADIATOR WAVE
        FCB     $00,$86,0,8                     ;WAVE 80- EGG WAVE

WTBRST  FCB     $00,$AF,0,WBPER+WBCL1+0         ;WAVE 81
        FCB     $00,$AF,0,WBPER+WBCL14+4        ;WAVE 82- COOP/TEAM/SURVIVE WAVE
        FCB     $00,$7F,3,WBPER+WBCL14+10       ;WAVE 83- PTERODACTYL WAVE
        FCB     $00,$AF,0,WBPER+WBCLS+6         ;WAVE 84- GLADIATOR WAVE
        FCB     $00,$8F,0,8                     ;WAVE 85- EGG WAVE

        FCB     $00,$AF,0,WBPER+0               ;WAVE 86
        FCB     $00,$AF,0,WBPER+4               ;WAVE 87- COOP/TEAM/SURVIVE WAVE
        FCB     $00,$7F,3,WBPER+10              ;WAVE 88- PTERODACTYL WAVE
        FCB     $00,$AF,0,WBPER+WBCL4+6         ;WAVE 89- GLADIATOR WAVE
        FCB     $00,$8F,0,8                     ;WAVE 80- EGG WAVE
WTBEND  EQU     *                       ;END OF WAVE TABLE, REPEAT AT "WTBRST"
     IF DEBUG = 0                                                               ;;Fixme was: IFE DEBUG
;*
;*      ALTERNATE COPYRIGHT MESSAGE
;*
MSCOP2  FDB     $10F8
        FCB     $2A!HIDE+HIDE2,$11      ;(                                      ;;Fixme was: !XHIDE
        FCB     $0D!HIDE+HIDE2  ;C                                              ;;Fixme was: !XHIDE
        FCB     $2B!HIDE+HIDE2  ;)                                              ;;Fixme was: !XHIDE
        FCB     $0A!HIDE+HIDE2  ;SPACE                                          ;;Fixme was: !XHIDE
        FCB     $21!HIDE+HIDE2  ;W                                              ;;Fixme was: !XHIDE
        FCB     $13!HIDE+HIDE2  ;I                                              ;;Fixme was: !XHIDE
        FCB     $16!HIDE+HIDE2  ;L                                              ;;Fixme was: !XHIDE
        FCB     $16!HIDE+HIDE2  ;L                                              ;;Fixme was: !XHIDE
        FCB     $13!HIDE+HIDE2  ;I                                              ;;Fixme was: !XHIDE
        FCB     $0B!HIDE+HIDE2  ;A                                              ;;Fixme was: !XHIDE
        FCB     $17!HIDE+HIDE2  ;M                                              ;;Fixme was: !XHIDE
        FCB     $1D!HIDE+HIDE2  ;S                                              ;;Fixme was: !XHIDE
        FCB     $0A!HIDE+HIDE2  ;SPACE                                          ;;Fixme was: !XHIDE
        FCB     $0F!HIDE+HIDE2  ;E                                              ;;Fixme was: !XHIDE
        FCB     $16!HIDE+HIDE2  ;L                                              ;;Fixme was: !XHIDE
        FCB     $0F!HIDE+HIDE2  ;E                                              ;;Fixme was: !XHIDE
        FCB     $0D!HIDE+HIDE2  ;C                                              ;;Fixme was: !XHIDE
        FCB     $1E!HIDE+HIDE2  ;T                                              ;;Fixme was: !XHIDE
        FCB     $1C!HIDE+HIDE2  ;R                                              ;;Fixme was: !XHIDE
        FCB     $19!HIDE+HIDE2  ;O                                              ;;Fixme was: !XHIDE
        FCB     $18!HIDE+HIDE2  ;N                                              ;;Fixme was: !XHIDE
        FCB     $13!HIDE+HIDE2  ;I                                              ;;Fixme was: !XHIDE
        FCB     $0D!HIDE+HIDE2  ;C                                              ;;Fixme was: !XHIDE
        FCB     $1D!HIDE+HIDE2  ;S                                              ;;Fixme was: !XHIDE
        FCB     $0A!HIDE+HIDE2  ;SPACE                                          ;;Fixme was: !XHIDE
        FCB     $13!HIDE+HIDE2  ;I                                              ;;Fixme was: !XHIDE
        FCB     $18!HIDE+HIDE2  ;N                                              ;;Fixme was: !XHIDE
        FCB     $0D!HIDE+HIDE2  ;C                                              ;;Fixme was: !XHIDE
        FCB     $2E!HIDE+HIDE2  ;.                                              ;;Fixme was: !XHIDE
        FCB     0
     ENDIF
;*
;*      WAVE SUBROUTINE TABLE
;*
WJSRTB  FDB     WAVRTS          ;NOP ROUTINE
        FDB     WINTRO          ;INTRODUCTION MESSAGE
        FDB     WCOOP           ;CO-OPERATION WAVE SET-UP
        FDB     WGLAD           ;GLADIATOR SET-UP
        FDB     WAVEGG          ;EGG WAVE SET-UP
        FDB     WPTERO          ;PTERODACTYL WAVE
;*
WAVRTS  RTS                     ;NOTHING TO DO
;*
WINTRO  LDX     #INTRO1
        JSR     WAVMSG
        LDA     #90/6
        JSR     WAVDEL
        LDX     #INTRO2
        JSR     WAVMSG
        LDA     #90/6           ;RESET OF 1 SECOND DELAY
        JMP     WPAUS2
;*
;*      PTERODACTYL WAVE START
;*
WPTERO  EQU     *               ;PTERODACTYL WAVE
        LDX     #PTER1
        JSR     WAVMSG
        LDA     #180/6
        JSR     WAVDEL
        JSR     WATWAV          ;WAIT TILL TRUE END OF WAVE
        SECCR   PTERWV,PTEID    ;START WAVE STARTED PTERODACYL'S
        LDX     PWAVE,U         ;GET WAVE AREA TO WORK FROM
        LDA     WPTEN,X         ; GET NBR OF PTERODCTYLS FOR THIS WAVE
        STA     PJOYT,Y         ;NUMBER OF PTERODACTYLS TO CREATE
        JMP     WPAUS3
;*
PTERWV  PCNAP   65
        DEC     PJOYT,U         ;NUMBER OF PTERO'S TO CREATE
        BLE     .1S             ; BR=LAST ONE
        SECCR   PTERST,PTEID
        BRA     PTERWV
;*
.1S     JMP     PTERST
;*
;*      CO-OPERATION (TEAM) WAVE OR SURVIVAL WAVE (2 PLAYER/1 PLAYER)
;*
WCOOP   LDA     SPLY2+6         ;THIS MESSAGE IS FOR TWO PLAYERS ONLY
        BEQ     WAVSUR          ; BR=PLAYER 2 DEAD, GO TO SURVIVAL WAVE
        LDA     SPLY1+6
        BEQ     WAVSUR          ; BR=PLAYER 1 DEAD, GO TO SURVIVAL WAVE
        LDD     #WCOSCR         ;CO-OPERATION WAVE SET-UP
        STD     PWPREV,U        ;       CO-OP SCORE ROUTINE
        CLR     PLYG1           ;RESET PLAYER HIT PLAYER COUNTER(S)
        CLR     PLYG2
        LDX     #COOP1
        JSR     WAVMSG
        LDX     #COOP2
        JMP     WAVMSG
;*
WCOSCR  EQU     *               ;END OF WAVE CLEAN-UP
        LDA     PLYG1           ;PLAYER 1 OR
        ORA     PLYG2           ;PLAYER 2 DIE FROM ONE ANOTHER?
        BEQ     .1S             ; BR=NO, GO AWARD THE TEAM
        LDX     #COOP3          ;NO BONUS POINTS MESSAGE
        BRA     ENDTS
;*
.1S     LDA     SPLY1+6         ;PLAYER 1 IS STILL ALIVE?
        BEQ     .2S             ; BR=NO, DEAD
        LDX     #P1DEC          ;AWARD POINTS TO PLAYER 1
        LDA     #$30            ; 3,000 POINTS!!!
        JSR     SCRHUN
.2S     LDA     SPLY2+6         ;PLAYER 2 IS STILL ALIVE?
        BEQ     .3S             ; BR=NO, DEAD
        LDX     #P2DEC          ;AWARD POINTS TO PLAYER 2
        LDA     #$30            ; 3,000 POINTS!!!
        JSR     SCRHUN
.3S     LDX     #COOP4          ;BONUS POINTS MESSAGE
ENDTS   JSR     WAVMSG
        LDA     #120/6          ;WAIT FOR 2 SECONDS
        JMP     WAVDEL          ;THEN RETURN TO BEGIN NEW WAVE
;*
;*      SURVIVAL WAVE (ASSUMES ONLY 1 PLAYER LEFT IN GAME)
;*
WAVSUR  LDD     #WSUSCR         ;END OF SURVIVAL WAVE
        STD     PWPREV,U        ; SCORE ROUTINE
        CLR     PLYD1           ;RESET PLAYER DEATH COUNTER(S)
        CLR     PLYD2
        LDX     #SURV1
        JMP     WAVMSG
;*
;*      END OF SURVIVAL WAVE SCOREING
;*
WSUSCR  LDX     #SURV3          ;ASSUME NO POINTS
        LDA     SPLY1+6         ;STILL HAVE SOME LIVES LEFT?
        BEQ     .1S             ; BR=NO, CK PLAYER 2
        LDA     PLYD1           ;DID PLAYER 1 DIE?
        BNE     ENDTS           ; BR=YES, NO SCORE
        LDX     #P1DEC          ;AWARD POINTS TO PLAYER 1
        LDA     #$30            ; 3,000 POINTS!!!
        JSR     SCRHUN
        LDX     #SURV4          ;AWARDED POINTS MESSAGE (PLAYER 1)
        BRA     ENDTS
;*
.1S     LDA     SPLY2+6         ;STILL HAVE SOME LIVES LEFT?
        BEQ     ENDTS           ; BR=NO, NO BONUS AWARDED
        LDA     PLYD2           ;DID PLAYER 2 DIE?
        BNE     ENDTS           ; BR=YES, NO SCORE
        LDX     #P2DEC          ;AWARD POINTS TO PLAYER 2
        LDA     #$30            ; 3,000 POINTS!!!
        JSR     SCRHUN
        LDX     #SURV5          ;AWARDED POINTS MESSAGE (PLAYER 5)
        BRA     ENDTS
;*
;*      START GLADIATOR WAVE
;*
WGLAD   LDA     SPLY1+6         ;THIS MESSAGE IS FOR TWO PLAYERS ONLY
        BEQ     WAVRT2          ; BR=PLAYER 1 DEAD
        LDA     SPLY2+6
        BEQ     WAVRT2          ; BR=PLAYER 2 DEAD
        LDD     #WGLSCR         ;GLADIATOR SET-UP
        STD     PWPREV,U        ;       TO SCORE ROUTINE
        LDA     #-1             ;SET-UP PLAYER KILLING PLAYER VARIABLES
        STA     PLYG1           ; TO AWARD SCORE UPON 1ST ENCOUNTER
        STA     PLYG2
        LDX     #GLAD1
        JSR     WAVMSG
        LDA     #90/6
        JSR     WAVDEL
        LDX     #GLAD2
        JSR     WAVMSG
        LDX     #GLAD3
        JSR     WAVMSG
        LDA     #90/6
        JMP     WPAUS2
WAVRT2  RTS
;*
;*      END OF GLADIATOR WAVE CLEAN-UP
;*
WGLSCR
        LDA     PLYG1           ;EITHER BOTH NEGATIVE, OR 1 IS, NO OPTIONS
        BPL     .2S             ; BR=PLAYER 2 GOT THE BOUNTY
        LDX     #GLAD5          ;PLAYER 1 BONUS POINTS MESSAGE
        LDA     PLYG2
        BPL     .3S             ;BR= PLAYER 1 GOT THE BOUNTY
        LDX     #GLAD4          ;NO ONE GOT THE BOUNTY
        BRA     .3S
.2S     LDX     #GLAD6          ;PLAYER 2 BONUS POINTS MESSAGE
.3S     JSR     WAVMSG
        CLR     PLYG1           ;NO MORE AWARDING BOUNTY POINTS
        CLR     PLYG2
        LDA     #120/6          ;WAIT FOR 2 SECONDS
        JMP     WAVDEL          ;THEN RETURN TO BEGIN NEW WAVE
;*
;*      START OF EGG WAVE
;*
WAVEGG  LDX     #EGG1           ;EGG WAVE
        JSR     WAVMSG
        LDA     #180/6
        JSR     WAVDEL
        JSR     WATWAV          ;WAIT TILL TRUE END OF WAVE
        JSR     EMSGS           ;ERASE AL MESSAGES
;*
        LDX     PWAVE,U         ;FIND INTELLIGENCE
        LDY     #P6DEC          ;ASSUME THE BEST
        LDA     WBOUND,X
        BNE     .1S
        LDA     WLORD,X         ;IT IS THE LORD HIMSELF
        BRA     .2S
.1S     LDY     #P5DEC          ;HUNTER?
        BITA    #$0F
        BNE     .3S             ; BR=YES
        LDY     #P4DEC          ;HO, HUM, THE BOUNDAR
.2S     LSRA
        LSRA
        LSRA
        LSRA
.3S     ANDA    #$0F
        STA     WENEMY          ;NUMBER OF ENEMIES TO HATCH AT A TIME
        STY     PINTEL,U        ;START INTELLIGENCE OF ALL
        LDB     EGGWT2          ;INITIAL EGG WAITING TIME
        LDA     SPLY2+6         ;2 PLAYERS IN THE GAME
        BEQ     .35S            ; BR=NO, ALL TIMES ARE BASIED ON 1 PLAYER
        LDA     SPLY1+6         ;2 PLAYERS IN THE GAME
        BEQ     .35S            ; BR=YES, ALL TIMES ARE BASIED ON 1 PLAYER
        LSRB                    ;ON 2 PLAYERS USE 1/2 OF THE TIME
.35S    STB     PEGGTM,U        ;EGG TIMER
        LDA     WPERSUE,X       ;NBR TO START PERSUING
        ANDA    #$0F
        STA     WSMART
        LDX     #EGPTBL         ;CLEAR EGG PLACEMENT TABLE
.4S     CLR     ,X+
        CMPX    #EGLEND         ;& CLEAR LEVEL RANDOMNESS
        BLO     .4S
;*
        LDA     #2              ;NUMBER OF PRE-MATURE EGG HATCHINGS
        STA     PWHCH,U
        LDA     #6
        STA     PWREGA,U        ;6 EGGS ON EACH LEDGE
.5S     LDY     #EGLEDG         ;PUT AN EGG ON EVERY LEDGE (RANDOM LEDGE)
        LDX     #EGLTBL
        JSR     VRAND           ;SELECT RANDOM LEDGE
        LDB     #6*2
        MUL
.54S    LDB     A,X
        BEQ     .55S
        DECA
        BPL     .54S
        LDA     #6-1
        BRA     .54S
;*
.55S    INC     A,X
        LEAY    A,Y
        JSR     VRAND
        ROLA                    ;GET RANDOM NBR 0 TO 255
        LDB     ,Y+
        SUBB    -2,Y
        MUL
        ADDA    -2,Y
        LDX     #EGPTBL         ;(EGG PLACEMENT TABLE)
        INC     A,X             ;THIS SPOT HAS BEEN TAKEN!
        JSR     CREGG           ;CREATE THE EGG
        DEC     PWREGA,U        ;ANY MORE EGGS LEFT
        BNE     .5S             ; BR=NO
        LDA     #6
        STA     PWREGA,U        ;6 MORE EGGS TO GO
.6S     LDX     #EGPTBL         ;POINT TO EGG POSITION TABLE
        JSR     VRAND
        LDB     #69*2
        MUL                     ;REG. A = RANDOM NBR 0-68
.7S     LDB     A,X             ;IS THIS LOCATION FREE?
        BEQ     .8S             ; BR=YES
        INCA                    ;NEXT LOCATION
        CMPA    #69             ;AND WRAP AROUND 69
        BLO     .7S
        CLRA
        BRA     .7S
;*
.8S     INC     A,X             ;THIS SPOT RESERVED
        JSR     CREGG           ;CREATE THE EGG
        DEC     PWREGA,U        ;ANY MORE LEFT?
        BNE     .6S             ; BR=YES
        JMP     WBEGIN
;*
;*      TROMSG
;*
TROMSG  FCB     ($1E+$35)!$9B,($12+$35)!$9B,($13+$35)!$9B,($1D+$35)!$9B         ;;Fixme was: !X$9B
        FCB      ($0A+$35)!$9B,($13+$35)!$9B,($1D+$35)!$9B,($0A+$35)!$9B        ;;Fixme was: !X$9B
        FCB      ($14+$35)!$9B,($19+$35)!$9B,($1F+$35)!$9B,($1D+$35)!$9B        ;;Fixme was: !X$9B
        FCB      ($1E+$35)!$9B,($2E+$35)!$9B,($00+$35)!$9B                      ;;Fixme was: !X$9B
        FCB     ($0E+$35)!$9B,($0F+$35)!$9B,($1D+$35)!$9B,($13+$35)!$9B         ;;Fixme was: !X$9B
        FCB      ($11+$35)!$9B,($18+$35)!$9B,($0F+$35)!$9B,($0E+$35)!$9B        ;;Fixme was: !X$9B
        FCB      ($0A+$35)!$9B,($0C+$35)!$9B,($23+$35)!$9B,($0A+$35)!$9B        ;;Fixme was: !X$9B
        FCB      ($21+$35)!$9B,($13+$35)!$9B,($16+$35)!$9B,($16+$35)!$9B        ;;Fixme was: !X$9B
        FCB      ($13+$35)!$9B,($0B+$35)!$9B,($17+$35)!$9B,($1D+$35)!$9B        ;;Fixme was: !X$9B
        FCB      ($0A+$35)!$9B,($0F+$35)!$9B,($16+$35)!$9B,($0F+$35)!$9B        ;;Fixme was: !X$9B
        FCB      ($0D+$35)!$9B,($1E+$35)!$9B,($1C+$35)!$9B,($19+$35)!$9B        ;;Fixme was: !X$9B
        FCB      ($18+$35)!$9B,($13+$35)!$9B,($0D+$35)!$9B,($1D+$35)!$9B        ;;Fixme was: !X$9B
        FCB      ($0A+$35)!$9B,($13+$35)!$9B,($18+$35)!$9B,($0D+$35)!$9B        ;;Fixme was: !X$9B
        FCB      ($2E+$35)!$9B,($00+$35)!$9B                                    ;;Fixme was: !X$9B
        FCB     ($2A+$35)!$9B,($0D+$35)!$9B,($2B+$35)!$9B                       ;;Fixme was: !X$9B
        FCB      ($0A+$35)!$9B,($01+$35)!$9B,($09+$35)!$9B                      ;;Fixme was: !X$9B
        FCB      ($08+$35)!$9B,($02+$35)!$9B,($0A+$35)!$9B,($21+$35)!$9B        ;;Fixme was: !X$9B
        FCB      ($13+$35)!$9B,($16+$35)!$9B,($16+$35)!$9B,($13+$35)!$9B        ;;Fixme was: !X$9B
        FCB      ($0B+$35)!$9B,($17+$35)!$9B,($1D+$35)!$9B,($0A+$35)!$9B        ;;Fixme was: !X$9B
        FCB      ($0F+$35)!$9B,($16+$35)!$9B,($0F+$35)!$9B,($0D+$35)!$9B        ;;Fixme was: !X$9B
        FCB      ($1E+$35)!$9B,($1C+$35)!$9B,($19+$35)!$9B,($18+$35)!$9B        ;;Fixme was: !X$9B
        FCB      ($13+$35)!$9B,($0D+$35)!$9B,($1D+$35)!$9B,($0A+$35)!$9B        ;;Fixme was: !X$9B
        FCB      ($13+$35)!$9B,($18+$35)!$9B,($0D+$35)!$9B,($2E+$35)!$9B        ;;Fixme was: !X$9B
        FCB      ($00+$35)!$9B                                                  ;;Fixme was: !X$9B
        FCB     ($0B+$35)!$9B,($16+$35)!$9B,($16+$35)!$9B,($0A+$35)!$9B         ;;Fixme was: !X$9B
        FCB      ($1C+$35)!$9B,($13+$35)!$9B,($11+$35)!$9B,($12+$35)!$9B        ;;Fixme was: !X$9B
        FCB      ($1E+$35)!$9B,($1D+$35)!$9B,($0A+$35)!$9B,($1C+$35)!$9B        ;;Fixme was: !X$9B
        FCB      ($0F+$35)!$9B,($1D+$35)!$9B,($0F+$35)!$9B,($1C+$35)!$9B        ;;Fixme was: !X$9B
        FCB      ($20+$35)!$9B,($0F+$35)!$9B,($0E+$35)!$9B,$2E                  ;;Fixme was: ($20+$35)!X$9B,($0F+$35)!X$9B,($0E+$35)!X$9B,!W($80+$35!X$9B) (Was getting range overflow error, so I just put in "$2E")
;*
;*      CREATE AN EGG ON THE GROUND
;*       INPUT  REG.A, LEDGE POSITION ( A NBR FROM 0-65)
;*              PINTEL,U = START INTELLIGENCE
;*              PEGGTM = TIME TILL HATCHING
;*       NO REGISTERS ARE SAVED
;*
CREGG   PSHS    A
        INC     NRIDER          ;1 MORE RIDER (EGG) IN THE GAME
        SECCR   EGGLN2,$80+EGGID
        PULS    A
        LDX     #EGGLNT-4
.1S     LEAX    4,X
        CMPA    ,X
        BHS     .1S
        LDB     #8              ;PUT AN EGG EVERY 8TH PIXEL POSITION
        STB     PFEET,Y         ;(NO CAUGHT IN THE AIR POINTS)
        MUL
        ADDD    2,X             ;NEW X POSITION
        STD     PPOSX,Y
        ADDD    #8-1-1
        STD     PCOLX,Y         ;MAINTAIN X-DIRECTION COLISION DETECT POINTERS
        LDB     1,X
        CLRA
        STD     PPOSY,Y         ;NEW Y POSITION
        STB     PCOLY1,Y        ;MAINTAIN Y-DIRECTION COLISION DETECT POINTERS
        SUBB    #7-1
        STB     PCOLY2,Y
        LDD     PINTEL,U        ;NEW INTELLIGENCE
        STD     PDECSN,Y
        LDB     PEGGTM,U        ;HATCHING TIME
        STB     PJOYT,Y
        DEC     PWHCH,U         ;ANYMORE EGGS TO HATCH PREMATURLY?
        BMI     .20S
        JSR     VRAND           ;A RANDOM NUMBER 0-127
        MUL                     ;GET A RANDOM TIME 1/2 OF THE RANGE
        NEGA
        ADDA    PJOYT,Y
        STA     PJOYT,Y         ;NEW HATCHING TIME
.20S    LDD     #0
        STD     PPICH,Y         ;NO IMAGE TO CLEAR
        STD     PDIST,Y         ;NO BUZZARD SENT AFTER EGG
;********       STD     PVELY,Y         ALL EGGS STRAIGHT UP?
        CLR     PCHASE,Y        ;NOT CHASEING ANYONE
        LDA     #4              ;4 EGGS BEFORE ENEMY R.I.P.'S
        STA     PEGG,Y
        LDD     ,S++            ;GET RETURN ADDRESS
        STD     PWRTS,U
        PCNAP   1               ;DELAY FOR OUT OF PHASE EGG HATCHING & MONITOR
        JMP     [PWRTS,U]       ;RETURN
;*
;*      PUT UP AN EGG ON EVERY LEDGE, LEDGE EGG LENGTH DEFINITIONS
;*
        FCB     0
EGLEDG  FCB     3+5                             ;LEVEL0 - CLIF1L, CLIF1R
        FCB     3+5+11                          ;LEVEL1 - CLIF2
        FCB     3+5+11+7                        ;LEVEL2 - CLIF3U
        FCB     3+5+11+7+7+5                    ;LEVEL3 - CLIF3L, CLIF3R
        FCB     3+5+11+7+7+5+8                  ;LEVEL4 - CLIF4
        FCB     3+5+11+7+7+5+8+23               ;LEVEL5 - CLIF5
;*
;*      EGG LAND DESCRIPTION
;*
EGGLNT
        FCB     3,$45-1                 ;CLIF1L
        FDB     $00+9
        FCB     3+5,$45-1               ;CLIF1R
        FDB     $F4-8*(3)+9
        FCB     3+5+11,$51-1            ;CLIF2
        FDB     $4D-8*(3+5)+9
        FCB     3+5+11+7,$81-1          ;CLIF3U
        FDB     $C1-8*(3+5+11)+9
        FCB     3+5+11+7+7,$8A-1        ;CLIF3L
        FDB     $00-8*(3+5+11+7)+9
        FCB     3+5+11+7+7+5,$8A-1      ;CLIF3R (EXTRA LONG STYLE)
        FDB     $100-8*(3+5+11+7+7)+1
        FCB     3+5+11+7+7+5+8,$A3-1    ;CLIF4
        FDB     $61-8*(3+5+11+7+7+5)+9
        FCB     3+5+11+7+7+5+8+23,$D3-1 ;CLIF5
        FDB     $2D-8*(3+5+11+7+7+5+8)+9
        FCB     $FF,$45-1               ;CATCH ALL
        FDB     $20-8*(3+5+11+7+7+4+8+23)+9
;*
;*      PTERODACTYL DIES
;*
DEATH4  PSHS    X,U     ;SAVE (REG.X VICTOR, & REG.U DEAD GUY)
        LDA     #8-1
        STA     PJOYT,U
        LDD     #PTEKLL         ;SHOW A DEAD PTERODACTYL!!!!!!!!!!!!!
        STD     PJOY,U
        LDX     #SNPTED         ;PTERODACTYL DYING SOUND
        JSR     VSND
        PULS    X,U,PC
;*
;*      ENEMY DIES
;*
DEATH3  PSHS    X,U     ;SAVE (REG.X VICTOR, & REG.U DEAD GUY)
      IF DEBUG <> 0     ;???????????? DEBUG PARAMATER ?????????                 ;;Fixme was: IFN DEBUG
        LDA     PID,U   ;THIS IS A DEAD ENEMY ISN'T IT?
        CMPA    #EMYID
        BEQ     .1S
        SWI
.1S
      ENDIF                     ;???????????? END OF DEBUG ????????????
        LDX     #SNEDIE         ;ENEMY DIES
        JSR     VSND
        LDA     NSMART          ;BUMP DOWN SMARTNESS VARIABLE
        SUBA    PCHASE,U
        STA     NSMART
        DEC     NENEMY          ;DECREMENT NBR OF ENEMIES ON THE SCREEN
      IF DEBUG <> 0     ;???????????? DEBUG PARAMATER ?????????                 ;;Fixme was: IFN DEBUG
        BPL     .45S
        SWI
.45S
      ENDIF                     ;???????????? END OF DEBUG ????????????
        LDA     #$80+EGGID      ;START EGG I.D.
        LDB     PPRI,U          ;EGG IS SAME PRIMARY/SECONDARY PROCESS
        LDX     #STEGG
        JSR     VCUPROC
        LDD     #0              ;NO BIRD IS AFTER THE LITTLE MAN
        STD     PDIST,Y
        STD     PPICH,Y         ;NO IMAGE TO CLEAR
        STD     PCOLY1,Y        ;& PCOLY2, INHIBIT EARLY COLISION
        LDD     PPOSY,U         ;ADJUST FOR BOTTOM OF EGG FROM
        SUBB    #13-5           ; BOTTOM OF HORSE (PLUS MIKE STROLL FUDGE
        STD     PPOSY,Y         ;       FACTOR TO MISS THE EGG)
        LDD     PPOSX,U
        ADDD    #4
        STD     PPOSX,Y
        CLR     PFEET,Y         ;NOT CAUGHT IN THE AIR YET! (500 PTS. BONUS)
        LDD     PDECSN,U        ;TRANSFER DECISION TABLE TO EGG
        CMPD    #P6DEC          ;MOST DIFFICULT ENEMY?
        BHS     DE3HRD          ; BR=YES
        ADDD    #P4DEC-P3DEC    ;NEXT LEVEL OF INTELLIGENCE
DE3HRD  STD     PDECSN,Y
        LDD     PVELY,U         ;SAME VELOCITIES
        STD     PVELY,Y
        LDA     PVELX,U
        STA     PVELX,Y
        CLR     PBUMPX,Y        ;RESET BUMPAGE REGISTERS
        CLR     PBUMPY,Y
        CLR     PTIMX,Y
        CLR     PFRAME,Y
        LDA     PEGG,U          ;TRANSFER NBR OF EGG LEFT
        STA     PEGG,Y
        DEC     PEGG,Y          ;YOU CAN ONLY SQUEEZE SO MUCH BLOOD FROM AN EGG
        BNE     .1S             ; BR=YOU CAN GET MORE EGGS
        TFR     Y,X
        LDU     ,S              ;GET VICTORS WORKSPACE (CURRENTLY DIEING ENEMY)
        BEQ     .1S
        JSR     EGGSCR          ;SCORE EGG
.1S     PULS    X,U,PC
;*
PLYEGG  EQU     *               ;COLISION DETECT WITH THE EGG
      IF DEBUG <> 0     ;???????????? DEBUG PARAMATER ?????????                 ;;Fixme was: IFN DEBUG
        LDA     PID,U           ;THIS BETTER BE THE PLAYER
        CMPA    #$80+PLYID
        BEQ     .12S
        SWI
.12S    LDA     PID,X           ;THIS BETTER BE AN EGG
        CMPA    #$80+EGGID
        BEQ     .13S
        SWI
.13S
      ENDIF                     ;???????????? END OF DEBUG ????????????
        JSR     EGGSCR          ;COLLECT THE EGGS SCORE VALUE
        JMP     HITEM2          ;END OF COLISION WITH EGG
;*
;*      SCORE THE EGG
;*       INPUT REG.U, THE PLAYER'S (VICTOR) WORKSPACE THAT HIT THE EGG
;*              REG.X, THE EGG'S WORKSPACE
;*       OUTPUT - THE EGG'S WORKSPACE TO DISPLAY SCORE VALUE
;*                PJOYT,PPVELX = MESSAGE & COLOR
;*
EGGSCR  PSHS    X,U
        LDX     #SNEGG          ;EGG & PLAYER COLIDE, IF HERE
        JSR     VSND
        LDY     PDECSN,U        ;FIND INCREMENTING SCORE VALUE FOR EGG
        LDA     DCONST,Y        ;GET SCORES COLOR
        LDX     ,S              ;RESTORE EGG'S WORKSPACE
        STA     PPVELX,X        ;SAVE IT IN EGGS PPVELX AREA
        LDY     DEGGS,Y
      IF DEBUG          ;???????????? DEBUG PARAMATER ?????????
        BNE     EGGDB1          ;SHOULD NEVER BE ZERO
        SWI
      ENDIF                     ;???????????? END OF DEBUG ????????????
EGGDB1  LDB     ,Y              ;GET NUMBER OF TIME AN EGG WAS HIT
        CMPB    #4              ;THE MAGIC MAXIMUM NUMBER IS 4
      IF DEBUG = 0      ;???????????? DEBUG PARAMATER ?????????                 ;;Fixme was: IFE DEBUG
        BHS     EGGSMN
      ELSE
        BLO     .1S
        BEQ     EGGSMN          ; BR=AT MAXIMUM
        SWI                     ;ERROR, SHOULD NEVER PASS 4
        LDB     #4-1
      ENDIF                     ;???????????? END OF DEBUG ????????????
.1S     INCB
EGGSMN  STB     ,Y
        STB     PRDIR,X         ;SAVE SCORE VALUE IN EGGS PRDIR WORKSPACE
        ASLB                    ;MULTIPLY BY 3
        ADDB    ,Y
        LDY     #EGGVAL-3       ;       EGG SCORE TABLE
        LEAY    B,Y
        LDA     ,Y              ;GET SCORE VALUE
        LDX     PDECSN,U        ;SCORE IN CORRECT AREA
        JSR     [1,Y]           ;SCORE POINTS WITH PROPER SCORE ROUTINE
;*
        LDY     ,S              ;CAUGHT IN THE AIR BEFORE BOUNCING?
        CLR     PEGG,Y          ;ASSUME NO ADDITIONAL SCORE
        LDA     PFEET,Y
        BNE     .1S             ; BR=NO
        COM     PEGG,Y          ;INDICATE ADDITIONAL SCORE
        LDA     #$05            ;SCORE 500 POINTS
        JSR     SCRHUN          ; (IN PLAYERS WORKSPACE)
;*
.1S     DEC     NRIDER          ;1 LESS ENEMY RIDER
      IF DEBUG          ;???????????? DEBUG PARAMATER ?????????
        BPL     .52S
        SWI             ;RIDER COUNT SHOULD NEVER BE NEGATIVE
.52S
      ENDIF                     ;???????????? END OF DEBUG ????????????
        LDX     ,S
        LDY     PDIST,X         ;WAS A BIRD AFTER THE LITTLE MAN?
        BEQ     EGGWAK          ; BR=NO
        DEC     NENEMY          ;THIS GUY IS NO LONGER AN ENEMY
      IF DEBUG <> 0     ;???????????? DEBUG PARAMATER ?????????                 ;;Fixme was: IFN DEBUG
        BPL     .234S
        SWI
.234S
      ENDIF                     ;???????????? END OF DEBUG ????????????
        LDD     #AUTOFF         ;THE BIRD SHOULD GO OFF SCREEN
        STD     PJOY,Y
EGGWAK  LDD     #EGGHIT         ;WAKE-UP AT HIT EGG AREA
        STD     PPC,X
        LDA     #4
        STA     PNAP,X
        LDA     PID,X           ;NO LONGER COLIDE WITH EGG
        ANDA    #$7F
        STA     PID,X
        PULS    X,U,PC
;*
EGGVAL  FCB     $52             ;250
         FDB    SCRTEN
        FCB     $05             ;500
         FDB    SCRHUN
        FCB     $57             ;750
         FDB    SCRTEN
        FCB     $10             ;PEG AT 1,000
         FDB    SCRHUN
;*
;*      GRAVITY FOR THE EGG
;*       INPUT REG.B ADDITION TO GRAVITY (VELOCITY)
;*       1 - MODIFY VELOCITY Y FOR GRAVITY
;*       2 - CALC NEW POSITIONS
;*
ADDEGG  LDB     GRAV            ;ADD IN VARIABLE GRAVITY
        SEX
        ADDD    PVELY,U
        STD     PVELY,U         ;NEW Y VELOCITY
        ADDD    PPOSY+1,U       ;ADD IN FRACTIONAL DISTANCE
        ADDA    PBUMPY,U        ;ADD IN BUMPING REGISTER
        CLR     PBUMPY,U
        CMPA    #CEILNG         ;HIGHEST POSITION *****
        BHI     ADECEI          ; BR=HAVE NOT HIT CEILING
        INC     PBUMPY,U
        LDD     PVELY,U
        BPL     ADEDWN          ; BR=ALREADY GOING DOWN, DON'T GO UP
        COMA
        NEGB
        SBCA    #-1             ;INVERT VELOCITY
        STD     PVELY,U
ADEDWN  LDD     #CEILNG*256
ADECEI  STD     PPOSY+1,U
        STA     PCOLY1,U        ;MAINTAIN Y-DIRECTION COLISION DETECT POINTERS
        SUBA    #7-1
        STA     PCOLY2,U
;*
        LDA     PVELX,U         ;MODIFY X DIRECTION
        LDX     #FLYX
        LDD     A,X
        ADDB    PVELX+2,U       ;ADD IN FRACTIONAL DISTANCE
        STB     PVELX+2,U
        ADCA    #0              ;CARRY TO POSITION X
        TFR     A,B             ;NEW DELTA DISTANCE
        JSR     WRAPX           ;ADD IN BUMPAGE REG. & NORMAL WRAP AROUND
        CMPD    #288            ;NEW WRAP AROUND STYLE (4 TO 288)
        BLE     EGGWR3
        ADDD    #4-288
EGGWR3  CMPD    #4
        BGE     EGGWR2
        ADDD    #288-4
EGGWR2  STD     PPOSX,U         ;FINAL POSITION
        ADDD    #8-1-1
        STD     PCOLX,U         ;MAINTAIN COLISION DETECT POINTERS
        RTS
;*
;*      EGG FALLING & BOUNCE ROUTINE
;*
STEGG   EQU     *
EGGLPA  JSR     WEGG
        LDA     EMYTIM          ;ENEMY FALL TIME
        JSR     VNAPTPC
        JSR     CEGG
        JSR     ADDEGG          ;FALL DOWN
;*
        JSR     EGGBKG          ;REFRESH BACKGROUND
        LDX     PPOSX,U         ;HAS THE EGG LANDED?
        LDY     PPOSY,U
        LDA     LNDXTB,X
        ORA     LNDXTB-2,X
        ANDA    LNDXTB-9,X
        ANDA    LNDYTB,Y
        ANDA    #$7F            ;IGNORE LAVA TROLL
        BNE     EGGBON          ;BR=EGG HIT TOP OF LAND, BOUNCE IT
EGGBCK
      IF DEBUG <> 0     ;???????????? DEBUG PARAMATER ?????????                 ;;Fixme was: IFN DEBUG
        CMPX    PPOSX,U         ;THIS REGISTER UNCHANGED?
        BEQ     .12S
        SWI
.12S
      ENDIF                     ;???????????? END OF DEBUG ????????????
        LDX     PPOSX,U         ;HAS THE EGG HIT THE BACKGROUND?
        LDY     PPOSY,U         ;NEED THIS IN CASE OF RE-ADJUSTED LANDING
        LDA     BCKXTB,X        ;HIT BACKGROUND CLIFF?
        ANDA    BCKXTB-10,X
        ANDA    BCKYTB+6,Y
        ANDA    BCKYTB+13,Y
        BEQ     .1S
        JSR     BCKCOL          ;COLLIDE WITH BACKGROUND
.1S     LDB     PPOSY+1,U
        CMPB    #FLOOR+4        ;EGG BELOW THE FLOOR? (UGH, WHAT A MESS)
        BLO     EGGLPA          ; BR=NO
        DEC     NRIDER          ;1 LESS RIDER IN THE GAME
      IF DEBUG <> 0     ;???????????? DEBUG PARAMATER ?????????                 ;;Fixme was: IFN DEBUG
        BPL     .52S
        SWI                     ;NBR OF RIDERS LEFT IN GAME SHOULD NOT BE NEG
.52S
      ENDIF                     ;???????????? END OF DEBUG ????????????
        JMP     EGGDN2          ;SCRAMBLED EGG IS FINISHED
;*
EGGBON  STA     PFEET,U         ;NO MORE EGG IN THE AIR BOUNS POINTS
        JSR     LND18           ;CORRECT FOR TOP OF CLIFF
        STB     PCOLY1,U        ;RE-ADJUST COLISION POINTERS
        SUBB    #7-1
        STB     PCOLY2,U
        LDA     PVELX,U
        BEQ     EGGVX0          ;BR=NO X VELOCITY
        BMI     EGGVXM
        ADDA    #-2
        BRA     EGGVX0
;*
EGGVXM  ADDA    #2
EGGVX0  STA     PVELX,U
        LDD     PVELY,U
        BMI     EGGBCK
        ASRA
        RORB
        ASRA
        RORB
        COMA
        NEGB
        SBCA    #-1
        STD     PVELY,U
        CMPD    #-$0020
        BLT     EGGBCK          ;BR=STILL TOO FAST TO LAND
        LDA     PVELX,U
        BNE     EGGBCK          ;BR=STILL TOO FAST TO LAND
;*
EGGLND  LDA     EGGWT           ;GET CURRENT WAIT TIME
        STA     PJOYT,U
EGGLN2  JSR     WEGG
        PCNAP   12              ;12 EGG MAXIMUM, HOPEFULLY MULTIPLEXED
        LDX     PPOSX,U         ;IS THE EGG STILL ON LAND? (BURNING BRIDGE)
        LDY     PPOSY,U
        LDA     LNDXTB,X
        ORA     LNDXTB-2,X
        ANDA    LNDXTB-9,X
        ANDA    LNDYTB+1,Y      ;(FUDGE Y-POSITION FOR STILL ON LAND CHECK)
        ANDA    #$7F            ;IGNORE LAVA TROLL
        LBEQ    STEGG           ;BR=LAND HAS DISAPPEARED, MAKE IT FALL
        DEC     PJOYT,U
        BNE     EGGLN2
        INC     PJOYT,U         ;SET = 1,
        LDA     NENEMY          ;ENOUGH ENEMIES IN THIS WAVE?
        CMPA    WENEMY
        BHS     EGGLN2
        INC     NENEMY          ;1 MORE ENEMY COMMING UP
        LDX     #SNEGGH         ;MAKE THE SOUND OF AN EGG HATCHING
        JSR     VSND
        LDA     #EMYID          ;SIGNAL BUZARD TO  START FLYING IN!
        LDB     PPRI,U
        LDX     #STFLY2
        JSR     VCUPROC         ;CREATE THE BIRD
        STY     PDIST,U         ;A BIRD IS NOW AFTER THE MAN (BIRDS WORKSPACE)
        STU     PDIST,Y         ; & EVEN GIVE THE BIRD TO THE MAN
        LDA     PEGG,U          ;MAINTAIN NBR OF EGGS LEFT IN THE BIRD
        STA     PEGG,Y
        CLR     PCHASE,Y        ;NOT CHASING THE PLAYER
        CLR     PFACE,Y         ;ASSUME BUZZARD COMING IN FROM LEFT HAND SIDE
        CLR     PRDIR,Y         ;ASSUME BIRD NEVER CAME WITHIN SHORT RANGE SCAN
        LDA     #8
        STA     PVELX,Y         ;AT MAXIMUM WARP SPEED
        LDD     #0
        STD     PVELY,Y         ;NOT FALLING YET
        STD     PRIDER,Y        ;& WITHOUT A RIDER
        CLR     PBUMPX,Y
        CLR     PTIMX,Y
        CLR     PFRAME,Y
        LDD     BUZARD
        STD     PHORSE,Y        ;GIVE BUZARD IMAGE
        LDD     PDECSN,U        ;DEFAULT INTELLIGENCE
        STD     PDECSN,Y
        LDD     #SEEKE          ;TELL THE DOGIE TO FETCH THE LITTLE MAN
        STD     PJOY,Y
        LDD     PPOSX,U         ;WHERE IS THE LITTLE MAN?
        SUBD    #(ERIGHT-ELEFT)/2
        BHI     EGGMRT          ; BR=MAN ON RIGHT SIDE OF SCREEN
        COM     PFACE,Y         ;OPPS... COMING FROM RIGHT TO LEFT
        NEG     PVELX,Y
        LDD     #ERIGHT-1
        BRA     EGGMAN
;*
EGGMRT  LDD     #ELEFT+1
EGGMAN  STD     PPOSX,Y
        LDA     PPOSY+1,U       ;FIND LEVEL TO START BIRD
        LDB     #$93+20+2       ;ASSUME STANDING ON CLIFF5
        CMPA    #($D3+$A3)/2    ;ON LEVEL5?
        BHI     .1S             ; BR=NO ON THIS LEVEL
        LDB     #$52+20+2       ;ASSUME STANDING ON CLIF4,CLIF3U,CLIF3R,CLIF3L
        CMPA    #($51+$81)/2    ;ON LEVEL4, LEVEL3, LEVEL2?
        BHI     .1S             ; BR=NO ON THIS LEVEL
        LDB     #$45            ;ASSUME ON LEVEL0, LEVEL1 (CLIF1R,CLIF1L,CLIF2)
.1S     CLRA
        STD     PPOSY,Y
        LDX     #EGGTBL         ;GET SIDE SHOW FOR THE EGG, WHILE THE BIRD IS IN
        STX     PRDIR,U         ; FLIGHT (PRDIR & PPVELX)
        BRA     EGGNXF          ;START THE SHOW!!
;*
EGGHCH  LEAX    3,X             ;NEXT EGG HATCHING FRAME
        STX     PRDIR,U
        JSR     VNAPTPC         ;NAP REG.A TIME
EGGNXF  JSR     CEGG
        JSR     VWR1CLS
        LDA     [PRDIR,U]               ;GET NEXT FRAME OFFSET
        JSR     WEGPAR
        LDX     PRDIR,U         ;GET SHOW TIME POINTER
        LDA     PPOSY+1,U       ;MAINTAIN COLISION DETECT POINTERS
        STA     PCOLY1,U
        SUBA    1,X
        STA     PCOLY2,U
        LDA     2,X
        BNE     EGGHCH          ;BR=MORE HATCHING FRAMES TO GO
;*
        PCNAP   7
        JSR     CEGG            ;WRITE PROPER ENEMIES COLOR
        LDY     PDECSN,U
        LDY     [DPLYR,Y]
        LEAY    24,Y            ;POINT TO STANDING PLAYER
        STY     PPICH,U
        JSR     WRREGY
EGGLLP  PCNAP   8               ;WAIT UNTILL BUZZARD COMES OR KILLED BY PLAYER
        LDY     PPICH,U
        JSR     WRREGY
        BRA     EGGLLP
;*
EGGBKG  LDX     PPOSX,U         ;REFRESH BACKGROUND FROM THE EGG
        LDA     BCKXTB,X        ;RE-PLOT BACKGROUND
        LDX     PPOSY,U
        ANDA    BCKYTB+5+6,X
        ORA     BCKRFS
        STA     BCKRFS
        RTS
;*
EGGHIT
      IF DEBUG <> 0     ;???????????? DEBUG PARAMATER ?????????                 ;;Fixme was: IFN DEBUG
        LDA     PID,U
        CMPA    #EGGID          ;IS THIS AN EGG?
        BEQ     .1S             ; BR=YES
        SWI
.1S
      ENDIF                     ;???????????? END OF DEBUG ????????????
        JSR     CEGG
        JSR     EGGBKG          ;REFRESH BACKGROUND
        LDA     GOVER           ;ATTRACT MODE EGG SCORING?
        BLE     .10S            ; BR=NO
        JSR     ATTEGG          ;ATTRACT MODES CYCLING EGG
.10S    PCNAP   2
        JSR     EGAREA          ;CALC A ACCEPTABLE VISABLE SCREEN ADDRESS
        LDA     #1
        STA     PLAVT,U         ;INITIAL DELAY = NO TIME
        LDX     [PDUMMY]        ;GET 2ND PROCESS IN THE LIST
.20S    LDX     PLINK,X         ;NEXT PROCESS
        BEQ     .100S           ; BR=END SEARCH FOR OVERLAPPING SCORES
        LDA     PID,X           ;AN EGG SCORE?
        CMPA    #SCRID
        BNE     .20S
        LDD     PPOSY,U         ;WITHIN 6 PIXELS IN Y DIRECTION?
        SUBD    PPOSY,X
        BPL     .31S
        COMA
        NEGB
        SBCA    #-1
.31S    SUBD    #6
        BGE     .20S            ; BR=NO, NOT EVEN CLOSE
        LDD     PPOSX,U         ;WITHIN 16 PIXELS IN X DIRECTION?
        SUBD    PPOSX,X
        BPL     .32S
        COMA
        NEGB
        SBCA    #-1
.32S    SUBD    #16
        BGE     .20S            ; BR=NO, NOT EVEN CLOSE
.33S    LDA     PJOYT,X         ;A FASTTER EGG  DISPLAY TIME?
        CMPA    #16/2
        BLO     .34S            ; BR=NO ONLY A FEW TICKS LEFT
        LDA     #16/2           ;YES, SPEED UP THE DISPLAYING SCORE TIME
        STA     PJOYT,X
        LDY     PLINK,X
        LDB     PID,Y           ;CAUGHT EGG I.D.?
        CMPB    #CATID
        BNE     .34S
        STA     PJOYT,Y         ;YES, THIS TIME IS ALSO REDUCED
.34S    ASLA
        ADDA    PLAVT,X         ;ADD IN DELAY FACTOR
        CMPA    PLAVT,U         ;IS THIS TOTAL TIME LARGER?
        BLO     .20S            ; BR=NO, CURRENT DELAY IS THE LONGEST
        STA     PLAVT,U
        BRA     .20S
;*
.100S   LDA     #SCRID          ;EGG SCORES I.D.
        STA     PID,U
        LDA     #60/2           ;1 SECOUND DISPLAY COUNT
        STA     PJOYT,U
.101S   PCNAP   1
        DEC     PLAVT,U
        BNE     .101S
        LDA     PEGG,U          ;DISPLAY THE SCORE IN THE AIR?
        BEQ     .111S           ; BR=NO
        LDX     #.112S          ;DISPLAY THE SCORE IN THE AIR
        LDD     #CATID*256+$FF
        JSR     VCUPROC
        LDD     #MSG500*256+EGGCOL*$11  ;GET SCORE VALUE & COLOR
        STD     PRDIR,Y
        LDD     PPOSX,U
        STD     PPOSX,Y
        LDD     PPOSY,U
        SUBB    #6
        STD     PPOSY,Y
        LDD     PSTATE,U                ;MESSAGE LOCATION
        SUBB    #6
        STD     PSTATE,Y
        LDA     PJOYT,U         ;CURRENT DISPLAY TIME
        STA     PJOYT,Y
        CLR     PLAVT,Y         ;WITH NO DELAYS
.111S   PCNAP   2
.112S   BRA     EGGSC2
;*
;*      PUT UP SCORE VALUE IN THE AIR
;*       INPUT: PPOSX - X PIXEL POSITION
;*              PPOSY - Y PIXEL POSITION
;*              PRDIR,PPVELX - MESSAGE NBR & COLOR
;*
SCRAIR  LDA     #60/2           ;1 SECOUND COUNT
        STA     PJOYT,U
        BSR     EGAREA          ;CALC A ACCEPTABLE VISABLE SCREEN ADDRESS
EGGSC2  LDX     PSTATE,U        ;GET AREA ON SCREEN TO PUT MESSAGE
        LDD     PRDIR,U         ;GET PRDIR (MESSAGE NUMBER) & PPVELX (COLOR)
        DEC     PJOYT,U
        BEQ     EGGSC3
        JSR     OUTP35
        PCNAP   2
        BRA     EGGSC2
;*
EGGSC3  CLRB                    ;ERASE SCORE
        JSR     OUTP35
        JSR     EGGBKG          ;RE-PLOT BACKGROUND
      IF DEBUG <> 0     ;???????????? DEBUG PARAMATER ?????????                 ;;Fixme was: IFN DEBUG
        LDA     PID,U
        CMPA    #EGGID          ;IS THIS AN EGG?
        BEQ     .1S             ; BR=YES
        CMPA    #SCRID          ;IS THIS AN SCORED EGG?
        BEQ     .1S             ; BR=YES
        CMPA    #CATID          ;IS THIS A CAUGHT SCORED EGG?
        BEQ     .1S             ; BR=YES
        CMPA    #PTEID          ;IS THIS AN PTERODACTYL?
        BEQ     .1S             ; BR=YES
        SWI
.1S
      ENDIF                     ;???????????? END OF DEBUG ????????????
        JMP     VSUCIDE
;*
EGGDON
      IF DEBUG <> 0     ;???????????? DEBUG PARAMATER ?????????                 ;;Fixme was: IFN DEBUG
        LDA     PID,U
        CMPA    #EGGID          ;IS THIS AN EGG? (END OF HATCH)
        BEQ     .1S             ; BR=YES
        CMPA    #$80+EGGID      ;IS THIS AN EGG? (ENTERING LAVA)
        BEQ     .1S             ; BR=YES
        SWI
.1S
      ENDIF                     ;???????????? END OF DEBUG ????????????
        JSR     CEGG
EGGDN2  JMP     VSUCIDE
;*
;*      CALCULATE VISABLE EGG SCREEN AREA
;*
EGAREA  LDD     PPOSX,U         ;CALC SCREEN ADDRESS
        ANDB    #$FE            ;UNFLAVOR AREA TO PUT SCORE
        STB     PPOSX+1,U
        RORA
        RORB
        TFR     B,A
        LDB     PPOSY+1,U
        SUBB    #5              ;RAISE THE SCORE (BASED ON TOP LEFT CORNER)
        CMPB    #$D3-1-4        ;MINIMUM LOWEST POINT IS TOP OF CLIFF5
        BLS     EGGPYM          ; BR=OK AREA
        LDB     #$D3-1-4
EGGPYM  CMPA    #(288-16)/2             ;MESSAGE WILL NOT WRAP AROUND
        BLS     EGGPXM
        LDA     #(288-16)/2
EGGPXM  STD     PSTATE,U
        STB     PPOSY+1,U       ;CORRECTED AREA FOR DISPLAYING SCORE
        TFR     A,B
        CLRA
        ASLB
        ROLA
        STD     PPOSX,U
        RTS
;*
;*      ATTRACT MODES CYCLING EGG SCORE
;*
ATTEGG  LDX     #.20S           ;ATTRACT MODE EGG SCORE CYCLE
        LDD     #EGGID*256+$FF
        JSR     VCUPROC
        LDD     PPOSX,U
        STD     PPOSX,Y
        LDD     PPOSY,U
        STD     PPOSY,Y
        LDD     PRDIR,U
        STD     PRDIR,Y
        RTS
;*
.10S    BSR     ATTEGG
        JMP     SCRAIR
.20S    PCNAP   60+8
        INC     PRDIR,U         ;NEXT MESSAGE NUMBER
        LDA     PRDIR,U
        CMPA    #4
        BLS     .10S
        JMP     VSUCIDE
;*
WEGG    JSR     VWR1CLS
        LDA     PVELX,U
        BPL     WEGRIT
        LDY     #EGFLFT         ;EGG FALLING TO THE LEFT
        BRA     WEGY
;*
WEGRIT  LDY     #EGFRIT         ;ASSUME EGG FALLING TO THE RIGHT
WEGY    LDD     PVELY,U         ;HOW FAST IS EGG FALLING?
        BMI     WEGVM           ; BR=EGG FALLING UP???
        SUBD    #$0080
        BGT     WEGD2           ;BR=NOT THIS SLOW
WEGUP   LDA     ,Y              ;GET FRAME LEVEL FRAME
        BRA     WEGPAR
;*
WEGD2   LDA     2,Y
        BRA     WEGPAR
;*
WEGVM   ADDD    #$0080
        BGT     WEGUP
WEGD3   LDA     1,Y
WEGPAR  LDY     EGGI
        LEAY    A,Y
        STY     PPICH,U
        JSR     WRHOR2
        JMP     CLIPER          ;CLIP THE EGG AS NEEDED
;*
;*      EGG ANIMATION TABLE
;*
EGFLFT  FCB     0,12,6          ;FALLING LEFT
EGFRIT  FCB     0,6,12          ;FALLING RIGHT
EGGTBL  FCB     6,6,7           ;WIGGLE LEFT
        FCB     0,6,3           ;WIGGLE UP
        FCB     12,6,7          ;WIGGLE RIGHT
        FCB     0,6,7+60        ;WIGGLE UP & PAUSE
        FCB     18,6,7          ;HATCH 1
        FCB     24,11,7         ;HATCH 2
        FCB     30,11,7         ;HATCH 3
        FCB     36,11,0         ;HATCH 4
;*
;*      BUZARD SEEKING MAN
;*       PDIST IS THE MANS WORKSPACE FOR PPOSX & PPOSY & HANDSHAKING
;*
SEEKE   LDY     PDIST,U         ;GET THE MANS WORKSPACE
        CLRB
        LDA     PPOSY+1,Y       ;HOW ABOUT THE Y LEVEL
        CMPA    PPOSY+1,U
        BEQ     SEEKF1
        BLO     SEEKBL          ; BR=BELOW TARGETED MAN
        LDB     PVELY,U         ;NOT TOO FAST A DROP!
        CMPB    #2
        BGE     SEEKBL
        LDX     PPOSX,U         ;IS A CLIFF IN THE WAY??
        LDA     BCKXTB+18,X     ;ASSUME FLYING TO THE RIGHT
        LDB     PVELX,U
        BPL     SEEKC2          ; BR=ASSUMPTION CORRECT
        LDA     BCKXTB-18,X     ;LOOK IN OPPOSITE DIRECTION
SEEKC2  LDX     PPOSY,U
        CLRB                    ;ASSUME NO FLAP
        ANDA    BCKYTB,X
        ANDA    #$08            ;CLIF3U IS A BITCH!
        BEQ     SEEKF1          ; BR=NO CLIFF IN THE WAY
SEEKBL  CLRB
        LDA     PVELY,U
        CMPA    #-1             ;MAXIMUM UPWARD VELOCITY (MINIMIZE OVERSHOOT)
        BLT     SEEKF1
        LDD     #SEEKF2         ;FLAP ROUTINE
        STD     PJOY,U
        LDA     #4
        STA     PJOYT,U
        LDB     #1              ;FLAP WINGS, YOU ARE BELOW THE MAN
SEEKF1  PSHS    B
        LDD     PPOSX,Y         ;WHICH DIRECTION TO FACE?
        ADDD    #-12
        SUBD    PPOSX,U
        BPL     SEEKFR          ; BR=LONG RANGE REG.X
        ADDD    #8+12
        BMI     SEEKFL          ; BR=LONG RANGE REG.X
SEEKFS  LDA     #1
        STA     PRDIR,U         ;THE BIRD CAME WITHIN SHORT RANGE SENSORS
        LDX     PSTATE,U        ;MAKE SURE BIRD IS NOT TRAPPED ON ANOTHER CLIFF
        BEQ     SEEKAR          ; BR=SEEKING FROM THE AIR
        LDA     PPOSY+1,Y
        CMPB    PPOSY+1,U
        BHI     SEEKFJ          ;BR=ON HIGHER CLIFF
        LDA     PVELX,U         ;FINALLY STOPPED??
        BEQ     MOUNTM          ;GOT THE MAN!!!
        LDA     PVELX,U         ;SLOW DOWN!!!
        BMI     SEEKR
        BRA     SEEKL
;*
SEEKAR  LDA     PVELX,U         ;SLOW DOWN, BUT DO NOT REVERSE
        BMI     SEEKL3
        BGT     SEEKR3
        LDA     PFACE,U         ;SPEED =0, USE DIRECTION FACING FOR DIRECTION
        BMI     SEEKL
        BRA     SEEKR
;*
SEEKL3  CMPA    #-2
        BEQ     SEEKF0          ;BR=SLOWEST SPEED
        BRA     SEEKR           ;HERE IF GOING TO THE LEFT TOO FAST
;*
SEEKR3  CMPA    #2
        BEQ     SEEKF0          ;BR=SLOWEST SPEED
        BRA     SEEKL           ;HERE IF GOING TO THE RIGHT TOO FAST
;*
SEEKFJ  LDA     PVELX,U         ;WRONG CLIFF TRY AGAIN
        BMI     SEEKL2
        BRA     SEEKR2
;*
SEEKFL  LDA     PRDIR,U         ;DID BIRD EVER COM IN SHORT RANGE AREA?
        BNE     SEEKS
SEEKL2  LDA     PVELX,U
        BMI     SEEKF0
SEEKL   LDA     #-1
        PULS    B
        STD     CURJOY
        RTS
;*
SEEKFR  LDA     PRDIR,U         ;DID BIRD EVER COM IN SHORT RANGE AREA?
        BNE     SEEKS
SEEKR2  LDA     PVELX,U
        BGT     SEEKF0
SEEKR   LDA     #1
        PULS    B
        STD     CURJOY
        RTS
;*
SEEKF0  CLRA
        PULS    B
        STD     CURJOY
        RTS
;*
SEEKS   LDD     PPOSX,Y
        SUBD    PPOSX,U         ;WHICH WAY IS THE SHORTEST WAY TO TRAVEL?
        BMI     SEEKSM
SEEKSP  CMPD    #(ERIGHT-ELEFT)/2       ;CHECK FOR WRAP AROUND
        BLT     SEEKSD
        SUBD    #ERIGHT-ELEFT           ;UNRAP THE DIFFERENCE
        BRA     SEEKSD
;*
SEEKSM  CMPD    #-(ERIGHT-ELEFT)/2
        BGT     SEEKSD
        ADDD    #ERIGHT-ELEFT
SEEKSD  TSTA
        BMI     SEEKL2
        BRA     SEEKR2
;*
MOUNTM  PULS    B               ;RESTORE STACK
        LDD     #MOUNLP
        STD     PJOY,U
        LDA     #5+1            ;WAIT A BIT
        STA     PJOYT,U
MOUNLP  DEC     PJOYT,U
        BEQ     MOUNRI          ;BR=TIME FOR RIDER
        LDA     #1              ;RUN TO THE RIGHT FOR YOUR LIFE
        LDB     PFACE,U
        BPL     MOUNRN
        NEGA
MOUNRN  CLRB
        STD     CURJOY
        RTS
;*
MOUNRI  INC     NSMART          ;JUST GOT SMARTER
      IF DEBUG <> 0     ;???????????? DEBUG PARAMATER ?????????                 ;;Fixme was: IFN DEBUG
        LDA     PCHASE,U        ;DEBUG, BETTER BE ZERO
        BEQ     .1S
        SWI
.1S
      ENDIF                     ;???????????? END OF DEBUG ????????????
        INC     PCHASE,U
        LDX     #SNMOUN         ;MAKE A MOUNT THE BUZZARD SOUND
        JSR     VSND
        LDX     PDIST,U         ;KILL EGG ROUTINE
        LDD     #EGGDON
        STD     PPC,X
        LDA     #1              ;WAKE-UP IMMEDIATELY
        STA     PNAP,X
        LDA     PID,X           ;NO-LONGER COLISIONABLE
        ANDA    #$7F
        STA     PID,X
        LDX     PDECSN,U
        LDA     GOVER           ;GAME OVER?
        BNE     .2S             ; BR=NO
        LDD     DJOY,X          ;YES, SELECT A DUMMIE DUM DUM BIRD
        BRA     .3S
;*
.2S     LDD     DSMART,X        ;SELECT PROPER JOYSTICK ROUTINE
.3S     STD     PJOY,U
        JMP     PLYLI2          ;ENEMY RE-INCARNATED!!! (WHO CAES ABOUT STACK)
;*
SEEKF2  DEC     PJOYT,U         ;FLAP ROUTINE
        BEQ     SEEKF3
        LDD     #1
        STD     CURJOY
        RTS
;*
SEEKF3  LDD     #SEEKE
        STD     PJOY,U
        LDD     #0
        STD     CURJOY
        RTS
;*
;*      RADDR
;*
RADDR   JSR     VRAND
        ROLA
        LDB     #$10
        MUL
        ORA     #$A0
        TFR     D,X
        INC     ,X
        RTS
;*
;*      LINE TRACKING INTELLIGENCE
;*
LINET   LDA     NSMART          ;GET NUMBER OF SMART ENEMIES
        CMPA    WSMART          ;BELOW MINIMUM INTELLIGENCE?
        BLO     LNTSMT          ; BR=YES, GET SMARTER
        DEC     PLAVT,U
        BGT     .1S
        LDA     LNTLAV          ;LINE TRACKING LAVA TROLL LOOKER
        STA     PLAVT,U
        LDX     PPREV           ;LAVA TROLL AFTER ME?
        LDA     PID,X
        CMPA    #LAVID
        BEQ     LNTUP
.1S     LDA     #AOFFL1         ;ASSUME NEAR TRACKING LINE 1
        LDB     PPOSY+1,U
        CMPB    #AOFFL1+AOFFUD
        BLO     LNTTRK          ; BR=TRACK ON LINE 1
        LDA     #AOFFL2         ;ASSUME NEAR TRACKING LINE 2
        CMPB    #AOFFL2+AOFFUD
        BLO     LNTTRK          ; BR=TRACK ON LINE 2
        LDA     #AOFFL3         ;ASSUME NEAR TRACKING LINE 3
LNTTRK  CLRB                    ;ASSUME ON TRACKING LINE
        SUBA    PPOSY+1,U       ;ABOVE OR BELOW LINE?
        BPL     LNTFLP          ;BR=AROUND THE LINE
        LDA     PVELY,U         ;ALREADY GOING UP?
        BMI     LNTFLP          ; BR=YES, SO WAIT TILL NEXT TIME
LNTUP   LDD     #LNTOFP         ;GET OFF GROUND OR JUST FLAP
        STD     PJOY,U
        LDB     #1
LNTFLP  TST     PFACE,U         ;MOVE IN DIRECTION OF FACING
        BMI     LNTLF2
        LDA     #1
        STD     CURJOY
        RTS
;*
LNTLF2  LDA     #-1
        STD     CURJOY
        RTS
;*
LNTOFP  LDD     #LINET
        STD     PJOY,U
        CLRB
        BRA     LNTFLP
;*
LNTSMT  INC     NSMART          ;JUST GOT SMARTER
      IF DEBUG <> 0     ;???????????? DEBUG PARAMATER ?????????                 ;;Fixme was: IFN DEBUG
        LDA     PCHASE,U        ;DEBUG, BETTER BE ZERO
        BEQ     .1S
        SWI
.1S
      ENDIF                     ;???????????? END OF DEBUG ????????????
        INC     PCHASE,U
        LDX     PDECSN,U
        LDX     DSMART,X
        STX     PJOY,U          ;NEW SMARTS
        JMP     ,X              ;START THE SMARTS
     IF DEBUG = 0                                                       ;;Fixme was: IFE DEBUG
;*
;*      AND THE EVER POPULAR COPYRIGHT MESSAGE
;*
        FCC     'JOUST (C) 1982 WILLIAMS ELECTRONICS INC.'
     ENDIF
;*
;*      BOUNDAR
;*
DYLEN   EQU     $14-6
;*
BOUNDR  DEC     PLAVT,U
        BGT     .1S
        LDA     LNTLAV          ;LINE TRACKING LAVA TROLL LOOKER
        STA     PLAVT,U
        LDX     PPREV           ;LAVA TROLL AFTER ME?
        LDA     PID,X
        CMPA    #LAVID
        BEQ     BODN1A
.1S
        JSR     SELPLY          ;SELECT TARGETED PLAYER
        BEQ     BOLEVV          ;BR=NO PLAYERS HERE
        LDD     PPOSY,X
        SUBD    PPOSY,U
        LBLT    BOUNUP
BOUNDN  CMPD    BODNRG          ;#DYLEN         LONG OR SHORT RANGE SEEK
        BLT     BOLEVV          ; BR=SHORT RANGE SEEK
BODN    LDD     BODNDI          ;-DYLEN*256     SET DISTANCE TO GO DOWN
        STD     PDIST,U
        LDD     #BODN1          ;FLAP WINGS
        STD     PJOY,U
        BRA     BODN10
;*
BOLEVV  JMP     BOLEV
;*
BODN1   LDD     PSTATE,U        ;ON THE GROUND?
        BNE     BOBRAIN         ; BR=YES, CANNOT GO DOWN ANY FURTHER
        LDD     PVELY,U         ;GOING DOWN?
        BMI     BOUP1B          ;BODN1B  BR=NO
        ADDD    PDIST,U
        BPL     BOBRAIN         ;BACK TO THE BRAINS
        STD     PDIST,U
BODN10  LDD     PVELY,U
BODN11  SUBD    BODNVY          ;#$0100         FALLING NOT TOO FAST?
        BMI     BOUP1B          ;BODN1B  BR=NO
BODN1A  LDD     #BODN2          ;FLAP WINGS
        STD     PJOY,U
        LDA     #2
        BRA     BOUP12
;********       STA     PJOYT,U         WING DOWN TIME
;********       LDB     #$01
;********       BRA     BODIRL
;*
BODN2   LDD     PVELY,U
        BMI     BODN22
        ADDD    PDIST,U
        BPL     BOBRAIN         ;BACK TO THE BRAINS
        STD     PDIST,U
BODN22  LDB     #1              ;ASSUME WINGS DOWN
        DEC     PJOYT,U         ;WING DOWN TIME UP??
        BGT     BODN2A          ; BR=NO
        LDD     #BODN1
        STD     PJOY,U
        CLRB                    ;WINGS UP
BODN2A  BRA     BODIRL
;*
BOBRAIN JMP     BOUNDR
;*
BOUNUP  CMPD    BOUPRG          ;#-DYLEN                LONG OR SHORT RANGE SEEK
        BGT     BOLEV           ; BR=SHORT RANGE SEEK
BOUP    LDX     PPOSX,U         ;CLIFF IN THE WAY??
        LDY     PPOSY,U
        LDA     BCKXTB,X
        ANDA    BCKYTB-DYLEN,Y
        BNE     BOLEV           ; BR=YES
        LDD     BOUPDI          ;#DYLEN*256     NO, SET DISTANCE TO GO UP
        STD     PDIST,U
        BRA     BOUP1A
;*
BOUP1   LDD     PVELY,U         ;GOING UP?
        BPL     BOUP11          ; BR=NO
        ADDD    PDIST,U
        BMI     BOBRAIN         ;BACK TO THE BRAINS
        STD     PDIST,U
BOUP11  DEC     PJOYT,U         ;TIME TO FLAP WINGS
        BGT     BOUP1B          ; BR=NO
BOUP1A  LDD     #BOUP2          ;FLAP WINGS
        STD     PJOY,U
        LDA     BOUPWD          ;#2
BOUP12  STA     PJOYT,U         ;WING DOWN TIME
        LDB     #$01
        BRA     BODIRL
;*
BOUP1B  CLRB                    ;WINGS UP
BODIRL  LDA     PPOSY+1,U       ;BELOW CLIF5?
        CMPA    #$D3
        BLO     BODIR           ; BR=NO
        LDA     PVELY,U         ;ALREADY GOING UP?
        LBPL    BOLAVA          ; BR=NO, GO UP FAST BEFORE THE LAVA GETS ME!!
;*
BODIR   LDA     PFACE,U
        BMI     BODN1C
        LDA     #1
        STD     CURJOY
        RTS
;*
BODN1C  LDA     #-1
        STD     CURJOY
        RTS
;*
BOUP2   LDD     PVELY,U
        BPL     BOUP22
        ADDD    PDIST,U
        BMI     BOBRAIN         ;BACK TO THE BRAINS
        STD     PDIST,U
BOUP22  LDB     #1              ;ASSSUME WINGS DOWN
        DEC     PJOYT,U         ;WING DOWN TIME UP??
        BGT     BOUP2A          ; BR=NO
        LDA     BOUPWU          ;#8
        STA     PJOYT,U
        LDD     #BOUP1
        STD     PJOY,U
        CLRB                    ;WINGS UP
BOUP2A  BRA     BODIRL
;*
BOBRA2  JMP     BOUNDR  ;BACK TO THE BRAINS
;*
BOLEV   LDD     #BOLEV1         ;LEVEL FLIGHT
        STD     PJOY,U
        LDD     PPOSY,U         ;REMEMBER LINE TO TRACK
        STD     PDIST,U
        LDA     PVELX,X         ;& PLAYERS VELOCITY
        STA     PPVELX,U
        LDA     BOLETM          ;#20+1          TIME UNTIL NEXT DECISION
        STA     PJOYT,U
BOLEV1  DEC     PJOYT,U
        BLE     BOBRA2
        LDB     PPOSY+1,U
        CMPB    #$D3            ;BELOW CLIF5?
        BLO     .3S             ; BR=NO
        JSR     SELPLY          ;SELECT TARGETED PLAYER
        BEQ     BOFAST          ;BR=NO PLAYERS HERE, GO UP
        LDD     PPOSX,X         ;IS PLAYER CLOSE BY?
        ADDD    #3*18+9
        CMPD    PPOSX,U
        BLT     BOFAST          ;BR=NO, GO UP
        ADDD    #-2*(3*18+9)
        CMPD    PPOSX,U
        BGT     BOFAST          ;BR=GO UP FAST BEFORE THE LAVA GETS ME!!
;*                              ;IF HERE, LET HIM LOURE ME INTO LAVA
.3S     LDA     PVELY,U         ;FALLING?
        BMI     BOLEVA          ; BR=NO
        LDB     PDIST+1,U       ;ABOVE TRACKING LINE
        CMPB    PPOSY+1,U
        BLO     BOLEVA          ; BR=YES
BOFAST  LDD     #BOLEV2         ;FAST EXIT UP
        STD     PJOY,U
        LDB     #$01            ;FLAP WINGS
        BRA     BOLEVB
;*
BOLEV2  LDD     #BOLEV1
        STD     PJOY,U
BOLEVA  CLRB                    ;WINGS UP
BOLEVB  LDA     PPVELX,U        ;DO NOT COPY PLAYERS MOVES TOO OFTEN
        CMPA    PVELX,U
        BNE     BODIR3
        DEC     PRDIR,U
        BMI     BODIR3
        CLR     PRDIR,U
        COM     PFACE,U         ;TRY THE OTHER DIRECTION
BODIR3  JMP     BODIR
;*
BOLAV1  LDA     PPOSY+1,U
        CMPA    #$D3            ;BELOW CLIF5?
        BLO     BOLAV4          ; BR=NOT ANY MORE
        LDA     PVELY,U         ;YES, GOING UP?
        BMI     BOLAV4          ; BR=YES, IGNORE LAVA
BOLAVA  LDD     #BOLAV2
        STD     PJOY,U
        LDB     #1
        BRA     BODIR3
;*
BOLAV2  LDD     #BOLAV1
        STD     PJOY,U
        CLRB
        BRA     BODIR3
;*
BOLAV4  LDX     PDECSN,U        ;BACK TO THE BRAINS
        JMP     [DSMART,X]
;*
;*      ADVANCED BOUNDAR (HUNTER)
;*
B2YLEN  EQU     $14-6
B2XLEN  EQU     27+4
;*
B2UNDR  DEC     PLAVT,U
        BGT     .1S
        LDA     LNTLAV          ;LINE TRACKING LAVA TROLL LOOKER
        STA     PLAVT,U
        LDX     PPREV           ;LAVA TROLL AFTER ME?
        LDA     PID,X
        CMPA    #LAVID
        BEQ     B2DN1A
.1S     JSR     SELPLY          ;SELECT TARGETED PLAYER
        BEQ     B2LEVV          ;BR=NO PLAYERS HERE
        LDD     PPOSY,X
        SUBD    PPOSY,U
        LBLT    B2UNUP
B2UNDN  SUBD    HUDNRG          ;#B2YLEN                LONG OR SHORT RANGE SEEK
        BLT     B2LEVV          ; BR=SHORT RANGE SEEK
;*
B2DN
B2DNST  LDD     HUDNDI          ;#-B2YLEN*256   NO, SET DISTANCE TO GO DOWN
        STD     PDIST,U
        LDD     #B2DN2          ;FLAP WINGS
        STD     PJOY,U
        BRA     B2DN1B
;*
B2LEVV  JMP     B2LEV
;*
B2DN1   LDD     PSTATE,U        ;ON THE GROUND?
        BNE     B2BRAIN         ; BR=YES
        LDD     PVELY,U         ;GOING DOWN?
        BMI     B2DN1B          ; BR=NO
        ADDD    PDIST,U
        BPL     B2BRAIN         ;BACK TO THE BRAINS
        STD     PDIST,U
        LDD     PVELY,U
B2DN11  SUBD    HUDNVY          ;#$0200         FALLING NOT TOO FAST?
        BMI     B2DN1B          ; BR=NO
B2DN1A  LDD     #B2DN2          ;FLAP WINGS
        STD     PJOY,U
        LDA     #2
        STA     PJOYT,U         ;WING DOWN TIME
B2DN2B  LDB     #$01
        JMP     B2DIRL
;*
B2DN2   LDD     PVELY,U
        BMI     B2DN22
        ADDD    PDIST,U
        BPL     B2BRAIN         ;BACK TO THE BRAINS
        STD     PDIST,U
B2DN22  LDB     #1              ;ASSUME WINGS DOWN
        DEC     PJOYT,U         ;WING DOWN TIME UP??
        BGT     B2DIR2          ; BR=NO
        LDD     #B2DN1
        STD     PJOY,U
B2DN1B  CLRB                    ;WINGS UP
B2DIR2  JMP     B2DIRL
;*
B2BRAIN JMP     B2UNDR
;*
B2UNUP  CMPD    HUUPRG          ;#-B2YLEN               LONG/SHORT RANGE SEEK
        BGT     B2LEVV          ; BR=SHORT RANGE SEEK
B2UP    LDX     PPOSX,U         ;CLIFF IN THE WAY??
        LDY     PPOSY,U
        LDA     BCKXTB,X
        ANDA    BCKYTB-B2YLEN,Y
        LBNE    B2UP3           ; BR=YES
B2UPST  LDD     HUUPDI          ;#B2YLEN*256    NO, SET DISTANCE TO GO UP
        STD     PDIST,U
        BRA     B2UP2D
;*
B2UP2   LDD     PVELY,U
        BPL     B2UP22
        ADDD    PDIST,U
        BMI     B2BRAIN         ;BACK TO THE BRAINS
        STD     PDIST,U
B2UP22  LDB     #1              ;ASSSUME WINGS DOWN
        DEC     PJOYT,U         ;WING DOWN TIME UP??
        BGT     B2UP2A          ; BR=NO
B2UP2D  LDA     HUUPWU          ;#8
        STA     PJOYT,U
        LDD     #B2UP1
        STD     PJOY,U
        CLRB                    ;WINGS UP
B2UP2A  BRA     B2DIRL
;*
B2LEV   LDD     #B2LEV1         ;LEVEL FLIGHT
        STD     PJOY,U
        LDD     PPOSY,U         ;REMEMBER LINE TO TRACK
        STD     PDIST,U
        LDA     PVELX,X         ;& PLAYERS VELOCITY
        STA     PPVELX,U
        LDA     HULETM          ;#20+1          TIME UNTIL NEXT DECISION
        STA     PJOYT,U
;*
B2LEV1  DEC     PJOYT,U
        LBLE    B2BRA2
        LDA     PVELY,U         ;FALLING?
        LBMI    B2LEVA          ; BR=NO
        LDB     PPOSY+1,U       ;YES, BELOW CLIF5?
        CMPB    #$D3
        BLO     .3S             ; BR=NO
        JSR     SELPLY          ;SELECT TARGETED PLAYER
        BEQ     B2FAST          ;BR=NO PLAYERS HERE, GO UP
        LDD     PPOSX,X         ;IS PLAYER CLOSE BY?
        ADDD    #2*18+9
        CMPD    PPOSX,U
        BLT     B2FAST          ;BR=NO, GO UP
        ADDD    #-2*(2*18+9)
        CMPD    PPOSX,U
        BGT     B2FAST          ;BR=GO UP FAST BEFORE THE LAVA GETS ME!!
;*                              ;IF HERE, LET HIM LOURE ME INTO LAVA
.3S     LDB     PDIST+1,U       ;AB2VE TRACKING LINE
        CMPB    PPOSY+1,U
        LBLO    B2LEVA          ; BR=YES
B2FAST  LDD     #B2LEV2
        STD     PJOY,U
        LDB     #$01            ;FLAP WINGS
;*
B2LE11  LDA     PPVELX,U        ;DO NOT COPY PLAYERS MOVES TOO OFTEN
        CMPA    PVELX,U
        BNE     B2DIR
        DEC     PRDIR,U
        BMI     B2DIR
        CLR     PRDIR,U
        COM     PFACE,U         ;TRY THE OTHER DIRECTION
        BRA     B2DIR
;*
;*
B2DIRL  LDA     PPOSY+1,U       ;BELOW CLIF5?
        CMPA    #$D3
        BLO     B2DIR
        LDA     PVELY,U         ;GOING DOWN?
        BMI     B2DIR           ; BR=NO
        JMP     BOLAVA          ;STANDARD WAY TO AVOID THE LAVA
;*
B2DIR   LDA     PVELX,U         ;WHICH DIRECTION GOING?
        BEQ     B2DIRA
        BPL     B2DILR
        PSHS    B
        LDD     PVELY,U         ;SEEKING DESTINATION CLIFF
        ASLB
        ROLA
        ASLB
        ROLA
        ASLB
        ROLA
        PULS    B
        LDY     PPOSY,U
        LDX     PPOSX,U
        LEAY    A,Y
        LDA     BCKXTB-B2XLEN,X
        ANDA    BCKYTB,Y
        BEQ     B2DIRA          ; BR=YES
        CLR     PFACE,U         ;FACE RIGHT
        BRA     B2DICL
;*
B2DILR  PSHS    B
        LDD     PVELY,U
        ASLB
        ROLA
        ASLB
        ROLA
        ASLB
        ROLA
        PULS    B
        LDY     PPOSY,U
        LDX     PPOSX,U
        LEAY    A,Y
        LDA     BCKXTB+B2XLEN,X
        ANDA    BCKYTB,Y
        BEQ     B2DIRA          ; BR=YES
        LDA     #-1
        STA     PFACE,U         ;FACE LEFT
B2DICL  LDD     #B2AV           ;SLOW DOWN!!! GOING INTO A CLIFF
        STD     PJOY,U
        LDA     #8
        STA     PJOYT,U
        LDB     #1
;*
B2DIRA  LDA     PBUMPX,U        ;FACE, BUMPED DIRECTION
        BEQ     B2FDIR
        STA     PFACE,U
B2FDIR  LDA     PFACE,U
        BMI     B2DN1C
        LDA     #1
        STD     CURJOY
        RTS
;*
B2DN1C  LDA     #-1
        STD     CURJOY
        RTS
;*
;*
B2LEV2  LDD     #B2LEV1
        STD     PJOY,U
B2LEVA  CLRB                    ;WINGS UP
        JMP     B2LE11
;*
B2BRA2  JMP     B2UNDR  ;BACK TO THE BRAINS
;*
B2UP1   LDD     PVELY,U         ;GOING DOWN?
        BPL     B2UP11          ; BR=NO
        ADDD    PDIST,U
        BMI     B2BRA2          ;BACK TO THE BRAINS
        STD     PDIST,U
B2UP11  DEC     PJOYT,U         ;TIME TO FLAP WINGS
        BGT     B2UP1B          ; BR=NO
        INC     PJOYT,U
        LDD     PVELY,U
        CMPD    HUUPVY          ;#-$0100
        BLT     B2UP1B
B2UP1A  LDD     #B2UP2          ;FLAP WINGS
        STD     PJOY,U
        LDA     HUUPWD          ;#2
        STA     PJOYT,U         ;WING DOWN TIME
        LDB     #$01
        JMP     B2DIRL
;*
B2UP1B  CLRB                    ;WINGS UP
        JMP     B2DIRL
;*
B2AV    CLRB
        DEC     PJOYT,U
        BGT     B2DIRA
        JMP     B2UNDR
;*
B2UP3   LDD     #B2UP3A         ;LEVEL FLIGHT, READY TO GO UP
        STD     PJOY,U
        LDD     PPOSY,U         ;REMEMBER LINE TO TRACK
        STD     PDIST,U
        LDA     #20+1           ;TIME UNTIL NEXT DECISION
        STA     PJOYT,U
;*
B2UP3A  LDX     PPOSX,U         ;CLIFF IN THE WAY??
        LDY     PPOSY,U
        LDA     BCKXTB,X
        ANDA    BCKYTB-B2YLEN,Y
        LBEQ    B2UPST
        DEC     PJOYT,U
        LBLE    B2UNDR
        LDD     PVELY,U         ;FALLING FAST ENOUGH?
        ADDD    #-$0040
        BMI     B2UP3B          ; BR=NO
        LDB     PDIST+1,U       ;ABOVE TRACKING LINE
        CMPB    PPOSY+1,U
        BLO     B2UP3B          ; BR=YES
        LDD     #B2UP4
        STD     PJOY,U
        LDB     #$01            ;FLAP WINGS
        JMP     B2DIRA
;*
B2UP4   LDD     #B2UP3A
        STD     PJOY,U
B2UP3B  CLRB                    ;FLAP WINGS
        JMP     B2DIRA
;*
;*      SHADOW LORD
;*
SHYLEN  EQU     $14-6
SHXLEN  EQU     27+4
;*
SHADOW  DEC     PLAVT,U
        BGT     .1S
        LDA     LNTLAV          ;LINE TRACKING LAVA TROLL LOOKER
        STA     PLAVT,U
        LDX     PPREV           ;LAVA TROLL AFTER ME?
        LDA     PID,X
        CMPA    #LAVID
        BEQ     SHUPST
.1S     JSR     SELPLY          ;SELECT TARGETED PLAYER
        LBEQ    SHLEV           ;BR=NO PLAYERS HERE
        LDD     PPOSY,X
        SUBD    PPOSY,U
        LBLT    SHUNUP
SHUNDN  SUBD    SHDNRG          ;#SHYLEN                LONG OR SHORT RANGE SEEK
        BLT     SHLEP           ; BR=SHORT RANGE SEEK
;*
SHDN    LDD     #SHDN2          ;NO FLAPING WINGS
        STD     PJOY,U
        CLRB                    ;WINGS UP
        LDA     PPOSY+1,U       ;BELOW CLIF5?
        CMPA    #$D3
        BLO     .3S             ; BR=NO
        LDA     PVELX,U         ;FALLING?
        BMI     .3S             ; BR=NO
        INCB                    ;FLAP YOUR WINGS!!!, HOT LAVA BELOW
.3S     JMP     SHDIRB
;*
SHUNUP  CMPD    SHUPRG          ;#-SHYLEN       LONG OR SHORT RANGE SEEK
        BGT     SHLEP           ; BR=SHORTEST RANGE SEEK
        LDX     PPOSX,U         ;CLIFF IN THE WAY??
        LDY     PPOSY,U
        LDA     BCKXTB,X
        ANDA    BCKYTB-SHYLEN,Y
        LBNE    SHUP3           ; BR=YES
SHUPST  LDD     #SHUP1
        STD     PJOY,U
SHUP0   CLRB                    ;WINGS UP
        JMP     SHDIRB
;*
SHUP1   LDD     #SHADOW         ;FLAP WINGS
        STD     PJOY,U
        LDD     PVELY,U
        CMPD    SHUPVY          ;#-$0200
        BLT     SHUP0
        LDB     #$01
        JMP     SHDIRB
;*
SHLEP   LDD     #SHLEP1         ;LEVEL FLIGHT
        STD     PJOY,U
        LDB     PPOSY+1,X       ;PLAYERS LINE TO TRACK
        STB     PDIST+1,U
        LDA     PVELX,X         ;& PLAYERS VELOCITY
        STA     PPVELX,U
        LDA     SHUPTM          ;#8+1           TIME UNTIL NEXT DECISION
        STA     PJOYT,U
;*
SHLEP1  DEC     PJOYT,U
        LBLE    SHBRA2
        LDB     PPOSY+1,U
        CMPB    #$D3            ;GETTING TOO CLOSE TO THE LAVA?
        BLO     .2S             ; BR=YES
        LDA     PVELY,U         ;ALREADY GOING UP?
        BPL     SHFAST          ; BR=NO
.2S     CMPB    PDIST+1,U       ;ABOVE TRACKING LINE
        BLS     SHLEPA          ; BR=YES
SHFAST  LDD     #SHLEP2
        STD     PJOY,U
        LDB     #$01            ;FLAP WINGS
        BRA     SHLEPB
;*
SHLEP2  LDD     #SHLEP1
        STD     PJOY,U
SHLEPA  CLRB                    ;WINGS UP
SHLEPB  LDA     PPVELX,U        ;DO NOT COPY PLAYERS MOVES TOO OFTEN
        CMPA    PVELX,U
        LBNE    SHDIRA
        DEC     PRDIR,U
        LBMI    SHDIRA
        CLR     PRDIR,U
        COM     PFACE,U         ;TRY THE OTHER DIRECTION
        JMP     SHDIRA
;*
SHLEV   LDD     #SHLEV1         ;LEVEL FLIGHT
        STD     PJOY,U
        LDB     PPOSY+1,U       ;REMEMBER LINE TO TRACK
        STB     PDIST+1,U
        LDA     SHLETM          ;#8+1           TIME UNTIL NEXT DECISION
        STA     PJOYT,U
;*
SHLEV1  DEC     PJOYT,U
        LBLE    SHBRA2
        LDA     PVELY,U         ;FALLING?
        LBMI    SHLEVA          ; BR=NO
        LDB     PDIST+1,U       ;ABOVE TRACKING LINE
        CMPB    PPOSY+1,U
        LBLO    SHLEVA          ; BR=YES
        LDD     #SHLEV2
        STD     PJOY,U
        LDB     #$01            ;FLAP WINGS
;*
SHDIR   LDA     PPOSY+1,U       ;BELOW CLIF5?
        CMPA    #$D0
        BLO     .1S             ; BR=NO
        LDA     PVELY,U         ;FALLING DOWN?
        LBPL    BOLAVA          ; BR=YES, AVOID THE LAVA
.1S     LDA     PVELX,U         ;WHICH DIRECTION GOING?
        BEQ     SHDIRA
        BPL     SHDILR
        PSHS    B
        LDD     PVELY,U         ;SEEKING DESTINATION CLIFF
        ASLB
        ROLA
        ASLB
        ROLA
        ASLB
        ROLA
        PULS    B
        LDY     PPOSY,U
        LDX     PPOSX,U
        LEAY    A,Y
        LDA     BCKXTB-SHXLEN,X
        ANDA    BCKYTB,Y
        BEQ     SHDIRA          ; BR=YES
        CLR     PFACE,U         ;FACE RIGHT
        BRA     SHDICL
;*
SHDILR  PSHS    B
        LDD     PVELY,U
        ASLB
        ROLA
        ASLB
        ROLA
        ASLB
        ROLA
        PULS    B
        LDY     PPOSY,U
        LDX     PPOSX,U
        LEAY    A,Y
        LDA     BCKXTB+SHXLEN,X
        ANDA    BCKYTB,Y
        BEQ     SHDIRA          ; BR=YES
        LDA     #-1
        STA     PFACE,U         ;FACE LEFT
SHDICL  LDD     #SHAV           ;SLOW DOWN!!! GOING INTO A CLIFF
        STD     PJOY,U
        LDA     SHCLTM          ;#8
        STA     PJOYT,U
        LDB     #1
;*
SHDIRA  LDA     PBUMPX,U        ;FACE, BUMPED DIRECTION
        BEQ     SHFDIR
        STA     PFACE,U
SHFDIR  LDA     PFACE,U
        BMI     SHDN1C
        LDA     #1
        STD     CURJOY
        RTS
;*
SHDIRB  LDA     PVELX,U
        BEQ     SHDIRA
        CLRA
        STD     CURJOY
        RTS
;*
SHDN1C  LDA     #-1
        STD     CURJOY
        RTS
;*
;*
SHLEV2  LDD     #SHLEV1
        STD     PJOY,U
SHLEVA  CLRB                    ;WINGS UP
        JMP     SHDIR
;*
SHBRA2  JMP     SHADOW  ;BACK TO THE BRAINS
;*
SHAV    CLRB
        DEC     PJOYT,U
        BGT     SHDIRA
        JMP     SHADOW
;*
SHUP3   LDD     #SHUP3A         ;LEVEL FLIGHT, READY TO GO UP
        STD     PJOY,U
        LDB     PPOSY+1,U       ;REMEMBER LINE TO TRACK
        STB     PDIST+1,U
        LDA     #20+1           ;TIME UNTIL NEXT DECISION
        STA     PJOYT,U
;*
SHUP3A  LDX     PPOSX,U         ;CLIFF IN THE WAY??
        LDY     PPOSY,U
        LDA     BCKXTB,X
        ANDA    BCKYTB-SHYLEN,Y
        LBEQ    SHUPST
        DEC     PJOYT,U
        LBLE    SHADOW
        LDD     PVELY,U         ;FALLING FAST ENOUGH?
        ADDD    #-$0040
        BMI     SHUP3B          ; BR=NO
        LDB     PDIST+1,U       ;ABOVE TRACKING LINE
        CMPB    PPOSY+1,U
        BLO     SHUP3B          ; BR=YES
        LDD     #SHUP4
        STD     PJOY,U
        LDB     #$01            ;FLAP WINGS
        JMP     SHDIRA
;*
SHUP4   LDD     #SHUP3A
        STD     PJOY,U
SHUP3B  CLRB                    ;FLAP WINGS
        JMP     SHDIRA
;*
SHDN2   LDD     #SHADOW
        STD     PJOY,U
        CLRB
        LDA     PVELX,U
        LBEQ    SHDIRA
        LDA     PSTATE,U        ;ON THE GROUND?
        BEQ     .1S             ; BR=NO IN THE AIR
        LDX     PPOSX,U         ;CLIF3U IN THE WAY?
        LDA     BCKXTB,X
        LDX     PPOSY,U
        ANDA    BCKYTB,X
        BEQ     .1S             ; BR=NO
        LDB     #1              ;FLAP WINGS
.1S     CLRA
        STD     CURJOY
        RTS
;*
;*
;*      SELECT CLOSEST PLAYER
;*       OUTPUT REG.X, TARGETED PLAYER (IF STATUS .NE. IS TRUE)
;*
SELPLY  LDX     TARPLY          ;GET TARGETED PLAYER TO KILL
        BEQ     SPNONE
        LDA     TARTM1          ;DELAY TIMER AT ZERO?
        BEQ     .20S            ; BR=NO, TRY PLAYER 2
        LDX     TARPL2          ;PLAYER 2 HERE?
        BEQ     SPNONE          ; BR=NO
        LDA     TARTM2          ;PLAYER 2'S DELAY TIMER AT ZERO?
        BEQ     SPN3PL          ;BR=GET PLAYER 2!
        BRA     SPNONE          ;BR=NO ONE TO CHASE
;*
.20S    LDY     TARPL2          ;PLAYER #2
        BEQ     SPN3PL          ; BR=ONLY 1 PLAYER NOW
        LDA     TARTM2
        BNE     SPN3PL
        LDB     PPOSY+1,X
        SUBB    PPOSY+1,U       ;FIND CLOSEST CO-ORDINANT
        BLO     SPRYX
        NEGB
SPRYX   STB     ,-S
        LDD     PPOSX,X
        SUBD    PPOSX,U
        BLO     SPRXX
        COMA
        COMB
        ADDD    #-1
SPRXX   TSTA
        BNE     SPRLOX
        CMPB    ,S
        BHI     SPRLOX
        STB     ,S
SPRLOX  EQU     *
;*
        LDB     PPOSY+1,Y
        SUBB    PPOSY+1,U       ;FIND CLOSEST CO-ORDINANT
        BLO     SPRYY
        NEGB
SPRYY   STB     ,-S
        LDD     PPOSX,Y
        SUBD    PPOSX,U
        BLO     SPRXY
        COMA
        COMB
        ADDD    #-1
SPRXY   TSTA
        BNE     SPRLOY
        CMPB    ,S
        BHI     SPRLOY
        STB     ,S
SPRLOY  EQU     *
;*
        CMPB    1,S
        PULS    D
        BLO     SPN3PL
SPN2PL  LDX     TARPL2
SPN3PL  ANDCC   #~$04           ;CLEAR ZERO BIT FOR .NE. BEING TRUE             ;;Fixme was: ANDCC  #!N$04
        RTS
;*
SPNONE  ORCC    #$04            ;SETT ZERO BIT FOR .EQ. BEING TRUE
        RTS
;*
;*      KEN LANTZ SPECIAL EFFECTS, PLAYER POOF (DEATH)
;*
;* a sequence of three images lasting 1 sec total
DEATH   LDD     PPOSX,U
        CMPD    #4              ;LET PLAYER SEE THE EXPLOSION
        BGT     .2S
        LDD     #4              ;NEW POSITION IN X DIRECTION
.2S     CMPD    #288
        BLT     .1S
        LDD     #288
.1S     STD     PPOSX,U
        LDY     POOF1           ;POOF FRAME 1
        JSR     WRREGY
        PCNAP   5
        LDY     POOF1
        JSR     CLREGY
        LDY     POOF2           ;POOF FRAME 2
        JSR     WRREGY
        PCNAP   8
        LDY     POOF2
        JSR     CLREGY
        LDY     POOF3           ;POOF FRAME 3
        JSR     WRREGY
        PCNAP   12
        LDY     POOF3
        JSR     CLREGY
;* test PPOSX/Y for nearest cliff and refresh if necessary
        LDX     PPOSX,U
        LDY     PPOSY,U
        LDA     BCKYTB-15,Y
        ORA     BCKYTB-13,Y
        ANDA    BCKXTB,X
        ORA     BCKRFS
        STA     BCKRFS
        JMP     VSUCIDE
;*
;*      PROCESS TO DESTROY A CLIFF
;*              BY KEN LANTZ 6/10/82
;*      INPUT PFRAME-2,U = CLIFF TO DESTROY
;*
CLFDES
        LDA     #5
        STA     PFRAME,U        ;number of shakes to do
.1S     LDY     PFRAME-2,U
        JSR     BCKYUP
        PCNAP   10              ;!
        LDY     PFRAME-2,U      ;!
        JSR     BCKYUP          ;!
        LDA     #$2A            ;by altering the cliffs flavor
        STA     WCDMA,X
        PCNAP   10
        DEC     PFRAME,U
        BNE     .1S
        JSR     LOCCLR          ;go erase the image as we will replace with
        PCNAP   2               ;debris
;******************************************************************************
        LDY     #FIRSTI         ;point to the image area
        LDA     #5              ;where there are five images
        STA     PFRAME+2,U
.2S     LDX     PFRAME-2,U
        CMPX    $0000           ;here we do adjustments to center
        BNE     .21S            ;and offset out debris images on the
        LDX     #$F145          ;larger and edge located cliffs
        BRA     .22S
.21S    CMPX    $0004           ;$0000 and $0004 are CLIF1L and CLIF2 vectors,
        BNE     .23S            ;respectively
        LDX     #$3151
        BRA     .22S
.23S    LDX     4,X             ;Get destination
.22S    STX     PFRAME,U        ;Adjust destination for centering on cliffs
        BSR     CLIFER
        STY     PFRAME+3,U      ;we must maintain our why
        PCNAP   8               ;while we sleep a little
        LDY     PFRAME+3,U
        DEC     PFRAME+2,U
        BNE     .2S
        BSR     LOCCLR          ;a final erase of the image area
        JMP     VSUCIDE         ;end the process
;*
;******************************************************************************
;* X contains screen location  Y contains table location of image to be 'drawn'
;*      (PFRAME,U)
CLIFER  LDX     PFRAME,U
.2S     LDA     ,Y+     ;lo nybble is color, hi nybble is length
        BEQ     .1S     ;length & color equ 0, end of image
        ANDA    #$0F
        LDB     #17     ;replicate lo nybble ($0A-=-$AA) for color
        MUL
        LDA     -1,Y
        ANDA    #$F0    ;length nybble is extracted
        LSRA            ;and adjusted
        LSRA
        LSRA
        LSRA
        BNE     .3S     ;if length equ 0, end of line
        LDX     PFRAME,U        ;next line is always 1 down
        LEAX    1,X
        STX     PFRAME,U
        BRA     .2S
.3S     BEQ     .2S     ;  (test is on top for minimal memory)
        CMPA    #1      ;last byte is always one pixel to enhance debris image
        BNE     .31S    ;while all others are bytes for minimal memory
        ANDB    #$F0    ;requirements
.31S    STB     ,X
        LEAX    $100,X  ;next location is over 1 as our images are horizontally
        CMPX    #$9800
        BHI     .2S
        DECA            ;oriented
        BRA     .3S
.1S     RTS
;*
LOCCLR  LDB     WCLENY,Y                ;CALC LOWEST POINT
        EORB    #4                                                              ;;Fixme was: EORB  #!WDMAFIX
        ADDB    WCY,Y
        JSR     VCL1ALL         ;clear cliff away
        LDD     #$1200          ;with a constant substitution of 00 color
        STD     WCDMA,X         ;in the DMA command
        LDY     PFRAME-2,U      ;the source is read for location and size
        LDD     WCSRC,Y         ;source is not use but is specified
        STD     WCSRC,X
        LDD     WCDEST,Y        ;destination
        STD     PFRAME,U
        STD     WCDEST,X
        LDD     WCLEN,Y         ;vertical length is extended to cover
        EORB    #4              ;the falling debris                             ;;Fixme was: EORB  #!WDMAFIX
        ADDB    #10+1
        EORB    #4                                                              ;;Fixme was: EORB  #!WDMAFIX
        STD     WCLEN,X
        RTS
;*******************************END OF CLIFF DESTROIER***********************
;*
;*      START PLAYER 1 & 2 IN TARGET AREA(S)
;*
STPLY1
STPLY2  LDD     TARPLY          ;IS THIS SPOT EMPTY?
        BNE     .1S             ; BR=NO
        STU     TARPLY          ;IT IS NOW IN USE
        LDA     TARTIM          ;GIVE CURRENT TIME DELAY TIME
        STA     TARTM1
        RTS
.1S     STU     TARPL2          ;USING SECOND AREA
        LDA     TARTIM          ;GIVE CURRENT TIME DELAY TIME
        STA     TARTM2
        RTS
;*
;*      DEATH OF PLAYER 1
;*
DEATH1  CLR     EGGS1
        INC     PLYD1           ;REMEMBER PLYR DIED IN THIS WAVE(SURVIVAL WAVE)
        BRA     SPDIE           ;REMOVE TARGET PLAYER POINTER
;*
;*      DEATH OF PLAYER 2
;*
DEATH2  CLR     EGGS2
        INC     PLYD2           ;REMEMBER PLYR DIED IN THIS WAVE(SURVIVAL WAVE)
SPDIE   LDB     #5*60/8         ;BAITER REMOVAL TIME
        STB     DBAIT
        LEAX    ,X              ;DEATH BY LAVA
        BEQ     SPDIE2          ; BR=YES
        LDY     PDECSN,X        ;GET WINNING PLAYER/ENEMY DECISION BLOCK
        BEQ     SPDIE3          ; BR=MUST BE A WINNING ENEMY
        LDY     DGLAD,Y         ;GET GLADIATOR ENTRY
        BEQ     SPDIE3          ; BR=MUST BE AN ENEMY
        INC     ,Y              ;KEEP TRACK OF PLAYER VS. PLAYER KILLS
        BGT     SPDIE2
        BEQ     SPDGLA          ; BR=GLADIATOR WAVE, SCORE THE WINNING PLAYER
        DEC     ,Y              ;(KEEP THE NBR POSITIVE)
        BRA     SPDIE2
;*
SPDGLA  CLR     PLYG1           ;ONLY 1 GLADIATOR IN THE WAVE
        CLR     PLYG2
        LDA     #$80            ;INDICATE TRUE WINNING GLADIATOR
        STA     ,Y
        LDX     PDECSN,X        ;GET WINNING GLADIATOR/PLAYERS SCORE AREA
        PSHS    X
        LDA     #$30            ;SCORE 3,000
        JSR     SCRHUN
         LDX    #SCRAIR         ;DISPLAY SCORE ON THE SCREEN
         LDD    #EGGID*256+$FF
         JSR    VCUPROC
        LDD     PPOSX,U         ;PUT SCORE IN LOSERS AREA
        ADDD    #6              ; (CENTER IN LOSERS KILL AREA)
        STD     PPOSX,Y
        LDD     PPOSY,U
        STD     PPOSY,Y
        LDA     #MSGTH3         ;DISPLAY 3,000 POINTS
        PULS    X               ;GET WINNERS DECSION TABLE BACK
        LDB     DCONST,X
        STD     PRDIR,Y
        LDX     #SNBOUN         ;AWARD BOUNTY SOUND
        JSR     VSND
        BRA     SPDIE2
;*
;*      PLAYER KILLED BY ENEMY OR PTERODACTYL
;*
SPDIE3  LDA     GOVER           ;ATTRACT MODE?
        BPL     SPDIE2          ; BR=YES
        LDA     TTROLL          ;1ST, 2ND, OR 3RD WAVE?
        BEQ     SPDIE2          ; BR=NO
        LDA     #2
        STA     EMYTIM          ;SLOW DOWN THE ENEMY ONLY!
SPDIE2  LDX     #DEATH          ;create a primary process for player death
        LDD     #$2000          ;POOF PROCESS I.D.
        JSR     VCUPROC
        LDD     PPOSX,U
        STD     PPOSX,Y
        LDD     PPOSY,U
        STD     PPOSY,Y
        LDX     PDECSN,U        ;SCORE 50 POINTS FOR DYING
        LDA     #$50
        JSR     SCRTEN
      IF DEBUG = 0                                                              ;;Fixme was: IFE DEBUG
        JSR     LZAP
      ENDIF
;*
      IF DEBUG <> 0     ;???????????? DEBUG PARAMATER ?????????                 ;;Fixme was: IFN DEBUG
        LDA     PID,U   ;THIS BETTER BE THE PLAYER
        CMPA    #PLYID
        BEQ     .12S
        SWI
.12S
      ENDIF                     ;???????????? END OF DEBUG ????????????
        LDX     #SNPDIE         ;PLAYER DIES
        JSR     VSND
        CMPU    TARPLY          ;REMOVE PLAYER FROM TARGET AREA, CORRECT PLAYER?
        BNE     .1S             ; BR=NO
        LDD     TARPL2
        STD     TARPLY          ;HERE IF YES
        LDA     TARTM2
        STA     TARTM1
.1S     LDD     #0              ;ASSUME OTHER POINTER
        STD     TARPL2
;*
;*                              CHECK FOR AN END OF GAME
;*
.2S     LDX     PDECSN,U
        LDX     DSCORE,X        ;GET PLAYER SCORE/LIVES AREA
      IF DEBUG <> 0     ;???????????? DEBUG PARAMATER ?????????                 ;;Fixme was: IFN DEBUG
        LDA     6,X             ;HOW MANY AUX LIVES ARE LEFT???
        BNE     .22S            ;BR=NONE
        SWI
.22S
      ENDIF                     ;???????????? END OF DEBUG ????????????
        DEC     6,X             ;SUBTRACT TO PLAYERS AUX NUMBER OF LIVES
        BNE     .5S
.4S     LDA     GOVER           ;ATTRACT MODE?
        BPL     .5S             ; BR=YES, GAME IS ALREADY OVER
        LDA     SPLY1+6         ;BOTH PLAYERS DEAD?
        ORA     SPLY2+6
        BNE     .6S             ; BR=NO
        PSHS    U
        LDU     PDUMMY          ;PUT AT BEGINNING OF LIST
         LDX    #GAMOVR
         LDD    #$3400
         JSR    VCUPROC
        PULS    U
.5S     RTS
.6S      LDX    #GAMOV1         ;GAME OVER FOR PLAYER 1 OR 2
         LDD    #PLYID*256+$FF
         JSR    VCUPROC
        LDA     #3*60/8         ;3 SECOND MESSAGE
        STA     PJOYT,Y
        LDX     PDECSN,U
        STX     PDECSN,Y
        RTS
;*
GAMOV1  LDX     PDECSN,U
        LDB     DCONST,X
        BSR     .10S
        PCNAP   8
        LDA     GOVER           ;GAME OVER?
        BEQ     .1S
        DEC     PJOYT,U
        BNE     GAMOV1
.1S     LDX     PDECSN,U
        CLRB
        BSR     .10S
        JMP     VSUCIDE
;*
.10S    LDA     DGAMO,X         ;PUT UP PLAYER 1/2 GAME OVER
        LDX     #$296C
        JSR     OUTPHR
        LEAX    $300,X          ;(SPACE CHARACTER)
        LDA     #MSGAMO
        JMP     OUTPHR
;*
;*      COLISION DETECT BETWEEN OPPONENTS VS ALL OPPONENTS
;*       (A SECONDARY PROCESS BEFORE COLISIONABLE PLAYERS)
;*
OPPCOL  PCNAP   1               ;COLISION DETECT ROUTINE
      IF DEBUG <> 0     ;???????????? DEBUG PARAMATER ?????????                 ;;Fixme was: IFN DEBUG
        STU     COLU
      ENDIF                     ;???????????? END OF DEBUG ????????????
.20S
      IF DEBUG <> 0     ;???????????? DEBUG PARAMATER ?????????                 ;;Fixme was: IFN DEBUG
        CMPU    COLU
        BEQ     .21S
        SWI
.21S
      ENDIF                     ;???????????? END OF DEBUG ????????????
.25S    LDU     PLINK,U         ;FIND TWO COLISIONAL OSTRICHES
        BEQ     OPPCOL          ; BR= END OF COLISION
        LDA     PID,U
        BPL     .25S
        STU     COLU
;*
        LEAX    ,U              ;FOUND 1ST OSRICH, FIND SECOND
      IF DEBUG <> 0     ;???????????? DEBUG PARAMATER ?????????                 ;;Fixme was: IFN DEBUG
        STX     COLOBJ
      ENDIF                     ;???????????? END OF DEBUG ????????????
.40S
      IF DEBUG <> 0     ;???????????? DEBUG PARAMATER ?????????                 ;;Fixme was: IFN DEBUG
        CMPX    COLOBJ
        BEQ     .41S
        SWI
.41S    CMPU    COLU
        BEQ     .42S
        SWI
.42S
      ENDIF                     ;???????????? END OF DEBUG ????????????
.45S    LDX     PLINK,X
        BEQ     .20S            ;BR= END OF PAIRS OF COLISION
        LDA     PID,X
        BPL     .45S
        ANDA    PID,U
        BITA    #$01            ;ENEMY/PTERO VS. ENEMY/PTERO
        BEQ     .45S
        BSR     HITEM
        BCC     .40S            ;THERE IS SOMETHING TO COLISION WITH
        BRA     .20S
;*
;*      COLISION DETECT BETWEEN PLAYERS VS ALL OPPONENTS
;*       (A PROCESS BEFORE COLISIONABLE PLAYERS)
;*
PLYCOL  PCNAP   1               ;COLISION DETECT ROUTINE
        LDA     TARTM1          ;DECREMENT TARGETED PLAYERS TIME
        BEQ     .10S
        DEC     TARTM1
.10S    LDA     TARTM2          ;DECREMENT TARGETED PLAYERS TIME
        BEQ     .15S
        DEC     TARTM2
.15S
      IF DEBUG <> 0     ;???????????? DEBUG PARAMATER ?????????                 ;;Fixme was: IFN DEBUG
        STU     COLU
      ENDIF                     ;???????????? END OF DEBUG ????????????
.20S
      IF DEBUG <> 0     ;???????????? DEBUG PARAMATER ?????????                 ;;Fixme was: IFN DEBUG
        CMPU    COLU
        BEQ     .21S
        SWI
.21S
      ENDIF                     ;???????????? END OF DEBUG ????????????
.25S    LDU     PLINK,U         ;FIND TWO COLISIONAL OSTRICHES
        BEQ     PLYCOL          ; BR= END OF COLISION
        LDA     PID,U
        CMPA    #PLYID+$80
        BNE     .25S
        STU     COLU
        LEAX    ,U              ;FOUND 1ST OSRICH, FIND SECOND
.35S    LDX     PLINK,X
        BEQ     PLYCOL          ;BR= END OF PAIRS OF COLISION
        LDA     PID,X
        BPL     .35S
        BSR     HITEM
        BCS     .20S
.40S
      IF DEBUG <> 0     ;???????????? DEBUG PARAMATER ?????????                 ;;Fixme was: IFN DEBUG
        CMPX    COLOBJ
        BEQ     .41S
        SWI
.41S    CMPU    COLU
        BEQ     .42S
        SWI
.42S
      ENDIF                     ;???????????? END OF DEBUG ????????????
.45S    LDX     PLINK,X
        BEQ     .20S            ;BR= END OF PAIRS OF COLISION
        LDA     PID,X
        BPL     .45S
        BSR     HITEM
        BCC     .40S            ;THERE IS SOMETHING TO COLISION WITH
        BRA     .20S
;*
;*      COLISION DETECT THESE TWO OBJECTS (REG.U & REG.X)
;*       CARRY =1 FOR KILLING REG.U OBJECT
;*       REG.X & REG.U ARE INTACT
;*
HITEM   STX     COLOBJ
        LDD     PPOSX,U         ;WITHIN X INTERSECTION SQUARES?
        SUBD    PCOLX,X
        BGT     HITEM1          ; BR=NO
        LDD     PPOSX,X
        CMPD    PCOLX,U
        BGT     HITEM1
        SUBD    PPOSX,U
        STD     COLDX
;*
        LDD     PCOLY1,X        ;WITHIN Y INTERSECTION SQUARES?
        CMPB    PCOLY1,U
        BHI     HITEM1          ; BR=NO
        CMPA    PCOLY2,U
        BLO     HITEM1
        LDY     [PPICH,X]
      IF DEBUG <> 0     ;???????????? DEBUG PARAMATER ?????????                 ;;Fixme was: IFN DEBUG
        BGT     .31S
        SWI
.31S
      ENDIF                     ;???????????? END OF DEBUG ????????????
        LDX     [PPICH,U]
      IF DEBUG <> 0     ;???????????? DEBUG PARAMATER ?????????                 ;;Fixme was: IFN DEBUG
        BGT     .32S
        SWI
.32S
      ENDIF                     ;???????????? END OF DEBUG ????????????
        SUBB    PCOLY2,U
        ASLB                    ;MAXIMUM Y DIFFERENCE = $1F
        ASLB
        BMI     OSTXP2          ;BR=X BOX ON TOP
        ABX
        BRA     OSTXYP
OSTXP2  NEGB
        LEAY    B,Y
OSTXYP  JSR     BPCOL
        BCS     OSTHIT
HITEM2  LDX     COLOBJ
HITEM1  ANDCC   #$FE
        RTS
;*
;*      PIXEL COLISION HAS HAPPENED, DECIDE WHAT TO DO WITH THE COLISION
;*
OSTHIT  LDX     COLOBJ          ;GET OTHER COLISIONED PARTY
        LDA     PID,U           ;ENEMIES DO NOT KILL EACH OTHER
        ANDA    PID,X
        BITA    #$01
        BNE     .100S           ; BR=PTE/PLY/EMY COLISION
        BITA    #$02
        LBEQ    PLYEGG          ; BR=CORRECT PERSON HIT EGG
        SWI                     ;FICTISIOUS COLISION
.100S   BITA    #$04
        BNE     OSTHT2          ; BR=NO KILL (ENEMY VS. ENEMY, PTERO VS. PTERO)
        BITA    #$08            ;PTERODACTYL VS. PLAYER?
        BNE     OSTBO           ; BR=NO BUZZARD VS. PLAYER
      IF DEBUG
        LDA     PID,X           ;BETTER BE A BUZZARD
        CMPA    #PTEID+$80
        BEQ     .1S
        SWI
.1S
      ENDIF
        LDB     PLANTZ,U        ;LANTZ ON CORRECT LINE?
        ADDB    PPOSY+1,U
        SUBB    PPOSY+1,X
        LDA     PIMAGE,X        ;               PFRAME,X
        CMPA    #FLY2-FLY1      ;ATTACKING FRAME?
        BLS     .13S            ; BR=NO WINGS DOWN FRAME
;**PTE  SUBB    #7      15-7    ;FUDGE FROM LANTZ TO CENTER OF PTERO-MOUTH
        SUBB    #15-7           ;FUDGE FROM LANTZ TO CENTER OF PTERO-MOUTH
        BPL     .15S
        NEGB
.15S    CMPB    #3              ;WITHIN 7 PIXELS?
        BRA     .14S
;*
.13S
;**PTE  SUBB    #5      15-4    ;FUDGE FROM LANTZ TO CENTER OF PTERO-MOUTH
        SUBB    #15-5           ;FUDGE FROM LANTZ TO CENTER OF PTERO-MOUTH
        BPL     .10S
        NEGB
.10S    CMPB    #2              ;WITHIN 5 PIXELS?
.14S    BHI     OSTBO           ; BR=NO, CANNOT KILL PTERODACTYL
        LDA     PFACE,U         ;FACING IN OPPSITE DIRECTIONS?
        EORA    PFACE,X
        BPL     OSTBO           ; BR=NO, CANNOT KILL PTERODACTYL
        LDD     COLDX           ;FACING PTERODACTYL?
        BPL     .12S
        LDA     PFACE,U         ;PTERODACTYL ON LEFT, PLAYER ON RIGHT
        BPL     OSTBO           ; BR=NO, CANNOT KILL PTERODACTYL
.11S    JMP     OSTPYP          ;BOUNCE KILLER AWAY FROM PTERODACTYL
;*
.12S    LDA     PFACE,U         ;PTERODACTYL ON RIGHT, PLAYER ON LEFT
        BPL     .11S            ; BR=YES, KILLED PTERODACTYL
OSTBO   LDB     PLANTZ,U
        SEX
        STD     ,--S
        LDB     PLANTZ,X        ;WHICH LANTZ IS ON TOP?
        SEX
        SUBD    ,S++
        ADDD    PPOSY,X         ; (DETERMINATION OF WHO IS KILLED)
        SUBD    PPOSY,U
        BEQ     .1S             ; BR=BOTH ON SAME LEVEL
        BMI     OSTXT3
        JMP     OSTPYP          ; BR=REG.Y ON TOP
;*
.1S     LDX     #SNPTHD         ;PLAYERS COLIDE
        JSR     VSND
        LDX     COLOBJ
        BRA     OSTXTT
;*
OSTHT2  LDX     #SNETHD         ;ENEMIES COLIDE
        JSR     VSND
        LDX     COLOBJ
        LDA     PID,U
        CMPA    #$80+PTEID      ;PTERODACTYL?
        BEQ     OSTH12          ; BR=YES
        LDA     PID,X
        CMPA    #$80+PTEID
        BEQ     OSTH13          ; BR=YES
OSTH11  JSR     OSTBMP          ;NO-ONE DIES, BUT BUMP EACH OTHER ANYWAYS
        JMP     HITEM2
;*
OSTH12  LDA     PID,X           ;2 PTERODACTYL'S?
        CMPA    #$80+PTEID
        BEQ     OSTH11          ;BR=YES, SAME OLD COLISION
OSTPX   JSR     PTEBRD          ;COLIDE PTERODACTYL & BIRD
        JMP     HITEM2
;*                              REG.U IS PTERODACTYL
OSTH13  EXG     X,U
        JSR     PTEBRD          ;COLIDE PTERODACTYL & BIRD
        EXG     X,U
        JMP     HITEM2
;*
OSTBMP  LDB     PPOSY+1,X       ;DETERMINATION OF WHO HAS BEEN BUMPED
        SUBB    PPOSY+1,U
        LBPL    OSTUTP
        LBEQ    OSTLR
        JMP     OSTXTP
;*
OSTXT3  LDX     COLOBJ          ;THE VICTOR!!!
        JSR     OSTWIN
        LDA     PID,X           ;IS THE WINNER A PTERODACTYL?
        CMPA    #$80+PTEID
        BEQ     OSTXPT
OSTXTT  JSR     OSTXTP          ;REG.X WILL BE RESTORIED
        BRA     OSTX12          ;REG.U GUY IS DEAD, GET NEXT REG.U GUY
;*
OSTXPT  EXG     X,U
        JSR     PTEBRD          ;COLIDE PTERODACTYL & BIRD
        EXG     X,U
OSTX12  ORCC    #$01            ;REG.U GUY IS DEAD, GET NEXT REG.U GUY
        RTS
;*
;*      OSTRICH GENERAL KILL ROUTINE
;*       REG.X = THE WINNER
;*       REG.U = THE LOSER
OSTWIN  PSHS    X,U             ;NEVER DESTROY THIS WORKSPACE POINTER
        LDA     PID,U           ;MAKE THIS MAN DEAD
        ANDA    #$7F
        STA     PID,U
        LDD     #0
        STD     PRIDER,U
        LDY     PDECSN,U
        LDD     #AUTOFF         ;MOVE OSTRICH OFF SCREEN
        STD     PJOY,U
        JSR     [DDEAD,Y]       ;CALL DEATH ROUTINE (REG.X VICTOR, REG.U DEAD)
        LDU     2,S             ;RESTORE REG.U
        LDY     PDECSN,U        ;GET DEAD OBJECTS SCORE
        LDA     DVALUE,Y
        LDX     ,S              ;RESTORE REG.X
        LDX     PDECSN,X
        JSR     [DVALUR,Y]      ;SCORE ROUTINE
        PULS    X,U,PC
;*
OSTPYP  LDX     COLOBJ          ;GET THE LOSER
        EXG     X,U             ;SORT REGIES FOR DEATH WISH
        JSR     OSTWIN
        EXG     X,U             ;SORT REGIES FOR DEATH WISH
        LDA     PID,U           ;IS THE WINNER A PTERODACTYL?
        CMPA    #$80+PTEID
        BEQ     OSTPX
OSTYTT  BSR     OSTUTP          ;REG.X WILL BE RESTORIED
        JMP     HITEM2          ;REG.X IS DEAD, GET NEW REG.X
;*
;*       BOUNCER ROUTINE
;*      PLAYER VS. PLAYER & ENEMY VS. PLAYER & ENEMY VS. ENEMY
;*      & PTERODACTYL VS. PTERODACTYL
;*
OSTUTP  LDX     COLOBJ
        EXG     X,U
        JSR     OSTXUP          ;MOVE REG.U GUY UP
        EXG     X,U
        JSR     OSTXDN          ; & REG.X GUY DOWN
        BRA     OSTLR
;*
OSTXTP  LDX     COLOBJ
        EXG     X,U
        JSR     OSTXDN          ;MOVE REG.U GUY DOWN
        EXG     X,U
        JSR     OSTXUP          ; & REG.X GUY UP
;*
OSTLR   LDX     COLOBJ
        LDD     COLDX           ;NOW BOUNCE IN X DIRECTION
        BEQ     OSTNLR          ; BR=CENTER TO CENTER COLISION
        BPL     OSTURT          ;BR=X ON RIGHT
OSTXLF  LDA     PVELX,X         ;U IS ON RIGHT, MOVE X LEFT
        BLE     .1S             ;SO MAKE
        NEGA
        ADDA    #2              ;SLOW DOWN A BIT
        STA     PVELX,X
.1S     NEGA                    ;BUMP OTHER PERSON
        ADDA    #2
        ASRA
        STA     PBUMPX,U
        LDA     #-1             ;MAKE X FACE LEFT
        STA     PFACE,X
        LDA     PVELX,U         ;U IS ON RIGHT, MAKE U GO RIGHT
        BGE     .2S
        NEGA
        SUBA    #2              ;SLOW DOWN A BIT
        STA     PVELX,U
.2S     ADDA    #2              ;BUMP OTHER PERSON
        NEGA
        ASRA
        STA     PBUMPX,X
        CLR     PFACE,U         ;MAKE U FACE RIGHT
        BRA     OSTNLR
;*
OSTURT  LDA     PVELX,X         ;X IS ON RIGHT, MAKE X GO RIGHT
        BGE     .1S
        NEGA
        SUBA    #2              ;SLOW DOWN A BIT
        STA     PVELX,X
.1S     ADDA    #2              ;BUMP OTHER PERSON
        NEGA
        ASRA
        STA     PBUMPX,U
        CLR     PFACE,X         ;MAKE X FACE RIGHT
        LDA     PVELX,U         ;X IS ON RIGHT, MAKE U GO LEFT
        BLE     .2S
        NEGA
        ADDA    #2              ;SLOW DOWN A BIT
        STA     PVELX,U
.2S     NEGA                    ;BUMP OTHER PERSON
        ADDA    #2
        ASRA
        STA     PBUMPX,X
        LDA     #-1             ;MAKE U FACE LEFT
        STA     PFACE,U
;*
OSTNLR  RTS
        FCB     $CE             ;LZAPPER FUDGE
;*
;*
OSTXUP  LDA     #-2
        STA     PBUMPY,X                ;X IS ON TOP, MAKE X GO UP
        LDD     PVELY,X
        BLE     .2S
        COMA
        NEGB
        SBCA    #-1
        ASRA                    ;SLOW DOWN A BIT
        RORB
        STD     PVELY,X
.2S     RTS
;*
OSTXDN  LDA     #2
        STA     PBUMPY,X                ;U IS ON TOP, MAKE X LOWER
        LDD     PVELY,X
        BGE     .2S
        COMA
        NEGB
        SBCA    #-1
        ASRA                    ;SLOW DOWN A BIT
        RORB
        STD     PVELY,X
.2S     RTS
;*
      IF DEBUG = 0                                                              ;;Fixme was: IFE DEBUG
LZAP    LDX     LZAP1
        LDD     #34
.1S     ADDA    ,X+
        DECB
        BNE     .1S
        CMPA    #$32            ;LZAPPER DATA
        BEQ     .2S
        LDX     [PFREE]
        INC     1,X
.2S     RTS
      ENDIF
;*
;*      COLIDE PTERODACTYL & BIRD
;*              REG.U = PTERODACTYL
;*              REG.X = BIRD
PTEBRD  CLRA                    ;DETERMINE WHO IS ON TOP
        LDB     PCOLY1,X
        SUBB    PCOLY1,U
        SBCA    #0
        ADDB    PCOLY2,X
        ADCA    #0
        SUBB    PCOLY2,U
        SBCA    #0
        BPL     .1S             ;BR=PTERODACTYL IS ON TOP
        BSR     OSTXUP          ;BIRD IS ON TOP, MAKE HIM HIGHER
        LDA     #-5
        STA     PBUMPY,X        ;A HARD BUMP
        BRA     .2S
;*
.1S     BSR     OSTXDN          ;MAKE BIRD LOWER
        LDA     #5
        STA     PBUMPY,X        ;A HARD BUMP
.2S     LDD     PPOSX,X
        SUBD    PPOSX,U
        ADDD    PCOLX,X
        SUBD    PCOLX,U         ;WHO IS ON THE RIGHT OF WHO??
        BPL     .3S             ; BR=BIRD IS ON THE RIGHT, SO BUMP HIM RIGHT
        LDA     PVELX,X         ;THE BIRD MOVES LEFT NOW
        BLE     .21S
        SUBA    #2              ;SLOW DOWN A BIT
        NEGA
        STA     PVELX,X
.21S    LDA     PVELX,U         ;BUMP BIRD
        NEGA
        ASLA
        STA     PBUMPX,X
        LDA     #$FF
        STA     PFACE,X         ;MAKE X FACE LEFT
        RTS
;*
.3S     LDA     PVELX,X         ;THE BIRD MOVES RIGHT NOW
        BGE     .31S
        NEGA
        SUBA    #2              ;SLOW DOWN A BIT
        STA     PVELX,X
.31S    LDA     PVELX,U         ;BUMP BIRD
        NEGA
        ASLA
        STA     PBUMPX,X
        CLR     PFACE,X         ;MAKE X FACE RIGHT
        RTS
LZAP1   FDB     $F320
;*
;*      LAVA FLAMES (BURNING THE BRIDGE)
;*
LAVAB   PCNAP   4
        LDA     SAFRM2+1        ;LAVA TOPPED OFF?
        CMPA    #FLOOR
        BHI     LAVAB           ; BR=NO, WAIT FOR LAVA TO RISE TO THE TOP
LAVABN  PCNAP   1
LAVABC  LDX     PDIST,U         ;MODIFY CLIFF5 LANDING AREA
        LDA     LNDXTB,X
        EORA    LNDXS3,X        ;GET XOR OF CORRECT BIT
        ANDA    #$20            ;GET BIT TO CHANGE
        EORA    LNDXTB,X        ;GET TRUE STATE OF BIT
        STA     LNDXTB,X        ;STORE IT AWAY!
        ANDA    #$20            ;HIT CLIFF5?
        BNE     .2S             ; BR=YES, STOP!!!
        LDB     PJOYT,U         ;MOVE FLAME
        LEAX    B,X
        STX     PDIST,U
        LDB     PVELX,U         ;TAKE CARE OF FLAME OFFSET
        LEAX    B,X
        CMPX    #ELEFT-4        ;TOO FAR LEFT?
        BLT     LAVABN          ; BR=YES
        CMPX    #ERIGHT+4       ;TO FAR RIGHT?
        BGT     LAVABN          ; BR=YES
        STX     PPOSX,U         ;NEW POSITION IN X DIRECTION
        INC     PFRAME,U
        LDA     PFRAME,U
        JSR     WFLAME          ;RE=WRITE FLAME
        PCNAP   6
        LDA     PFRAME,U
        JSR     CFLAME          ;ERASE FLAME
        INC     PFRAME,U
        LDA     PFRAME,U
        JSR     WFLAME          ;RE=WRITE FLAME
        PCNAP   6
        LDA     PFRAME,U
        JSR     CFLAME          ;ERASE FLAME
        BRA     LAVABC          ;LOOP ON EATING FLAME
;*                      END OF BRIDGE COLAPSE, SO DROP THE FLAME INTO LAVA
.2S     INC     PFRAME,U
        LDA     PFRAME,U
        JSR     WFLAME          ;RE=WRITE FLAME
        PCNAP   6
        LDA     PFRAME,U
        JSR     CFLAME          ;ERASE FLAME
        LDA     PFRAME,U
        ANDA    #$03
        BNE     .2S
        INC     PPOSY+1,U
        LDA     PPOSY+1,U
        CMPA    #FLOOR+16       ;DOWN IN THE DEPTHS?
        BLO     .2S             ; BR=YES
        LDA     #$80            ;REFRESH CLIFF5
        ORA     BCKRFS
        STA     BCKRFS
        JMP     VSUCIDE
;*
;*      LAVA FLAMES (NORMAL)
;*
LAVAF   LDA     PFRAME,U
        JSR     CFLAME
        INC     PFRAME,U        ;NEXT FRAME
        LDB     PPOSY+1,U       ;RAISE FLAME?
        CMPB    #FLOOR
        BLS     .1S             ; BR=NO
        DEC     PPOSY+1,U       ;HERE IF YES
.1S     LDA     PFRAME,U
        JSR     WFLAME          ;WRITE THE NEXT FLAME
        PCNAP   6
        BRA     LAVAF
;*
WFLAME  PSHS    A               ;INPUT 0-3 FRAME NUMBER
        JSR     VWR1CLS
        BRA     WCFLAM
;*
CFLAME  PSHS    A
        JSR     VCL1CLS
WCFLAM  PULS    A
        LDY     IFLAME
        ANDA    #3              ;COUNTS 0 TO 3
        ASLA
        LEAY    A,Y
        ASLA
        LEAY    A,Y
        JSR     WRHOR2
        JMP     CLIPER          ;CLIF THE BOTTOM OF THE FLAME
;*
;*      PUT THE NUMBER OF PLAYERS LIVES UP ON THE SCREEN
;*      INPUT;
;*       REG.X HAS DECISION BLOCK ADDRESS (P1DEC OR P2DEC)
;*       REG.A HAS NUMBER OF LIVES TO PUT UP ON SCREEN
;*      OUTPUT; NEW LIFES & SCREEN UPDATED IMMEDIATELY
;*       REG.X - INTACT
;*
PLYRUP  PSHS    A               ;SAVE NUMBER OF LIVES
PLYRUL  JSR     INCLIV          ;ADD 1 LIFE TO PLAYER
        DEC     ,S
        BNE     PLYRUL          ;GET NBR OF PLAYERS UP ON SCREEN
        PULS    A,PC
;*
;*      ADD 1 LIFE ON THE SCREEN
;*       REG.X HAS DECISION BLOCK
;*      OUTPUT; NEW LIFE & SCREEN UPDATED IMMEDIATELY
;*       REG.X - INTACT
;*
INCLIV  PSHS    X,CC            ;SAVE INTERUPT STATUS
        LDX     DSCORE,X        ;GET PLAYER SCORE/LIVES AREA
        BEQ     INLDON
        INC     5,X             ;ADD TO PLAYERS NUMBER OF LIVES
        INC     6,X             ;(ADD TO AUX NUMBER OF LIVES LEFT
        BNE     INLMAX          ; BR=NOT EXCEEDED 255 LIVES
        DEC     5,X             ;WHAT I GIVETH, I TAKETH AWAY
        DEC     6,X
INLMAX  LDA     5,X
        CMPA    #5
        BHI     INLDON
        ASLA                    ;CALC PROPER SCREEN LOCATION TO UPDATE
        ADDA    5,X
        SUBA    #3
        CLRB
        LDX     1,S             ;GET REG.X DECISION BLOCK BACK
        ADDD    DSCLOC,X
        ORCC    #$F0            ;NO INTERUPTS FOR DMA
        STD     DDMA
        LDD     #$0307!DMAFIX   ;CHARACTER SIZE                                 ;;Fixme was: !XDMAFIX
        STD     WDMA
        LDD     DSCPLY,X        ;GET PLAYERS SOURCE CHARACTER ADDRESS
        STD     SDMA
        LDA     #$0A            ;DMA CONTROL
        STA     DMA
INLDON  PULS    X,CC,PC
;*
;*      DECREMENT (BY 1) THE NUMBER OF LIVES A PLAYER HAS
;*       REG.X HAS DECISION BLOCK
;*      OUTPUT; 1 LESS LIFE & SCREEN UPDATED IMMEDIATELY
;*       STATUS .EQ. NO MORE LIVES LEFT
;*              .NE. MORE LIVES LEFT
;*       REG.X - INTACT
;*
DECLIV  PSHS    X
        LDX     DSCORE,X        ;GET PLAYER SCORE/LIVES AREA
        BEQ     DCLNON
        LDA     5,X
        BEQ     DCLNON
        LDB     GOVER
        BPL     .10S
        LDB     #7              ;BOOKS, NUMBER OF MEN PLAYED
        JSR     AUDIT1
.10S    DECA                    ;1 LESS MAN LEFT
        STA     5,X             ;SAVE THIS AS NBR OF LIVES LEFT
        CMPA    #5-1
        BHI     DCLDON
        ASLA
        ADDA    5,X
        CLRB
        LDX     ,S              ;GET REG.X DECISION BLOCK BACK
        ADDD    DSCLOC,X
        PSHS    CC              ;SAVE INTERUPT STATUS
        ORCC    #$F0            ;NO INTERUPTS FOR DMA
        STD     DDMA
        LDD     #$0307!DMAFIX   ;CHARACTER SIZE                                 ;;Fixme was: !XDMAFIX
        STD     WDMA
        LDD     DSCPLY,X        ;GET PLAYERS SOURCE CHARACTER ADDRESS
        STD     SDMA
        LDD     #$1A*256+(DKB*$11)      ;DMA CONTROL & ERASE CONSTANT
        STB     KDMA
        STA     DMA
        PULS    CC
DCLDON  LDA     #1              ;STATUS NE
DCLNON  PULS    X,PC
;*
;*      GENERAL DMA PUTTER-UPPER
;*       (REG.X) HAS LENGTH, THEN SOURCE ADDRESS (X+2)
;*       REG.D HAS DESTINATION ADDRESS
;*       REG.Y HAS DMA CONTROL & CONSTANT
;*
GENDMA  PSHS    CC
        ORCC    #$F0            ;NO INTERUPTS FOR DMA
        STD     DDMA
        LDD     ,X++
        EORA    #$04                                                            ;;Fixme was: EORA  #!HDMAFIX
        EORB    #$04                                                            ;;Fixme was: EORB  #!HDMAFIX
        STD     WDMA
        STX     SDMA
        TFR     Y,D
        STB     KDMA
        STA     DMA
        PULS    CC,PC
;*
;*      FIND A FREE (NOT CROWDED) TRANSPORTER TO USE
;*       REG.X = ADDRESS OF FREE TRANSPORTER BOUNDS TABLE
;*
FREET   PSHS    X
        LDD     CURTR1  ;CALCULATE FOR A FREE TRANSPORTER
        STD     STTR1
        LDD     CURTR3
        STD     STTR3
        LDU     [PDUMMY]        ;SEARCH THE LIST
CRENPR  LDU     PLINK,U         ;FOR OTHER FLYING OBJECTS
        BNE     CREID           ; BR=NOT END OF LIST
        PULS    X,PC
CREID   LDA     PID,U           ;PROCESS ACTIVE ON SCREEN?
        BPL     CRENPR          ; BR=NO
        CMPA    #$80+EGGID      ;AN EGG?
        BNE     .1S             ; BR=NO
        LDD     PDIST,U         ;CALLING A BIRD?
        BEQ     CRENPR          ; BR=NO, SO IGNORE HIM
.1S     LDB     PVELX,U
        LDY     ,S              ;GET TRANSPORTER BOUNDS TABLE
        LDX     ,Y++            ;SPEED FUDGE TABLE
        LDD     B,X
        ADDD    PPOSX,U
        CMPD    #ELEFT
        BGE     .10S
        ADDD    #ERIGHT-ELEFT
.10S    CMPD    #ERIGHT
        BLE     .20S
        ADDD    #ELEFT-ERIGHT
.20S    TFR     D,X
        LDA     PPOSY+1,U
        CMPA    #$51+7          ;UPPER LEVEL?
        BHI     .30S            ; BR=NO
        LDA     STTR1           ;TRANSPORTER DISABLED?
        BNE     CRENPR          ; BR=YES, NEXT PERSON
        BSR     TRBOND          ;CHECK IF THIS TRANSPORTER IS AVAILABLE
        BRA     CRENPR          ;NEXT PERSON
;*
.30S    CMPA    #$8A+7          ;MIDDLE LEVEL?
        BHI     .40S            ; BR=NO
        LEAY    FTLEN,Y         ; NEXT ENTRY
        LDA     STTR2           ;TRANSPORTER DISABLED?
        BNE     .35S            ; BR=YES, NEXT PERSON
        BSR     TRBOND          ;CHECK IF THIS TRANSPORTER IS AVAILABLE
.35S    LDA     STTR3           ;TRANSPORTER DISABLED?
        BNE     CRENPR          ; BR=YES, NEXT PERSON
        LEAY    FTLEN,Y         ; NEXT ENTRY
        BSR     TRBOND          ;CHECK IF THIS TRANSPORTER IS AVAILABLE
        BRA     CRENPR          ;NEXT PERSON
;*
.40S    CMPA    #$A3+7          ;LOWER LEVEL?
        BLO     CRENPR          ; BR=NO
        LDA     STTR4           ;TRANSPORTER DISABLED?
        BNE     CRENPR          ; BR=YES, NEXT PERSON
        LEAY    FTLEN+FTLEN+FTLEN,Y     ; NEXT ENTRY
        BSR     TRBOND          ;CHECK IF THIS TRANSPORTER IS AVAILABLE
        BRA     CRENPR          ;NEXT PERSON
;*
TRBOND
        LDB     FXREV,Y         ;WRAP AROUND COMPARE?
        BNE     .10S            ; BR=YES
        CMPX    FXMIN,Y         ;IS OBJECT FAR AWAY ENOUGH TO LEFT?
        BLO     .30S            ; BR=YES
        CMPX    FXMAX,Y         ;IS OBJECT FAR AWAY ENOUGH TO RIGHT?
        BHI     .30S            ; BR=YES
        BRA     .20S            ;FAIL THIS TRANSPORTER
;*
.10S    CMPX    FXMIN,Y         ;IS OBJECT FAR AWAY ENOUGH TO LEFT?
        BHI     .20S            ; BR=NO
        CMPX    FXMAX,Y         ;IS OBJECT FAR AWAY ENOUGH TO RIGHT?
        BHI     .30S            ; BR=YES
.20S    INC     [FLEVEL,Y]      ;NO, FAIL TRANSPORTER
.30S    RTS
;*
;*      ENEMY TRANSPORTER BOUNDS
;*
TRENY   FDB     SPDFDG
        FCB     0                               ;TOP TRANSPORTER
        FDB     $6A-66,$6A+14+66,STTR1
        FCB     0                               ;MIDDLE RT TRANSPORTER
        FDB     $E0-66,$E0+14+39,STTR2
        FCB     1                               ;MIDDLE LF TRANSPORTER
        FDB     $10-39+ERIGHT,$10+14+66,STTR3
        FCB     0                               ;BOTTOM TRANSPORTER
        FDB     $78-66,$78+14+66,STTR4
;*
;*
;*      PLAYERS TRANSPORTER BOUNDS
;*
TRPLY   FDB     SPDFDG
        FCB     0                               ;TOP TRANSPORTER
        FDB     $6A-90,$6A+14+90,STTR1
        FCB     1                               ;MIDDLE RT TRANSPORTER
        FDB     $E0-90,$E0+14+90-ERIGHT,STTR2
        FCB     1                               ;MIDDLE LF TRANSPORTER
        FDB     $10-90+ERIGHT,$10+14+90,STTR3
        FCB     0                               ;BOTTOM TRANSPORTER
        FDB     $78-90,$78+14+90,STTR4
;*
        FDB     -60,-30,-15,-8
SPDFDG  FDB     0,8,15,30,60            ;SPEED FUDGE
;*
G1DEC   FDB     G1JOY,G1JOY,SPLY1,$39D9,SCOPL1,PLYR1,TREPL1,CREP1 ;PLAYER 1
        FDB     DEATH1,EGGS1,STPLY1,SCRHUN,PLYG1,PLYTIM
        FDB     SNPLWU,SNPLWD,SNPLSK,SNPLS2,SNPRU1,SNPRU2,SNPFAL,0,SNPCR1
        FCB     PL1*$11,$20,MSP1
G2DEC   FDB     G2JOY,G2JOY,SPLY2,$60D9,SCOPL2,PLYR2,TREPL2,CREP2 ;PLAYER 2
        FDB     DEATH2,EGGS2,STPLY2,SCRHUN,PLYG2,PLYTIM
        FDB     SNPLWU,SNPLWD,SNPLSK,SNPLS2,SNPRU1,SNPRU2,SNPFAL,0,SNPCR2
        FCB     PL2*$11,$20,MSP2
P1DEC   FDB     P1JOY,P1JOY,SPLY1,$39D9,SCOPL1,PLYR1,TREPL1,CREP1 ;PLAYER 1
        FDB     DEATH1,EGGS1,STPLY1,SCRHUN,PLYG1,PLYTIM
        FDB     SNPLWU,SNPLWD,SNPLSK,SNPLS2,SNPRU1,SNPRU2,SNPFAL,SNPTREF,SNPCR1
        FCB     PL1*$11,$20,MSP1
P2DEC   FDB     P2JOY,P2JOY,SPLY2,$60D9,SCOPL2,PLYR2,TREPL2,CREP2 ;PLAYER 2
        FDB     DEATH2,EGGS2,STPLY2,SCRHUN,PLYG2,PLYTIM
        FDB     SNPLWU,SNPLWD,SNPLSK,SNPLS2,SNPRU1,SNPRU2,SNPFAL,SNPTREF,SNPCR2
        FCB     PL2*$11,$20,MSP2
P3DEC   FDB     AUTOFF,AUTOFF,0000,$0000,SCOPL2,PLYR3,TREPL3,EMYDIE
        FDB     DEATH3,0,STENMY,SCRTEN,0,EMYTIM
        FDB     SNELWU,SNELWD,SNEMSK,SNEMS2,SNERU1,SNERU2,SNEFAL,0,SNECRE
        FCB     WHI*$11,$10,MSGAMO
P4DEC   FDB     LINET,BOUNDR,0000,$0000,SCOPL2,PLYR3,TREPL3,EMYDIE
        FDB     DEATH3,0,STENMY,SCRTEN,0,EMYTIM
        FDB     SNELWU,SNELWD,SNEMSK,SNEMS2,SNERU1,SNERU2,SNEFAL,0,SNECRE
        FCB     WHI*$11,$05,MSGAMO
P5DEC   FDB     LINET,B2UNDR,0000,$0000,SCOPL2,PLYR4,TREPL3,EMYDIE
        FDB     DEATH3,0,STENMY,SCRTEN,0,EMYTIM
        FDB     SNELWU,SNELWD,SNEMSK,SNEMS2,SNERU1,SNERU2,SNEFAL,0,SNECRE
        FCB     WHI*$11,$57,MSGAMO
P6DEC   FDB     LINET,SHADOW,0000,$0000,SCOPL2,PLYR5,TREPL3,EMYDIE
        FDB     DEATH3,0,STENMY,SCRHUN,0,EMYTIM
        FDB     SNELWU,SNELWD,SNEMSK,SNEMS2,SNERU1,SNERU2,SNEFAL,0,SNECRE
        FCB     WHI*$11,$15,MSGAMO
P7DEC   FDB     LINET,PTERO,0000,$0000,SCOPL2,0,TREPL3,EMYDIE
        FDB     DEATH4,0,STENMY,SCRHUN,0,EMYTIM
        FDB     SNELWU,SNELWD,SNEMSK,SNEMS2,0,0,SNEFAL,0,SNECRE
        FCB     WHI*$11,$10,MSGAMO
;*
;*      TRANSPORTER COLOR EFFECT
;*
TREPL1  FCB     PL1*$11,PL1*$11,WHI*$11,PL1*$11,PL1*$11,GRY*$11,PL1*$11,PL1*$11
TREPL2  FCB     PL2*$11,PL2*$11,WHI*$11,PL2*$11,PL2*$11,GRY*$11,PL2*$11,PL2*$11
TREPL3  FCB     WHI*$11,WHI*$11,GRY*$11,WHI*$11,WHI*$11,GRY*$11,WHI*$11,WHI*$11
;*
;*      TRANSPORTER LOCATION TABLE
;*
TR1ID   FDB     TRANS1,$6A+7,$51-1,CURTR1
TR2ID   FDB     TRANS2,$E0+7,$81-1,CURTR2
TR3ID   FDB     TRANS3,$10+7,$8A-1,CURTR3
TR4ID   FDB     TRANS4,$78+7,$D3-1,CURTR4
;*
;*      START THE ENEMY
;*
STENMY  RTS
     IF DEBUG = 0                                                               ;;Fixme was: IFE DEBUG
;*
;*      AND THE EVER POPULAR COPYRIGHT MESSAGE
;*
        FCC     'JOUST (C) 1982 WILLIAMS ELECTRONICS INC.'
     ENDIF
PLYTIM  FCB     1
;*
;*      PLAYER, & ENEMY FINALLY DIE
;*
PLYDIE
EMYDIE  JMP     VSUCIDE
;*
;*      BEING CREATED/RE-CREATED
;*
CREP1   EQU     *       ;* * * * CREATE PLAYER 1
CREP2   EQU     *       ;* * * * CREATE PLAYER 2
        LDX     PDECSN,U        ;GET DECISION BLOCK!
        JSR     DECLIV          ;DECREMENT NBR OF LIVES
        BEQ     PLYDIE
        LDA     NPSERV          ;TAKE A NUMBER TO BE SERVED BY THE TRANSPORTER
        STA     PTIMX,U
        INC     NPSERV
        BRA     CRELP
;*
CREPLY  CMPB    LPSERV          ;IS IT THIS PLAYERS TURN?
        BNE     CRELP           ; BR=NO, FAIL THIS GUY
        CLR     AREA1           ;FIND A CLEAR AREA TO APPEAR FROM
        CLR     AREA2
        CLR     AREA3
        LDX     [PDUMMY]        ;SEARCH THE LIST
.10S    LDX     PLINK,X         ;FOR OTHER FLYING OBJECTS
        BEQ     .40S            ; BR=END OF LIST
        LDA     PID,X           ;PROCESS ACTIVE ON SCREEN?
        BPL     .10S            ; BR=NO
        CMPA    #$80+EGGID      ;AN EGG?
        BNE     .30S            ; BR=NO
        LDD     PDIST,X         ;CALLING A BIRD?
        BEQ     .10S            ; BR=NO, SO IGNORE HIM
.30S    JSR     SELARE          ;CHECK IF AREA IS CLEAR
        BRA     .10S
;*
.40S    LDD     CURTR1  ;CALCULATE FOR A FREE TRANSPORTER
        STD     STTR1
        LDD     CURTR3
        STD     STTR3
        LDA     AREA3           ;BOTTOM AREA EMPYT?
        BNE     .50S            ; BR=NO
        LDA     STTR4           ;BOTTOM TRANSPORTER NOT IN USE?
        BEQ     GOTR4           ; BR=NO, GO USE IT
.50S    LDA     AREA2           ;MIDDLE AREA EMPYT?
        BNE     .60S            ; BR=NO
        LDA     STTR2           ;RIGHT MIDDLE TRANSPORTER NOT IN USE?
        BEQ     GOTR2           ; BR=NO, GO USE IT
        LDA     STTR3           ;LEFT MIDDLE TRANSPORTER NOT IN USE?
        BEQ     GOTR3           ; BR=NO, GO USE IT
.60S    LDA     AREA1           ;TOP AREA EMPYT?
        BNE     .70S            ; BR=NO
        LDA     STTR1           ;TOP TRANSPORTER NOT IN USE?
        BEQ     GOTR1           ; BR=NO, GO USE IT
.70S    LDX     #TRPLY          ;TRANSPORTER SAFTEY AREA
        LDA     TRSMALL         ;SMALLER TRANSPORTER AREA?
        BNE     CREALL          ; BR=NO
        LDX     #TRENY          ;NARROWER TRANSPORTER SAFTEY AREA
        BRA     CREALL          ;GO CREATE VIA DEFAULT WAY
;*
;*      CREATE THE ENEMY (BOO HISS..)
;*
CREEM   EQU     *       ;* * * * CREATE ENEMY
        LDA     NESERV          ;TAKE A NUMBER TO BE SERVED BY THE TRANSPORTER
        STA     PTIMX,U
        INC     NESERV
CRELP   PCNAP   1
        LDB     PTIMX,U         ;PLEASE HAVE YOUR NUMBER READY FOR THE OPERATOR
        LDA     PID,U
        CMPA    #PLYID          ;A NORMAL PLAYER?
        BEQ     CREPLY
        LDA     NPSERV          ;ANY PLAYERS HOLDING A NUMBER?
        CMPA    LPSERV
        BNE     CRELP           ; BR=YES, LET THEM FIND A TRANSPORTER 1ST
        CMPB    LESERV          ;IS IT THIS ENEMIES TURN?
        BNE     CRELP           ; BR=NO, FAIL THIS GUY
        LDX     #TRENY          ;TRANSPORTER SAFTEY AREA
CREALL  JSR     FREET
        JSR     VRAND
        BCC     GOTR12
        RORA
        BCS     GOTR4
        BRA     GOTR3
GOTR12  RORA
        BCS     GOTR2
GOTR1   LDX     #TR1ID
        LDA     STTR1   ;TOP MOST TRANSPORTER?
        BEQ     GOTTR
GOTR2   LDX     #TR2ID
        LDA     STTR2   ;NEXT MIDDLE TRANSPORTER?
        BEQ     GOTTR
GOTR3   LDX     #TR3ID
        LDA     STTR3   ;NEXT MIDDLE TRANSPORTER?
        BEQ     GOTTR
GOTR4   LDX     #TR4ID
        LDA     STTR4   ;BOTTOM TRANSPORTER?
        BEQ     GOTTR
        LDX     #TR1ID
        LDA     STTR1   ;TOP MOST TRANSPORTER?
        BEQ     GOTTR
        LDX     #TR2ID
        LDA     STTR2   ;NEXT MIDDLE TRANSPORTER?
        BEQ     GOTTR
        LDX     #TR3ID
        LDA     STTR3   ;NEXT MIDDLE TRANSPORTER?
        BEQ     GOTTR
        LDX     #TR4ID
        LDA     STTR4   ;BOTTOM TRANSPORTER?
        BNE     CRELP
GOTTR   INC     [TCURUSE,X]     ;CURRENTLY THIS TRANSPORTER IN USE
        LDU     PEXEC
        LDD     TPOSX,X         ;& INITIAL STANDING POSITION
        STD     PPOSX,U
        LDD     TPOSY,X
        STD     PPOSY,U
        STX     PSTATE,U        ;TEMPORARY TRANSPORTER LEVEL
        LDX     PDECSN,U
        LDX     DSNCRE,X
        LDA     PID,U
        CMPA    #PLYID
        BNE     .2S
        INC     LPSERV  ;ALLOW PLAYERS NEXT NUMBERED CARD TO USE TRANSPORTER
        BRA     .3S
.2S     INC     LESERV  ;ALLOW ENEMIES NEXT NUMBERED CARD TO USE TRANSPORTER
.3S     JSR     VSND
        LDA     #30
        STA     PFRAME,U
        LDY     PDECSN,U
        LDD     [DPLYR,Y]
        STD     PRIDER,U        ;PUT RIDER ON HORSE
        LDA     #STAND
        JSR     SRCADA
TREFF   LDX     PSTATE,U
        LDY     [TIMAGE,X]
        JSR     BCKYUP
        LDA     ,X              ;CONSTANT FILL OF TRANSPORTER
        ORA     #$10
        LDY     PDECSN,U
        LDB     DCONST,Y        ;COLORED TRANSPORTER WHEN ACTIVE
        STD     ,X
        LDA     PFRAME,U
        CMPA    #20
        BGT     TREFF2
;*******************************************************************************
;*
;*  PATCHED-IN SPECIAL EFFECTS
;*                      by Kenneth F. Lantz  Williams Electronics May 1982
;*
;*******************************************************************************
        JSR     WPLYR
        LDB     PFRAME,U
        TFR     B,A
        COMA            ;VERT SIZE
        ASRA
        ANDA    #$0F
        EORA    #$04
        STA     WCLENY,X
        TFR     A,B
        CMPA    #3
        BLE     .2S
        LDB     #3
.2S     STB     (WCLENY-10),X
        EORA    #$04
        NEGA
        INCA
        INCA
        ANDA    #$0F
        TFR     A,B
        ADDA    WCY,X
        ADDB    WCY-10,X
        STA     WCY,X
        STB     (WCY-10),X
;*
        LDB     WCLENY,X        ;MAKE SURE BUZARD/OSTRICH LENGTH IS NOT TOO LONG
        EORB    #4                                                              ;;Fixme was: EORB  #!WDMAFIX
        ADDB    WCY,X
        CMPB    PPOSY+1,U
        BLS     .3S
        LDB     PPOSY+1,U
        INCB
        SUBB    WCY,X           ;CALC NEW LENGTH THAT IS NOT BELOW TRANSPORTER
        EORB    #4                                                              ;;Fixme was: EORB  #!WDMAFIX
        STB     WCLENY,X
;*
.3S     LDY     PDECSN,U
        LDB     DCONST,Y
        LDA     WCDMA,X
        ORA     #$10
        STD     WCDMA,X
        STD     WCDMA-10,X
;*******************************************************************************
TREFF2  PCNAP   1               ;EFFECTS TIME
        JSR     CNORIA
        LDA     #$12
        STA     WCDMA,X
        LDD     PPOSX,U
        ASRA
        RORB
        STB     WCX,X
        LDA     #(18/2)!4               ;PROPER X LENGTH FOR BOX ERASE                  ;;Fixme was: LDA  #18/2!X(!WDMAFIX) (Should be $0D - $8C29)
        STA     WCLENX,X
        DEC     PFRAME,U
        LBNE    TREFF
;*
;*      WAIT FOR 1ST MOVE, OR TIME OUT; WHICH EVER COMES FIRST
;*
        LDX     PDECSN,U
        LDD     DJOY,X          ;SELECT PROPER JOYSTICK ROUTINE
        STD     PJOY,U
        LDA     #16*2
        STA     PFEET,U
        LSRA
        STA     PACCX,U
        LDA     #2
        STA     PLANTZ,U
        CLR     PTIMUP,U
        CLR     PTIMX,U
;********       CLR     PADGRA+0,U      ASSUME ALL LAST SWITCH POSITIONS OFF
;********       CLR     PADGRA+1,U
;********       CMPX    #P1DEC          PLAYER1 JOYSTICK?
;********       BEQ     .10S             BR=YES
;********       CMPX    #P2DEC          PLAYER2 JOYSTICK?
;********       BNE     .40S             BR=NO, NO SWITCHES WILL BE USED
;********.10S   JSR     [DJOY,X]        GET 1ST JOYSTICK POSITION
;********       STD     PADGRA,U        REMEMBER THE SWITCHES
        BRA     .40S
;*
.20S    PCNAP   1
.40S
        JSR     [PJOY,U]        ;GET JOYSTICK/DECISION
        LDD     CURJOY
;********       CMPA    PADGRA+0,U      JOYSTICK IN LAST POSITION?
;********       BEQ     .140S            BR=YES, IGNORE THESE SWITCHES
;********       CLR     PADGRA+0,U      NO, REMEMBER NO SWITCHES ON
;********       TSTA                    JOYSTICK SWITCHES ON?
;********       BNE     .51S            BR=PLAYER/ENEMY WANTS TO MOVE
;********.140S  CMPB    PADGRA+1,U      FLAP SWITCH IN LAST POSITION?
;********       BEQ     .141S            BR=YES, IGNORE THIS SWITCH
;********       CLR     PADGRA+1,U      NO, REMEMBER NO SWITCHES ON
;********       TSTB                    JOYSTICK SWITCHES ON?
        BNE     .51S            ;BR=PLAYER/ENEMY WANTS TO FLAP
;********.141S
        DEC     PTIMUP,U        ;TIME TO CHANGE SPEEDS?
        BGT     .41S
        LDA     #75
        STA     PTIMUP,U
        LSR     PFEET,U
        BEQ     .50S
.41S    JSR     WPLYR
        LDX     PSTATE,U        ;CLIFF TRANSPORTER HI-LIGHT
        LDY     [TIMAGE,X]
        JSR     BCKYUP
        LDY     PDECSN,U
        LDY     DTREFF,Y
        LEAX    -10-10,X        ;BACKUP TO 1ST BUFFER
        LDB     PLANTZ,U
        BSR     .45S
        DECB
        BSR     .45S
        DECB
        BSR     .45S
        DEC     PACCX,U         ;CHANGE EFFECT
        BGT     .42S
        INC     PLANTZ,U        ;BLINK CLIFF TRANSPORTER ON/OFF
        LDA     PFEET,U
        STA     PACCX,U
.42S    LDA     PFEET,U
        LSRA
        BNE     .20S
        INC     PTIMX,U
        BRA     .20S
;*
.45S    PSHS    B
        ANDB    #$07
        BNE     .47S
        LDB     #2
        STB     PLANTZ,U
        STB     ,S
.47S    LDB     B,Y
        TST     PTIMX,U
        BEQ     .48S
        CMPB    #PL1*$11
        BEQ     .49S
        CMPB    #PL2*$11
        BEQ     .49S
.48S    LDA     WCDMA,X
        ORA     #$10
        STD     WCDMA,X
.49S    LEAX    10,X            ;NEXT DMA BUFFER
        PULS    B,PC
;*
.51S    LDX     PDECSN,U        ;ABORTED EARLY, KILL SOUND
        LDX     DSNTREF,X
        BEQ     .50S            ; BR=NO SOUND
        JSR     VSND
.50S    JSR     CPLYR
        LDX     PSTATE,U        ;CLIFF TRANSPORTER BACK TO NORMAL
        DEC     [TCURUSE,X]     ;CURRENTLY THIS TRANSPORTER NOT IN USE
        LDY     [TIMAGE,X]
        JSR     BCKYUP
        LDU     PEXEC           ;GET WORKSPACE BACK
        LDX     PDECSN,U
        JSR     [DSTART,X]      ;START THE ENEMIES AFTER THE PLAYER
        BSR     PLYINT          ;RE-INCARNATED ENEMY/PLAYER
        LDD     CURJOY          ;GIVE CURRENT JOYSTICK
        BRA     PLYRS2
;*
;*      INITILIZE SOME PLAYERS WORKSPACE
;*
PLYINT  LDD     [DPLYR,X]
        STD     PRIDER,U        ;PUT RIDER ON HORSE
        LDD     #PLYBR          ;START AT GROUND STATE B
        STD     PSTATE,U
        LDD     #0              ;NO PVELY, (FOR INTELLIGENCE)
        STD     PVELY,U
        CLR     PVELX,U         ;EVERYONE STARTS FROMA STAND STILL
        CLR     PTIMX,U
        CLR     PFRAME,U
        CLR     PTIMUP,U
        CLR     PACCX,U
        CLR     PBUMPX,U        ;HAVE NOT BEEN BUMPED REGISTER
        CLR     PBUMPY,U
        LDA     #$80            ;ENABLE THIS PLAYERS COLISIONS
        ORA     PID,U
        STA     PID,U
        LDA     #STAND          ;STANDING POSITION
        JMP     SRCADG          ;GET CORRECT SOURCE ADDRESS FOR THE GROUND
;*
;*      PLAYER(S) MOVING RULES
;*
PLAYR   EQU     *               ;PLAYER 1 & 2 START
        LDD     #LAND5          ;START Y POSITION
        STD     PPOSY,U
        PCNAP   60              ;WAIT A SECOND THEN..
        LDX     PDECSN,U        ;GET DECISION BLOCK!
        JSR     DECLIV          ;DECREMENT NBR OF LIVES
        LDU     PEXEC           ;GET WORKSPACE BACK
        LDX     PDECSN,U
        JSR     [DSTART,X]      ;START THE ENEMIES AFTER THE PLAYER
        LDX     PDECSN,U
        LDD     DJOY,X          ;SELECT PROPER JOYSTICK ROUTINE
        STD     PJOY,U
PLYLI2  BSR     PLYINT          ;RE-INCARNATED ENEMY
        JSR     WPLYR
;*
;*      MAIN RUNNING/STANDING/SKIDDING LOOP
;*
PLYRLP  LDX     PDECSN,U
        LDA     [DTIME,X]
        JSR     VNAPTPC
        JSR     [PJOY,U]
PLYRS2
      IF DEBUG <> 0     ;???????????? DEBUG PARAMATER ?????????                 ;;Fixme was: IFN DEBUG
        CMPA    #-1
        BLT     .1S
        CMPA    #1
        BGT     .1S
        CMPB    #1
        BLS     .2S
.1S     SWI
.2S
      ENDIF                     ;???????????? END OF DEBUG ????????????
        TST     PTIMUP,U        ;FLAP BUTTON WAS RELEASED, WASNT IT?
        BNE     PLNFLY          ; BR=YES
        TSTB                    ;STARTING TO FLY??
        LBNE    STFLY           ; BR=YES
PLNFLY  STB     PTIMUP,U        ;WAIT UNTIL BUTTON RELEASED
        LDB     PFACE,U         ;WHICH DIRECTION FACING?
        BPL     PLFRIT          ; BR=RIGHT
        NEGA                    ;REVERSE JOYSTICK FOR LEFT OPERATION
PLFRIT  LDB     PACCX,U         ;TIME TO UPDATE STATE TABLE?
        BEQ     UPDSTA          ; BR=YES
        DEC     PACCX,U
        BNE     UPDNON          ; BR=NO
UPDSTA  LDX     PSTATE,U
        ADDA    #4              ;GET NEXT OFFSET TO NEW STATE
        LDB     A,X             ;OFFSET TO NEXT STATE IN REG.B
        BEQ     UPDNON          ; BR= SAME STATE
        LDA     #8              ;NEW STATE, WAIT FOR NEXT STATE
        STA     PACCX,U
        CLR     PTIMX,U         ;NEW STATES UPDATE POSITION
        LEAX    B,X
        STX     PSTATE,U
        CMPX    #PLYLR          ;START END OF SKID SOUND?
        BNE     UPDNON          ; BR=NO
        LDX     PDECSN,U        ;HERE IF YES, GET PROPER SOUND
        LDX     DSNSK2,X
        JSR     VSND            ;MAKE END OF SKIDDING SOUND
UPDNON  DEC     PTIMX,U         ;TIME TO UPDATE POSITION?
        BLE     UPDNO2          ; BR=YES
        LDB     PBUMPX,U        ;       BEEN BUMPED?
        BEQ     PLYRLP          ; BR=NO
        JSR     CPLYR           ;ERASE PLAYER
        CLRB
        BRA     PL2RIT          ;HERE IS YES
;*
UPDNO2  JSR     CPLYR           ;ERASE PLAYER
        LDD     CURJOY          ;GET CURRENT JOYSTICK POSITION
        LDX     PSTATE,U
        LDA     6,X             ;UPDATE FICTISIOUS VELX FOR BUMPING
        STA     PVELX,U
        LDA     ,X+             ;GET NEXT WAIT TIME
        STA     PTIMX,U         ;NEW WAIT TIME TILL NEXT STATE
        JSR     [,X]            ;GET REG.B=DELTA X, REG.X FRAME TO SHOW
        STA     PIMAGE,U        ;REMEMBER LAST FRAME
        LDA     PFACE,U
        BPL     PL2RIT
        NEG     PVELX,U
        NEGB                    ;REVERSE DIRECTION FOR LEFT OPERATION
PL2RIT  JSR     WRAPX           ;ADD BUMP & WRAP AROUND IN THE X DIRECTION
        LDX     PPOSX,U         ;STILL WALKING ON THE CLIFF?
        LDY     PPOSY,U
        LDA     LNDXTB,X
        ANDA    LNDYTB+1,Y
        ANDA    #$7F            ;IGNORE LAVA TROLL
        LBEQ    STFALL          ;BR=NO, MUST BE FALLING
        LDA     BCKXTB+6,X      ;BUMPING INTO CLIFF3U??
        ANDA    BCKYTB,Y
        BEQ     PL2EDG          ; BR=NO
        ORA     BCKRFS          ;REFRESH CLIFF 3U
        STA     BCKRFS
        CLR     PFACE,U         ;FACE LEFT
        LDA     PBUMPX,U
        BPL     PL2LF2
        NEGA
PL2LF2  ADDA    #3
        STA     PBUMPX,U
PL2EDG  BSR     SRCADH          ;GET CORRECT SOURCE ADDRESS
        BSR     WPLYR
        JMP     PLYRLP
;*
;*      CALC WRITE IMAGE SOURCE ADDRESS
;*
SRCADG  STA     PIMAGE,U        ;COLISION DETECT ON THE GROUND
SRCADH  LDB     PPOSY+1,U
        STB     PCOLY1,U        ;A LARGE COLISION DETECT BOX
        SUBB    #$14-1          ;TOP LINE OF COLISION DETECTS BOX
        STB     PCOLY2,U
        BRA     SRCCOM
;*
SRCADA  STA     PIMAGE,U        ;IN THE AIR IMAGE
SRCADR  LDB     PPOSY+1,U
        SUBB    #6              ;A SMALLER COLISION DETECT BOX
        STB     PCOLY1,U
        SUBB    #$14-1-6        ;TOP LINE OF COLISION DETECTS BOX
        STB     PCOLY2,U
SRCCOM  LDD     PPOSX,U
        ADDD    #18-1-1
        STD     PCOLX,U         ;MAINTAIN COLISION DETECT POINTERS
        CLR     PLANTZ,U        ;LANTZ OFFSET IS ZERO
        CLRB
        LDA     PFACE,U         ;FACE OFFSET
        BPL     SRCNOF
        LDB     #6
SRCNOF  ADDB    PIMAGE,U
        LDX     PHORSE,U        ;CALCULATE HORSE FRAME OFFSET
        ABX
        STX     PPICH,U
        LDX     PRIDER,U        ;CALCULATE RIDERS FRAME OFFSET
        BEQ     WPNORI          ; BR=NO RIDER
        CMPB    #STAND          ;*FOR NOW, RUN1 TO FLY3 USES STANDING IMAGE
        BLO     SRCSKP          ;*
        SUBB    PIMAGE,U        ;*
        ADDB    #STAND          ;*
        ABX
WPNORI  STX     PPICR,U         ;STORE RESULTANT RIDER FRAME
        RTS
;*
SRCSKP  ABX
        STX     PPICR,U         ;STORE RESULTANT RIDER FRAME
        LDB     #2              ;SKIDDING OSTRICH HAS A LANTZ 2 PIXELS LOWER
        STB     PLANTZ,U
        RTS
;*
;*      WRITE OR CLEAR IMAGE
;*      INPUT REG.X ADDRESS OF TOTAL IMAGE TO PUT TOGETHER
;*
WPLYR   LDU     PEXEC
        LDY     PPICR,U
        BEQ     WNORIA          ;BR=NO RIDER
        JSR     VWR2CLS         ;GET 2 DMA BLOCKS FOR RIDER/HORSE
WRRIDR  LDD     2,Y             ;WRITE PLAYER
        ADDA    CLSX
        ADDB    CLSY
        STD     WCDEST,X
        LDY     4,Y
        LDD     ,Y++
        STD     WCLEN,X
        STY     WCSRC,X
        LEAX    10,X
;*
WRHORS  LDY     PPICH,U         ;WRITE HORSE
WRHOR2  LDD     2,Y
        ADDA    CLSX
        ADDB    CLSY
        STD     WCDEST,X
        LDY     4,Y
        LDD     ,Y++
        STD     WCLEN,X
        STY     WCSRC,X
WRRTS   RTS
;*
WNORIA  LDY     PPICH,U         ;WRITE THE HORSE
        BEQ     WRRTS
WRREGY  JSR     VWR1CLS
        BRA     WRHOR2
;*
;*      CLEAR LAST IMAGE PLOTTED AT LAST PPOSX & Y
;*       (ORDER IS NOT IMPORTANT FOR ERASEING OBJECT)
;*
CPLYR   LDY     PPICR,U
        BEQ     CNORIA          ;BR=NO RIDER
        JSR     VCL2CLS         ;GET 2 DMA BLOCKS FOR RIDER/HORSE
        BRA     WRRIDR
;*
CNORIA  LDY     PPICH,U         ;CLEAR THE HORSE
        BEQ     WRRTS
CLREGY  JSR     VCL1CLS
        BRA     WRHOR2
;*
;*      START TO FLY
;*
STFLY   JSR     CPLYR           ;ERASE PLAYER
        LDD     #-$0080         ;INITIAL Y VELOCITY
        STD     PVELY,U
STKILL  DEC     PPOSY+1,U       ;JUMP UP 1 PIXEL (GET OUT OF LANDING AREA)
STFLY2  CLR     PPOSY+2,U       ;RESET FRACTIONAL DISTANCES
        CLR     PPOSX+2,U
        CLR     PBUMPY,U        ;RESET BUMP Y REGISTER
        LDD     #0
        STD     PSTATE,U        ;FLYING STATE
        LDD     #ADDGRA         ;NORMAL GRAVITY ROUTINE (NOT LAVA TROLLS)
        STD     PADGRA,U
        INC     PACCX,U         ;MAKE WINGS SHOW UP (1 FRAME), THEN DOWN
        JMP     FLAST2
;*
;*      START TO FALL
;*
STFALL  LDA     PFRAME,U        ;A SKIDDING FALL OFF A CLIFF?
        BPL     .1S             ; BR=NO
        LDX     PDECSN,U        ;START FALLING SOUND (STOP SKIDDING SOUND)
        LDX     DSNFAL,X
        JSR     VSND
.1S     CLR     PPOSY+2,U       ;RESET FRACTIONAL DISTANCES
        CLR     PPOSX+2,U
        CLR     PBUMPY,U        ;RESET BUMP Y REGISTER
        LDA     #10
        STA     PACCX,U         ;SLOW TIME TO RAISE WINGS
        LDD     #0
        STD     PVELY,U         ;INITIAL Y VELOCITY
        STD     PSTATE,U        ;FLYING STATE
        LDD     #ADDGRA         ;NORMAL GRAVITY ROUTINE (NOT LAVA TROLLS)
        STD     PADGRA,U
        CLR     PTIMUP,U        ;NEEDS TO BE DONE
        LDA     CURJOY+1        ;FLAP BUTTON PRESSED?
        BNE     FLAPS2          ; BR=YES
        BRA     FLIPS2          ;NO, START AT CORRECT FRAME
;*
;*      FLYING FLAP/FLIP LOOPS
;*
;*              WINGS ARE DOWN LOOP (FLAP PRESSED)
;*
FLAPLP  JSR     WPLYR
        LDX     PDECSN,U
        LDA     [DTIME,X]
        JSR     VNAPTPC
        JSR     AIROVR          ;FLYING OVERHEAD
        TSTB                    ;FLAP BUTTON STILL PRESSE?
        BEQ     GOFLIP          ; BR=NO
FLAPS2  CLRB                    ;NO OFFSET TO GRAVITY
FLAPST  LDX     #FLYX           ;BIRDS X VELOCITY TABLE
        JSR     [PADGRA,U]      ;ADD IN GRAVITY
        LDA     PACCX,U         ;MAINTAIN MINIMUM WING DOWN TIME
        BLE     WINGDN
        DEC     PACCX,U
WINGDN  LDA     #FLY1           ;WINGS DOWN
WINGFK  JSR     SRCADA
        JSR     CKGND           ;LANDED?
        BNE     FLAPLP          ; BR=NO
        BRA     STLAN           ;START LANDING PROCEDURES
;*
GOFLIP  LDX     PDECSN,U
        LDX     DSNWU,X         ;GET WING UP SOUND
        JSR     VSND
        CLR     PTIMUP,U        ;RE-INIT BUTTON PRESSES
        BRA     FLIPS2
;*
;*              WINGS ARE UP LOOP (FLAP RELEASED)
;*
FLIPLP  JSR     WPLYR
        LDX     PDECSN,U
        LDA     [DTIME,X]
        JSR     VNAPTPC
        JSR     AIROVR          ;FLYING OVERHEAD
        TSTB                    ;FLAP BUTTON STILL RELEASED?
        BNE     GOFLAP          ; BR=NO
FLIPS2  LDB     #$04            ;OFFSET TO GRAVITY
FLIPST  LDX     #FLYX           ;BIRDS X VELOCITY TABLE
        JSR     [PADGRA,U]      ;ADD IN GRAVITY
        LDA     PACCX,U         ;MAINTAIN MINIMUM WING DOWN TIME
        BLE     .1S
        DEC     PACCX,U
        LDA     #FLY1           ;PSYDO-WINGS DOWN FRAME (THEY ARE REALLY UP)
        BRA     GOTFIT
;*
.1S     LDA     #FLY3           ;WINGS UP
GOTFIT  JSR     SRCADA
        JSR     CKGND           ;LANDED?
        BNE     FLIPLP          ; BR=NO
        BRA     STLAN           ;START LANDING PROCEDURES
;*
GOFLAP  JSR     ADDFLP          ;ADD IN NEW X & Y VELOCITIES
        CLRB                    ;NO OFFSET TO GRAVITY (WINGS WILL BE DOWN)
        LDX     #FLYX           ;BIRDS X VELOCITY TABLE
        JSR     [PADGRA,U]      ;ADD IN GRAVITY
FLAST2  LDX     PDECSN,U
        LDX     DSNWD,X         ;GET WING UP SOUND
        JSR     VSND
        CLR     PTIMUP,U
        LDB     PACCX,U         ;SAVE MINIMUM WING DOWN TIME
        LDA     #5              ;WING DOWN MINIMUM TIME
        STA     PACCX,U
        TSTB                    ;WERE WINGS ALLOWED TO GO UP?
        BLE     WINGDN          ; BR=YES, SHOW NORMAL WINGS DOWN
        LDA     #FLY3           ;FAKE WINGS UP FRAME
        BRA     WINGFK
;*
;*      START LANDING PROCEDURES
;*       1 - DETERMINE RUNNING POSITION BASED ON VELOCITY X
;*       2 - DETERMINE RUNNING SPEED VIA TABLE LOOK UP (ROUNDING)
;*       3 - GIVE JOYSTICK POISTION FOR RUNNING DECISIONS
;*
STLAN   LDA     PVELX,U         ;WHICH DIRECTION?
        BEQ     STLDIR          ;LAND IN SAME DIRECTION OF FLYING,
        CLR     PFACE,U         ;ASSUME FACING RIGHT
        TSTA
        BPL     STLDIR          ;LANDING RIGHT
        COM     PFACE,U         ;FACING LEFT
        NEGA                    ;NEED A POSITIVE SPEED
STLDIR  LDX     #FRCONV         ;CONVERT FLYING TO RUNNING
        LDX     A,X             ;GET STATE
        STX     PSTATE,U        ;       & REMEMBER IT
        CLR     PTIMX,U         ;ALSO CHANGE ANIMATION FRAME
        CLR     PACCX,U         ;IMMEDIATE LAND JOYSTICK SERVICE
        LDA     #1              ;MINIMUM DOWN TIME
        STA     PTIMUP,U
        LDD     #0              ;NO PVELY, (FOR INTELLIGENCE)
        STD     PVELY,U
        LDA     #STAND          ;LAND STANDING
        STA     PIMAGE,U
        JMP     PL2EDG          ;NO MORE FLYING
;*
FRCONV  FDB     PLYBR   ;STAND STILL
        FDB     PLYCR   ;NAP 8 - SLOWEST SPEED
        FDB     PLYDR   ;NAP 4
        FDB     PLYER   ;NAP 2
        FDB     PLYFR   ;NAP 1 - FASTEST SPEED
;*
ENDAD1  EQU     *       ;CURRENT END ADDRESS
        IF *-$DFFF >= 0                                                         ;;Fixme was: IFGE  *-$DFFF
         FCB    $1111   ;ERROR, $D800-$DFFF MODULE IS TOO LONG
        ENDIF
;       PAGE
;*
;****************************************************************************
;****************************************************************************
;*
;*      PATCHES TO PREVENT PLAYER FROM PTERODACTYL HUNTING
;*
        ORG     $D760   ;MODULE "ATT.SRC" ENDED AT $D6EF ON 10/29/82
PATCHS  EQU     *       ;START ADDRESS OF PATCHES
        IF *-$D6EF <= 0                                                         ;;Fixme was: IFLE  *-$D6EF
         FCB    $1111   ;ERROR, BUMPING INTO "ATT.SRC" MODULE AT $D6EF
        ENDIF
;*
;*      FUDGE TO MAKE THIS PROM CHECKSUM CORRECTLY
;*
        FCB     $F3     ;(ZAPPER) FUDGE TO GET THIS PART ($D000) ADD UP TO $3D
;*
;*      11TH PATCH, CLEAN UP GLADIATOR WAVE (GAME START GOOF)
;*
PATC11  CLR     PLYG1           ;RESET 3,000 POINT TRIGGER
        CLR     PLYG2
        JMP     EMSGS           ;ERASE ANY END OF WAVE MESSAGES(OLD INSTRUCTION)
;*
;*      10TH PATCH, IF BAITER PTERODACTYL IS KILLED, SPEED THINGS UP!
;*       IF KILLED, THINGS REVERT BACK TO NORAML SPEED
;*
PATC10  LDA     #1
        STA     EMYTIM          ;MAKE SLOW 1ST, 2ND, & OPTIONAL 3RD WAVE NORMAL
        CLR     PCHASE,U
        RTS
;*
;*      9TH PATCH, MAKE PTERODACTYL ACCOUNT FOR ITSELF DURING ATTACKS
;*
PATCH9  TST     PCHASE,U        ;NON-BAITERS IGNORE THIS
        BEQ     .10S
        DEC     PPVELX,U        ;CONTINUE NEXT SEEK TIMER
        BNE     .10S            ;BUT SATURATE IT AT 1
        INC     PPVELX,U
.10S    DEC     PEGG,U          ;ATTACK SEQUENCE TIME OUT?
        RTS
;*
;*      8TH PATCH, MAKE THE 1ST PASS OF A BAITER PTERODACTYL MISS THE PLAYER
;*              TO INDICATE A CHANGE IN INTELLIGENCE
;*
PATCH8  TST     PCHASE,U        ;THIS ONLY APPLIES TO BAITERS
        BEQ     .10S
        LDA     #138            ;DELAY TILL PTERODACTYL IS 1/2 WAY ACROSS SCREEN
.10S    STA     PPVELX,U        ;(RESTORE OLD INSTRUCTION)
        RTS
;*
;*      7TH PATCH, MAKE BAITERS COME OUT MORE QUICKLY, TYPICAL OLD TIME 4 MIN
;*        16 SEC, NEW TIME 2 MIN 16 SEC.
;*                              VERSION 4 SOFTWARE
;*
PATCH7  EQU     *               ;NO CODE MODIFIED, JUST A TABLE
;*
;*      6TH PATCH, MODIFY PTERODACTYLS LINE TRACKING INTELLIGENCE TO SKIM
;*              OVER HIGHER CLIF3U, THEN LOWER ITSELF TO CLIF3L & CLIF3R
;*                              VERSION 4 SOFTWARE
;*
PATCH6  BLO     .10S            ;BR=TRACK ON LINE 2 (RESTORE OLD 2 INSTRUCTIONS)
        LDA     #AOFFL3-2       ;ASSUME NEAR TRACKING LINE 3
        RTS
;*
.10S    TST     PCHASE,U        ;AGAIN, THIS IS ONLY FOR BAITERS
        BEQ     .30S
        LDD     PPOSX,U         ;TRACKING LINE 2, TO THE RIGHT OF CLIF3U?
        SUBD    #(260+7)
        BGT     .20S            ; BR=YES, GO TO LOWER TRACKING LINE
        SUBD    #(200-28-7)-(260+7)     ;TO THE LEFT OF CLIF3U?
        BGT     .30S            ; BR=NO, USE NORMAL UPPER CLIF3U LINE
.20S    LDA     #$88            ;NEW LINE TO TRACK FOR LOWER CLIFFS
        RTS
;*
.30S    LDA     #AOFFL2-2       ;ASSUME NEAR TRACKING LINE 2
        RTS
;*
;*      5TH PATCH, SLOW DOWN 'Y' VELOCITY SO THAT ATTACKING PETRODACTYLS
;*              DO NOT OVER SHOOT THEIR TARGET
;*                              VERSION 4 SOFTWARE
;*
PATCH5  STA     PEGG,U          ;RESTORE OLD INSTRUCTION
        TST     PCHASE,U        ;AND AGAIN, THIS DOES NOT PERTAIN TO NON-BAITERS
        BEQ     .10S
        ASR     PVELY+0,U
        ROR     PVELY+1,U
        ASR     PVELY+0,U
        ROR     PVELY+1,U
.10S    RTS
;*
;*      4TH PATCH, ADJUST PTERODACTYL TO HIT PLAYER IN THE LEGGS
;*       (PREVENT PLAYER FROM STANDING ON CLIF4 AND KILLING MY PETS)
;*                              VERSION 4 SOFTWARE
;*
PATCH4  TST     PCHASE,U        ;HOWEVER, THIS PATCH IS NOT USED ON NON-BAITERS
        BEQ     .10S
        ADDB    #2              ;JUST LOWER THE ATTACK WINDOW BY 2 PIXELS
.10S    STB     PRDIR,U         ;X=PDIST, Y=PRDIR (RESTORE OLD INSTRUCTION)
        RTS
;*
;*      3RD PATCH, USE LAVA TROLLS NEW VARIABLE GRAVITY (IN "ADDLAV")
;*                              VERSION 3 SOFTWARE
;*
;*                              END OF 3RD PATCH
PATCH3  EQU     *               ;NO ROUTINES NEEDED
;*
;*      2ND PATCH, IF TIMER NOT EQUAL TO ZERO DECREMENT TIMER
;*                 IF TIMER EQUAL TO ZERO, INCREASE LAVA TROLL PULL
;*                              VERSION 3 SOFTWARE
;*
;*
PATCH2  LDD     LAVKLL          ;CHECK LAVA TROOL TIMER
        ADDD    #-1
        BGT     .10S
        LDD     CLVGRA
        CMPD    #$500           ;MAXIMUM LAVA TROLL GRAVITY
        BHI     .5S
        ADDD    #1
        STD     CLVGRA
.5S     LDD     #1
.10S    STD     LAVKLL
        LDA     #1
        JMP     VNAPTIM
;*
;*      1ST PATCH, INITILIZE LAVA TROLL KILL TIME.
;*                 INITILIZE LAVA TROLL VARIABLE GRAVITY
;*                              VERSION 3 SOFTWARE
;*
;*
PATCH1  STD     PPICH,Y         ;OLD INSTRUCTION
        LDD     #30*60          ;30 SECOND WAIT TILL TOUGHER LAVA TROLL
        STD     LAVKLL
        LDD     LAVGRA          ;GIVE CURRENT LAVA TROLL GRAVITY
        STD     CLVGRA
        RTS
;*
        IF *-$D800 > 0                                                          ;;Fixme was: IFGT  *-$D800
         FCB    $1111   ;ERROR, PATCH AREA ($D796-$D800) MODULE IS TOO LONG
        ENDIF
PATCHL  EQU     *-PATCHS        ;LENGTH OF PATCHES
PATCHA  EQU     $D800-PATCHL    ;RECOMMENDED START ADDRESS
;****************************************************************************
;       PAGE
;****************************************************************************

        ORG     $D800
;*
;*      SEARCH FOR A FREE AREA
;*       INPUT REG.X = WORKSPACE OF PROCESS WITH A VALID Y POSITION
;*
SELARE  LDA     PPOSY+1,X
        CMPA    #$A3+6          ;$8A+6  BOTTOM AREA3 FREE?
        BLO     .1S             ; BR=YES
        INC     AREA3           ;HERE IF NO!
        RTS
;*
.1S     CMPA    #$51            ;MIDDLE AREA2 FREE?
        BLO     .2S             ; BR=YES
        INC     AREA2           ;HERE IF NO!
        RTS
;*
.2S     INC     AREA1           ;MUST BE IN TOP AREA1
        RTS
;*
;*      ADD IN THE FLAP TO FLIP VELOCITIES
;*
ADDFLP  LDB     PTIMUP,U        ;NOW CALC GAINED Y VELOCITY
        LDA     #256*96/255     ;CALC NBR -96 TO 0 FROM 0 TO 255
        MUL
        TFR     A,B
        CLRA
        SUBD    #96             ;NEW DELTA-Y, USE IN GRAVITY CALC
        ADDD    PVELY,U
        STD     PVELY,U
        LDA     CURJOY          ;ADD IN JOYSTICKS LEFT OR RIGHT POSITION
        ASLA
        ADDA    PVELX,U         ;GET CURRENT TABLE VELOCITY-X SPEED
        BLT     ADXMAX
        CMPA    #MAXVX          ;PASSED MAXIMUM X VELOCITY?
        BGT     ADXMX2          ; BR=NO
        STA     PVELX,U
        RTS
;*
ADXMAX  CMPA    #-MAXVX         ;PASSED MINIMUM X VELOCITY?
        BLT     ADXMX2          ; BR=NO
        STA     PVELX,U
ADXMX2  RTS
;*
;*      IN THE AIR OVERHEAD
;*       0 - GET JOYSTICK POSITION, (UPDATES CLEAR POINTERS)
;*       1 - FACE THE JOYSTICKS DIRECTION
;*       2 - INCREMENT FLAP/FLIP TIMER
;*
AIROVR  JSR     [PJOY,U]                ;READ JOYSTICK
;********      IFN DEBUG                ???????????? DEBUG PARAMATER ?????????
;********       CMPA    #-1
;********       BLT     .1S
;********       CMPA    #1
;********       BGT     .1S
;********       CMPB    #-1
;********       BEQ     .2S
;********       CMPB    #1
;********       BLS     .2S
;********      .1S      SWI
;********      .2S
;********            ENDIF                      ???????????? END OF DEBUG ??????
;??????
        TSTA                    ;FACE RIGHT/LEFT??
        BEQ     AIRTIM          ; BR=USE LAST DIRECTION
        CLR     PFACE,U         ;ASSUME RIGHT
        TSTA
        BPL     AIRTIM
        COM     PFACE,U         ;FACEING LEFT
AIRTIM  INC     PTIMUP,U        ;NBR OF TICKS IN THE AIR
        BNE     AIRRTS
        DEC     PTIMUP,U        ;NO OVERFLOW, JUST SATURATE
AIRRTS  JSR     CPLYR           ;ERASE PLAYER
        LDD     CURJOY          ;GIVE BACK JOYSTICK POSITION
        RTS
;*
;*      ADD IN GRAVITY
;*       INPUT REG.B = ADDITION TO GRAVITY (VELOCITY)
;*              REG.X = X DRECTION VELOCITY TABLE
;*       1 - MODIFY VELOCITY Y FOR GRAVITY
;*       2 - CALC NEW POSITIONS
;*
ADDGRA  ADDB    GRAV            ;ADD IN VARIABLE GRAVITY
        SEX
        ADDD    PVELY,U
        STD     PVELY,U         ;NEW Y VELOCITY
;*
ADDGRX  ADDD    PPOSY+1,U       ;ADD IN FRACTIONAL DISTANCE
        ADDA    PBUMPY,U        ;ADD IN BUMPING REGISTER
        CLR     PBUMPY,U
        CMPA    #CEILNG         ;HIGHEST POSITION *****
        BHI     ADGCEI          ; BR=HAVE NOT HIT CEILING
        INC     PBUMPY,U
        LDD     PVELY,U
        BPL     ADGDWN          ; BR=ALREADY GOING DOWN, DON'T GO UP
        COMA
        NEGB
        SBCA    #-1             ;INVERT VELOCITY
        STD     PVELY,U
ADGDWN  LDD     #CEILNG*256
        BRA     ADGCEI
ADGCEI  CMPA    #FLOOR+7        ;BELOW SEA LEVEL (ON THE FLOOR)?
        BHS     ADGFLR          ; BR=YES, TOO BAD, YOU ARE DEAD
        STD     PPOSY+1,U
;*
        LDA     PVELX,U
        LDD     A,X
        ADDB    PVELX+2,U       ;ADD IN FRACTIONAL DISTANCE
        STB     PVELX+2,U
        ADCA    #0              ;CARRY TO POSITION X
        TFR     A,B
        JMP     WRAPX
;*
;*
;*      DEATH VIA SWIMMING IN THE LAVA
;*
ADGFLR
;********            IFN DEBUG          ???????????? DEBUG PARAMATER ?????????
;********       LDA     PID,U           ONLY PLAYERS & EMIES SHOULD GET HERE
;********       CMPA    #$80+PLYID
;********       BEQ     .123S
;********       CMPA    #$80+EMYID
;********       BEQ     .123S
;********       SWI
;********      .123S
;********            ENDIF                      ???????????? END OF DEBUG ??????
;??????
        LDX     #SNPLAV
        LDA     PID,U
        CMPA    #$80+PLYID      ;PLAYER
        BEQ     .1S
        LDX     #SNELAV         ;ENEMY IN LAVA
.1S     JSR     VSND
ADGLAV  JSR     WPLYR           ;WRITE THE PLAYER
        JSR     FCLIP           ;CLIP THE IMAGE BASED ON THE FLOOR
        PCNAP   3
        JSR     CPLYR           ;ERASE THE PLAYER
        JSR     FCLIP           ;CLIP THE IMAGE BASED ON THE FLOOR
        LDA     PID,U           ;IS THE GUY DEAD OR JUST HERE FOR THE RIDE?
        BPL     ADGDED          ; BR=DEAD
;********            IFN DEBUG          ???????????? DEBUG PARAMATER ?????????
;********       LDB     PPICR,U         THERE IS A RIDER ISN'T THERE?
;********       BNE     .1S
;********       SWI
;********      .1S
;********            ENDIF                      ???????????? END OF DEBUG ??????
;??????
        LDB     WCLENY,X        ;HAS THE GUYS LENGTH CHANGED? (IN LAVA)
        CMPB    #7!4            ;GUYS LENGTH IS ASSUMED TO BE 7 PIXELS TALL     ;;Fixme was: CMPB  #7!X(!WDMAFIX)
        BEQ     ADGDED          ; BR=NO, THE GUY IS STILL ABOVE THE LAVA
        ANDA    #$7F            ;NOW THIS GUY IS DEAD
        STA     PID,U
        LDD     #0
        STD     PPICR,U
        STD     PRIDER,U
        LDX     #0              ;NO VICTOR
        LDY     PDECSN,U
        JSR     [DDEAD,Y]       ;CALL DEATH ROUTINE (REG.X VICTOR, REG.U DEAD)
;*
ADGDED  INC     PPOSY+1,U
        LDA     PPOSY+1,U
        CMPA    #FLOOR+20+1     ;ALL THE WAY IN THE LAVA?
        BLO     ADGLAV          ; BR=NO, IT'S NOT SOUP YET!
        PCNAP   30
        LDX     PDECSN,U        ;TRY TO RE-CREATE THIS GUY
        JMP     [DCRE,X]
;*
;*      FLOOR CLIPPING ROUTINE FOR THE BIRDS
;*
FCLIP   BSR     CLIPER          ;CLIP THE OSTRICH
        LDD     PPICR,U         ;IS A RIDER PRESENT?
        BEQ     CLPRTS          ; BR=NO
        LEAX    -10,X           ;MUST BE, SO CLIP HIM ALSO
;*
;*      GENERAL CLIPPING ROUTINE FOR AFTER CLxCLS or WRxCLS WITH OFFSETS
;*
CLIPER  LDA     WCLENY,X        ;FIND BOTTOM LINE OF OBJECT
        EORA    #4                                                              ;;Fixme was: EORA  #!WDMAFIX
        ADDA    WCY,X
        CMPA    #FLOOR+1        ;BELOW THE FLOOR
        BLO     CLPRTS          ; BR=NO
        LDA     WCY,X           ;YES, IS THE TOP BELOW THE FLOOR?
        CMPA    #FLOOR+1        ;BELOW THE FLOOR
        BLO     CLPIT           ; BR=NO, JUST THE BOTTOM
        LDA     #$F0            ;WELL, WRITE THIS OFF SCREEN, A ROM
        STA     WCX,X           ; IS OK TO WRITE INTO (I HOPE)
        LDD     #$0000!DMAFIX   ;A 1 BYTE TRANSFER                              ;;Fixme was: LDD  #$0000!XDMAFIX
        STD     WCLEN,X
CLPRTS  RTS
;*
CLPIT   NEGA
        ADDA    #FLOOR+1        ;NEW LENGTH
        EORA    #4                                                              ;;Fixme was: EORA  #!WDMAFIX
        STA     WCLENY,X
        RTS
;*
;*      ADD IN LAVA TROLLS GRAVITY
;*       INPUT REG.B ADDITION TO GRAVITY (VELOCITY)
;*       1 - MODIFY VELOCITY Y FOR GRAVITY
;*       2 - CALC NEW POSITIONS
;*
ADDLAV  CLR     PBUMPX,U        ;NO BUMPAGE ALLOWED
        CLR     PBUMPY,U
        CLR     PVELX,U         ;THE PLAYER IS NOT GOING ANYWERE
        SEX
        ADDD    CLVGRA          ;PATCH3
;********       ADDD    LAVGRA
        ADDD    PVELY,U
        STD     PVELY,U         ;NEW Y VELOCITY
        CMPD    #-$0180         ;BREAK FREE VELOCITY?
        BLT     ADLFRE          ; BR=NO, SO STOP FALLING
        ADDD    PPOSY+1,U       ;ADD IN FRACTIONAL DISTANCE
        STD     PPOSY+1,U
        CMPA    #FLOOR+7        ;BIRD IN THE LAVA?
        BLO     ADLX            ; BR=NO
        LDX     PLINK,U         ;KILL LAVA TROLL TASKS
        LDA     PID,X           ;ANOTHER PROCESS CAN SNEAK IN,
        CMPA    #LAVID+1        ;SO, CHECK TO MAKE SURE THIS IS THE TROLL
        BNE     .11S
        LDD     #LT2DIE         ;ERASE & STOP GRAB ROUTINE
        STD     PPC,X
.11S    LDX     PPREV
;********            IFN DEBUG          ???????????? DEBUG PARAMATER ?????????
;********       LDA     PID,X
;********       CMPA    #LAVID
;********       BEQ     .2S
;********       SWI
;********       BRA     .22S
;********      .2S
;********            ENDIF                      ???????????? END OF DEBUG ??????
;??????
        LDD     #LT1DON         ;STOP RAISE/LOWER HAND ROUTINE
        STD     PPC,X
        LDD     #ADDGRA         ;BACK TO NORMAL GRAVITY
        STD     PADGRA,U
.22S    JMP     ADGFLR          ;NOW, THE GUY IS IN THE LAVA
;*
ADLX    LDD     PPOSX,U         ;PUT THE GUY ON THE VISABLE SCREEN
        CMPD    #ELEFT+14+4
        BGT     .10S
        LDD     #ELEFT+14+4
.10S    CMPD    #ERIGHT-14
        BLT     .11S
        LDD     #ERIGHT-14
.11S    STD     PPOSX,U
        TFR     U,Y
        JSR     LAVVI3          ;BIRD OUT OF LAVA TROLLS RANGE?
        BNE     ADLFRE          ; BR=YES
;********            IFN DEBUG          ???????????? DEBUG PARAMATER ?????????
;********       LDX     PLINK,U         LAVA TROLL STILL ACTIVE?
;********       LDA     PID,X
;********       CMPA    #LAVID+1
;********       BEQ     .12S             BR=NO, A PROBLEM EXISTS
;********       SWI
;********      .12S
;********            ENDIF                      ???????????? END OF DEBUG ??????
;??????
        RTS
;*
ADLFRE  LDA     PID,U           ;IS THE PERSON ALIVE
        BPL     .33S
        LDA     #$50            ;SCORE 50 POINTS FOR BREAKING FREE
        LDX     PDECSN,U
        JSR     SCRTEN
.33S    LDX     PLINK,U         ;KILL LAVA TROLL GRAB TASK
        LDA     PID,X           ;ANOTHER PROCESS CAN SNEAK IN,
        CMPA    #LAVID+1        ;SO, CHECK TO MAKE SURE THIS IS THE TROLL
        BNE     .11S
        LDD     #LT2DIE
        STD     PPC,X
.11S    LDX     PPREV           ;DROP THE HAND
;********            IFN DEBUG          ???????????? DEBUG PARAMATER ?????????
;********       LDA     PID,X           DEBUG
;********       CMPA    #LAVID
;********       BEQ     .2S
;********       SWI
;********       BRA     .22S
;********      .2S
;********            ENDIF                      ???????????? END OF DEBUG ??????
;??????
        LDD     #LT1DRP
        STD     PPC,X
        LDA     #1
        STA     PNAP,X
.22S    LDD     #ADDGRA         ;BACK TO NORMAL GRAVITY
        STD     PADGRA,U
        LDD     PVELY,U         ;SHOW NEW HIGHER POSITION
        ADDD    PPOSY+1,U       ;ADD IN FRACTIONAL DISTANCE
        STD     PPOSY+1,U
        RTS
;*
;*      CHECK IF ON THE GROUND, FROM PPOSX & PPOSY
;*              STATUS NE = STILL IN THE AIR
;*                     EQ = ON THE GROUND
;*              OUTPUTS REG.B = Y LOCATION
;*
CKGND   LDX     PPOSX,U         ;GET X LOCATION OF OBJECT
        LDY     PPOSY,U         ;GET Y LOCATION OF OBJECT
        LDA     LNDXTB,X        ;STARTING TO LAND ON A CLIFF?
        ANDA    LNDYTB,Y
        BNE     LND18           ; BR=STARTING TO LAND(CANNOT COLIDE WITH BCKGND)
        LDA     BCKXTB,X        ;BACKGROUND MAP IN X DIRECTION
        ANDA    BCKYTB,Y        ;BACKGROUND MAP IN Y DIRECTION
        BEQ     CKG2            ; BR=NO BOX COLLISION WITH BACKGROUND
        JSR     BCKCOL          ;PIXEL HIT BACKGROUND IMAGE?
CKG2    LDA     #1              ;NOT ON GROUND
        RTS
;*
LND18   CMPA    #$08
        BLO     LND13
        BEQ     LNDB3
LND47   CMPA    #$20
        BLO     LNDB4
        BITA    #$20
        BNE     LNDB5
        BRA     LNDB7
;*
LND13   CMPA    #$02
        BEQ     LNDB1
        BHI     LNDB2
;*
LNDB0   EQU     *       ;CLIF1L & CLIF1R
        LDB     #$0045-1        ;ON TOP OF CLIFF PIXEL HEIGHT
        STB     PPOSY+1,U
        CLRA
        RTS
;*
LNDB1   EQU     *       ;CLIF2
        LDB     #$0051-1        ;ON TOP OF CLIFF PIXEL HEIGHT
        STB     PPOSY+1,U
        CLRA
        RTS
;*
LNDB2   EQU     *       ;CLIF3R
        LDB     #$0081-1        ;ON TOP OF CLIFF PIXEL HEIGHT
        STB     PPOSY+1,U
        CLRA
        RTS
;*
LNDB3   EQU     *       ;CLIF3L & CLIF3R
        LDB     #$008A-1        ;ON TOP OF CLIFF PIXEL HEIGHT
        STB     PPOSY+1,U
        CLRA
        RTS
;*
LNDB4   EQU     *       ;CLIF4
        LDB     #$00A3-1        ;ON TOP OF CLIFF PIXEL HEIGHT
        STB     PPOSY+1,U
        CLRA
        RTS
;*
LNDB5   EQU     *       ;CLIF5
        LDB     #$00D3-1        ;ON TOP OF CLIFF PIXEL HEIGHT
        STB     PPOSY+1,U
        CLRA
        RTS
;*
LNDB7   EQU     *       ;LAVA TROLLS
        LDA     TTROLL  ;LAVA TROLL ACTIVE?
        BNE     LNDB7C  ; BR=NO
        LDA     LAVNBR  ;TOO MANY LAVA TROLLS?
        BNE     LNDB7C  ; BR=YES, DO NOT START ANOTHER
        LDA     PID,U           ;CHOOSY MOTHER CHOOSE JIFF???
        CMPA    #$80+PLYID      ;PLAYER?
        BEQ     .1S
        CMPA    #$80+EMYID      ;ENEMY?
        BNE     LNDB7C          ;ANY ONE ELSE, JUST IGNORE
.1S     INC     LAVNBR          ;1 MORE LAVA TROLL
        LDA     #LAVID          ;LAVATROLL I.D.
        LDB     PPRI,U          ;ALSO COPY PIRORITY VALUE
        LDX     #LAVAT1         ;START LAVA TROLL PROCESS
        LDU     PPREV           ;AFTER PREVIOUS PROCESS (BEFORE THIS ONE)
        JSR     VCUPROC         ;CREATE A PROCESS, ABRAKADABRA...
        LDU     PEXEC           ;HU HUM... BACK TO SAME OLD WORKSPACE
        STU     PJOY,Y          ;FINGER PRINT THIS PROCESS FOR THE LAVA TROLL
        CLR     PFRAME,Y        ;LAVA TROLL FRAME ZERO TO START
        LDD     #FLOOR-9        ;STARTING AT THE GROUND FLOOR
        STD     PPOSY,Y         ; BUT NEXT WEEK HE'LL GET A PROMOTION
        LDD     PPOSX,U         ;START X POSITION
        ADDD    #-2             ;LAVA TROLL OFFSET
        STD     PPOSX,Y
        LDD     #0
        STD     PPICH,Y         ;NO PREMATURE CLEAR OF AN IMAGE
        LDA     #1              ;START FIRST FRAME
        STA     PJOYT,Y
LNDB7C  LDB     PPOSY+1,U       ;INDICATE NOT TO LAND
        RTS
;*
;*      DETECT & BOUNCE OFF BACKGROUND COLISION (FROM PPOSX & PPOSY)
;*      INPUT:  REG.A - COLISION BIT OF ROUGH BACKGROUND COLISION
;*              REG.U - THE OBJECT COLIDING WITH
;*
BCKCOL  TFR     A,B
        ORA     BCKRFS          ;REFRESH THIS BACKGROUND IMAGE WHEN NECESSARY
        STA     BCKRFS
        TSTB
        LBMI    BCKB7
        CMPB    #$08
        BLO     BCK13
        LBEQ    BCKB3
BCK47   ANDB    #$70
        CMPB    #$20
        LBHI    BCKB6
        BLO     BCKB4
        JMP     BCKB5
;*
BCK13   CMPB    #$02
        BEQ     BCKB1
        LBHI    BCKB2
;*
BCKB0   EQU     *       ;BIT 0 = CLIF1L
        LDY     [CLIF1L]        ;COLISION DETECT POINTERS
        LDD     #-32
        LDX     #69
        BRA     BCKB04
;*
BCKB4   EQU     *       ;BIT 4 = CLIF3L
        LDY     [CLIF3L]        ;COLISION DETECT POINTERS
        LDD     #-32
        LDX     #138
BCKB04  PSHS    Y
        JSR     BCKPIX
        BCC     NOBCK
        CMPY    ,S++
        BNE     BCCOML
        LDA     1*4,X           ;TOP COLISION? ,LOWER 4 LINES OF BIRD/HORSE?
        BMI     .1S             ; BR=YES
        LDA     2*4,X
        BMI     .1S             ; BR=YES
        LDA     3*4,X
        BMI     .1S             ; BR=YES
        LDA     4*4,X
        BPL     BCCOML          ; BR=NO, MUST OF HIT PLAYERS HEAD
.1S     JMP     BCTOP
;*
BCCOML  LDA     4,Y             ;BOTTOM COLISION?
        BMI     BCBOT2          ; BR=YES
        LDD     ,Y              ;LEFT OR RIGHT SIDE?
        ADDD    2,Y             ;TO DECIDE TAKE A TYPE OF AVERAGE FOR THIS
        SUBD    ,X              ; COLISIONED LINE
        SUBD    2,X
        ADDD    COLDX
        ADDD    COLDX
        LBMI    BCRIT
        JMP     BCBOT           ;BR=OBJECT ON LEFT
;*
NOBCK   LEAS    2,S
NOBCK2  RTS
;*
BCKB1   EQU     *       ;BIT 1 = CLIF1R
        LDY     [CLIF1R]        ;COLISION DETECT POINTERS
        LDD     #252
        LDX     #69
        BRA     BCKB15
;*
BCKB5   EQU     *       ;BIT 5 = CLIF3R
        LDY     [CLIF3R]        ;COLISION DETECT POINTERS
        LDD     #202
        LDX     #129
        JSR     BCKPIX
        BCC     NOBCK2
        LDB     PPOSY+1,U
        CMPB    #$89+4+6
        BHI     BCCOMR
        BRA     BCK15C
;*
BCKB3   EQU     *       ;BIT 3 = CLIF3U
        LDY     [CLIF3R]        ;COLISION DETECT POINTERS
        LDD     #202
        LDX     #129
BCKB15  PSHS    Y
        JSR     BCKPIX
        BCC     NOBCK
        CMPY    ,S++
        BNE     BCCOMR
BCK15C  LDA     1*4,X           ;TOP COLISION?, LOWER 4 LINES OF BIRD/HORSE?
        BMI     .1S             ; BR=YES
        LDA     2*4,X
        BMI     .1S             ; BR=YES
        LDA     3*4,X
        BMI     .1S             ; BR=YES
        LDA     4*4,X
        BPL     BCCOMR          ; BR=NO, MUST OF HIT PLAYERS HEAD
.1S     JMP     BCTOP
;*
BCCOMR  LDA     4,Y             ;BOTTOM COLISION?
        BMI     BCBOT2          ; BR=YES
        LDD     ,Y              ;LEFT OR RIGHT SIDE?
        ADDD    2,Y             ;TO DECIDE TAKE A TYPE OF AVERAGE FOR THIS
        SUBD    ,X              ; COLISIONED LINE
        SUBD    2,X
        ADDD    COLDX
        ADDD    COLDX
        LBPL    BCLFT           ;BR=OBJECT ON LEFT
BCBOT2  JMP     BCBOT
;*
BCKB7   EQU     *       ;BIT 7 = CLIF5
        LDY     [CLIF5]         ;COLISION DETECT POINTERS
        LDD     #54
        LDX     #211
        BRA     BCKB27
;*
BCKB2   EQU     *       ;BIT 2 = CLIF2
        LDY     [CLIF2]         ;COLISION DETECT POINTERS
        LDD     #86
        LDX     #81
        BRA     BCKB27
;*
NOBCKB  LEAS    2,S
        RTS
;*
BCKB6   EQU     *       ;BIT 6 = CLIF4
        LDY     [CLIF4]         ;COLISION DETECT POINTERS
        LDD     #106
        LDX     #163
BCKB27  PSHS    Y
        JSR     BCKPIX
        BCC     NOBCKB
        CMPY    ,S++
        BNE     BCCOM
        LDA     1*4,X           ;TOP OF CLIFF?, LOWER 4 LINES OF BIRD/HORSE?
        BMI     BCTOP           ; BR=NO
        LDA     2*4,X
        BMI     BCTOP           ; BR=NO
        LDA     3*4,X
        BMI     BCTOP           ; BR=NO
        LDA     4*4,X
        BMI     BCTOP           ; BR=NO
BCCOM   LDA     4,Y             ;BOTTOM COLISION?
        BMI     BCBOT           ; BR=YES
BCLR    LDD     ,Y              ;LEFT OR RIGHT SIDE?
        ADDD    2,Y             ;TO DECIDE TAKE A TYPE OF AVERAGE FOR THIS
        SUBD    ,X              ; COLISIONED LINE
        SUBD    2,X
        ADDD    COLDX
        ADDD    COLDX
        BPL     BCLFT           ;BR=OBJECT ON LEFT
;*
BCRIT   LDA     PVELX,U         ;MAKE VELOCITY X DIRECTION POSITIVE
        BGE     BCRITB
        NEGA
BCRITM  SUBA    #2              ;SLOW DOWN X VELOCITY
        STA     PVELX,U
BCRITB  ADDA    #6
        BRA     BCLFTV
;*
BCBOT   LDD     PVELY,U         ;MAKE VELOCITY Y POSITIVE
        BPL     BCBOTM
        COMA
        NEGB
        SBCA    #-1
        ASRA
        RORB
        STD     PVELY,U
BCBOTM  BRA     BCLFTE
;*
BCLFT   LDA     PVELX,U         ;MAKE VELOCITY X DIRECTION NEGATIVE
        BLE     BCLFTB
        NEGA
        ADDA    #2              ;SLOW DOWN X VELOCITY
        STA     PVELX,U
BCLFTB  SUBA    #6
BCLFTV  STA     PBUMPX,U
        LDD     PVELY,U         ;FALL A LITTLE BIT MORE
        CMPD    #-$0040
        BPL     BCLFTH
        LDD     #-$0040
BCLFTH  STD     PVELY,U
BCLFTE  LDA     #2
        STA     PBUMPY,U
        LDX     #SNCTHD
        JMP     VSND
;*
BCTOP   LDD     PVELY,U         ;MAKE VELOCITY Y NEGATIVE
        BMI     BCTOPC
        COMA
        COMB
        ASRA
        RORB
        STD     PVELY,U
BCTOPC  LDA     #-2
        STA     PBUMPY,U
        LDA     PVELX,U
        BNE     BCUP            ;BOUNCE LEFT/RIGHT IF NO VELOCITY X
        LDD     ,Y              ;LEFT OR RIGHT SIDE?
        ADDD    2,Y             ;TO DECIDE TAKE A TYPE OF AVERAGE FOR THIS
        SUBD    ,X              ; COLISIONED LINE
        SUBD    2,X
        ADDD    COLDX
        ADDD    COLDX
        BPL     BCTL            ;BR=OBJECT ON LEFT
        LDA     #2
        STA     PVELX,U
BCUP    LDX     #SNCTHD
        JMP     VSND
;*
BCTL    LDA     #-2
        STA     PVELX,U
        LDX     #SNCTHD
        JMP     VSND
;*
;*      PIXEL BACKGROUND COLISION DETECT ROUTINE
;*       NEEDS; REG.U = PROCESS BLOCK WITH VALID PPOSX & PPOSY2 & PPICH
;*              REG.Y = CLIFFS COLISION DETECT POINTER
;*              REG.X = TOP LINE OF CLIFF (Y POSITION)
;*              REG.D = LEFT COLUMN OF CLIFF (X POSITION)
;*      OUTPUTS; REG.X = CURRENT OBJECTS COLISION POINTER
;*               REG.Y = CURRENT BACKGROUNDS COLISION POINTER
;*               STATUS C=0 (CC) - NO COLISION
;*                      C=1 (CS) - COLSION
;*
BCKPIX  SUBD    PPOSX,U         ;GET DIFFERENCES IN X DIRECTION
        STD     COLDX           ;REMEMBER THIS DIFFERENCE
        TFR     X,D             ;FIGURE WHO IS ON TOP OF WHO
        LDX     [PPICH,U]       ;(AND GET OBJECTS COLISION DETECT DATA)
        SUBB    PCOLY2,U        ;COLISION DETECT UPON TOP LINE OF OBJECT
        BMI     BPYONX          ; BR=Y (BCKGND) IS ON TOP OF X (OBJECT)
        ASLB                    ;X (OBJECT) IS ON TOP, MATCH X LEVEL TO Y
        ASLB                    ;(DIFFERENCE X4, OR 2 WORDS PER LINE)
        ROLA                    ; (MAXIMUM DIFFERENCE DELTA Y = $7F)
        LEAX    D,X
        BRA     BPCOL
;*
BPYONX  NEGB                    ;MAKE DIFFERENCE POSITIVE
        ASLB
        ASLB
        ROLA
        LEAY    D,Y
        BRA     BPCOL
;*
BP1STA  LDA     ,X
BP1STB  ORA     ,Y
        RORA                    ;CONTINUATION OR END OF TABLE POINTER?
        BCS     BPEN            ; BR=END OF TABLE POINTER
        LEAX    4,X             ;NEXT POINTERS
        LEAY    4,Y
BPCOL   LDD     2,X
        BLT     BP1STB
        SUBD    ,Y
        BVS     BP1STA
        SUBD    COLDX
        BLT     BPYX4           ;BR=NO COLISION BUT Y ON LEFT OF X
        LDD     ,X
        SUBD    2,Y
        SUBD    COLDX
        BGT     BPXY4           ;BR=NO COLISION BUT X ON LEFT OF Y
        COMA                    ;COLISION
        RTS
;*
BPYX0   LEAX    4+4+4+4,X               ;Y ON LEFT OF X
        LEAY    4+4+4+4,Y               ;NEXT POINTERS
        LDD     2,X
        BLT     BPEN
        SUBD    ,Y
        BVS     BPEN
        SUBD    COLDX
        BLT     BPYX4           ;BR=NO COLISION
        COMA                    ;COLISION, Y ON LEFT OF X
        RTS
;*
BPYX4   LDD     4+2,X
        BLT     BPEN
        SUBD    4+0,Y
        BVS     BPEN
        SUBD    COLDX
        BLT     BPYX8           ;BR=NO COLISION
        LEAX    4,X
        LEAY    4,Y
        COMA                    ;COLISION, Y ON LEFT OF X
        RTS
;*
BPYX8   LDD     4+4+2,X
        BLT     BPEN
        SUBD    4+4+0,Y
        BVS     BPEN
        SUBD    COLDX
        BLT     BPYXC           ;BR=NO COLISION
        LEAX    4+4,X
        LEAY    4+4,Y
        COMA                    ;COLISION, Y ON LEFT OF X
        RTS
;*
BPYXC   LDD     4+4+4+2,X
        BLT     BPEN
        SUBD    4+4+4+0,Y
        BVS     BPEN
        SUBD    COLDX
        BLT     BPYX0           ;BR=NO COLISION
        LEAX    4+4+4,X
        LEAY    4+4+4,Y
        COMA                    ;COLISION, Y ON LEFT OF X
        RTS
;*
BPEN    CLRA                    ;NO COLISION
        RTS
;*
BPXY0   LEAX    4+4+4+4,X               ;X ON LEFT OF Y
        LEAY    4+4+4+4,Y               ;NEXT POINTERS
        LDD     0,X
        BLT     BPEN
        SUBD    2,Y
        BVS     BPEN
        SUBD    COLDX
        BGT     BPXY4           ;BR=NO COLISION
        COMA
        RTS
;*
BPXY4   LDD     4+0,X
        BLT     BPEN
        SUBD    4+2,Y
        BVS     BPEN
        SUBD    COLDX
        BGT     BPXY8           ;BR=NO COLISION
        LEAX    4,X
        LEAY    4,Y
        COMA
        RTS
;*
BPXY8   LDD     4+4+0,X
        BLT     BPEN
        SUBD    4+4+2,Y
        BVS     BPEN
        SUBD    COLDX
        BGT     BPXYC           ;BR=NO COLISION
        LEAX    4+4,X
        LEAY    4+4,Y
        COMA                    ;COLISION, X ON LEFT OF Y
        RTS
;*
BPXYC   LDD     4+4+4+0,X
        BLT     BPEN
        SUBD    4+4+4+2,Y
        BVS     BPEN
        SUBD    COLDX
        BGT     BPXY0           ;BR=NO COLISION
        LEAX    4+4+4,X
        LEAY    4+4+4,Y
        COMA                    ;COLISION, X ON LEFT OF Y
        RTS
;*
;*
;*      BIRDS X VELOCITY TABLE
;*
        FDB     -$0200
        FDB     -$0100
        FDB     -$0080
        FDB     -$0040
FLYX    FDB     $0000
        FDB     $0040
        FDB     $0080
        FDB     $0100
        FDB     $0200
;*
STATE   MACRO   WAIT,CALL,MINUS,ZERO,PLUS,FLYVEL
        FCB     WAIT                                                            ;;Fixme was: FCB  WAIT,!HCALL,!WCALL,MINUS-*,ZERO-*,PLUS-*,FLYVEL
        FDB     CALL
        FCB     (MINUS-*)+3,(ZERO-*)+3,(PLUS-*)+3,FLYVEL                        ;;The label for the macro should technically start on this line
        ENDM                                                                    ;; so to get the correct values we compensate by adding 3
PLYAR   STATE   8,REVR,PLYBR,PLYBR,PLYBR,0
PLYBR   STATE   0,STANDR,PLYAR,PLYBR,PLYCR,0
PLYCR   STATE   8,RUNR,PLYGR,PLYCR,PLYDR,2
PLYDR   STATE   4,RUNR,PLYCR,PLYDR,PLYER,4
PLYER   STATE   2,RUNR,PLYHR,PLYER,PLYFR,6
PLYFR   STATE   1,RUNR,PLYIR,PLYFR,PLYFR,8
PLYGR   STATE   2,RUNSR,PLYBR,PLYBR,PLYCR,2
PLYHR   STATE   2,SKIDR,PLYKR,PLYKR,PLYDR,4
PLYIR   STATE   2,SKIDR,PLYJR,PLYJR,PLYER,6
PLYJR   STATE   2,SKIDR,PLYKR,PLYKR,PLYDR,4
PLYKR   STATE   2,SKIDR,PLYLR,PLYLR,PLYDR,4
PLYLR   STATE   4,SKIDR,PLYMR,PLYMR,PLYCR,2
PLYMR   STATE   4,SKIDR,PLYBR,PLYBR,PLYCR,2
;*
;*      LEFT RIGHT TYPES OF MOVEMENTS
;*
REVR    COM     PFACE,U         ;REVERSE DIRECTION
;*
STANDR  LDD     #STAND*256+0            ;GET STANDING FRAME & DELTA POSITION
        CLR     PFRAME,U
        RTS
;*
ORRUN   FCB     RUN1,0          ;INITIAL FRAME FROM STANDSTILL TO FRAME 1
        FCB     RUN4,3          ;PIXEL JUMP FROM FRAME 3 TO 4 (PFRAME 2 TO 1)
        FCB     RUN3,2          ;PIXEL JUMP FROM FRAME 2 TO 3 (PFRAME 3 TO 2)
        FCB     RUN2,1          ;PIXEL JUMP FROM FRAME 1 TO 2 (PFRAME 4 TO 3)
        FCB     RUN1,2          ;PIXEL JUMP FROM FRAME 4 TO 1 (PFRAME 1 TO 4)
;*
RUNR    LDB     PFRAME,U        ;NEXT FRAME
        BLE     RUNRST          ; BR=STARTING TO RUN
        DECB
        BGT     RUNFRM          ;BR=CORRECT FRAME NBR
        LDB     #4              ;START FRAME 4 THEN 3,2,1
RUNFRM  STB     PFRAME,U
        CMPB    #1              ;RUNNING THUMP FRAME?
        BNE     .1S             ; BR=NO
        LDX     PDECSN,U
        INC     PFEET,U         ;NEXT FOOT SOUND
        LDA     PFEET,U
        RORA
        BCC     .3S
        LDX     DSNRU1,X        ;FIRST FOOT RUNNING SOUND
        BRA     .2S
;*
.3S     LDX     DSNRU2,X        ;SECOND FOOT RUNNING SOUND
.2S     JSR     VSND
        LDB     PFRAME,U
.1S     ASLB                    ;X2
        LDX     #ORRUN          ;GET RUNNING INFORMATION.
        ABX
        LDD     ,X              ;GET DELTA X DIRECTION & FRAME OFFSET
        RTS
;*
RUNRST  LDB     #4              ;CURRENT FRAME
        STB     PFRAME,U
        LDD     ORRUN           ;STARTING RUNNING ANIMATION FRAME & FRAME OFFSET
        RTS
;*
        FCB     0               ;STOP RUNNING OFFSET FROM A SKID
STPRUN  FCB     0               ;STOP RUNNING OFFSET FROM STANDING POSITION
        FCB     2               ;STOP RUNNING OFFSET FROM FRAME 4
        FCB     4               ;STOP RUNNING OFFSET FROM FRAME 3
        FCB     1               ;STOP RUNNING OFFSET FROM FRAME 2
        FCB     1               ;STOP RUNNING OFFSET FROM FRAME 1
;*
RUNSR   LDX     #STPRUN         ;STOP RUNNING DELTA
        LDB     PFRAME,U
        LDB     B,X             ;GET CORRECT DELTA X FOR SKID
        LDA     #STAND
        CLR     PFRAME,U
        RTS
;*
SKIDR   LDA     PFRAME,U
        BMI     .1S             ;BR=ALREADY SKIDDING
        LDX     PDECSN,U
        LDX     DSNSK,X         ;GIVE SKIDDING SOUND
        JSR     VSND
.1S     LDA     #-1
        STA     PFRAME,U        ;-1 FRAME NBR
        LDD     #SKID*256+2     ;GET CORRECT DELTA X & PICTURE FOR SKID
        RTS
;*
;*      PLAYER 1 -READ JOYSTICK
;*
P1JOY   LDA     WCPIAB          ;SELECT HALF OF MUX
        ORA     #$08
        BRA     P2SAM           ;SAME AS PLAYER 2 JOYSTICK
;*
;*      PLAYER 2-READ JOYSTICK
;*
P2JOY   LDA     WCPIAB
        ANDA    #$F7
P2SAM   STA     WCPIAB
        LDA     WPIAA           ;READ JOYSTICK
        CLRB                    ;ASSUME JUMP BUTTON NOT PRESSED
        BITA    #$04            ;IS JUMP BUTTON PRESSED?
        BEQ     P2NJMP          ; BR=NO
        INCB                    ;INDICATE JUMP PRESSED
P2NJMP  ANDA    #$03            ;CONVERT JOYSTICK TO + (RIGHT), 0, - (LEFT)
        ASRA                    ; VIA MATHAMATICAL EXPRESSION
        SBCA    #0
        STD     CURJOY          ;STORE AS CURRENT JOYSTICK
        RTS
;*
;*      ADD BUMP,U OFFSET & WRAP AROUND IN THE X DIRECTION
;*       INPUT REG.B = NEW DELTA X POSITION
;*
WRAPX   LDA     PBUMPX,U        ;ALSO ADD IN BUMP REGISTER
        BEQ     WRPWRD          ;NO BUMPING!
        BLT     WRPBLF          ; BR=BUMPING LEFT
        CMPA    #3
        BLE     WRPBRM          ;BR=BUMP REMAINING TIME
        ADDB    #3
        SUBA    #3
        STA     PBUMPX,U
        BRA     WRPWRD
;*
WRPBLF  CMPA    #-3
        BGE     WRPBRM          ;BR=BUMP REMAINING TIME
        ADDB    #-3
        SUBA    #-3
        STA     PBUMPX,U
        BRA     WRPWRD
;*
WRPBRM  ADDB    PBUMPX,U
        CLR     PBUMPX,U                ;AND RESET BUMP REGISTER
;*
WRPWRD  SEX                     ;NEW DELTA DISTANCE
        ADDD    PPOSX,U         ;CHECK IF .EQ. OR BETWEEN -11 TO 296
        CMPD    #ERIGHT
        BLE     WRXMAX
        ADDD    #-(ERIGHT-ELEFT+1)
WRXMAX  CMPD    #ELEFT
        BGE     WRXMIN
        ADDD    #(ERIGHT-ELEFT+1)
WRXMIN  STD     PPOSX,U
        RTS
;*
;*      DYNAMIC CHANGES IN INTELLIGENCE
;*
DYTBL
        DYWORD  $000B,$0006,$0004,-01,$0001,$FA86,$4433,$21     ;LAVTIM
        DYWORD  $0004,$0006,$0008,+02,$002D,$FA86,$4333,$21     ;LAVGRA
        DYWORD  $0010,$0008,$0004,-01,$0001,$FA86,$4433,$21     ;LAVLAV
        DYWORD  $0060,$0040,$0020,-02,$0010,$FFCA,$8643,$21     ;EGGWT
        DYWORD  $5A+4,$34+4,$1E+4,-04,$0008,$CA53,$A525,$21     ;EGGWT2
        DYWORD  $000E,$000E,$000C,-01,$000B,$FFFF,$FFF8,$42     ;BODNRG
        DYWORD  $F000,$F200,$F800,$20,$FF00,$4211,$4214,$21     ;BODNDI
        DYWORD  $0080,$0100,$0200,$20,$0300,$4211,$F813,$21     ;BODNVY
        DYWORD  $FFF1,$FFF2,$FFF4,+01,$FFF5,$FFFF,$FFF8,$42     ;BOUPRG
        DYWORD  $1000,$0E00,$0800,$E0,$0100,$4211,$4214,$21     ;BOUPDI
        DYWORD  $0003,$0002,$0001,-01,$0001,$FA86,$4433,$21     ;BOUPWD
        DYWORD  $000A,$0008,$0006,-01,$0002,$FA86,$4433,$21     ;BOUPWU
        DYWORD  $0020,$0015,$0010,-01,$0002,$7766,$4433,$21     ;BOLETM
        DYWORD  $000F,$000E,$000C,-01,$000B,$FFFF,$FFFA,$22     ;HUDNRG
        DYWORD  $F000,$F200,$F800,$20,$FF00,$FFFF,$FF84,$22     ;HUDNDI
        DYWORD  $0100,$0200,$0300,$20,$0380,$FFFF,$FF84,$84     ;HUDNVY
        DYWORD  $FFF1,$FFF2,$FFF4,+01,$FFF5,$FFFF,$FFF8,$22     ;HUUPRG
        DYWORD  $1000,$0E00,$0800,$E0,$0100,$FFF8,$FF84,$22     ;HUUPDI
        DYWORD  $0003,$0002,$0001,-01,$0001,$FFF8,$FF83,$22     ;HUUPWD
        DYWORD  $000A,$0008,$0006,-01,$0002,$FFF8,$FF83,$22     ;HUUPWU
        DYWORD  $FF80,$FF00,$FE00,$20,$FE00,$FFFF,$FF84,$84     ;HUUPVY
        DYWORD  $0020,$0015,$0010,-01,$0002,$FFF8,$8433,$22     ;HULETM
        DYWORD  $0014,$0010,$000E,-01,$000C,$FFFF,$FFFA,$82     ;SHDNRG
        DYWORD  $FFEC,$FFE0,$FFF2,+01,$FFF4,$FFFF,$FFFA,$82     ;SHUPRG
        DYWORD  $FFF0,$FE00,$FD00,$20,$FC00,$FFFF,$FFFA,$84     ;SHUPVY
        DYWORD  $0014,$000A,$0008,-01,$0002,$FFFF,$FFFA,$82     ;SHUPTM
        DYWORD  $0020,$0015,$0010,-01,$0002,$FFFF,$FFFA,$82     ;SHLETM
        DYWORD  $000A,$0008,$0006,-01,$0002,$FFFF,$FFFA,$61     ;SHCLTM
DYEND   EQU     *
;*
ENDAD2  EQU     *       ;CURRENT END ADDRESS
        IF *-$DFFF >= 0                                                         ;;Fixme was: IFGE  *-$DFFF
         FCB    $1111   ;ERROR, $D800-$DFFF MODULE IS TOO LONG
        ENDIF
        ORG     $E6A8
;*
;*      INCREMENT SCORE BY THOUSANDS AND HUNDREDS
;*       INPUT REG.X - DECISION BLOCK
;*             REG.A - THOUSANDS & HUNDREDS BCD DIGIT
;*      DESTROIES REG.Y & REG.D
;*      SAVES REG.X
;*
SCRHUN  LDY     DSCORE,X        ;GET SCORE AREA
        BEQ     SCRRTS
        ADDA    2,Y
        BRA     SCRCOM
;*
;*      INCREMENT SCORE BY HUNDREDS AND TENS
;*       INPUT REG.X - DECISION BLOCK
;*             REG.A - TENS & HUNDREDS BCD DIGIT (BACKWARDS)
;*      DESTROIES REG.Y & REG.D
;*      SAVES REG.X
;*
SCRTEN  LDY     DSCORE,X        ;GET SCORE AREA
        BEQ     SCRRTS
        TFR     A,B
        ANDA    #$F0            ;SCORE TENS
        ANDB    #$0F            ;       & HUNDREDS
        ADDA    3,Y
        DAA
        STA     3,Y
        TFR     B,A
        ADCA    2,Y
SCRCOM  DAA
        STA     2,Y
        INC     4,Y             ;SCORE OCCURED
        LDA     1,Y
        ADCA    #0
        DAA
        STA     1,Y
        LDA     ,Y
        ADCA    #0
        DAA
        BCC     .1S
        ADDA    #$10            ;PEGG TEN MILLIONS FOR ZERO SURPRESSION DETECT
.1S     STA     ,Y
        LDD     LEVPAS          ;IF LEVEL PASS =0 THEN NO EXTRA MEN
        BEQ     SCRRTS
SCRLEV  LDD     1,Y             ;GET 100'S OF THOUSANDS TO 100'S.
        ADDA    7,Y             ; ADD OFFSET FOR NO OVERFLOW
        DAA
        CMPD    8,Y             ;PAST LEVEL FOR EXTRA MAN?
        BLO     SCRRTS          ; BR=NO
        LDA     9,Y             ;FIGURE OUT NEXT LEVEL
        ADDA    LEVPAS+1
        DAA
        STA     9,Y
        LDA     8,Y
        ADCA    LEVPAS
        DAA
        STA     8,Y
        CMPA    #$30            ;THE MAGIC NUMBER IS 3000XX BEFORE NEW OFFSET
        BLO     SCRPLY          ;AWARD THE EXTRA PLAYER
        ADDA    #$A0-$20        ;SUBTRACT  BCD 20
        DAA
        STA     8,Y
        LDA     7,Y             ;ALSO OFFSET THE SCORE TO REFLECT THE NEW LEVEL
        ADDA    #$A0-$20        ;SUBTRACT  BCD 20
        DAA
        STA     7,Y
SCRPLY  PSHS    X,Y             ;SAVE DECISION BLOCK
        JSR     INCLIV          ;AWARD THE PLAYER
        LDX     #SNREPL         ;MAKE REPLAY SOUND
        JSR     VSND
        LDB     #5              ;INCREMENT BOOKS NBR OF FREE MEN
        JSR     AUDIT1
        PULS    X,Y
        BRA     SCRLEV          ;RE-CHECK FOR LEVEL PASS (LOW LEVELS)
;*
SCRRTS  RTS
;*
;*      SCORE TABLE FOR PLAYER 1
;*
SCRPL1  FDB     SPLY1+4                 ;SCORE CHANGED FLAG
        FDB     $1A00+PL1*$11           ;SCORE COLOR
        FDB     SPLY1+0,$24D9,BCDLSN    ;1,000,000 DIGIT INFORMATION
        FDB     SPLY1+1,$27D9,BCDMSN    ;  100,000 DIGIT INFORMATION
        FDB     SPLY1+1,$2AD9,BCDLSN    ;   10,000 DIGIT INFORMATION
        FDB     SPLY1+2,$2DD9,BCDMSN    ;    1,000 DIGIT INFORMATION
        FDB     SPLY1+2,$30D9,BCDLSN    ;      100 DIGIT INFORMATION
        FDB     SPLY1+3,$33D9,BCDMSN    ;       10 DIGIT INFORMATION
        FCB     0,0,-1                  ;END OF SCORE INFORMATION
SCRINT  FDB     SPLY1+3,$36D9,BCDLSN    ;        1 DIGIT INFORMATION
        FCB     0,0,-1                  ;END OF SCORE INFORMATION
;*
;*      SCORE TABLE FOR PLAYER 2
;*
SCRPL2  FDB     SPLY2+4                 ;SCORE CHANGED FLAG
        FDB     $1A00+PL2*$11           ;SCORE COLOR
        FDB     SPLY2+0,$4BD9,BCDLSN    ;1,000,000 DIGIT INFORMATION
        FDB     SPLY2+1,$4ED9,BCDMSN    ;  100,000 DIGIT INFORMATION
        FDB     SPLY2+1,$51D9,BCDLSN    ;   10,000 DIGIT INFORMATION
        FDB     SPLY2+2,$54D9,BCDMSN    ;    1,000 DIGIT INFORMATION
        FDB     SPLY2+2,$57D9,BCDLSN    ;      100 DIGIT INFORMATION
        FDB     SPLY2+3,$5AD9,BCDMSN    ;       10 DIGIT INFORMATION
        FCB     0,0,-1                  ;END OF SCORE INFORMATION
        FDB     SPLY2+3,$5DD9,BCDLSN    ;        1 DIGIT INFORMATION
        FCB     0,0,-1                  ;END OF SCORE INFORMATION
;*
;*      BCD DISPLAY OF SCORE (PLAYER 1 & 2)
;*       INPUT: PRAM,U - ADDRESS OF SCORE TABLE
;*
SCODSP  LDX     PRAM,U          ;PUT UP SCORE ZERO
        LEAX    SCRINT-SCRPL1,X
;*
.100S   STX     PRAM+2,U        ;REMEMBER DIGIT TO PUT UP
        LDY     PRAM,U          ;GET DMA CONTROL & COLOR NIBBLE
        LDU     2,Y
        LDY     2,X             ;GET DESTINATION ADDRESS
        BMI     .1S             ; BR=END OF LIST
        LDB     [,X]            ;GET SCORE BYTE
        JSR     [4,X]           ;CALL OUTPUT ROUTINE & WAIT
        LDX     PRAM+2,U        ;NEXT DIGIT
        LEAX    6,X
        BRA     .100S
;*
.1S     PCNAP   2
        LDX     PRAM,U          ;SCORE CHANGED?
        LDB     [,X]
        BEQ     .1S             ; BR=NO
        CLR     [,X]            ;RESET CHANGED SCORE FLAG
        LEAX    4,X
        LDB     [,X]            ;LEADING ZERO BLANKING
        BNE     .100S           ; BR=MILLIONS TO SCORE
        LEAX    6,X
        LDB     [,X]            ;100,000 & 10,000 CHECK
        BEQ     .2S             ; BR=CHECK HUNDREDS DIGIT
        ANDB    #$F0
        BNE     .100S           ; BR=100,000
        LEAX    6,X
        BRA     .100S           ;HERE IF 10,000
;*
.2S     LEAX    6+6,X
        LDB     [,X]            ;1,000 & 100 CHECK
        BEQ     .3S             ;BR=NO DIGITS HERE
        ANDB    #$F0
        BNE     .100S
        LEAX    6,X             ;100'S TO DISPLAY
        BRA     .100S
;*
.3S     LEAX    6+6,X
        BRA     .100S           ;10'S TO DISPLAY
;*
;*      DISPLAY BCD SCORE, (NAPS BETWEEN DIGITS)
;*        REG.B HAS NIBBLE,
;*        REG.Y HAS DESTINATION ADDRESS
;*        REG.U HAS DMA CONTROL & CONSTANT
;*
BCDMSN  RORB                    ;HIGH BYTE SHIFT
        RORB
        RORB
        RORB
BCDLSN  ANDB    #$0F            ;LOW BYTE SHIFT
        LDA     #3*7+2          ;FONT SIZE IS 6X7 PIXELS PLUS 2BYTE SIZE
        MUL
        PSHS    CC
        ORCC    #$F0            ;NO INTERUPTS FOR DMA (TIME FOR INT TO SETTLE)
        ADDD    [FONT5]
        ADDD    #2              ;SKIP THE SIZE, IT IS 3X7
        STD     SDMA
        LDD     #$0307!DMAFIX                                                   ;;Fixme was: LDD  #$0307!XDMAFIX
        STD     WDMA
        STY     DDMA
        LDD     #$12*256+(DKB*$11)      ;ERASE OLD DIGIT
        STB     KDMA
        STA     DMA
        TFR     U,D
        STB     KDMA            ;WRITE NEW DIGIT
        STA     DMA
        PULS    CC              ;NAP BEFORE RETURNING TO CALLER
        LDA     #1
        JMP     VNAPTPC         ;NAP OF 1, BEFORE NEXT DIGIT(S)
;*
;********       NLIST                   DON'T BOTHER WITH DATA LISTS
;*
;*      LITTLE PLAYERS SITTING ON BOXES, READY TO PLAY
;*
SCOPL1  EQU     *       ;PLAYER 1 IMAGES LEFT (SIZE $0307)
        FCB     $00,PL1*$10+WHI,$00
        FCB     $00,PL1*$11,$00
        FCB     $00,PL1*$10,$00
        FCB     PL1,PL1*$11,$00
        FCB     PL1,PL1*$11,$00
        FCB     $00,PL1*$11,PL1*$10
        FCB     WHI,WHI*$10,PL1*$11
;*
SCOPL2  EQU     *       ;PLAYER 2 IMAGES LEFT (SIZE $0307)
        FCB     $00,YELLOW*$10+PL2,$00
        FCB     $00,PL2*$11,$00
        FCB     $00,PL2,$00
        FCB     $00,PL2*$11,PL2*$10
        FCB     $00,PL2*$11,PL2*$10
        FCB     PL2,PL2*$11,$00
        FCB     PL2*$11,WHI,WHI*$10
;*
;*      BACKGROUND BOX COLISION TABLE, Y DIRECTION
;*       BIT 0 = CLIF1L
;*       BIT 1 = CLIF1R
;*       BIT 2 = CLIF2
;*       BIT 3 = CLIF3U
;*       BIT 4 = CLIF3L
;*       BIT 5 = CLIF3R
;*       BIT 6 = CLIF4
;*       BIT 7 = CLIF5
;*
BCKYTB  FCB     %00000000,%00000000,%00000000,%00000000 ;CRT LINE $00
        FCB     %00000000,%00000000,%00000000,%00000000
        FCB     %00000000,%00000000,%00000000,%00000000
        FCB     %00000000,%00000000,%00000000,%00000000
        FCB     %00000000,%00000000,%00000000,%00000000 ;CRT LINE $10
        FCB     %00000000,%00000000,%00000000,%00000000
        FCB     %00000000,%00000000,%00000000,%00000000
        FCB     %00000000,%00000000,%00000000,%00000000
        FCB     %00000000,%00000000,%00000000,%00000000 ;CRT LINE $20
        FCB     %00000000,%00000000,%00000000,%00000000
        FCB     %00000000,%00000000,%00000000,%00000000
        FCB     %00000000,%00000000,%00000000,%00000000
        FCB     %00000000,%00000000,%00000000,%00000000 ;CRT LINE $30
        FCB     %00000000,%00000000,%00000000,%00000000
        FCB     %00000000,%00000000,%00000000,%00000000
        FCB     %00000000,%00000000,%00000000,%00000000
        FCB     %00000000,%00000000,%00000000,%00000000 ;CRT LINE $40
        FCB     %00000000,%00000000,%00000000,%00000000
        FCB     %00000000,%00000000,%00000000,%00000011
        FCB     %00000011,%00000011,%00000011,%00000011
        FCB     %00000011,%00000011,%00000011,%00000011 ;CRT LINE $50
        FCB     %00000011,%00000011,%00000011,%00000111
        FCB     %00000111,%00000111,%00000111,%00000111
        FCB     %00000111,%00000111,%00000111,%00000100
        FCB     %00000100,%00000100,%00000100,%00000100 ;CRT LINE $60
        FCB     %00000100,%00000100,%00000100,%00000100
        FCB     %00000100,%00000100,%00000100,%00000100
        FCB     %00000100,%00000000,%00000000,%00000000
        FCB     %00000000,%00000000,%00000000,%00000000 ;CRT LINE $70
        FCB     %00000000,%00000000,%00000000,%00000000
        FCB     %00000000,%00000000,%00000000,%00000000
        FCB     %00000000,%00000000,%00000000,%00000000
        FCB     %00000000,%00000000,%00000000,%00000000 ;CRT LINE $80
        FCB     %00000000,%00000000,%00000000,%00001000
        FCB     %00001000,%00001000,%00001000,%00001000
        FCB     %00001000,%00001000,%00001000,%00001000
        FCB     %00111000,%00111000,%00111000,%00111000 ;CRT LINE $90
        FCB     %00111000,%00111000,%00111000,%00111000
        FCB     %00111000,%00111000,%00111000,%00111000
        FCB     %00111000,%00111000,%00111000,%00110000
        FCB     %00110000,%00110000,%00110000,%00110000 ;CRT LINE $A0
        FCB     %00010000,%00000000,%00000000,%00000000
        FCB     %00000000,%01000000,%01000000,%01000000
        FCB     %01000000,%01000000,%01000000,%01000000
        FCB     %01000000,%01000000,%01000000,%01000000 ;CRT LINE $B0
        FCB     %01000000,%01000000,%01000000,%01000000
        FCB     %01000000,%01000000,%01000000,%01000000
        FCB     %01000000,%01000000,%00000000,%00000000
        FCB     %00000000,%00000000,%00000000,%00000000 ;CRT LINE $C0
        FCB     %00000000,%00000000,%00000000,%00000000
        FCB     %00000000,%00000000,%00000000,%00000000
        FCB     %00000000,%00000000,%00000000,%00000000
        FCB     %00000000,%00000000,%00000000,%00000000 ;CRT LINE $D0
        FCB     %00000000,%00000000,%00000000,%00000000
        FCB     %00000000,%10000000,%10000000,%10000000
        FCB     %10000000,%10000000,%10000000,%10000000
        FCB     %10000000,%10000000,%10000000,%10000000 ;CRT LINE $E0
        FCB     %10000000,%10000000,%10000000,%10000000
        FCB     %10000000,%10000000,%10000000,%10000000
        FCB     %10000000,%10000000,%10000000,%10000000
        FCB     %10000000,%10000000,%10000000,%10000000 ;CRT LINE $F0
        FCB     %10000000,%10000000,%10000000,%10000000
        FCB     %10000000,%10000000,%10000000,%10000000
        FCB     %10000000,%10000000,%10000000,%10000000
;*
;*      TABLE FOR X DIRECTION, RANGE -$10 TO $128
;*
BCKXS1  EQU     *
        FCB     %00010001,%00010001,%00010001,%00010001 ;CRT PIXEL -$20
        FCB     %00010001,%00010001,%00010001,%00010001
        FCB     %00010001,%00010001,%00010001,%00010001
        FCB     %00010001,%00010001,%00010001,%00010001
        FCB     %00010001,%00010001,%00010001,%00010001 ;CRT PIXEL -$10
        FCB     %00010001,%00010001,%00010001,%00010001
        FCB     %00010001,%00010001,%00010001,%00010001
        FCB     %00010001,%00010001,%00010001,%00010001
;*
;* LABEL BCKXTB OR POSITION ZERO IN X DIRECTION
;*
        FCB     %00010001,%00010001,%00010001,%00010001 ;CRT PIXEL $00
        FCB     %00010001,%00010001,%00010001,%00010001
        FCB     %00010001,%00010001,%00010001,%00010001
        FCB     %00010001,%00010001,%00010001,%00010001
        FCB     %00010001,%00010001,%00010001,%00010001 ;CRT PIXEL $10
        FCB     %00010001,%00010001,%00010001,%00010001
        FCB     %00010001,%00010001,%00010001,%00010001
        FCB     %00010001,%00010001,%00010001,%00010001
        FCB     %00010001,%00010001,%00010001,%00010001 ;CRT PIXEL $20
        FCB     %00010000,%10010000,%10010000,%10010000
        FCB     %10010000,%10010000,%10010000,%10010000
        FCB     %10010000,%10010000,%10010000,%10010000
        FCB     %10010000,%10010000,%10010000,%10010000 ;CRT PIXEL $30
        FCB     %10010000,%10010000,%10010000,%10010000
        FCB     %10010000,%10010000,%10010000,%10010000
        FCB     %10010000,%10010000,%10010000,%10010000
        FCB     %10010000,%10010000,%10000000,%10000000 ;CRT PIXEL $40
        FCB     %10000000,%10000100,%10000100,%10000100
        FCB     %10000100,%10000100,%10000100,%10000100
        FCB     %10000100,%10000100,%10000100,%10000100
        FCB     %10000100,%10000100,%10000100,%10000100 ;CRT PIXEL $50
        FCB     %10000100,%10000100,%10000100,%10000100
        FCB     %10000100,%11000100,%11000100,%11000100
        FCB     %11000100,%11000100,%11000100,%11000100
        FCB     %11000100,%11000100,%11000100,%11000100 ;CRT PIXEL $60
        FCB     %11000100,%11000100,%11000100,%11000100
        FCB     %11000100,%11000100,%11000100,%11000100
        FCB     %11000100,%11000100,%11000100,%11000100
        FCB     %11000100,%11000100,%11000100,%11000100 ;CRT PIXEL $70
        FCB     %11000100,%11000100,%11000100,%11000100
        FCB     %11000100,%11000100,%11000100,%11000100
        FCB     %11000100,%11000100,%11000100,%11000100
        FCB     %11000100,%11000100,%11000100,%11000100 ;CRT PIXEL $80
        FCB     %11000100,%11000100,%11000100,%11000100
        FCB     %11000100,%11000100,%11000100,%11000100
        FCB     %11000100,%11000100,%11000100,%11000100
        FCB     %11000100,%11000100,%11000100,%11000100 ;CRT PIXEL $90
        FCB     %11000100,%11000100,%11000100,%11000100
        FCB     %11000100,%11000100,%11000100,%11000100
        FCB     %11000100,%11000100,%11000100,%11000100
        FCB     %11000100,%11000100,%11000100,%11000100 ;CRT PIXEL $A0
        FCB     %11000100,%11000100,%11000100,%11000100
        FCB     %11000100,%11000100,%10000100,%10000100
        FCB     %10000100,%10000100,%10000000,%10000000
        FCB     %10000000,%10000000,%10000000,%10000000 ;CRT PIXEL $B0
        FCB     %10000000,%10000000,%10000000,%10000000
        FCB     %10000000,%10001000,%10001000,%10001000
        FCB     %10001000,%10001000,%10001000,%10001000
        FCB     %10001000,%10001000,%10001000,%10001000 ;CRT PIXEL $C0
        FCB     %10001000,%10001000,%10001000,%10001000
        FCB     %10001000,%10001000,%10001000,%10001000
        FCB     %10001000,%10001000,%10001000,%10001000
        FCB     %10001000,%10001000,%10001000,%10001000 ;CRT PIXEL $D0
        FCB     %10001000,%10001000,%10001000,%10001000
        FCB     %10001000,%10001000,%10001000,%10001000
        FCB     %10001000,%10001000,%10001000,%10001000
        FCB     %10001000,%10001000,%10001000,%10001000 ;CRT PIXEL $E0
        FCB     %10001000,%10001000,%10001000,%10001000
        FCB     %10001000,%10001000,%10001000,%10001010
        FCB     %10001010,%10001010,%10101010,%10101010
        FCB     %00101010,%00101010,%00101010,%00101010 ;CRT PIXEL $F0
        FCB     %00101010,%00101010,%00101010,%00101010
        FCB     %00101010,%00101010,%00101010,%00101010
        FCB     %00101010,%00101010,%00101010,%00101010
        FCB     %00101010,%00101010,%00101010,%00101010 ;CRT PIXEL $100
        FCB     %00100010,%00100010,%00100010,%00100010
        FCB     %00100010,%00100010,%00100010,%00100010
        FCB     %00100010,%00100010,%00100010,%00100010
        FCB     %00100010,%00100010,%00100010,%00100010 ;CRT PIXEL $110
        FCB     %00100010,%00100010,%00100010,%00100010
        FCB     %00100010,%00100010,%00100010,%00100010
        FCB     %00100010,%00100010,%00100010,%00100010
        FCB     %00100010,%00100010,%00100010,%00100010 ;CRT PIXEL $120
        FCB     %00100010,%00100010,%00100010,%00100010
        FCB     %00100010,%00100010,%00100010,%00100010
        FCB     %00100010,%00100010,%00100010,%00100010
        FCB     %00100010,%00100010,%00100010,%00100010 ;CRT PIXEL $130
        FCB     %00100010,%00100010,%00100010,%00100010
        FCB     %00100010,%00100010,%00100010,%00100010
        FCB     %00100010,%00100010,%00100010,%00100010
BCKXS2  EQU     *
;*
;*      BACKGROUND BOX LANDING TABLE, Y DIRECTION
;*       BIT 0 = CLIF1L & CLIF1R
;*       BIT 1 = CLIF2
;*       BIT 2 = CLIF3R (TOP)
;*       BIT 3 = CLIF3L & CLIF3R
;*       BIT 4 = CLIF4
;*       BIT 5 = CLIF5
;*       BIT 6 = LAVA TROLLS LEFT & RIGHT
;*
LNDYTB  FCB     %00000000,%00000000,%00000000,%00000000 ;CRT LINE $00
        FCB     %00000000,%00000000,%00000000,%00000000
        FCB     %00000000,%00000000,%00000000,%00000000
        FCB     %00000000,%00000000,%00000000,%00000000
        FCB     %00000000,%00000000,%00000000,%00000000 ;CRT LINE $10
        FCB     %00000000,%00000000,%00000000,%00000000
        FCB     %00000000,%00000000,%00000000,%00000000
        FCB     %00000000,%00000000,%00000000,%00000000
        FCB     %00000000,%00000000,%00000000,%00000000 ;CRT LINE $20
        FCB     %00000000,%00000000,%00000000,%00000000
        FCB     %00000000,%00000000,%00000000,%00000000
        FCB     %00000000,%00000000,%00000000,%00000000
        FCB     %00000000,%00000000,%00000000,%00000000 ;CRT LINE $30
        FCB     %00000000,%00000000,%00000000,%00000000
        FCB     %00000000,%00000000,%00000000,%00000000
        FCB     %00000000,%00000000,%00000000,%00000000
        FCB     %00000000,%00000000,%00000000,%00000000 ;CRT LINE $40
        FCB     %00000000,%00000001,%00000001,%00000001
        FCB     %00000001,%00000000,%00000000,%00000000
        FCB     %00000000,%00000000,%00000000,%00000000
        FCB     %00000000,%00000010,%00000010,%00000010 ;CRT LINE $50
        FCB     %00000010,%00000000,%00000000,%00000000
        FCB     %00000000,%00000000,%00000000,%00000000
        FCB     %00000000,%00000000,%00000000,%00000000
        FCB     %00000000,%00000000,%00000000,%00000000 ;CRT LINE $60
        FCB     %00000000,%00000000,%00000000,%00000000
        FCB     %00000000,%00000000,%00000000,%00000000
        FCB     %00000000,%00000000,%00000000,%00000000
        FCB     %00000000,%00000000,%00000000,%00000000 ;CRT LINE $70
        FCB     %00000000,%00000000,%00000000,%00000000
        FCB     %00000000,%00000000,%00000000,%00000000
        FCB     %00000000,%00000000,%00000000,%00000000
        FCB     %00000000,%00000100,%00000100,%00000100 ;CRT LINE $80
        FCB     %00000100,%00000000,%00000000,%00000000
        FCB     %00000000,%00000000,%00001000,%00001000
        FCB     %00001000,%00001000,%00000000,%00000000
        FCB     %00000000,%00000000,%00000000,%00000000 ;CRT LINE $90
        FCB     %00000000,%00000000,%00000000,%00000000
        FCB     %00000000,%00000000,%00000000,%00000000
        FCB     %00000000,%00000000,%00000000,%00000000
        FCB     %00000000,%00000000,%00000000,%00010000 ;CRT LINE $A0
        FCB     %00010000,%00010000,%00010000,%00000000
        FCB     %00000000,%00000000,%00000000,%00000000
        FCB     %00000000,%00000000,%00000000,%00000000
        FCB     %00000000,%00000000,%00000000,%00000000 ;CRT LINE $B0
        FCB     %00000000,%00000000,%00000000,%00000000
        FCB     %00000000,%00000000,%00000000,%00000000
        FCB     %00000000,%00000000,%00000000,%00000000
        FCB     %00000000,%00000000,%00000000,%00000000 ;CRT LINE $C0
        FCB     %00000000,%00000000,%00000000,%00000000
        FCB     %00000000,%00000000,%00000000,%10000000
        FCB     %10000000,%10000000,%10000000,%10000000
        FCB     %10000000,%10000000,%10000000,%10100000 ;CRT LINE $D0
        FCB     %10100000,%10100000,%10100000,%10100000
        FCB     %10100000,%10100000,%10100000,%10100000
        FCB     %10100000,%10100000,%10100000,%10100000
        FCB     %10100000,%10100000,%10100000,%10100000 ;CRT LINE $E0
        FCB     %10000000,%10000000,%10000000,%10000000
        FCB     %10000000,%10000000,%10000000,%10000000
        FCB     %10000000,%10000000,%10000000,%10000000
        FCB     %10000000,%10000000,%10000000,%10000000 ;CRT LINE $F0
        FCB     %10000000,%10000000,%10000000,%10000000
        FCB     %10000000,%10000000,%10000000,%10000000
        FCB     %10000000,%10000000,%10000000,%10000000
        FCB     $18     ;KZAPPER FUDGE
;*
;*      TABLE FOR X DIRECTION, RANGE -$10 TO $128
;*
LNDXS1  EQU     *
        FCB     %10001001,%10001001,%10001001,%10001001 ;CRT PIXEL -$20
        FCB     %10001001,%10001001,%10001001,%10001001
        FCB     %10001001,%10001001,%10001001,%10001001
        FCB     %10001001,%10001001,%10001001,%10001001
        FCB     %10001001,%10001001,%10001001,%10001001 ;CRT PIXEL -$10
        FCB     %10001001,%10001001,%10001001,%10001001
        FCB     %10001001,%10001001,%10001001,%10001001
        FCB     %10001001,%10001001,%10001001,%10001001
;*
;*LABEL LNDXTB OR THE ZERO POINT ON SCREEN
;*
LNDXS3  FCB     %10001001,%10001001,%10001001,%10001001 ;CRT PIXEL $00
        FCB     %10001001,%10001001,%10001001,%10001001
        FCB     %10001001,%10001001,%10001001,%10001001
        FCB     %10001001,%10001001,%10001001,%10001001
        FCB     %10001001,%10001001,%10001001,%10001001 ;CRT PIXEL $10
        FCB     %10001001,%10001001,%10001001,%10001001
        FCB     %10001001,%10001001,%10001001,%10001000
        FCB     %10001000,%10001000,%10001000,%10001000
        FCB     %10001000,%10001000,%10001000,%10001000 ;CRT PIXEL $20
        FCB     %10001000,%10001000,%10001000,%00001000
        FCB     %00001000,%00001000,%00001000,%00001000
        FCB     %00001000,%00101000,%00101000,%00101000
        FCB     %00101000,%00101000,%00101000,%00101000 ;CRT PIXEL $30
        FCB     %00101000,%00101000,%00101000,%00101000
        FCB     %00101000,%00100000,%00100000,%00100000
        FCB     %00100000,%00100000,%00100000,%00100000
        FCB     %00100000,%00100000,%00100000,%00100000 ;CRT PIXEL $40
        FCB     %00100000,%00100000,%00100000,%00100000
        FCB     %00100000,%00100000,%00100000,%00100000
        FCB     %00100000,%00100010,%00100010,%00100010
        FCB     %00100010,%00100010,%00100010,%00100010 ;CRT PIXEL $50
        FCB     %00100010,%00100010,%00100010,%00100010
        FCB     %00100010,%00100010,%00100010,%00100010
        FCB     %00100010,%00100010,%00100010,%00100010
        FCB     %00100010,%00110010,%00110010,%00110010 ;CRT PIXEL $60
        FCB     %00110010,%00110010,%00110010,%00110010
        FCB     %00110010,%00110010,%00110010,%00110010
        FCB     %00110010,%00110010,%00110010,%00110010
        FCB     %00110010,%00110010,%00110010,%00110010 ;CRT PIXEL $70
        FCB     %00110010,%00110010,%00110010,%00110010
        FCB     %00110010,%00110010,%00110010,%00110010
        FCB     %00110010,%00110010,%00110010,%00110010
        FCB     %00110010,%00110010,%00110010,%00110010 ;CRT PIXEL $80
        FCB     %00110010,%00110010,%00110010,%00110010
        FCB     %00110010,%00110010,%00110010,%00110010
        FCB     %00110010,%00110010,%00110010,%00110010
        FCB     %00110010,%00110010,%00110010,%00110010 ;CRT PIXEL $90
        FCB     %00110010,%00110010,%00110010,%00110010
        FCB     %00110010,%00110010,%00110010,%00110010
        FCB     %00110010,%00110010,%00110010,%00110010
        FCB     %00110010,%00100010,%00100010,%00100010 ;CRT PIXEL $A0
        FCB     %00100010,%00100010,%00100000,%00100000
        FCB     %00100000,%00100000,%00100000,%00100000
        FCB     %00100000,%00100000,%00100000,%00100000
        FCB     %00100000,%00100000,%00100000,%00100000 ;CRT PIXEL $B0
        FCB     %00100000,%00100000,%00100000,%00100000
        FCB     %00100000,%00100000,%00100000,%00100000
        FCB     %00100000,%00100000,%00100000,%00100000
        FCB     %00100000,%00100100,%00100100,%00100100 ;CRT PIXEL $C0
        FCB     %00100100,%00100100,%00100100,%00100100
        FCB     %00100100,%00100100,%00100100,%00100100
        FCB     %00100100,%00100100,%00100100,%00100100
        FCB     %00100100,%00100100,%00100100,%00100100 ;CRT PIXEL $D0
        FCB     %00100100,%00100100,%00100100,%00100100
        FCB     %00100100,%00100100,%00100100,%00100100
        FCB     %00100100,%00100100,%00100100,%00100100
        FCB     %00100100,%00100100,%00100100,%00100100 ;CRT PIXEL $E0
        FCB     %00100100,%00100100,%00100100,%00000100
        FCB     %00000100,%00000100,%00000100,%00000100
        FCB     %00000100,%00000100,%00000100,%10000100
        FCB     %10000100,%10001100,%10001100,%10001100 ;CRT PIXEL $F0
        FCB     %10001101,%10001101,%10001101,%10001101
        FCB     %10001101,%10001101,%10001101,%10001101
        FCB     %10001001,%10001001,%10001001,%10001001
        FCB     %10001001,%10001001,%10001001,%10001001 ;CRT PIXEL $100
        FCB     %10001001,%10001001,%10001001,%10001001
        FCB     %10001001,%10001001,%10001001,%10001001
        FCB     %10001001,%10001001,%10001001,%10001001
        FCB     %10001001,%10001001,%10001001,%10001001 ;CRT PIXEL $110
        FCB     %10001001,%10001001,%10001001,%10001001
        FCB     %10001001,%10001001,%10001001,%10001001
        FCB     %10001001,%10001001,%10001001,%10001001
        FCB     %10001001,%10001001,%10001001,%10001001 ;CRT PIXEL $120
        FCB     %10001001,%10001001,%10001001,%10001001
        FCB     %10001001,%10001001,%10001001,%10001001
        FCB     %10001001,%10001001,%10001001,%10001001
        FCB     %10001001,%10001001,%10001001,%10001001 ;CRT PIXEL $130
        FCB     %10001001,%10001001,%10001001,%10001001
        FCB     %10001001,%10001001,%10001001,%10001001
        FCB     %10001001,%10001001,%10001001,%10001001
LNDXS2  EQU     *
     IF DEBUG = 0                                                               ;;Fixme was: IFE DEBUG
KZAP    CLR     PRAM,U
        CLR     PRAM+1,U
        CLR     PRAM+2,U
.1S     PCNAP   1
        LDX     PRAM,U
        LDA     ,X++
        ADDA    PRAM+2,U
        STA     PRAM+2,U
        STX     PRAM,U
        BPL     .1S
        CMPA    KZAP1
        BEQ     KZAP
        JSR     RADDR
        BRA     KZAP
     ENDIF
;*
;*******************************************************************************
;*
;*      KEN LANTZ CLIFF DESTROIER, COMPACT DATA TABLE
;*       (RUN LENGTH [UPPER NIBBLE], THEN COLOR NIBBLE [LOWER NIBBLE])
;******************************************************************************
FIRSTI  FCB     $F0,$F0,$20,$01
        FCB     $80,$40+LIB,$40,$40+LIB,$E0,$01
        FCB     $F0+LIB,$F0+LIB,$20+LIB,$01
        FCB     $10,$F0+LIB,$60+LIB,$50+DKB,$40+LIB,$10,$01
        FCB     $20,$20+LIB,$50+DKB,$20+LIB,$50+MEB,$20+MEB,$20+LIB
        FCB      $20+DKB,$60+MEB,$20,$01
        FCB     $30,$50+MEB,$30+DKB,$20+LIB,$30+MEB,$30+DKB,$20+MEB
        FCB      $20+DKB,$40+MEB,$50,$01
        FCB     $40,$B0+MEB,$40+DKB,$90+MEB,$40,$01
        FCB     $80,$80+MEB,$30+DKB,$20+MEB,$B0,$01
        FCB     $D0,$20+MEB,$20+DKB,$40+MEB,$C0,$01
        FCB     $00
;*SECOND IMAGE
        FCB     $10,$01
        FCB     $F0,$F0,$20,$01
        FCB     $F0,$F0,$20,$01
        FCB     $70,$50+LIB,$30,$50+LIB,$E0,$01
        FCB     $10,$A0+MEB,$B0+LIB,$50+DKB,$40+MEB,$10,$01
        FCB     $20,$20+MEB,$50+DKB,$90+MEB,$20+LIB,$20+DKB,$60+MEB,$20,$01
        FCB     $30,$30+MEB,$50+DKB,$50+MEB,$30+DKB,$20+MEB,$20+DKB
        FCB      $40+MEB,$50,$01
        FCB     $40,$90+MEB,$80+DKB,$70+MEB,$40,$01
        FCB     $80,$60+MEB,$30,$20+DKB,$20+MEB,$B0,$01
        FCB     $D0,$10+MEB,$10+DKB,$20,$30+MEB,$C0,$01
        FCB     $00
;*THIRD IMAGE
        FCB     $10,$01
        FCB     $10,$01
        FCB     $10,$01
        FCB     $F0,$F0,$20,$01
        FCB     $F0,$F0,$20,$01
        FCB     $70,$50+MEB,$30,$50+MEB,$E0,$01
        FCB     $10,$A0+DKB,$B0+MEB,$50+DKB,$20+MEB,$10+DKB,$10+MEB,$10,$01
        FCB     $20,$20+MEB,$50+DKB,$20+MEB,$30+DKB,$60+MEB,$20+DKB
        FCB      $20+MEB,$40+MEB,$20,$01
        FCB     $30,$30+MEB,$70+DKB,$30+MEB,$30+DKB,$10+MEB,$10+MEB
        FCB      $30+DKB,$30+MEB,$50,$01
        FCB     $40,$10+MEB,$20+MEB,$30+MEB,$20+MEB,$10+MEB,$80+DKB
        FCB      $20+MEB,$30+DKB,$20+MEB,$40,$01
        FCB     $80,$10+MEB,$40+DKB,$10+MEB,$30,$20+DKB,$20+MEB,$B0,$01
        FCB     $F0,$F0,$20,$01
        FCB     $D0,$10+DKB,$10+DKB,$20,$30+DKB,$C0,$01
        FCB     $00
;*FOURTH IMAGE
        FCB     $10,$01
        FCB     $10,$01
        FCB     $10,$01
        FCB     $10,$01
        FCB     $10,$01
        FCB     $F0,$F0,$20,$01
        FCB     $F0,$F0,$20,$01
        FCB     $70,$50+DKB,$30,$50+DKB,$E0,$01
        FCB     $10,$A0+DKB,$40+DKB,$30+MEB,$90+DKB,$10+MEB,$20+DKB
        FCB      $10+DKB,$10+DKB,$10,$01
        FCB     $20,$20+MEB,$50+DKB,$20+MEB,$30+DKB,$20+MEB,$50+DKB
        FCB      $30+MEB,$20+MEB,$40,$01
        FCB     $30,$30+MEB,$70+DKB,$30+MEB,$30+DKB,$10+MEB,$10+MEB
        FCB      $30+DKB,$30+MEB,$50,$01
        FCB     $40,$10+DKB,$20+MEB,$30+DKB,$20+DKB,$10+MEB,$80+DKB
        FCB      $20+DKB,$50+DKB,$40,$01
        FCB     $80,$10+DKB,$40+DKB,$10+DKB,$50,$20+DKB,$B0,$01
        FCB     $A0,$10+DKB,$20,$10+DKB,$10+DKB,$10,$10+DKB,$20
        FCB      $10+DKB,$10+DKB,$C0,$01
        FCB     $B0,$10+DKB,$10,$10+DKB,$20,$20+DKB,$10,$C0,$01
        FCB     $00
;*FIFTH IMAGE
        FCB     $10,$01
        FCB     $10,$01
        FCB     $10,$01
        FCB     $10,$01
        FCB     $10,$01
        FCB     $10,$01
        FCB     $10,$01
        FCB     $F0,$F0,$20,$01
        FCB     $F0,$F0,$20,$01
        FCB     $F0,$F0,$20,$01
        FCB     $10,$A0+DKB,$10,$20+DKB,$10,$30+DKB,$90,$10+DKB,$20
        FCB      $10+DKB,$10+DKB,$10,$01
        FCB     $20,$20+DKB,$50+DKB,$20+DKB,$30+DKB,$20+DKB,$50,$30+DKB
        FCB      $20+DKB,$40,$01
        FCB     $30,$30+DKB,$10,$10+DKB,$20,$10+DKB,$20,$10+DKB,$30+DKB
        FCB      $30,$10+DKB,$10+DKB,$30,$30+DKB,$50,$01
        FCB     $40,$10+DKB,$20+DKB,$30+DKB,$20+DKB,$10+DKB,$20+DKB,$20
        FCB      $10+DKB,$10,$10+DKB,$20,$10+DKB,$50,$20+DKB,$40,$01
        FCB     $80,$10+DKB,$40,$10+DKB,$50,$20+DKB,$B0,$01
        FCB     $F0,$F0,$20,$01
        FCB     $A0,$10+DKB,$20,$10+DKB,$10,$10,$10+DKB,$20,$10,$10+DKB,$C0,$01
        FCB     $C0,$10+DKB,$10,$10+DKB,$20,$10+DKB,$20,$C0,$01
        FCB     $00
KZAP1   FCB     $E8             ;KZAPPER DATA
;       LIST
;*
AOFFL1  EQU     $45
AOFFL2  EQU     $81
AOFFL3  EQU     $D0
AOFFUD  EQU     $20
;*
;*      AUTO MATIC REMOVAL OF PLAYER
;*
AUTOFF  LDD     PPOSX,U         ;OFF SCREEN?
        CMPD    #ELEFT+3
        BLT     AUTSCR
        CMPD    #ERIGHT-3
        BGT     AUTSCR
AUT2    LDA     #AOFFL1         ;ASSUME NEAR TRACKING LINE 1
        LDB     PPOSY+1,U
        CMPB    #AOFFL1+AOFFUD
        BLO     AUTTRK          ; BR=TRACK ON LINE 1
        LDA     #AOFFL2         ;ASSUME NEAR TRACKING LINE 2
        CMPB    #AOFFL2+AOFFUD
        BLO     AUTTRK          ; BR=TRACK ON LINE 2
        LDA     #AOFFL3         ;ASSUME NEAR TRACKING LINE 3
AUTTRK  CLRB                    ;ASSUME ON TRACKING LINE
        SUBA    PPOSY+1,U       ;ABOVE OR BELOW LINE?
        BPL     AUTFLP          ;BR=AROUND THE LINE
        LDA     PVELY,U         ;ALREADY GOING UP?
        BMI     AUTFLP          ; BR=YES, SO WAIT TILL NEXT TIME
        LDD     #AUTOFP         ;GET OFF GROUND OR JUST FLAP
        STD     PJOY,U
        LDB     #1
AUTFLP  LDA     PFACE,U         ;MOVE IN DIRECTION OF FACING
        BMI     AUTLF2
        LDA     #1
        STD     CURJOY
        RTS
;*
AUTLF2  LDA     #-1
        STD     CURJOY
        RTS
;*
AUTSCR  JSR     CPLYR           ;ERASE PLAYER FOR THE LAST TIME
        PCNAP   60              ;WAIT A SECOND
        LDX     #150            ;TRY TO START PLAYER AGAIN
        STX     PPOSX,U
        LDX     PDECSN,U
        JMP     [DCRE,X]
;*
AUTOFP  LDD     #AUTOFF
        STD     PJOY,U
        CLRB
        BRA     AUTFLP
;*
;*
;*      SOUND TABLE
;*       PIRORITY,SOUND,LENGTH (IF M.S.BIT SET ON SOUND, SOUND,LENGTH)          ;;LOTs of Fixme edits here:
;*              SOUND !N$00 DOES NOT DISTURBE THE SOUND, BUT EXTENDS TIMER      ;; !N = ~
;*              SOUND !N$FF TURNS OFF (KILLS) THE SOUND                         ;; !. = &
;*              SOUND !N$xx (RANGE 01-3E) SENDS THE CORRESPONDING SOUND         ;; !+ = |
;*
SNCRED  FCB     200,~$0A&$7F,40         ;CREDIT CHANGE SOUND                    ;;Fixme was: FCB  200,!N$0A!.$7F,40
SNGS    FCB     200,~$1B&$7F,1          ;GAME START                             ;;Fixme was: FCB  200,!N$1B!.$7F,1
SNHI2   FCB     190,~$1C&$7F,6          ;HIGH SCORE TO DATE END SOUND           ;;Fixme was: FCB  190,!N$1C!.$7F,6
SNHIGH  FCB     190                     ;HIGH SCORE TO DATE                     ;;Fixme was: FCB  190
        FCB         ~$11|$80,60                                                 ;;Fixme was: FCB  !N$11!+$80,60
        FCB         ~$10|$80,20                                                 ;;Fixme was: FCB  !N$10!+$80,20
        FCB         ~$10|$80,30                                                 ;;Fixme was: FCB  !N$10!+$80,30
        FCB         ~$0F|$80,2*60                                               ;;Fixme was: FCB  !N$0F!+$80,2*60
        FCB         ~$10|$80,60                                                 ;;Fixme was: FCB  !N$10!+$80,60
        FCB         ~$10|$80,100                                                ;;Fixme was: FCB  !N$10!+$80,100
        FCB         ~$0F|$80,4*60                                               ;;Fixme was: FCB  !N$0F!+$80,4*60
        FCB         ~$1A|$80,20                                                 ;;Fixme was: FCB  !N$1A!+$80,20
        FCB         ~$1A|$80,100                                                ;;Fixme was: FCB  !N$1A!+$80,100
        FCB         ~$10|$80,60                                                 ;;Fixme was: FCB  !N$10!+$80,60
        FCB         ~$0F|$80,4*60                                               ;;Fixme was: FCB  !N$0F!+$80,4*60
        FCB         ~$1A|$80,30                                                 ;;Fixme was: FCB  !N$1A!+$80,30
        FCB         ~$18|$80,4*60                                               ;;Fixme was: FCB  !N$18!+$80,4*60
;*
        FCB         ~$10|$80,80                                                 ;;Fixme was: FCB      !N$10!+$80,80
        FCB         ~$10|$80,60                                                 ;;Fixme was: FCB      !N$10!+$80,60
        FCB         ~$10|$80,20                                                 ;;Fixme was: FCB      !N$10!+$80,20
        FCB         ~$0F|$80,4*60                                               ;;Fixme was: FCB      !N$0F!+$80,4*60
        FCB         ~$10|$80,20                                                 ;;Fixme was: FCB      !N$10!+$80,20
        FCB         ~$10|$80,60                                                 ;;Fixme was: FCB      !N$10!+$80,60
        FCB         ~$10|$80,80                                                 ;;Fixme was: FCB      !N$10!+$80,80
        FCB         ~$10|$80,60                                                 ;;Fixme was: FCB      !N$10!+$80,60
        FCB         ~$10|$80,20                                                 ;;Fixme was: FCB      !N$10!+$80,20
        FCB         ~$10|$80,60                                                 ;;Fixme was: FCB      !N$10!+$80,60
        FCB         ~$0F|$80,4*60                                               ;;Fixme was: FCB      !N$0F!+$80,4*60
        FCB         ~$10|$80,20                                                 ;;Fixme was: FCB      !N$10!+$80,20
        FCB         ~$10|$80,60                                                 ;;Fixme was: FCB      !N$10!+$80,60
        FCB         ~$10|$80,80                                                 ;;Fixme was: FCB      !N$10!+$80,80
        FCB         ~$10|$80,60                                                 ;;Fixme was: FCB      !N$10!+$80,60
        FCB         ~$10|$80,20                                                 ;;Fixme was: FCB      !N$10!+$80,20
        FCB         ~$10|$80,60                                                 ;;Fixme was: FCB      !N$10!+$80,60
        FCB         ~$10|$80,80                                                 ;;Fixme was: FCB      !N$10!+$80,80
        FCB         ~$0F|$80,2*60                                               ;;Fixme was: FCB      !N$0F!+$80,2*60
        FCB         ~$0F&$7F,4*60                                               ;;Fixme was: FCB      !N$0F!.$7F,4*60
SNREPL  FCB     100,~$0B&$7F,90         ;EXTRA MAN                              ;;Fixme was: FCB  100,!N$0B!.$7F,90
SNCLIF  FCB     067,~$19&$7F,90         ;CLIFF DESTROYER                        ;;Fixme was: FCB  067,!N$19!.$7F,90
SNPTED  FCB     066,~$16|$80,15,~$16|$80,15     ;PTERODACTYL DYING SOUND        ;;Fixme was: FCB  066,!N$16!+$80,15,!N$16!+$80,15
        FCB         ~$16|$80,07,~$16|$80,7                                    ;;Fixme was: FCB      !N$16!+$80,07,!N$16!+$80,7
        FCB         ~$16&$7F,90                                                 ;;Fixme was: FCB      !N$16!.$7F,90
SNPTEI  FCB     065,~$24|$80,30,~$25&$7F,30     ;PTERODACTYL INTRODUCTION SCREAM ;;Fixme was: FCB  065,!N$24!+$80,30,!N$25!.$7F,30
SNPTE   FCB     065,~$24&$7F,120                ;PTERODACTYL SCREAM             ;;Fixme was: FCB  065,!N$24!.$7F,120
SNBOUN  FCB     050,~$1C&$7F,60         ;COLLECT BOUNTY                         ;;Fixme was: FCB  050,!N$1C!.$7F,60
SNTROL  FCB     050,~$09&$7F,30         ;CAPTURED BY LAVA TROLL SOUND           ;;Fixme was: FCB  050,!N$09!.$7F,30
SNEGG   FCB     045,~$03&$7F,30         ;PLAYER HITS EGG SOUND                  ;;Fixme was: FCB  045,!N$03!.$7F,30
SNEGGH  FCB     045,~$02&$7F,30         ;EGG HATCHING SOUND                     ;;Fixme was: FCB  045,!N$02!.$7F,30
SNMOUN  FCB     045,~$0C&$7F,30         ;ENEMY MOUNTING THE BIRD                ;;Fixme was: FCB  045,!N$0C!.$7F,30
SNCTHD  FCB     010,~$06&$7F,10         ;CLIFF THUD                             ;;Fixme was: FCB  010,!N$06!.$7F,10
;*
SNECRE  FCB     040,~$07|$80,90,$00,1   ;ENEMY RE-CREATED (TRANSPORTER)         ;;Fixme was: FCB  040,!N$07!+$80,90,$00,1
SNEDIE  FCB     040,~$16&$7F,20         ;ENEMY DIES                             ;;Fixme was: FCB  040,!N$16!.$7F,20
SNELAV  FCB     040,~$0D&$7F,30         ;ENEMY IN LAVA                          ;;Fixme was: FCB  040,!N$0D!.$7F,30
SNETHD  FCB     009,~$08|$80,30,$00,1   ;ENEMIES THUD                           ;;Fixme was: FCB  009,!N$08!+$80,30,$00,1
SNELWU  FCB     006,~$21&$7F,60         ;ENEMIES WING UP SOUND                  ;;Fixme was: FCB  006,!N$21!.$7F,60
SNELWD  FCB     006,~$20&$7F,60         ;ENEMIES WING DOWN SOUND                ;;Fixme was: FCB  006,!N$20!.$7F,60
SNERU1  FCB     006,~$22&$7F,60         ;ENEMY RUNS                             ;;Fixme was: FCB  006,!N$22!.$7F,60
SNERU2  FCB     006,~$23&$7F,60         ;ENEMY RUNS                             ;;Fixme was: FCB  006,!N$23!.$7F,60
SNEMSK  FCB     006,~$26&$7F,60         ;ENEMIES SKIDDING SOUND                 ;;Fixme was: FCB  006,!N$26!.$7F,60
SNEMS2  FCB     006,~$27&$7F,30         ;END OF ENEMIES SKIDDING SOUND          ;;Fixme was: FCB  006,!N$27!.$7F,30
SNEFAL  FCB     006,~$FF&$7F,1          ;ENEMY STARTING TO FALL (SKID STOP)     ;;Fixme was: FCB  006,!N$FF!.$7F,1
;*
SNPDIE  FCB     080,~$16&$7F,20         ;PLAYER DIES                            ;;Fixme was: FCB  080,!N$16!.$7F,20
SNPCR1  FCB     070,~$12|$80,30         ;PLAYER 1 RE-CREATED (TRANSPORTER)      ;;Fixme was: FCB  070,!N$12!+$80,30
        FCB         ~$14|$80,255        ;PLAYER FADING IN  (TRANSPORTER)        ;;Fixme was: FCB      !N$14!+$80,255
        FCB         ~$00&$7F,165                                                ;;Fixme was: FCB      !N$00!.$7F,165
SNPCR2  FCB     070,~$12|$80,30+13      ;PLAYER 2 RE-CREATED (TRANSPORTER)      ;;Fixme was: FCB  070,!N$12!+$80,30+13
        FCB         ~$15|$80,255        ;PLAYER FADING IN  (TRANSPORTER)        ;;Fixme was: FCB      !N$15!+$80,255
        FCB         ~$00&$7F,165-13                                             ;;Fixme was: FCB      !N$00!.$7F,165-13
SNPTREF FCB     070,~$FF&$7F,1          ;PLAYER ABORTED FADING IN  (TRANSPORTER) ;;Fixme was: FCB  070,!N$FF!.$7F,1
SNPLAV  FCB     060,~$0D&$7F,30         ;PLAYER IN LAVA                         ;;Fixme was: FCB  060,!N$0D!.$7F,30
SNPTHD  FCB     020,~$08|$80,30,$00,1   ;AT LEAST 1 PERSON THUD'ED              ;;Fixme was: FCB  020,!N$08!+$80,30,$00,1
SNPLWU  FCB     010,~$21&$7F,90         ;PLAYERS WING UP SOUND                  ;;Fixme was: FCB  010,!N$21!.$7F,90
SNPLWD  FCB     010,~$20&$7F,90         ;PLAYERS WING DOWN SOUND                ;;Fixme was: FCB  010,!N$20!.$7F,90
SNPRU1  FCB     010,~$22&$7F,70         ;PLAYER RUNS                            ;;Fixme was: FCB  010,!N$22!.$7F,70
SNPRU2  FCB     010,~$23&$7F,70         ;PLAYER RUNS                            ;;Fixme was: FCB  010,!N$23!.$7F,70
SNPLSK  FCB     010,~$26&$7F,70         ;PLAYERS SKIDDING SOUND                 ;;Fixme was: FCB  010,!N$26!.$7F,70
SNPLS2  FCB     010,~$27&$7F,40         ;END OF PLAYERS SKIDDING SOUND          ;;Fixme was: FCB  010,!N$27!.$7F,40
SNPFAL  FCB     010,~$FF&$7F,60         ;PLAYER STARTING TO FALL (SKID STOP)    ;;Fixme was: FCB  010,!N$FF!.$7F,60
;*
ENDA1A  EQU     ENDAD1  ;CURRENT END ADDRESS OF $6000 - $8FFF
ENDA2A  EQU     ENDAD2  ;CURRENT END ADDRESS OF $D800 - $DFFF
ENDAD3  EQU     *       ;CURRENT END ADDRESS OF $E6A8 - $EFF0
        IF *-$EFF0 >= 0                                                         ;;Fixme was: IFGE  *-$EFF0
         FCB    $1111   ;ERROR, $E6A8-$EFF0 MODULE IS TOO LONG
        ENDIF
;       END     ;VINIT2